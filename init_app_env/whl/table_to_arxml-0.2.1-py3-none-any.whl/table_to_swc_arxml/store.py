"""源文件缓存：保存已修改但尚未写盘的 ARXML 字节，并按文件版本缓存解析结果。"""

from __future__ import annotations

import logging
import re
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Sequence

from .lib.arxml_backend import ArxmlBackend, ArxmlDocument, DocumentSummary

LOGGER = logging.getLogger(__name__)
SHORT_NAME_PATTERN = re.compile(r"<SHORT-NAME>\s*([^<]*?)\s*</SHORT-NAME>")


def load_bytes(backend: ArxmlBackend, source: bytes) -> tuple[ArxmlDocument, list[str]]:
    """把内存中的 ARXML 字节写入临时文件后交给后端解析。"""

    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".arxml", delete=False) as temporary:
            temporary.write(source)
            temporary_path = Path(temporary.name)
        return backend.load(temporary_path)
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


class SourceStore:
    """保存已修改但尚未写盘的 ARXML 字节，并缓存解析结果。

    新建接口后端口阶段需要能查到它，因此后续读取和解析都走这里的缓存，
    使 dry-run 也能验证完整链路。armodel 同一时间只持有一个文档，因此只复用最近一次加载、
    之后既未加载其他文件也未被修改的文档；组件和接口摘要按文件版本缓存。
    """

    def __init__(self) -> None:
        self._buffers: dict[Path, bytes] = {}
        self._versions: dict[Path, int] = defaultdict(int)
        self._short_name_index: dict[str, list[Path]] | None = None
        self._short_name_index_key: tuple[Path, ...] | None = None
        self._loaded: tuple[Path, int, int, ArxmlDocument] | None = None
        self._summaries: dict[tuple[Path, int], DocumentSummary] = {}
        self._parsed: set[tuple[Path, int]] = set()
        self.definitions: dict[tuple[str, str], tuple[Path, str] | None] = {}

    def read(self, path: Path) -> bytes:
        return self._buffers.get(path, b"") or path.read_bytes()

    def write(self, path: Path, document: bytes) -> None:
        self._buffers[path] = document
        self._versions[path] += 1
        self._short_name_index = None
        self._short_name_index_key = None
        self.definitions.clear()

    def modified(self) -> dict[Path, bytes]:
        return dict(self._buffers)

    def short_name_index(self, arxml_files: Sequence[Path]) -> dict[str, list[Path]]:
        """返回 ``SHORT-NAME`` -> 所在文件列表的反向索引，按需构建并在任何写入后失效。"""

        key = tuple(arxml_files)
        if self._short_name_index is not None and self._short_name_index_key == key:
            return self._short_name_index
        index: dict[str, list[Path]] = defaultdict(list)
        for arxml_file in arxml_files:
            try:
                text = self.read(arxml_file).decode("utf-8-sig")
            except UnicodeDecodeError:
                continue
            # 同一文件里重复出现的简称只记一次，否则同一个定义会被误报为多个定义。
            for short_name in {match.group(1) for match in SHORT_NAME_PATTERN.finditer(text)}:
                index[short_name].append(arxml_file)
        self._short_name_index = dict(index)
        self._short_name_index_key = key
        return self._short_name_index

    def load(self, backend: ArxmlBackend, path: Path) -> ArxmlDocument:
        """按缓存内容加载文档；原始文件的解析诊断只在首次解析时记录一次。"""

        version = self._versions[path]
        if self._loaded is not None:
            loaded_path, loaded_version, generation, document = self._loaded
            if (
                (loaded_path, loaded_version, generation) == (path, version, backend.generation)
                and not document.dirty
            ):
                return document

        key = (path, version)
        first = key not in self._parsed
        self._parsed.add(key)
        pending = " (with pending changes)" if path in self._buffers else ""
        LOGGER.log(logging.INFO if first else logging.DEBUG, "Parsing ARXML%s: %s", pending, path)
        if path in self._buffers:
            document, diagnostics = load_bytes(backend, self._buffers[path])
        else:
            document, diagnostics = backend.load(path)
            if first:
                for diagnostic in diagnostics:
                    LOGGER.warning("%s: %s: %s", backend.name, path, diagnostic)
        self._loaded = (path, version, backend.generation, document)
        return document

    def summary(self, backend: ArxmlBackend, path: Path) -> DocumentSummary:
        """返回文件中全部组件和端口接口的摘要，每个文件版本只解析一次。"""

        key = (path, self._versions[path])
        if key not in self._summaries:
            self._summaries[key] = self.load(backend, path).summarize()
        return self._summaries[key]
