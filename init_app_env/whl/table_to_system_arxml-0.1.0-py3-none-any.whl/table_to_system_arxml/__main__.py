from .table_to_system_arxml import main


raise SystemExit(main())