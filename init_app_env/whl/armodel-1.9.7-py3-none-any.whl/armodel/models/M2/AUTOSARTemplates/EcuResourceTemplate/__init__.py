"""
This module contains classes for representing AUTOSAR hardware element templates
in the EcuResourceTemplate module.

Hardware elements define the physical components of ECUs including pins, pin groups,
and connections between hardware elements.
"""

from typing import TYPE_CHECKING, List, Optional
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.VariationPointCapable import VariationPointCapable

from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import Integer, RefType, String
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Describable, Identifiable, Referrable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ARPackage import ARElement

if TYPE_CHECKING:
    from armodel.models.M2.AUTOSARTemplates.EcuResourceTemplate.HwElementCategory import HwAttributeValue


class HwDescriptionEntity(Referrable):
    """
    This meta-class represents the ability to describe a hardware entity.
    """

    # HwDescriptionEntity method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.1, p.15
    # Spec verified: R23-11
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addHwAttributeValue          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwAttributeValues         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] addHwCategoryRef             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwCategoryRefs            [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getHwTypeRef                 [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHwTypeRef                 [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self, parent, short_name: str):
        if type(self) is HwDescriptionEntity:
            raise TypeError("HwDescriptionEntity is an abstract class.")
        super().__init__(parent, short_name)

        # This aggregation represents a particular hardware attribute value.
        self.hwAttributeValues: List["HwAttributeValue"] = []

        # One of the associations representing one particular category of the hardware entity.
        self.hwCategoryRefs: List[RefType] = []

        # This association is used to assign an optional HwType which contains the common attribute values for all occurences of this HwDescriptionEntity. Note that Hw Types can not be redefined and therefore shall not have a hwType reference.
        self.hwTypeRef: Optional[RefType] = None

    def addHwAttributeValue(self, value: "HwAttributeValue"):
        """
        This aggregation represents a particular hardware attribute value.

        A None value is a no-op and does not add an hwAttributeValue.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwAttributeValues.append(value)
        return self

    def getHwAttributeValues(self) -> List["HwAttributeValue"]:
        """
        This aggregation represents a particular hardware attribute value.

        Returns:
            The list of hwAttributeValues, or an empty list if none are set
        """
        return self.hwAttributeValues

    def addHwCategoryRef(self, value: RefType):
        """
        One of the associations representing one particular category of the hardware entity.

        A None value is a no-op and does not add an hwCategoryRef.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwCategoryRefs.append(value)
        return self

    def getHwCategoryRefs(self) -> List[RefType]:
        """
        One of the associations representing one particular category of the hardware entity.

        Returns:
            The list of hwCategoryRefs, or an empty list if none are set
        """
        return self.hwCategoryRefs

    def getHwTypeRef(self) -> Optional[RefType]:
        """
        This association is used to assign an optional HwType which contains the common attribute values for all occurences of this HwDescriptionEntity. Note that Hw Types can not be redefined and therefore shall not have a hwType reference.

        Returns:
            The hwTypeRef, or None if not set
        """
        return self.hwTypeRef

    def setHwTypeRef(self, value: Optional[RefType]):
        """
        This association is used to assign an optional HwType which contains the common attribute values for all occurences of this HwDescriptionEntity. Note that Hw Types can not be redefined and therefore shall not have a hwType reference.

        A None value is a no-op and does not overwrite an existing hwTypeRef.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwTypeRef = value
        return self


class HwPin(Identifiable, HwDescriptionEntity, VariationPointCapable):
    """
    This meta-class represents the possibility to describe a hardware pin.
    """

    # HwPin method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.7, p.20
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__             [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] createFunctionName   [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] addFunctionName      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getFunctionNames     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setFunctionNames     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getPackagingPinName  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setPackagingPinName  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getPinNumber         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setPinNumber         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent, short_name: str):
        super().__init__(parent, short_name)

        # This attribute describes the function of the pin (e.g. CLK for Clock).
        self.functionNames: List[String] = []

        # This attribute contains the name of the pin according to the packaging of the hardware element (e.g. A03).
        self.packagingPinName: Optional[String] = None

        # This attribute contains the physical pin number.
        self.pinNumber: Optional[Integer] = None

    def createFunctionName(self, value: String) -> String:
        """This attribute describes the function of the pin (e.g. CLK for Clock)."""
        if value not in self.functionNames:
            self.functionNames.append(value)
        return value

    def addFunctionName(self, value: String) -> "HwPin":
        """This attribute describes the function of the pin (e.g. CLK for Clock)."""
        if value not in self.functionNames:
            self.functionNames.append(value)
        return self

    def getFunctionNames(self) -> List[String]:
        """This attribute describes the function of the pin (e.g. CLK for Clock)."""
        return self.functionNames

    def setFunctionNames(self, value: List[String]):
        """This attribute describes the function of the pin (e.g. CLK for Clock). Only sets the value if it is not None."""
        if value is not None:
            self.functionNames = value
        return self

    def getPackagingPinName(self) -> Optional[String]:
        """This attribute contains the name of the pin according to the packaging of the hardware element (e.g. A03)."""
        return self.packagingPinName

    def setPackagingPinName(self, value: String):
        """This attribute contains the name of the pin according to the packaging of the hardware element (e.g. A03). Only sets the value if it is not None."""
        if value is not None:
            self.packagingPinName = value
        return self

    def getPinNumber(self) -> Optional[Integer]:
        """This attribute contains the physical pin number."""
        return self.pinNumber

    def setPinNumber(self, value: Integer):
        """This attribute contains the physical pin number. Only sets the value if it is not None."""
        if value is not None:
            self.pinNumber = value
        return self


class HwPinGroupContent(ARObject):
    """
    Represents the content of a hardware pin group in AUTOSAR.
    This class links individual pins and pin groups together to form complex pin structures.

    Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.6, p.20
    Spec verified: R23-11
    Note: XSD defines atpMixed choice (HW-PIN-GROUP | HW-PIN), not a sequence. Multiplicity 0..1 for both fields.
    """

    # HwPinGroupContent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.6, p.20
    # Spec verified: R23-11
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getHwPin                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] createHwPin                  [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getHwPinGroup                [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] setHwPinGroup                [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    def __init__(self):
        """
        Initializes the HwPinGroupContent with default values.
        """
        super().__init__()

        self.hwPin: Optional[HwPin] = None
        self.hwPinGroup: Optional["HwPinGroup"] = None

    def getHwPin(self) -> Optional[HwPin]:
        """
        Gets the hardware pin in this pin group content.

        Returns:
            HwPin instance, or None if not set
        """
        return self.hwPin

    def createHwPin(self, short_name: str) -> HwPin:
        """
        Creates a new hardware pin in this pin group content.

        Args:
            short_name: The short name for the new hardware pin

        Returns:
            The created HwPin instance
        """
        pin = HwPin(self, short_name)
        self.hwPin = pin
        return pin

    def getHwPinGroup(self) -> Optional["HwPinGroup"]:
        """
        Gets the hardware pin group in this pin group content.

        Returns:
            HwPinGroup instance, or None if not set
        """
        return self.hwPinGroup

    def setHwPinGroup(self, value: "HwPinGroup"):
        """
        Sets the hardware pin group in this pin group content.
        Only sets the value if it is not None.

        Args:
            value: The hardware pin group to set

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinGroup = value
        return self


class HwPinGroup(Identifiable, HwDescriptionEntity, VariationPointCapable):
    """
    This meta-class represents the ability to describe groups of pins which are used to connect hardware elements. This group acts as a bundle of pins. Thereby they allow to describe high level connections. Pin groups can even be nested.
    """

    # HwPinGroup method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.5, p.19
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getHwPinGroupContent    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setHwPinGroupContent    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent, short_name: str):
        super().__init__(parent, short_name)

        # This aggregation describes the contained pins/pin groups.
        self.hwPinGroupContent: Optional[HwPinGroupContent] = None

    def getHwPinGroupContent(self) -> Optional[HwPinGroupContent]:
        """
        This aggregation describes the contained pins/pin groups.
        """
        return self.hwPinGroupContent

    def setHwPinGroupContent(self, value: HwPinGroupContent):
        """
        This aggregation describes the contained pins/pin groups.
        A None value is a no-op and does not overwrite an existing hwPinGroupContent.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinGroupContent = value
        return self


class HwPinConnector(Describable, VariationPointCapable):
    """
    This meta-class represents the ability to connect two pins.

    [constr_11004] Multiplicity of HwPinConnector . hwPin: For each HwPinConnector there shall exist exactly 2 references in the role hwPin.
    """

    # HwPinConnector method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.10, p.22
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addHwPinRef                  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwPinRefs                 [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self):
        super().__init__()

        # This association connects two hardware pins.
        self.hwPinRefs: List[RefType] = []

    def addHwPinRef(self, value: RefType):
        """
        This association connects two hardware pins.

        A None value is a no-op and does not add an hwPinRef.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinRefs.append(value)
        return self

    def getHwPinRefs(self) -> List[RefType]:
        """
        This association connects two hardware pins.

        Returns:
            The list of hwPinRefs, or an empty list if none are set
        """
        return self.hwPinRefs


class HwPinGroupConnector(Describable, VariationPointCapable):
    """
    This meta-class represents the ability to connect two pin groups.

    [constr_11003] Multiplicity of HwPinGroupConnector . hwPinGroup: For each HwPinGroupConnector there shall exist exactly 2 references in the role hwPinGroup.
    """

    # HwPinGroupConnector method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.9, p.22
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addHwPinConnection           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwPinConnections          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] addHwPinGroupRef             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwPinGroupRefs            [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self):
        super().__init__()

        # This represents one particular connection between two hardware pins. The connected pins shall match the connection provided by the parent hwPinGroup Connection.
        self.hwPinConnections: List[HwPinConnector] = []

        # This association connects two hardware pin groups.
        self.hwPinGroupRefs: List[RefType] = []

    def addHwPinConnection(self, value: HwPinConnector):
        """
        This represents one particular connection between two hardware pins. The connected pins shall match the connection provided by the parent hwPinGroup Connection.

        A None value is a no-op and does not add an hwPinConnection.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinConnections.append(value)
        return self

    def getHwPinConnections(self) -> List[HwPinConnector]:
        """
        This represents one particular connection between two hardware pins. The connected pins shall match the connection provided by the parent hwPinGroup Connection.

        Returns:
            The list of hwPinConnections, or an empty list if none are set
        """
        return self.hwPinConnections

    def addHwPinGroupRef(self, value: RefType):
        """
        This association connects two hardware pin groups.

        A None value is a no-op and does not add an hwPinGroupRef.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinGroupRefs.append(value)
        return self

    def getHwPinGroupRefs(self) -> List[RefType]:
        """
        This association connects two hardware pin groups.

        Returns:
            The list of hwPinGroupRefs, or an empty list if none are set
        """
        return self.hwPinGroupRefs


class HwElementConnector(Describable, VariationPointCapable):
    """
    This meta-class represents the ability to connect two hardware elements. The details of the connection can be refined by hwPinGroupConnection.

    [constr_11002] Multiplicity of HwElementConnector . hwElement: For each HwElementConnector there shall exist exactly 2 references in the role hwElement.
    """

    # HwElementConnector method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.8, p.21
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addHwElementRef              [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwElementRefs             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] addHwPinConnection           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwPinConnections          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] addHwPinGroupConnection      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHwPinGroupConnections     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self):
        super().__init__()

        # This association connects two hardware elements.
        self.hwElementRefs: List[RefType] = []

        # This represents one particular connection between two hardware pins. This connection shall be used if pin-to-pin-connection is to be described but no description of the connection between the hierarchical composition of HwPinGroups (using HwPinGroupConnector) is required.
        self.hwPinConnections: List[HwPinConnector] = []

        # This represents one particular connection between two hardware pin groups.
        self.hwPinGroupConnections: List[HwPinGroupConnector] = []

    def addHwElementRef(self, value: RefType):
        """
        This association connects two hardware elements.

        A None value is a no-op and does not add an hwElementRef.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwElementRefs.append(value)
        return self

    def getHwElementRefs(self) -> List[RefType]:
        """
        This association connects two hardware elements.

        Returns:
            The list of hwElementRefs, or an empty list if none are set
        """
        return self.hwElementRefs

    def addHwPinConnection(self, value: HwPinConnector):
        """
        This represents one particular connection between two hardware pins. This connection shall be used if pin-to-pin-connection is to be described but no description of the connection between the hierarchical composition of HwPinGroups (using HwPinGroupConnector) is required.

        A None value is a no-op and does not add an hwPinConnection.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinConnections.append(value)
        return self

    def getHwPinConnections(self) -> List[HwPinConnector]:
        """
        This represents one particular connection between two hardware pins. This connection shall be used if pin-to-pin-connection is to be described but no description of the connection between the hierarchical composition of HwPinGroups (using HwPinGroupConnector) is required.

        Returns:
            The list of hwPinConnections, or an empty list if none are set
        """
        return self.hwPinConnections

    def addHwPinGroupConnection(self, value: HwPinGroupConnector):
        """
        This represents one particular connection between two hardware pin groups.

        A None value is a no-op and does not add an hwPinGroupConnection.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwPinGroupConnections.append(value)
        return self

    def getHwPinGroupConnections(self) -> List[HwPinGroupConnector]:
        """
        This represents one particular connection between two hardware pin groups.

        Returns:
            The list of hwPinGroupConnections, or an empty list if none are set
        """
        return self.hwPinGroupConnections


class HwElement(ARElement, HwDescriptionEntity):
    """
    This represents the ability to describe Hardware Elements on an instance level. The particular types of hardware are distinguished by the category. This category determines the applicable attributes. The possible categories and attributes are defined in HwCategory.
    """

    # HwElement method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUResourceTemplate.pdf, Table 2.4, p.18
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] addHwElementConnection  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getHwElementConnections [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] createHwPinGroup        [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getHwPinGroups          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] addNestedElementRef     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getNestedElementRefs    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11

    def __init__(self, parent, short_name: str):
        super().__init__(parent, short_name)

        # This represents one particular connection between two hardware elements.
        self.hwElementConnections: List[HwElementConnector] = []

        # This aggregation is used to describe the connection facilities of a hardware element. Note that hardware element has no pins but only pingroups.
        self.hwPinGroups: List[HwPinGroup] = []

        # This association is used to establish hierarchies of hw elements. Note that one particular HwElement can be target of this association only once. I.e. multiple instantiation of the same HwElement is not supported (at any hierarchy level).
        self.nestedElementRefs: List[RefType] = []

    def getHwElementConnections(self) -> List[HwElementConnector]:
        """
        This represents one particular connection between two hardware elements.

        Returns:
            The list of hwElementConnections, or an empty list if none are set
        """
        return self.hwElementConnections

    def addHwElementConnection(self, value: HwElementConnector):
        """
        This represents one particular connection between two hardware elements.

        A None value is a no-op and does not add an hwElementConnection.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.hwElementConnections.append(value)
        return self

    def getHwPinGroups(self) -> List[HwPinGroup]:
        """
        This aggregation is used to describe the connection facilities of a hardware element. Note that hardware element has no pins but only pingroups.

        Returns:
            The list of hwPinGroups, or an empty list if none are set
        """
        return self.hwPinGroups

    def createHwPinGroup(self, short_name: str) -> HwPinGroup:
        """
        Creates and adds a new hardware pin group to this element.

        Args:
            short_name: The short name for the new hardware pin group

        Returns:
            The created HwPinGroup instance
        """
        if not any(pin_group.getShortName() == short_name for pin_group in self.hwPinGroups):
            pin_group = HwPinGroup(self, short_name)
            self.hwPinGroups.append(pin_group)
        return next(pin_group for pin_group in self.hwPinGroups if pin_group.getShortName() == short_name)

    def getNestedElementRefs(self) -> List[RefType]:
        """
        This association is used to establish hierarchies of hw elements. Note that one particular HwElement can be target of this association only once. I.e. multiple instantiation of the same HwElement is not supported (at any hierarchy level).

        Returns:
            The list of nestedElementRefs, or an empty list if none are set
        """
        return self.nestedElementRefs

    def addNestedElementRef(self, value: RefType):
        """
        This association is used to establish hierarchies of hw elements. Note that one particular HwElement can be target of this association only once. I.e. multiple instantiation of the same HwElement is not supported (at any hierarchy level).

        A None value is a no-op and does not add a nestedElementRef.

        Returns:
            self for method chaining
        """
        if value is not None:
            self.nestedElementRefs.append(value)
        return self
