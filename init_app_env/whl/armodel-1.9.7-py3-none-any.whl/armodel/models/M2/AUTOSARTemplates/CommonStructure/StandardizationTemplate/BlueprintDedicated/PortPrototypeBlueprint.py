"""
This module defines classes for port prototype blueprints in AUTOSAR standardization templates.

Port prototype blueprints provide a way to define standard templates for port prototypes
that can be reused across different AUTOSAR software components. This is particularly useful
for standardization and blueprint-based development approaches in AUTOSAR architecture.

Classes:
    PortPrototypeBlueprintInitValue: Represents initial value specifications for port prototype blueprints
    PortPrototypeBlueprint: Defines a blueprint for port prototypes with communication specifications
    PortPrototypeBlueprintMapping: Maps a PortPrototypeBlueprint to a PortProtoype
"""

from typing import List, Optional

from armodel.models.M2.AUTOSARTemplates.CommonStructure import ValueSpecification
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.AbstractBlueprintStructure import (
    AtpBlueprintMapping,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.AbstractStructure import AtpStructureElement
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import RefType
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Communication import PPortComSpec, RPortComSpec


class PortPrototypeBlueprintInitValue(ARObject):
    """
    Represents an initial value specification for a port prototype blueprint.
    This class defines the initial value and associated data prototype reference
    for a specific port prototype blueprint element.
    """

    # PortPrototypeBlueprintInitValue method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [x] test
    # [x] getDataPrototypeRef          [x] impl  [x] docstring  [x] test
    # [x] setDataPrototypeRef          [x] impl  [x] docstring  [x] test
    # [x] getValue                     [x] impl  [x] docstring  [x] test
    # [x] setValue                     [x] impl  [x] docstring  [x] test

    def __init__(self):
        super().__init__()

        self.dataPrototypeRef: RefType = None
        self.value: ValueSpecification = None

    def getDataPrototypeRef(self) -> RefType:
        """
        Gets the data prototype reference for this initial value specification.

        Returns:
            Reference to the data prototype
        """
        return self.dataPrototypeRef

    def setDataPrototypeRef(self, value: RefType):
        """
        Sets the data prototype reference for this initial value specification.

        Args:
            value: Reference to the data prototype

        Returns:
            Self instance for method chaining
        """
        if value is not None:
            self.dataPrototypeRef = value
        return self

    def getValue(self) -> ValueSpecification:
        """
        Gets the value specification for this initial value.

        Returns:
            The value specification
        """
        return self.value

    def setValue(self, value: ValueSpecification):
        """
        Sets the value specification for this initial value.

        Args:
            value: The value specification

        Returns:
            Self instance for method chaining
        """
        if value is not None:
            self.value = value
        return self


class PortPrototypeBlueprint(AtpStructureElement):
    """
    Defines a blueprint for port prototypes in AUTOSAR standardization templates.
    This class provides a template for defining port prototypes that can be reused
    across different software components, helping to standardize port configurations.
    """

    # PortPrototypeBlueprint method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [x] test
    # [x] getInitValues                [x] impl  [x] docstring  [x] test
    # [x] setInitValues                [x] impl  [x] docstring  [x] test
    # [x] getInterfaceRef              [x] impl  [x] docstring  [x] test
    # [x] setInterfaceRef              [x] impl  [x] docstring  [x] test
    # [x] getProvidedComSpecs          [x] impl  [x] docstring  [x] test
    # [x] setProvidedComSpecs          [x] impl  [x] docstring  [x] test
    # [x] getRequiredComSpecs          [x] impl  [x] docstring  [x] test
    # [x] setRequiredComSpecs          [x] impl  [x] docstring  [x] test

    def __init__(self, parent, short_name):
        super().__init__(parent, short_name)

        self.initValues: List[PortPrototypeBlueprintInitValue] = []
        self.interfaceRef: RefType = None
        self.providedComSpecs: List[PPortComSpec] = []
        self.requiredComSpecs: List[RPortComSpec] = []

    def getInitValues(self) -> List[PortPrototypeBlueprintInitValue]:
        """
        Gets the list of initial value specifications for this port prototype blueprint.

        Returns:
            List of initial value specifications
        """
        return self.initValues

    def setInitValues(self, value: List[PortPrototypeBlueprintInitValue]):
        """
        Sets the list of initial value specifications for this port prototype blueprint.

        Args:
            value: List of initial value specifications

        Returns:
            Self instance for method chaining
        """
        if value is not None:
            self.initValues = value
        return self

    def getInterfaceRef(self) -> RefType:
        """
        Gets the interface reference for this port prototype blueprint.

        Returns:
            Reference to the interface
        """
        return self.interfaceRef

    def setInterfaceRef(self, value: RefType):
        """
        Sets the interface reference for this port prototype blueprint.

        Args:
            value: Reference to the interface

        Returns:
            Self instance for method chaining
        """
        if value is not None:
            self.interfaceRef = value
        return self

    def getProvidedComSpecs(self) -> List[PPortComSpec]:
        """
        Gets the list of provided communication specifications for this port prototype blueprint.

        Returns:
            List of provided communication specifications
        """
        return self.providedComSpecs

    def setProvidedComSpecs(self, value: List[PPortComSpec]):
        """
        Sets the list of provided communication specifications for this port prototype blueprint.

        Args:
            value: List of provided communication specifications

        Returns:
            Self instance for method chaining
        """
        if value is not None:
            self.providedComSpecs = value
        return self

    def getRequiredComSpecs(self) -> List[RPortComSpec]:
        """
        Gets the list of required communication specifications for this port prototype blueprint.

        Returns:
            List of required communication specifications
        """
        return self.requiredComSpecs

    def setRequiredComSpecs(self, value: List[RPortComSpec]):
        """
        Sets the list of required communication specifications for this port prototype blueprint.

        Args:
            value: List of required communication specifications

        Returns:
            Self instance for method chaining
        """
        if value is not None:
            self.requiredComSpecs = value
        return self


class PortPrototypeBlueprintMapping(AtpBlueprintMapping):
    """
    This meta-class represents the ability to map a PortPrototypeBlueprint to a PortProtoype of which one acts as the blueprint for the other.
    """

    # PortPrototypeBlueprintMapping method parity checklist:
    # Spec: AUTOSAR_00052.xsd, complexType PORT-PROTOTYPE-BLUEPRINT-MAPPING l.93034, group l.92997 (XSD-only; no own table in repo corpus; atp.Status="removed")
    # XSD verified: AUTOSAR_00052.xsd
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                        [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getPortPrototypeBlueprintRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setPortPrototypeBlueprintRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getDerivedPortPrototypeRef      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setDerivedPortPrototypeRef      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # The PortPrototypeBlueprint in the context of the mapping.
        self.portPrototypeBlueprintRef: Optional[RefType] = None

        # The PortPrototype in the context of the mapping.
        self.derivedPortPrototypeRef: Optional[RefType] = None

    def getPortPrototypeBlueprintRef(self) -> Optional[RefType]:
        """
        The PortPrototypeBlueprint in the context of the mapping.
        """
        return self.portPrototypeBlueprintRef

    def setPortPrototypeBlueprintRef(self, value: Optional[RefType]) -> "PortPrototypeBlueprintMapping":
        """
        The PortPrototypeBlueprint in the context of the mapping. A None value is a no-op and is not set.
        """
        if value is not None:
            self.portPrototypeBlueprintRef = value
        return self

    def getDerivedPortPrototypeRef(self) -> Optional[RefType]:
        """
        The PortPrototype in the context of the mapping.
        """
        return self.derivedPortPrototypeRef

    def setDerivedPortPrototypeRef(self, value: Optional[RefType]) -> "PortPrototypeBlueprintMapping":
        """
        The PortPrototype in the context of the mapping. A None value is a no-op and is not set.
        """
        if value is not None:
            self.derivedPortPrototypeRef = value
        return self
