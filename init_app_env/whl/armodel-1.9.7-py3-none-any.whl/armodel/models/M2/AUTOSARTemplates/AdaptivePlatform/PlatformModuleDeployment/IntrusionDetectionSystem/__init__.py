from abc import ABC
from typing import Any, List, Optional

from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Identifiable

__all__ = ["IdsPlatformInstantiation", "IdsmModuleInstantiation"]


class IdsPlatformInstantiation(Identifiable, ABC):
    """
    This meta-class acts as an abstract base class for platform modules that
    implement the intrusion detection system. Tags: atp.Status=candidate

    Sources:
      - AUTOSAR_FO_TPS_SecurityExtractTemplate.pdf (Page 63, Foundation R23-11)
    """

    # IdsPlatformInstantiation method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [ ] test
    # [ ] getNetworks                  [x] impl  [ ] docstring  [ ] test
    # [ ] setNetworks                  [x] impl  [ ] docstring  [ ] test
    # [ ] addNetwork                   [x] impl  [x] docstring  [ ] test
    # [ ] getTimeBases                 [x] impl  [ ] docstring  [ ] test
    # [ ] setTimeBases                 [x] impl  [ ] docstring  [ ] test

    def __init__(self, parent: ARObject, short_name: str):
        if type(self) is IdsPlatformInstantiation:
            raise TypeError("IdsPlatformInstantiation is an abstract class.")
        super().__init__(parent, short_name)

        # Type: PlatformModule.
        # This association contains the network configuration that shall be applied to
        # an instance of an IDS entity.
        # atp.
        # Status=candidate.
        self.networks: List[Any] = []
        # Type: TimeBaseResource.
        # This reference identifies the applicable time base atpVariation.
        self.timeBases: Optional[Any] = None

    def getNetworks(self) -> List[Any]:
        return self.networks

    def setNetworks(self, value: List[Any]) -> "IdsPlatformInstantiation":
        self.networks = value
        return self

    def addNetwork(self, value: Any) -> "IdsPlatformInstantiation":
        """Adds a value to the networks list."""
        self.networks.append(value)
        return self

    def getTimeBases(self) -> Any:
        return self.timeBases

    def setTimeBases(self, value: Any) -> "IdsPlatformInstantiation":
        self.timeBases = value
        return self


class IdsmModuleInstantiation(IdsPlatformInstantiation):
    """
    This meta-class defines the attributes for the IdsM configuration on a
    specific machine. Tags: atp.Status=candidate

    Sources:
      - AUTOSAR_FO_TPS_SecurityExtractTemplate.pdf (Page 63, Foundation R23-11)
    """

    # IdsmModuleInstantiation method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [x] test

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)
