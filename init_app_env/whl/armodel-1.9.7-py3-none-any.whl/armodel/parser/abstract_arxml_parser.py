import logging
import re
import xml.etree.ElementTree as ET
from abc import ABC
from typing import List, Optional

from colorama import Fore

from armodel.models.M2.AUTOSARTemplates.AutosarTopLevelStructure import AUTOSAR
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import (
    ARLiteral,
    ARNumerical,
    ARType,
    Boolean,
    DateTime,
    Float,
    Identifier,
    Integer,
    IntervalTypeEnum,
    Limit,
    Numerical,
    PositiveInteger,
    RefType,
    RevisionLabelString,
    String,
    TimeValue,
    UriString,
    VerbatimString,
)


class AbstractARXMLParser(ABC):
    """
    Abstract base class for ARXML parsers providing common XML parsing
    utilities, namespace handling, and error/warning management.
    """

    def __init__(self, options=None) -> None:
        if type(self) is AbstractARXMLParser:
            raise TypeError("AbstractArxmlParser is an abstract class.")

        self.nsmap = {"xmlns": "http://autosar.org/schema/r4.0"}
        self.options = {}
        self.options["warning"] = False
        self.logger = logging.getLogger()

        self._processOptions(options=options)

    def getTagName(self, tag: ET.Element) -> str:
        if isinstance(tag, ET.Element):
            tag = tag.tag
        if isinstance(tag, str):
            return tag.replace("{%s}" % self.nsmap["xmlns"], "")
        self.raiseError("Invalid Tag type <%s>" % type(tag))

    def _processOptions(self, options):
        if options:
            if "warning" in options:
                self.options["warning"] = options["warning"]

    def raiseError(self, error_msg):
        if self.options["warning"] is True:
            self.logger.error(Fore.RED + error_msg + Fore.WHITE)
        else:
            raise ValueError(error_msg)

    def notImplemented(self, error_msg):
        if self.options["warning"] is True:
            self.logger.error(Fore.RED + error_msg + Fore.WHITE)
        else:
            raise NotImplementedError(error_msg)

    def raiseWarning(self, error_msg):
        self.logger.warning(error_msg)

    def getPureTagName(self, tag):
        return re.sub(r"\{[\w:\/.]+\}(\w+)", r"\1", tag)

    """
    def getChildElement(self, short_name: str, element: ET.Element, key: str) -> str:
        child_element = element.find("./xmlns:%s" % key, self.nsmap)
        if (child_element is not None):
            return child_element.text
        self._raiseError("The attribute %s of <%s> has not been defined" % (key, short_name))
    """
    """
    def getChildElementOptionalValue(self, element: ET.Element, key: str) -> str:
        child_element = element.find("./xmlns:%s" % key, self.nsmap)
        if (child_element is not None):
            if child_element.text is None:
                return ""
            return child_element.text
        return None
    """

    def getChildElementLiteral(self, short_name: str, element: ET.Element, key: str) -> ARLiteral:
        child_element = self.find(element, key)
        if child_element is not None:
            literal = ARLiteral()
            self.readARType(child_element, literal)
            literal._value = child_element.text
            return literal
        self.raiseError("The attribute %s of <%s> has not been defined" % (key, short_name))

    def getChildElementLiteralValueList(self, element: ET.Element, key: str) -> List[ARLiteral]:
        child_elements = self.findall(element, key)
        results = []
        for child_element in child_elements:
            literal = ARLiteral()
            literal.setValue(child_element.text)
            results.append(literal)
        return results

    def getChildElementOptionalLiteral(self, element: ET.Element, key: str) -> Optional[ARLiteral]:
        child_element = self.find(element, key)
        literal = None
        if child_element is not None:
            # self.logger.debug("getChildElementOptionalLiteral : %s" % child_element.text)
            literal = ARLiteral()
            self.readARType(child_element, literal)
            # Patch for empty element <USED-CODE-GENERATOR></USED-CODE-GENERATOR>
            if child_element.text is None:
                literal.setValue("")
            else:
                literal.setValue(child_element.text)
        return literal

    def getChildElementOptionalVerbatimString(self, element: ET.Element, key: str) -> VerbatimString:
        child_element = self.find(element, key)
        literal = None
        if child_element is not None:
            literal = VerbatimString()
            self.readARType(child_element, literal)
            if child_element.text is None:
                literal.setValue("")
            else:
                literal.setValue(child_element.text)
        return literal

    def getChildElementOptionalIdentifier(self, element: ET.Element, key: str) -> Identifier:
        child_element = self.find(element, key)
        identifier = None
        if child_element is not None:
            identifier = Identifier()
            self.readARType(child_element, identifier)
            # Patch for empty element <USED-CODE-GENERATOR></USED-CODE-GENERATOR>
            if child_element.text is None:
                identifier.setValue("")
            else:
                identifier.setValue(child_element.text)
        return identifier

    def getChildElementOptionalRevisionLabelString(self, element: ET.Element, key: str) -> RevisionLabelString:
        child_element = self.find(element, key)
        literal = None
        if (child_element is not None) and (child_element.text is not None):
            # self.logger.debug("getChildElementOptionalRevisionLabelString : %s" % child_element.text)
            m = re.match(r"[0-9]+\.[0-9]+\.[0-9]+([\._;].*)?", child_element.text)
            if not m:
                raise ValueError("Invalid RevisionLabelString <%s>" % child_element.text)
            literal = RevisionLabelString()
            self.readARType(child_element, literal)
            # Patch for empty element <USED-CODE-GENERATOR></USED-CODE-GENERATOR>
            if child_element.text is None:
                literal.setValue("")
            else:
                literal.setValue(child_element.text)
        return literal

    def getChildElementOptionalDateTime(self, element: ET.Element, key: str) -> DateTime:
        return self.getChildElementOptionalLiteral(element, key)

    def getChildElementOptionalString(self, element: ET.Element, key: str) -> String:
        child_element = self.find(element, key)
        literal = None
        if child_element is not None:
            literal = String()
            self.readARType(child_element, literal)
            if child_element.text is None:
                literal.setValue("")
            else:
                literal.setValue(child_element.text)
        return literal

    def getChildElementOptionalUriString(self, element: ET.Element, key: str) -> UriString:
        child_element = self.find(element, key)
        literal = None
        if child_element is not None:
            literal = UriString()
            self.readARType(child_element, literal)
            literal.setValue(child_element.text if child_element.text is not None else "")
        return literal

    def _convertStringToBooleanValue(self, value: str) -> bool:
        if value == "true":
            return True
        return False

    def getChildElementOptionalFloatValue(self, element: ET.Element, key: str) -> Float:
        child_element = self.find(element, key)
        float_value = None
        if (child_element is not None) and (child_element.text is not None):
            float_value = Float()
            self.readARType(child_element, float_value)
            float_value.setValue(child_element.text)
        return float_value

    def getChildElementFloatValueList(self, element: ET.Element, key: str) -> Float:
        child_elements = self.findall(element, key)
        results = []
        for child_element in child_elements:
            float_value = Float()
            float_value.setValue(child_element.text)
            results.append(float_value)
        return results

    def getChildElementNumericalList(self, element: ET.Element, key: str) -> List[Numerical]:
        child_elements = self.findall(element, key)
        results = []
        for child_element in child_elements:
            numerical_value = Numerical()
            self.readARType(child_element, numerical_value)
            if child_element.text is not None:
                numerical_value.setValue(child_element.text)
            results.append(numerical_value)
        return results

    def getChildElementOptionalTimeValue(self, element: ET.Element, key: str) -> TimeValue:
        child_element = self.find(element, key)
        time_value = None
        if (child_element is not None) and (child_element.text is not None):
            time_value = TimeValue()
            time_value.setValue(child_element.text)
        return time_value

    """
    def getChildElementBooleanValue(self, short_name: str, element: ET.Element, key: str) -> Boolean:
        literal = self.getChildElementLiteral(short_name, element, key)
        bool_value = Boolean()
        bool_value.timestamp = literal.timestamp
        bool_value.value = self._convertStringToBooleanValue(literal._value)
        return bool_value
    """

    def getChildElementOptionalBooleanValue(self, element: ET.Element, key: str) -> Boolean:
        literal = self.getChildElementOptionalLiteral(element, key)
        if literal is None:
            return None
        if literal.getText() == "":
            return None
        bool_value = Boolean()
        bool_value.timestamp = literal.timestamp
        bool_value.setValue(literal.getText())
        return bool_value

    def _convertStringToNumberValue(self, value) -> int:
        m = re.match(r"0x([0-9a-f]+)", value, re.I)
        if m:
            return int(m.group(1), 16)
        return int(value)

    def getChildElementOptionalNumericalValue(self, element: ET.Element, key: str) -> ARNumerical:
        child_element = self.find(element, key)
        if child_element is None:
            return None
        numerical = ARNumerical()
        self.readARType(child_element, numerical)
        if "SHORT-LABEL" in child_element.attrib:
            numerical.setShortLabel(child_element.attrib["SHORT-LABEL"])
        numerical.setValue(child_element.text)
        return numerical

    def getChildElementOptionalNumerical(self, element: ET.Element, key: str) -> Numerical:
        child_element = self.find(element, key)
        numerical_value = None
        if child_element is not None:
            numerical_value = Numerical()
            self.readARType(child_element, numerical_value)
            if child_element.text is not None:
                numerical_value.setValue(child_element.text)
        return numerical_value

    def getChildElementOptionalIntegerValue(self, element: ET.Element, key: str) -> Integer:
        child_element = self.find(element, key)
        if child_element is None:
            return None
        numerical = Integer()
        self.readARType(child_element, numerical)
        numerical.setValue(child_element.text)
        return numerical

    def getChildElementOptionalPositiveInteger(self, element: ET.Element, key: str) -> PositiveInteger:
        child_element = self.find(element, key)
        if child_element is None:
            return None
        if child_element.text is None:
            return None
        numerical = PositiveInteger()
        self.readARType(child_element, numerical)
        numerical.setValue(child_element.text)
        if numerical.getValue() < 0:
            raise ValueError("Invalid PositiveInteger <%s>" % child_element.text)
        return numerical

    def getChildElementNumericalValueList(self, element: ET.Element, key: str) -> List[ARNumerical]:
        child_elements = self.findall(element, key)
        results = []
        for child_element in child_elements:
            numerical = ARNumerical()
            numerical.setValue(child_element.text)
            results.append(numerical)
        return results

    def getChildLimitElement(self, element: ET.Element, key: str) -> Limit:
        child_element = self.find(element, key)
        if child_element is not None:
            limit = Limit()
            self.readARObject(child_element, limit)
            if "INTERVAL-TYPE" in child_element.attrib:
                limit.setIntervalType(IntervalTypeEnum().setValue(child_element.attrib["INTERVAL-TYPE"]))
            else:
                limit.setIntervalType(None)
            limit.setValue(child_element.text)
            return limit
        return None

    def _getChildElementRefTypeDestAndValue(self, element: ET.Element) -> RefType:
        ref = RefType()
        if "BASE" in element.attrib:
            ref.setBase(element.attrib["BASE"])
        if "DEST" in element.attrib:
            ref.setDest(element.attrib["DEST"])
        ref.setValue(element.text)
        return ref

    def getChildElementRefType(self, short_name: str, element: ET.Element, key: str) -> RefType:
        child_element = self.find(element, key)
        if child_element is not None:
            return self._getChildElementRefTypeDestAndValue(child_element)
        self.raiseError("The attribute %s of <%s> has not been defined" % (key, short_name))

    def getChildElementOptionalRefType(self, element: ET.Element, key: str) -> RefType:
        child_element = self.find(element, key)
        if child_element is not None:
            return self._getChildElementRefTypeDestAndValue(child_element)
        return None

    def getChildElementRefTypeList(self, element: ET.Element, key: str) -> List[RefType]:
        child_elements = self.findall(element, key)
        results = []
        for child_element in child_elements:
            ref = RefType()
            if "BASE" in child_element.attrib:
                ref.setBase(child_element.attrib["BASE"])
            if "DEST" in child_element.attrib:
                ref.setDest(child_element.attrib["DEST"])
            ref.setValue(child_element.text)
            results.append(ref)
        return results

    def readElementOptionalAttrib(self, element: ET.Element, key: str) -> str:
        if key in element.attrib:
            return element.attrib[key]
        return None

    def readARObject(self, element: ET.Element, ar_object: ARObject):
        checksum = self.readElementOptionalAttrib(element, "S")  # read the checksum
        if checksum is not None:
            checksum_value = String()
            checksum_value.setValue(checksum)
            ar_object.setChecksum(checksum_value)
        timestamp = self.readElementOptionalAttrib(element, "T")  # read the timestamp
        if timestamp is not None:
            timestamp_value = DateTime()
            timestamp_value.setValue(timestamp)
            ar_object.setTimestamp(timestamp_value)

    def readARType(self, element: ET.Element, ar_type: ARType):
        # The ARType hierarchy (AUTOSAR primitive types) carries the timestamp as a
        # plain string. Per the XSD (AUTOSAR_00052.xsd, AR-OBJECT attributeGroup)
        # primitives carry only S/T — the uuid attribute lives in the IDENTIFIABLE
        # attributeGroup and is read by readIdentifiable (see the uuid move in
        # docs/plan/sync-todo/Group1.md).
        ar_type.timestamp = self.readElementOptionalAttrib(element, "T")

    def getAUTOSARInfo(self, element: ET.Element, document: AUTOSAR):
        key = "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation"
        if key in element.attrib:
            document.schema_location = element.attrib[key]

        self.logger.debug("schemaLocation %s" % document.schema_location)

    def detectNamespace(self, element: ET.Element):
        """Detect the AUTOSAR namespace of the document from the root element tag.

        Supports the R4.x namespace (http://autosar.org/schema/r4.0) and the
        legacy R3.x namespace (http://autosar.org).
        """
        tag = element.tag
        if isinstance(tag, str) and tag.startswith("{"):
            self.nsmap = {"xmlns": tag[1 : tag.index("}")]}

    def getShortName(self, element: ET.Element) -> str:
        child_element = self.find(element, "SHORT-NAME")
        if child_element is None:
            raise ValueError("Short Name is required")
        return child_element.text

    def convert_find_key(self, key: str) -> str:
        keys = key.split("/")
        for idx, item in enumerate(keys):
            if item != "*" and item != ".":
                keys[idx] = "xmlns:%s" % item
        return "/".join(keys)

    def find(self, parent: ET.Element, key: str) -> ET.Element:
        return parent.find(self.convert_find_key(key), self.nsmap)

    def findall(self, parent: ET.Element, key: str) -> List[ET.Element]:
        return parent.findall(self.convert_find_key(key), self.nsmap)
