import os
import xml.etree.ElementTree as ET
from typing import List, Optional, Union

from armodel.models.M2.AUTOSARTemplates.AutosarTopLevelStructure import AUTOSAR, FileInfoComment
from armodel.models.M2.AUTOSARTemplates.AdaptivePlatform.PlatformModuleDeployment.CryptoDeployment import (
    CryptoKeySlot,
    CryptoKeySlotAllowedModification,
    CryptoKeySlotContentAllowedUsage,
    CryptoKeySlotTypeEnum,
    CryptoObjectTypeEnum,
)
from armodel.models.M2.AUTOSARTemplates.AdaptivePlatform.PlatformModuleDeployment.Firewall import (
    DataLinkLayerRule,
    DdsRule,
    DoIpRule,
    FirewallActionEnum,
    FirewallRule,
    FirewallRuleProps,
    IcmpRule,
    Ipv4Rule,
    Ipv6Rule,
    NetworkLayerRule,
    PayloadBytePatternRule,
    PayloadBytePatternRulePart,
    SomeipProtocolRule,
    SomeipSdRule,
    StateDependentFirewall,
    TcpRule,
    TransportLayerRule,
    UdpRule,
)
from armodel.models.M2.AUTOSARTemplates.AdaptivePlatform.PlatformModuleDeployment.AdaptiveModuleImplementation import (
    PlatformModuleEthernetEndpointConfiguration,
)
from armodel.models.M2.AUTOSARTemplates.AdaptivePlatform.PlatformModuleDeployment.IntrusionDetectionSystem import (
    IdsPlatformInstantiation,
    IdsmModuleInstantiation,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.AbstractBlueprintStructure import (
    AtpBlueprintMapping,
    LifeCycleState,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.BlueprintDedicated.PortInterfaceBlueprint import (
    PortInterfaceBlueprintMapping,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.BlueprintDedicated.PortPrototypeBlueprint import (
    PortPrototypeBlueprintMapping,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.BlueprintMapping import (
    BlueprintMapping,
    BlueprintMappingSet,
)
from armodel.models.M2.AUTOSARTemplates.BswModuleTemplate.BswBehavior import (
    BswApiOptions,
    BswAsynchronousServerCallPoint,
    BswAsynchronousServerCallResultPoint,
    BswAsynchronousServerCallReturnsEvent,
    BswBackgroundEvent,
    BswCalledEntity,
    BswClientPolicy,
    BswDataReceivedEvent,
    BswDataReceptionPolicy,
    BswDataSendPolicy,
    BswDirectCallPoint,
    BswExclusiveAreaPolicy,
    BswExternalTriggerOccurredEvent,
    BswInternalBehavior,
    BswInternalTriggeringPoint,
    BswInternalTriggeringPointPolicy,
    BswInternalTriggerOccurredEvent,
    BswInterruptCategory,
    BswInterruptEntity,
    BswModeManagerErrorEvent,
    BswModeReceiverPolicy,
    BswModeSenderPolicy,
    BswModeSwitchAckRequest,
    BswModeSwitchedAckEvent,
    BswModeSwitchEvent,
    BswModuleCallPoint,
    BswModuleEntity,
    BswOperationInvokedEvent,
    BswParameterPolicy,
    BswPerInstanceMemoryPolicy,
    BswQueuedDataReceptionPolicy,
    BswReleasedTriggerPolicy,
    BswSchedulableEntity,
    BswScheduleEvent,
    BswServiceDependency,
    BswSynchronousServerCallPoint,
    BswTimingEvent,
    BswTriggerDirectImplementation,
    BswVariableAccess,
    RoleBasedBswModuleEntryAssignment,
)
from armodel.models.M2.AUTOSARTemplates.DiagnosticExtract.DiagnosticMapping.ServiceMapping import BswServiceDependencyIdent
from armodel.models.M2.AUTOSARTemplates.BswModuleTemplate.BswImplementation import BswImplementation
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ServiceNeeds import DiagnosticAudienceEnum
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import DiagRequirementIdString
from armodel.models.M2.AUTOSARTemplates.BswModuleTemplate.BswInterfaces import BswEntryRelationship, BswEntryRelationshipEnum, BswEntryRelationshipSet, BswModuleClientServerEntry, BswModuleEntry
from armodel.models.M2.AUTOSARTemplates.BswModuleTemplate.BswOverview import BswModuleDescription
from armodel.models.M2.AUTOSARTemplates.BswModuleTemplate.BswOverview.InstanceRefs import ModeInBswModuleDescriptionInstanceRef
from armodel.models.M2.AUTOSARTemplates.CommonStructure import (
    ApplicationRuleBasedValueSpecification,
    ApplicationValueSpecification,
    ArrayValueSpecification,
    CompositeRuleBasedValueSpecification,
    ConstantReference,
    ConstantSpecification,
    NumericalValueSpecification,
    RecordValueSpecification,
    ReferenceValueSpecification,
    RuleArguments,
    RuleBasedAxisCont,
    RuleBasedValueCont,
    RuleBasedValueSpecification,
    TextValueSpecification,
    ValueSpecification,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Constants import (
    ConstantSpecificationMapping,
    ConstantSpecificationMappingSet,
    NotAvailableValueSpecification,
    NumericalOrText,
    NumericalRuleBasedValueSpecification,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Filter import DataFilter, DataFilterTypeEnum
from armodel.models.M2.AUTOSARTemplates.CommonStructure.FlatMap import FlatInstanceDescriptor, FlatMap, RtePluginProps
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Implementation import Code, DependencyUsageEnum, Implementation, ImplementationProps, ProgramminglanguageEnum
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ImplementationDataTypes import ImplementationDataType, ImplementationDataTypeElement
from armodel.models.M2.AUTOSARTemplates.CommonStructure.InternalBehavior import ExecutableEntity, ExecutableEntityActivationReason, InternalBehavior
from armodel.models.M2.AUTOSARTemplates.CommonStructure.McGroups import McGroup, McGroupDataRefSet
from armodel.models.M2.AUTOSARTemplates.CommonStructure.MeasurementCalibrationSupport import (
    ImplementationElementInParameterInstanceRef,
    McDataAccessDetails,
    McDataInstance,
    McFunction,
    McParameterElementGroup,
    McSupportData,
    McSwEmulationMethodSupport,
    RoleBasedMcDataAssignment,
    RteEventInEcuInstanceRef,
    VariableAccessInEcuInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.MeasurementCalibrationSupport.RptSupport import (
    McFunctionDataRefSet,
    RptComponent,
    RptExecutableEntity,
    RptExecutableEntityEvent,
    RptServicePoint,
    RptSupportData,
    RptSwPrototypingAccess,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ModeDeclaration import (
    ModeActivationKind,
    ModeDeclarationGroup,
    ModeDeclarationGroupPrototype,
    ModeDeclarationGroupPrototypeMapping,
    ModeErrorBehavior,
    ModeErrorReactionPolicyEnum,
    ModeRequestTypeMap,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption import HardwareConfiguration, ResourceConsumption, SoftwareContext
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.ExecutionTime import (
    AnalyzedExecutionTime,
    MeasuredExecutionTime,
    MemorySectionLocation,
    RoughEstimateOfExecutionTime,
    SimulatedExecutionTime,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.HeapUsage import MeasuredHeapUsage, RoughEstimateHeapUsage, WorstCaseHeapUsage
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.MemorySectionUsage import MemorySection
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.StackUsage import MeasuredStackUsage, RoughEstimateStackUsage, StackUsage, WorstCaseStackUsage
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ServiceNeeds import (
    BswMgrNeeds,
    ComMgrUserNeeds,
    CryptoKeyManagementNeeds,
    CryptoServiceJobNeeds,
    CryptoServiceNeeds,
    DevelopmentError,
    DiagnosticControlNeeds,
    DiagEventDebounceCounterBased,
    DiagEventDebounceMonitorInternal,
    DiagEventDebounceTimeBased,
    DiagnosticCapabilityElement,
    DiagnosticCommunicationManagerNeeds,
    DiagnosticComponentNeeds,
    DiagnosticEnableConditionNeeds,
    DiagnosticEventManagerNeeds,
    DiagnosticEventInfoNeeds,
    DiagnosticEventNeeds,
    DiagnosticIoControlNeeds,
    DiagnosticOperationCycleNeeds,
    DiagnosticRequestFileTransferNeeds,
    DiagnosticRoutineNeeds,
    DiagnosticStorageConditionNeeds,
    DiagnosticUploadDownloadNeeds,
    DiagnosticValueNeeds,
    DiagnosticsCommunicationSecurityNeeds,
    DltUserNeeds,
    DoIpActivationLineNeeds,
    DoIpGidNeeds,
    DoIpGidSynchronizationNeeds,
    DoIpPowerModeStatusNeeds,
    DoIpRoutingActivationAuthenticationNeeds,
    DoIpRoutingActivationConfirmationNeeds,
    DiagnosticClearDtcNotificationEnum,
    DiagnosticProcessingStyleEnum,
    DiagnosticRoutineTypeEnum,
    DiagnosticServiceRequestCallbackTypeEnum,
    DiagnosticValueAccessEnum,
    DtcFormatTypeEnum,
    DtcKindEnum,
    DtcStatusChangeNotificationNeeds,
    EcuStateMgrUserNeeds,
    ErrorTracerNeeds,
    FunctionInhibitionAvailabilityNeeds,
    FunctionInhibitionNeeds,
    FurtherActionByteNeeds,
    GlobalSupervisionNeeds,
    HardwareTestNeeds,
    IdsMgrCustomTimestampNeeds,
    IdsMgrNeeds,
    IndicatorStatusNeeds,
    J1939DcmDm19Support,
    J1939RmIncomingRequestServiceNeeds,
    J1939RmOutgoingRequestServiceNeeds,
    NvBlockNeeds,
    ObdControlServiceNeeds,
    ObdInfoServiceNeeds,
    ObdMonitorServiceNeeds,
    ObdPidServiceNeeds,
    ObdRatioDenominatorNeeds,
    ObdRatioServiceNeeds,
    PossibleErrorReaction,
    RoleBasedDataAssignment,
    RuntimeError,
    SecureOnBoardCommunicationNeeds,
    ServiceDependency,
    ServiceNeeds,
    SupervisedEntityCheckpointNeeds,
    SupervisedEntityNeeds,
    SymbolicNameProps,
    SyncTimeBaseMgrUserNeeds,
    TracedFailure,
    TransientFault,
    V2xDataManagerNeeds,
    V2xFacUserNeeds,
    V2xMUserNeeds,
    VendorSpecificServiceNeeds,
    WarningIndicatorRequestedBitNeeds,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.SignalServiceTranslation import (
    SignalServiceTranslationElementProps,
    SignalServiceTranslationEventProps,
    SignalServiceTranslationProps,
    SignalServiceTranslationPropsSet,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.BlueprintDedicated.PortPrototypeBlueprint import PortPrototypeBlueprint, PortPrototypeBlueprintInitValue
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.BlueprintFormula import BlueprintFormula
from armodel.models.M2.AUTOSARTemplates.FeatureModelTemplate import (
    FMConditionByFeaturesAndAttributes,
    FMConditionByFeaturesAndSwSystemconsts,
    FMFormulaByFeaturesAndAttributes,
    FMFormulaByFeaturesAndSwSystemconsts,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.BlueprintGenerator import BlueprintGenerator
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.Keyword import Keyword, KeywordSet
from armodel.models.M2.AUTOSARTemplates.CommonStructure.SwcBswMapping import SwcBswMapping, SwcBswRunnableMapping, SwcBswSynchronizedModeGroupPrototype, SwcBswSynchronizedTrigger
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingClock import TDLETZoneClock, TimingClock, TimingClockSyncAccuracy
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription import (
    TimingDescriptionEvent,
    TimingDescriptionEventChain,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventCom import (
    TDEventCom,
    TDEventCycleStart,
    TDEventFrClusterCycleStart,
    TDEventTTCanCycleStart,
    TDEventISignal,
    TDEventISignalTypeEnum,
    TDEventIPdu,
    TDEventIPduTypeEnum,
    TDEventFrame,
    TDEventFrameTypeEnum,
    TDEventFrameEthernet,
    TDEventFrameEthernetTypeEnum,
    TDHeaderIdRange,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventVfb import (
    TDEventModeDeclaration,
    TDEventModeDeclarationTypeEnum,
    TDEventOperation,
    TDEventOperationTypeEnum,
    TDEventTrigger,
    TDEventTriggerTypeEnum,
    TDEventVariableDataPrototype,
    TDEventVariableDataPrototypeTypeEnum,
    TDEventVfb,
    TDEventVfbPort,
    TDEventVfbReference,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventSwcInternalBehavior import (
    TDEventSwc,
    TDEventSwcInternalBehavior,
    TDEventSwcInternalBehaviorReference,
    TDEventSwcInternalBehaviorTypeEnum,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventBswInternalBehavior import (
    TDEventBswInternalBehavior,
    TDEventBswInternalBehaviorTypeEnum,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventBsw import (
    TDEventBsw,
    TDEventBswModule,
    TDEventBswModuleTypeEnum,
    TDEventBswModeDeclaration,
    TDEventBswModeDeclarationTypeEnum,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventComplex import (
    TDEventComplex,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventSLLET import (
    TDEventSLLET,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventSLLET import (
    TDEventSLLETPort,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.AgeConstraint import AgeConstraint
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.ExecutionOrderConstraint import (
    EOCEventRef,
    EOCExecutableEntityRef,
    EOCExecutableEntityRefAbstract,
    EOCExecutableEntityRefGroup,
    ExecutionOrderConstraint,
    ExecutionOrderConstraintTypeEnum,
    LetDataExchangeParadigmEnum,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.ExecutionTimeConstraint import (
    ExecutionTimeConstraint,
    ExecutionTimeTypeEnum,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.EventTriggeringConstraint import (
    ArbitraryEventTriggering,
    BurstPatternEventTriggering,
    ConcretePatternEventTriggering,
    ConfidenceInterval,
    EventTriggeringConstraint,
    PeriodicEventTriggering,
    SporadicEventTriggering,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.LatencyTimingConstraint import (
    LatencyConstraintTypeEnum,
    LatencyTimingConstraint,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.OffsetConstraint import OffsetTimingConstraint
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.SynchronizationPointConstraint import SynchronizationPointConstraint
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint.SynchronizationTimingConstraint import (
    EventOccurrenceKindEnum,
    SynchronizationTimingConstraint,
    SynchronizationTypeEnum,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingConstraint import TimingConstraint
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingExtensions import SwcTiming, TimingExtension
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingCondition import TimingConditionFormula
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingCondition import ModeInBswInstanceRef, ModeInSwcInstanceRef
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingCondition import (
    TimingCondition,
    TimingExtensionResource,
    TimingModeInstance,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Composition.InstanceRefs import ComponentInCompositionInstanceRef
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventOccurrenceExpression import (
    AutosarOperationArgumentInstance,
    AutosarVariableInstance,
    OperationArgumentInComponentInstanceRef,
    TDEventOccurrenceExpression,
    TDEventOccurrenceExpressionFormula,
    VariableInComponentInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.TriggerDeclaration import Trigger, TriggerMapping
from armodel.models.M2.AUTOSARTemplates.DiagnosticExtract.CommonService import DiagnosticServiceInstance
from armodel.models.M2.AUTOSARTemplates.DiagnosticExtract.Dcm import DiagnosticAccessPermission, DiagnosticAuthRoleProxy, DiagnosticJumpToBootLoaderEnum, DiagnosticSecurityLevel, DiagnosticSession
from armodel.models.M2.AUTOSARTemplates.DiagnosticExtract.DiagnosticContribution import DiagnosticServiceTable
from armodel.models.M2.AUTOSARTemplates.DiagnosticExtract.EnvironmentalCondition import (
    DiagnosticCompareTypeEnum,
    DiagnosticEnvCompareCondition,
    DiagnosticEnvConditionFormula,
    DiagnosticEnvironmentalCondition,
    DiagnosticLogicalOperatorEnum,
)
from armodel.models.M2.AUTOSARTemplates.ECUCDescriptionTemplate import (
    BooleanValue,
    ConfigReferenceValue,
    Container,
    EcucAbstractReferenceValue,
    ReferenceValue,
    EcucAddInfoParamValue,
    EcucContainerValue,
    EcucInstanceReferenceValue,
    EcucModuleConfigurationValues,
    EcucNumericalParamValue,
    EcucParameterValue,
    EcucReferenceValue,
    EcucTextualParamValue,
    EcucValueCollection,
    EnumerationValue,
    FloatValue,
    FunctionNameValue,
    InstanceReferenceValue,
    IntegerValue,
    LinkerSymbolValue,
    ModuleConfiguration,
    ParameterValue,
    StringValue,
)
from armodel.models.M2.AUTOSARTemplates.ECUCParameterDefTemplate import (
    EcucAbstractConfigurationClass,
    EcucAbstractExternalReferenceDef,
    EcucAbstractInternalReferenceDef,
    EcucAbstractReferenceDef,
    EcucAbstractStringParamDef,
    EcucAddInfoParamDef,
    EcucBooleanParamDef,
    EcucChoiceContainerDef,
    EcucChoiceReferenceDef,
    EcucCommonAttributes,
    EcucConditionFormula,
    EcucConditionSpecification,
    EcucContainerDef,
    EcucDefinitionCollection,
    EcucDefinitionElement,
    EcucDerivationSpecification,
    EcucDestinationUriDef,
    EcucDestinationUriDefRefType,
    EcucDestinationUriDefSet,
    EcucDestinationUriNestingContractEnum,
    EcucDestinationUriPolicy,
    EcucEnumerationLiteralDef,
    EcucEnumerationParamDef,
    EcucFloatParamDef,
    EcucForeignReferenceDef,
    EcucFunctionNameDef,
    EcucLinkerSymbolDef,
    EcucInstanceReferenceDef,
    EcucIntegerParamDef,
    EcucModuleDef,
    EcucMultilineStringParamDef,
    EcucMultiplicityConfigurationClass,
    EcucParamConfContainerDef,
    EcucParameterDef,
    EcucParameterDerivationFormula,
    EcucQuery,
    EcucQueryExpression,
    EcucReferenceDef,
    EcucStringParamDef,
    EcucSymbolicNameReferenceDef,
    EcucValidationCondition,
    EcucValueConfigurationClass,
)
from armodel.models.M2.AUTOSARTemplates.EcuResourceTemplate import HwDescriptionEntity, HwElement, HwElementConnector, HwPin, HwPinConnector, HwPinGroup, HwPinGroupContent, HwPinGroupConnector
from armodel.models.M2.AUTOSARTemplates.EcuResourceTemplate.HwElementCategory import HwAttributeValue
from armodel.models.M2.AUTOSARTemplates.EcuResourceTemplate.HwElementCategory import HwAttributeDef, HwCategory, HwType
from armodel.models.M2.AUTOSARTemplates.GenericStructure.DocumentationOnM1 import Documentation, DocumentationContext
from armodel.models.M2.AUTOSARTemplates.GenericStructure.BuildActionManifest import (
    BuildAction,
    BuildActionEntity,
    BuildActionEnvironment,
    BuildActionManifest,
    BuildActionIoElement,
    BuildActionInvocator,
    BuildEngineeringObject,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.AnyInstanceRef import AnyInstanceRef
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.StereotypeMixins import AtpMixedString
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.TagWithOptionalValue import TagWithOptionalValue
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.StereotypeMixins import VariationPointCapable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.SpecialDataDef import (
    SdgAggregationWithVariation,
    SdgClass,
    SdgDef,
    SdgForeignReference,
    SdgForeignReferenceWithVariation,
    SdgPrimitiveAttribute,
    SdgPrimitiveAttributeWithVariation,
    SdgReference,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ModelRestrictionTypes import (
    AbstractValueRestriction,
    AbstractVariationRestriction,
    FullBindingTimeEnum,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.VariantHandling import (
    EvaluatedVariantSet,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ARPackage import ARPackage, ReferenceBase
from armodel.models.M2.AUTOSARTemplates.GenericStructure.RolesAndRights import AclObjectSet, AclOperation, AclPermission, AclRole
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ARPackage import LifeCycleStateDefinitionGroup
from armodel.models.M2.AUTOSARTemplates.GenericStructure.ViewMapSet import ViewMap, ViewMapSet
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ElementCollection import AutoCollectEnum, Collection
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.EngineeringObject import AutosarEngineeringObject, EngineeringObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Enumerations import BindingTimeEnum, XmlSpaceEnum
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import (
    Describable,
    Identifiable,
    MultilanguageReferrable,
    Referrable,
    ShortNameFragment,
    SingleLanguageReferrable,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ARPackage import ARElement
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.MultidimensionalTime import MultidimensionalTime
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import (
    AclScopeEnum,
    AnyServiceInstanceId,
    AnyVersionString,
    ARLiteral,
    Boolean,
    CIdentifier,
    DateTime,
    Identifier,
    Integer,
    IntervalTypeEnum,
    Ip4AddressString,
    Ip6AddressString,
    MacAddressString,
    MimeTypeString,
    NameToken,
    NameTokens,
    Numerical,
    PositiveInteger,
    PrimitiveIdentifier,
    Ref,
    RefType,
    ReferrableSubtypesEnum,
    SectionInitializationPolicyType,
    String,
    UriString,
    UnlimitedInteger,
    VerbatimString,
    VerbatimStringPlain,
    ViewTokens,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.LifeCycles import LifeCycleInfo, LifeCycleInfoSet, LifeCyclePeriod
from armodel.models.M2.AUTOSARTemplates.GenericStructure.VariantHandling import (
    ConditionByFormula,
    SwSystemconstDependentFormula,
    PostBuildVariantCondition,
    PostBuildVariantCriterion,
    PostBuildVariantCriterionValue,
    PredefinedVariant,
    SwSystemconstantValueSet,
    SwSystemconstValue,
    VariationPoint,
)
from armodel.models.M2.AUTOSARTemplates.GenericStructure.VariantHandling.AttributeValueVariationPoints import (
    AbstractEnumerationValueVariationPoint,
    AttributeValueVariationPoint,
    BooleanValueVariationPoint,
    FloatValueVariationPoint,
    IntegerValueVariationPoint,
    LimitValueVariationPoint,
    NumericalValueVariationPoint,
    PositiveIntegerValueVariationPoint,
    TimeValueValueVariationPoint,
    UnlimitedIntegerValueVariationPoint,
)

VALUE_ACCESS_TAG_TO_CLASS = {
    "LIMIT": LimitValueVariationPoint,
    "NUMERICAL-VALUE-VARIATION-POINT": NumericalValueVariationPoint,
    "BOOLEAN-VALUE-VARIATION-POINT": BooleanValueVariationPoint,
    "FLOAT-VALUE-VARIATION-POINT": FloatValueVariationPoint,
    "INTEGER-VALUE-VARIATION-POINT": IntegerValueVariationPoint,
    "POSITIVE-INTEGER-VALUE-VARIATION-POINT": PositiveIntegerValueVariationPoint,
    "TIME-VALUE-VARIATION-POINT": TimeValueValueVariationPoint,
    "UNLIMITED-INTEGER-VALUE-VARIATION-POINT": UnlimitedIntegerValueVariationPoint,
}
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.ApplicationAttributes import (
    ClientServerAnnotation,
    DataLimitKindEnum,
    DelegatedPortAnnotation,
    FilterDebouncingEnum,
    IoHwAbstractionServerAnnotation,
    ModePortAnnotation,
    NvDataPortAnnotation,
    ParameterPortAnnotation,
    ProcessingKindEnum,
    PulseTestEnum,
    SenderReceiverAnnotation,
    SignalFanEnum,
    TriggerPortAnnotation,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Communication import (
    ClientComSpec,
    CompositeNetworkRepresentation,
    ModeSwitchedAckRequest,
    ModeSwitchReceiverComSpec,
    ModeSwitchSenderComSpec,
    NonqueuedReceiverComSpec,
    NonqueuedSenderComSpec,
    NvProvideComSpec,
    NvRequireComSpec,
    ParameterProvideComSpec,
    ParameterRequireComSpec,
    PPortComSpec,
    QueuedReceiverComSpec,
    QueuedSenderComSpec,
    ReceiverComSpec,
    ReceptionComSpecProps,
    RPortComSpec,
    SenderComSpec,
    ServerComSpec,
    TransformationComSpecProps,
    TransmissionAcknowledgementRequest,
    TransmissionComSpecProps,
    UserDefinedTransformationComSpecProps,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Components import (
    AbstractProvidedPortPrototype,
    AbstractRequiredPortPrototype,
    ApplicationSwComponentType,
    AtomicSwComponentType,
    ComplexDeviceDriverSwComponentType,
    EcuAbstractionSwComponentType,
    NvBlockSwComponentType,
    PortGroup,
    PortPrototype,
    PPortPrototype,
    PRPortPrototype,
    RPortPrototype,
    SensorActuatorSwComponentType,
    ServiceProxySwComponentType,
    ServiceSwComponentType,
    SwComponentType,
    SymbolProps,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Components.InstanceRefs import (
    InnerPortGroupInCompositionInstanceRef,
    ModeGroupInAtomicSwcInstanceRef,
    PModeGroupInAtomicSwcInstanceRef,
    PTriggerInAtomicSwcTypeInstanceRef,
    RModeGroupInAtomicSWCInstanceRef,
    RModeInAtomicSwcInstanceRef,
    RVariableInAtomicSwcInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Composition import (
    AssemblySwConnector,
    CompositionSwComponentType,
    DelegationSwConnector,
    InstantiationTimingEventProps,
    PassThroughSwConnector,
    SwComponentPrototype,
    SwConnector,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Composition.InstanceRefs import (
    InstanceEventInCompositionInstanceRef,
    PPortInCompositionInstanceRef,
    RPortInCompositionInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Components.InstanceRefs import (
    POperationInAtomicSwcInstanceRef,
    ROperationInAtomicSwcInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Datatype.DataPrototypes import (
    ApplicationCompositeElementDataPrototype,
    ApplicationRecordElement,
    AutosarDataPrototype,
    DataPrototype,
    ParameterDataPrototype,
    VariableDataPrototype,
)
from armodel.models.M2.AUTOSARTemplates.AbstractPlatform import ApplicationDeferredDataType
from armodel.models.M2.AUTOSARTemplates.AdaptivePlatform.ApplicationDesign.PortInterface import Field
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Datatype.Datatypes import (
    ApplicationArrayDataType,
    ApplicationCompositeDataType,
    ApplicationDataType,
    ApplicationPrimitiveDataType,
    ApplicationRecordDataType,
    AutosarDataType,
    DataTypeMap,
    DataTypeMappingSet,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.EndToEndProtection import (
    EndToEndDescription,
    EndToEndProtection,
    EndToEndProtectionSet,
    EndToEndProtectionVariablePrototype,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.EndToEndProtection import EndToEndProtectionISignalIPdu
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.ImplicitCommunicationBehavior import (
    ConsistencyNeeds,
    DataPrototypeGroup,
    RunnableEntityGroup,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.ImplicitCommunicationBehavior.InstanceRef import (
    InnerDataPrototypeGroupInCompositionInstanceRef,
    InnerRunnableEntityGroupInCompositionInstanceRef,
    RunnableEntityInCompositionInstanceRef,
    VariableDataPrototypeInCompositionInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.NvBlockComponent import BulkNvDataDescriptor, ModeSwitchEventTriggeredActivity, NvBlockDataMapping, NvBlockDescriptor
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.PortInterface import (
    ArgumentDataPrototype,
    ClientServerApplicationErrorMapping,
    ClientServerInterface,
    ClientServerInterfaceMapping,
    ClientServerOperation,
    ClientServerOperationMapping,
    DataInterface,
    DataPrototypeMapping,
    InvalidationPolicy,
    MetaDataItem,
    MetaDataItemSet,
    ModeDeclarationMapping,
    ModeDeclarationMappingSet,
    ModeInterfaceMapping,
    ModeSwitchInterface,
    NvDataInterface,
    ParameterInterface,
    PortInterface,
    PortInterfaceMappingSet,
    TriggerInterfaceMapping,
    SenderReceiverInterface,
    SubElementMapping,
    ApplicationCompositeDataTypeSubElementRef,
    TextTableMapping,
    TextTableValuePair,
    TriggerInterface,
    VariableAndParameterInterfaceMapping,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.PortInterface.InstanceRefs import ApplicationCompositeElementInPortInterfaceInstanceRef
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.RPTScenario import ModeAccessPointIdent, RptExecutableEntityProperties, RptImplPolicy
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SoftwareComponentDocumentation import (
    SwComponentDocumentation,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcImplementation import PerInstanceMemorySize, SwcImplementation
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior import (
    ExternalTriggeringPoint,
    InternalTriggeringPoint,
    RunnableEntity,
    RunnableEntityArgument,
    SwcExclusiveAreaPolicy,
    SwcInternalBehavior,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.AccessCount import AccessCount, AccessCountSet
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.DataElements import ArVariableInImplementationDataInstanceRef, AutosarVariableRef
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.DataElements import ParameterAccess, VariableAccess, VariableAccessScopeEnum
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.IncludedDataTypes import IncludedDataTypeSet
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.DataElements import AutosarParameterRef
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.DataElements.InstanceRefsUsage import ParameterInAtomicSWCTypeInstanceRef, VariableInAtomicSWCTypeInstanceRef
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.InstantiationDataDefProps import InstantiationDataDefProps
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.ModeDeclarationGroup import IncludedModeDeclarationGroupSet, ModeAccessPoint, ModeSwitchPoint
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.PortAPIOptions import (
    PortAPIOption,
    PortDefinedArgumentValue,
    CommunicationBufferLocking,
    SupportBufferLockingEnum,
    DataTransformationErrorHandlingEnum,
    DataTransformationStatusForwardingEnum,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.RTEEvents import (
    AsynchronousServerCallReturnsEvent,
    BackgroundEvent,
    DataReceiveErrorEvent,
    DataReceivedEvent,
    DataSendCompletedEvent,
    DataWriteCompletedEvent,
    InitEvent,
    InternalTriggerOccurredEvent,
    ModeSwitchedAckEvent,
    OperationInvokedEvent,
    RTEEvent,
    SwcModeSwitchEvent,
    TimingEvent,
)
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.ServerCall import ServerCallPoint
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.ServiceMapping import RoleBasedDataTypeAssignment, RoleBasedPortAssignment, SwcServiceDependency
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.VariantHandling import VariationPointProxy
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.MeasurementAndCalibration.InterpolationRoutineMappingSet import (
    InterpolationRoutine,
    InterpolationRoutineMapping,
    InterpolationRoutineMappingSet,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate import (
    ClientIdDefinition,
    ClientIdDefinitionSet,
    ComManagementMapping,
    CpSoftwareCluster,
    J1939SharedAddressCluster,
    SwComponentPrototypeAssignment,
    SwcToEcuMapping,
    System,
    SystemMapping,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.DataMapping import (
    DataMapping,
    IndexedArrayElement,
    SenderRecArrayElementMapping,
    SenderRecArrayTypeMapping,
    SenderRecCompositeTypeMapping,
    SenderReceiverToSignalGroupMapping,
    SenderReceiverToSignalMapping,
    SenderRecRecordElementMapping,
    SenderRecRecordTypeMapping,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.DiagnosticConnection import DiagnosticConnection, TpConnection
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.DoIP import DoIpConfig, DoIpInterface, DoIpRoutingActivation
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.ECUResourceMapping import CommunicationControllerMapping, ECUMapping, HwPortMapping
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.RteEventToOsTaskMapping import AppOsTaskProxyToEcuTaskProxyMapping, OsTaskPreemptabilityEnum, OsTaskProxy
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Can.CanCommunication import (
    CanAddressingModeType,
    CanFrame,
    CanFrameRxBehaviorEnum,
    CanFrameTriggering,
    CanFrameTxBehaviorEnum,
    CanXlFrameTriggeringProps,
    RxIdentifierRange,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ttcan.TtcanCommunication import TtcanAbsolutelyScheduledTiming
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Can.CanTopology import (
    AbstractCanCommunicationController,
    AbstractCanCommunicationControllerAttributes,
    CanCommunicationConnector,
    CanCommunicationController,
    CanControllerConfigurationRequirements,
    CanControllerFdConfiguration,
    CanControllerFdConfigurationRequirements,
    CanControllerXlConfiguration,
    CanControllerXlConfigurationRequirements,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.EthernetCommunication import (
    RuntimeAddressConfigurationEnum,
    SocketConnectionBundle,
    SocketConnectionIpduIdentifier,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.TcpOptionFilterSet import (
    TcpOptionFilterList,
    TcpOptionFilterSet,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.ObsoleteModel import (
    SoAdRoutingGroup,
    SocketConnection,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.EthernetFrame import GenericEthernetFrame
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.EthernetTopology import (
    EthTcpIpIcmpProps,
    EthTcpIpProps,
    CouplingPort,
    CouplingPortAbstractShaper,
    CouplingPortConnection,
    CouplingPortDetails,
    CouplingPortFifo,
    CouplingPortRatePolicy,
    CouplingPortScheduler,
    CouplingPortStructuralElement,
    CouplingPortTrafficClassAssignment,
    EthernetCluster,
    GlobalTimeCouplingPortProps,
    PlcaProps,
    EthernetCommunicationConnector,
    EthernetCommunicationController,
    EthernetPriorityRegeneration,
    DhcpServerConfiguration,
    Ipv4DhcpServerConfiguration,
    Ipv6DhcpServerConfiguration,
    InitialSdDelayConfig,
    MacMulticastGroup,
    SdClientConfig,
    VlanMembership,
    GenericTp,
    TcpTp,
    TpPort,
    TransportProtocolConfiguration,
    UdpTp,
    TcpProps,
    UdpProps,
    TcpIpIcmpv4Props,
    TcpIpIcmpv6Props,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.ServiceInstances import RequestResponseDelay
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.SecureCommunication import (
    CryptoCertificateAlgorithmFamilyEnum,
    CryptoCertificateFormatEnum,
    CryptoEllipticCurveProps,
    CryptoServiceCertificate,
    CryptoServicePrimitive,
    CryptoSignatureScheme,
    MacSecCapabilityEnum,
    MacSecCipherSuiteConfig,
    MacSecConfidentialityOffsetEnum,
    MacSecCryptoAlgoConfig,
    MacSecFailPermissiveModeEnum,
    MacSecGlobalKayProps,
    MacSecKayParticipant,
    MacSecLocalKayProps,
    MacSecProps,
    MacSecRoleEnum,
    IPsecDpdActionEnum,
    IPsecHeaderTypeEnum,
    IPsecIpProtocolEnum,
    IPsecModeEnum,
    IPsecPolicyEnum,
    IPSecConfigProps,
    IPSecRule,
    SecOcCryptoServiceMapping,
    TlsCryptoCipherSuite,
    TlsCryptoCipherSuiteProps,
    TlsCryptoServiceMapping,
    TlsPskIdentity,
    TlsVersionEnum,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Can.CanTopology import CanControllerConfiguration, CanXlProps
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.FibexCore.CoreCommunication import CommunicationDirectionType
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.EthernetTopology import (
    ApplicationEndpoint,
    CouplingPortRatePolicyActionEnum,
    CouplingPortRoleEnum,
    DoIpEntity,
    DoIpEntityRoleEnum,
    EthernetConnectionNegotiationEnum,
    EthernetMacLayerTypeEnum,
    EthernetPhysicalLayerTypeEnum,
    EthernetSwitchVlanIngressTagEnum,
    InfrastructureServices,
    IpAddressKeepEnum,
    IPSecConfig,
    Ipv4Configuration,
    Ipv6AddressSourceEnum,
    Ipv6Configuration,
    NetworkEndpoint,
    OrderedMaster,
    TimeSyncClientConfiguration,
    TimeSyncServerConfiguration,
    TimeSyncTechnologyEnum,
    TimeSynchronization,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.ServiceInstances import (
    AbstractServiceInstance,
    ConsumedEventGroup,
    ConsumedProvidedServiceInstanceGroup,
    ConsumedServiceInstance,
    EventGroupControlTypeEnum,
    EventHandler,
    PduActivationRoutingGroup,
    ProvidedServiceInstance,
    SdServerConfig,
    ServiceVersionAcceptanceKindEnum,
    SoAdConfig,
    StaticSocketConnection,
    SocketAddress,
    TcpRoleEnum,
    UdpChecksumCalculationEnum,
    SomeipSdClientEventGroupTimingConfig,
    SomeipSdClientServiceInstanceConfig,
    SomeipSdServerEventGroupTimingConfig,
    SomeipServiceVersion,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Flexray.FlexrayCommunication import FlexrayAbsolutelyScheduledTiming, FlexrayFrame, FlexrayFrameTriggering
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Flexray.FlexrayTopology import (
    FlexrayCluster,
    FlexrayCommunicationConnector,
    FlexrayCommunicationController,
    FlexrayFifoConfiguration,
    FlexrayFifoRange,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Lin.LinCommunication import (
    ApplicationEntry,
    AssignFrameId,
    AssignFrameIdRange,
    AssignNad,
    ConditionalChangeNad,
    DataDumpEntry,
    FreeFormat,
    LinConfigurationEntry,
    LinErrorResponse,
    LinFrameTriggering,
    LinScheduleTable,
    LinUnconditionalFrame,
    ResumePosition,
    RunMode,
    SaveConfigurationEntry,
    ScheduleTableEntry,
    UnassignFrameId,
    FramePid,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Lin.LinTopology import (
    LinCluster,
    LinCommunicationConnector,
    LinCommunicationController,
    LinConfigurableFrame,
    LinMaster,
    LinOrderedConfigurableFrame,
    LinSlaveConfig,
    LinSlaveConfigIdent,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Multiplatform import DefaultValueElement, FrameMapping, Gateway, IPduMapping, ISignalMapping, PduMappingDefaultValue, TargetIPduRef
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.FibexCore.CoreCommunication import (
    CommConnectorPort,
    ContainedIPduProps,
    DcmIPdu,
    DynamicPart,
    DynamicPartAlternative,
    Frame,
    FramePort,
    FrameTriggering,
    GeneralPurposeIPdu,
    GeneralPurposePdu,
    IPdu,
    IPduPort,
    IPduTiming,
    ISignal,
    ISignalGroup,
    ISignalIPdu,
    ISignalIPduGroup,
    ISignalPort,
    ISignalProps,
    ISignalToIPduMapping,
    ISignalTriggering,
    MultiplexedIPdu,
    MultiplexedPart,
    NmPdu,
    NPdu,
    Pdu,
    PduTriggering,
    PdurIPduGroup,
    SecureCommunicationAuthenticationProps,
    SecureCommunicationFreshnessProps,
    SecureCommunicationProps,
    SecureCommunicationPropsSet,
    SecuredIPdu,
    SegmentPosition,
    StaticPart,
    SystemSignal,
    SystemSignalGroup,
    UserDefinedIPdu,
    UserDefinedPdu,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Can.CanTopology import (  # noqa: F401
    AbstractCanPhysicalChannel,
    CanPhysicalChannel,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Can.CanTopology import CanClusterBusOffRecovery, J1939Cluster
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.FibexCore.CoreTopology import (
    AbstractCanCluster,
    CanCluster,
    ClientIdRange,
    CommunicationCluster,
    CommunicationConnector,
    CommunicationController,
    CommunicationCycle,
    CycleCounter,
    CycleRepetition,
    PhysicalChannel,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Lin.LinTopology import LinPhysicalChannel
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.EthernetTopology import EthernetPhysicalChannel
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Flexray.FlexrayTopology import FlexrayPhysicalChannel
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.FibexCore.CoreTopology import EcuInstance
from armodel.models.M2.AUTOSARTemplates.LogAndTraceExtract import DltApplication, DltArgument, DltContext, DltEcu, DltMessage, PrivacyLevel
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Dlt import DltConfig, DltDefaultTraceStateEnum, DltLogChannel, LogTraceDefaultLogLevelEnum
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.SWmapping import EcuPartition
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.FibexCore.CoreCommunication.Timing import (
    CyclicTiming,
    EventControlledTiming,
    ModeDrivenTransmissionModeCondition,
    TimeRangeType,
    TransmissionModeCondition,
    TransmissionModeDeclaration,
    TransmissionModeTiming,
    TriggerIPduSendCondition,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.InstanceRefs import (
    ComponentInSystemInstanceRef,
    OperationInSystemInstanceRef,
    PortGroupInSystemInstanceRef,
    VariableDataPrototypeInSystemInstanceRef,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.NetworkManagement import (
    CanNmCluster,
    CanNmClusterCoupling,
    CanNmNode,
    CanNmEcu,
    FlexrayNmCluster,
    FlexrayNmClusterCoupling,
    FlexrayNmEcu,
    J1939NmCluster,
    J1939NmEcu,
    J1939NmNode,
    J1939NodeName,
    NmCluster,
    NmConfig,
    NmEcu,
    NmNode,
    UdpNmCluster,
    UdpNmClusterCoupling,
    UdpNmEcu,
    UdpNmNode,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.SWmapping import ApplicationPartitionToEcuPartitionMapping, SwcToImplMapping
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Transformer import (
    BufferProperties,
    CSTransformerErrorReactionEnum,
    DataPrototypeInPortInterfaceRef,
    DataPrototypeInClientServerInterfaceInstanceRef,
    DataPrototypeInSenderReceiverInterfaceInstanceRef,
    DataPrototypeTransformationProps,
    DataTransformation,
    DataTransformationSet,
    E2EProfileCompatibilityProps,
    EndToEndTransformationComSpecProps,
    EndToEndTransformationDescription,
    EndToEndTransformationISignalProps,
    SOMEIPMessageTypeEnum,
    SOMEIPTransformationISignalProps,
    TlvDataIdDefinition,
    TlvDataIdDefinitionSet,
    TransformationDescription,
    TransformationISignalProps,
    TransformationTechnology,
    UserDefinedTransformationISignalProps,
)
from armodel.models.M2.AUTOSARTemplates.SystemTemplate.TransportProtocols import (
    CanTpAddress,
    CanTpAddressingFormatType,
    CanTpChannel,
    CanTpConfig,
    CanTpConnection,
    CanTpEcu,
    CanTpNode,
    DoIpLogicAddress,
    DoIpTpConfig,
    DoIpTpConnection,
    LinTpConfig,
    LinTpConnection,
    LinTpNode,
    TpAddress,
    TpConfig,
)
from armodel.models.M2.MSR.AsamHdo.AdminData import AdminData, DocRevision, Modification
from armodel.models.M2.MSR.AsamHdo.BaseTypes import BaseTypeDirectDefinition, SwBaseType
from armodel.models.M2.MSR.AsamHdo.ComputationMethod import (
    CompuGenericMath,
    Compu,
    CompuConst,
    CompuConstContent,
    CompuConstFormulaContent,
    CompuConstNumericContent,
    CompuConstTextContent,
    CompuMethod,
    CompuNominatorDenominator,
    CompuRationalCoeffs,
    CompuScale,
    CompuScaleConstantContents,
    CompuScaleRationalFormula,
    CompuScales,
)
from armodel.models.M2.MSR.AsamHdo.Constraints.GlobalConstraints import DataConstr, DataConstrRule, InternalConstrs, PhysConstrs, ScaleConstr, ScaleConstrValidityEnum
from armodel.models.M2.MSR.AsamHdo.SpecialData import Sd, Sdf, Sdg, SdgContents
from armodel.models.M2.MSR.AsamHdo.Units import PhysicalDimension, SingleLanguageUnitNames, Unit, UnitGroup
from armodel.models.M2.MSR.CalibrationData.CalibrationValue import SwValueCont, SwValues, ValueGroup
from armodel.models.M2.MSR.DataDictionary.AuxillaryObjects import MemoryAllocationKeywordPolicyType, MemorySectionType, SwAddrMethod
from armodel.models.M2.MSR.DataDictionary.Axis import SwAxisGeneric, SwAxisGrouped, SwAxisIndividual, SwGenericAxisParam, SwGenericAxisParamType
from armodel.models.M2.MSR.DataDictionary.CalibrationParameter import SwCalprmAxis, SwCalprmAxisSet
from armodel.models.M2.MSR.DataDictionary.DataDefProperties import (
    SwBitRepresentation,
    SwCalibrationAccessEnum,
    SwDataDefProps,
    SwDataDependency,
    SwDataDependencyArgs,
    SwImplPolicyEnum,
    SwPointerTargetProps,
    SwTextProps,
    ValueList,
)
from armodel.models.M2.MSR.DataDictionary.DatadictionaryProxies import SwCalprmRefProxy, SwVariableRefProxy
from armodel.models.M2.MSR.DataDictionary.RecordLayout import SwRecordLayout, SwRecordLayoutGroup, SwRecordLayoutGroupContent, SwRecordLayoutV
from armodel.models.M2.MSR.DataDictionary.ServiceProcessTask import SwServiceArg
from armodel.models.M2.MSR.DataDictionary.SystemConstant import SwSystemconst
from armodel.models.M2.MSR.Documentation.Annotation import Annotation, GeneralAnnotation
from armodel.models.M2.MSR.Documentation.BlockElements import Caption, Colspec, Entry, Row, Table, Tbody, Tgroup, Url
from armodel.models.M2.MSR.Documentation.BlockElements.GerneralParameters import (
    GeneralParameter,
    PrmChar,
    PrmCharAbsTol,
    PrmCharMinTypMax,
    PrmCharNumericalContents,
    PrmCharTextualContents,
    Prms,
)
from armodel.models.M2.MSR.Documentation.BlockElements.Figure import Area, AreaEnumNohref, AreaEnumShape, Graphic, GraphicFitEnum, GraphicNotationEnum, LGraphic, Map, MlFigure
from armodel.models.M2.MSR.Documentation.BlockElements.Formula import MlFormula
from armodel.models.M2.MSR.Documentation.BlockElements.OasisExchangeTable import AlignEnum, FloatEnum, FrameEnum, OrientEnum, PgwideEnum, TableSeparatorString, ValignEnum
from armodel.models.M2.MSR.Documentation.Chapters import (
    Chapter,
    ChapterContent,
    ChapterModel,
    ChapterOrMsrQuery,
    PredefinedChapter,
    Topic1,
    TopicContent,
    TopicContentOrMsrQuery,
    TopicOrMsrQuery,
)
from armodel.models.M2.MSR.Documentation.MsrQuery import MsrQueryChapter, MsrQueryResultChapter, MsrQueryResultTopic1, MsrQueryTopic1
from armodel.models.M2.MSR.Documentation.TextModel.BlockElements import DocumentationBlock
from armodel.models.M2.MSR.Documentation.BlockElements.ListElements import ARList, DefItem, DefList, IndentSample, Item, ItemLabelPosEnum, LabeledItem, LabeledList, ListEnum
from armodel.models.M2.MSR.Documentation.BlockElements.Note import Note, NoteTypeEnum
from armodel.models.M2.MSR.Documentation.BlockElements.PaginationAndView import ChapterEnumBreak, DocumentViewSelectable, KeepWithPreviousEnum, Paginateable
from armodel.models.M2.MSR.Documentation.BlockElements.RequirementsTracing import (
    StructuredReq,
    Traceable,
    TraceableTable,
    TraceableText,
)
from armodel.models.M2.MSR.Documentation.TextModel.InlineAttributeEnums import (
    ResolutionPolicyEnum,
    ShowContentEnum,
    ShowResourceAliasNameEnum,
    ShowResourceCategoryEnum,
    ShowResourceLongNameEnum,
    ShowResourceNumberEnum,
    ShowResourcePageEnum,
    ShowResourceShortNameEnum,
    ShowResourceTypeEnum,
    ShowSeeEnum,
)
from armodel.models.M2.MSR.Documentation.TextModel.InlineTextElements import Br, EmphasisText, IndexEntry, Std, Superscript, Tt, Xdoc, Xfile, Xref, XrefTarget
from armodel.models.M2.MSR.Documentation.TextModel.LanguageDataModel import (
    LanguageSpecific,
    LLongName,
    LOverviewParagraph,
    LParagraph,
    LPlainText,
    LVerbatim,
    MixedContentForLongName,
    MixedContentForOverviewParagraph,
    MixedContentForUnitNames,
    MixedContentForVerbatim,
    SlParagraph,
    WhitespaceControlled,
)
from armodel.models.M2.MSR.Documentation.MsrQuery import MsrQueryArg, MsrQueryP1, MsrQueryP2, MsrQueryProps
from armodel.models.M2.MSR.Documentation.TextModel.MultilanguageData import MultilanguageLongName, MultiLanguageOverviewParagraph, MultiLanguageParagraph, MultiLanguagePlainText, MultiLanguageVerbatim
from armodel.models.M2.MSR.Documentation.TextModel.SingleLanguageData import SingleLanguageLongName, SlOverviewParagraph
from armodel.parser.abstract_arxml_parser import AbstractARXMLParser

#: Mapping between BindingTimeEnum camelCase values and their XML attribute tokens
#: (AR:BINDING-TIME-ENUM--SIMPLE).
BINDING_TIME_XML_MAP = {
    "codeGenerationTime": "CODE-GENERATION-TIME",
    "linkTime": "LINK-TIME",
    "preCompileTime": "PRE-COMPILE-TIME",
    "systemDesignTime": "SYSTEM-DESIGN-TIME",
}

#: Mapping between IntervalTypeEnum values and their XML attribute tokens
#: (AR:INTERVAL-TYPE-ENUM--SIMPLE).
INTERVAL_TYPE_XML_MAP = {
    "closed": "CLOSED",
    "open": "OPEN",
}

#: Mapping between AutoCollectEnum literal values and their XML element text
#: (AR:AUTO-COLLECT-ENUM--SIMPLE).
AUTO_COLLECT_XML_MAP = {
    "refAll": "REF-ALL",
    "refNone": "REF-NONE",
    "refNonStandard": "REF-NON-STANDARD",
}

#: Mapping between AclScopeEnum literal values and their XML element text
#: (AR:ACL-SCOPE-ENUM--SIMPLE).
ACL_SCOPE_XML_MAP = {
    "dependant": "DEPENDANT",
    "descendant": "DESCENDANT",
    "explicit": "EXPLICIT",
}

#: Mapping between SwImplPolicyEnum literal values and their XML element text
#: (AR:SW-IMPL-POLICY-ENUM--SIMPLE).
SW_IMPL_POLICY_XML_MAP = {
    "const": "CONST",
    "fixed": "FIXED",
    "measurementPoint": "MEASUREMENT-POINT",
    "queued": "QUEUED",
    "standard": "STANDARD",
}

#: Mapping between VariableAccessScopeEnum literal values and their XML element text
#: (AR:VARIABLE-ACCESS-SCOPE-ENUM--SIMPLE).
VARIABLE_ACCESS_SCOPE_XML_MAP = {
    "communicationInterEcu": "COMMUNICATION-INTER-ECU",
    "communicationIntraPartition": "COMMUNICATION-INTRA-PARTITION",
    "interPartitionIntraEcu": "INTER-PARTITION-INTRA-ECU",
}

BSW_INTERRUPT_CATEGORY_XML_MAP = {
    "cat1": "CAT-1",
    "cat2": "CAT-2",
}

BSW_ENTRY_RELATIONSHIP_XML_MAP = {
    "derivedFrom": "DERIVED-FROM",
}

DIAGNOSTIC_LOGICAL_OPERATOR_XML_MAP = {
    "logicalAnd": "LOGICAL-AND",
    "logicalOr": "LOGICAL-OR",
}

DIAGNOSTIC_COMPARE_TYPE_XML_MAP = {
    "isEqual": "IS-EQUAL",
    "isNotEqual": "IS-NOT-EQUAL",
    "isLessThan": "IS-LESS-THAN",
    "isLessOrEqual": "IS-LESS-OR-EQUAL",
    "isGreaterThan": "IS-GREATER-THAN",
    "isGreaterOrEqual": "IS-GREATER-OR-EQUAL",
}

DIAGNOSTIC_AUDIENCE_XML_MAP = {
    "aftermarket": "AFTERMARKET",
    "afterSales": "AFTER-SALES",
    "development": "DEVELOPMENT",
    "manufacturing": "MANUFACTURING",
    "supplier": "SUPPLIER",
}
DIAGNOSTIC_SERVICE_REQUEST_CALLBACK_TYPE_XML_MAP = {
    "requestCallbackTypeManufacturer": "REQUEST-CALLBACK-TYPE-MANUFACTURER",
    "requestCallbackTypeSupplier": "REQUEST-CALLBACK-TYPE-SUPPLIER",
}

DIAGNOSTIC_ROUTINE_TYPE_XML_MAP = {
    "asynchronous": "ASYNCHRONOUS",
    "synchronous": "SYNCHRONOUS",
}

DIAGNOSTIC_VALUE_ACCESS_XML_MAP = {
    "readOnly": "READ-ONLY",
    "readWrite": "READ-WRITE",
    "writeOnly": "WRITE-ONLY",
}

DIAGNOSTIC_PROCESSING_STYLE_XML_MAP = {
    "processingStyleAsynchronous": "PROCESSING-STYLE-ASYNCHRONOUS",
    "processingStyleAsynchronousWithError": "PROCESSING-STYLE-ASYNCHRONOUS-WITH-ERROR",
    "processingStyleSynchronous": "PROCESSING-STYLE-SYNCHRONOUS",
}

DIAGNOSTIC_CLEAR_DTC_NOTIFICATION_XML_MAP = {
    "start": "START",
    "finish": "FINISH",
}

DTC_FORMAT_TYPE_XML_MAP = {
    "j1939": "J-1939",
    "obd": "OBD",
}

DTC_KIND_XML_MAP = {
    "emissionRelatedDtc": "EMISSION-RELATED-DTC",
    "nonEmmissionRelatedDtc": "NON-EMMISSION-RELATED-DTC",
}


class ARXMLParser(AbstractARXMLParser):
    """
    Main ARXML parser that loads AUTOSAR XML files into the model.
    Parses elements by dispatching to type-specific read methods based on
    XML tag names.
    """

    def __init__(self, options=None) -> None:
        super().__init__(options)

    def getRxIdentifierRange(self, element: ET.Element, key: str) -> Optional[RxIdentifierRange]:
        child_element = self.find(element, key)
        range = None
        if child_element is not None:
            range = RxIdentifierRange()
            range.setLowerCanId(self.getChildElementOptionalPositiveInteger(child_element, "LOWER-CAN-ID"))
            range.setUpperCanId(self.getChildElementOptionalPositiveInteger(child_element, "UPPER-CAN-ID"))
        return range

    def getJ1939NodeName(self, element: ET.Element, key: str) -> Optional[J1939NodeName]:
        child_element = self.find(element, key)
        node_name = None
        if child_element is not None:
            node_name = J1939NodeName()
            node_name.setArbitraryAddressCapable(self.getChildElementOptionalBooleanValue(child_element, "ARBITRARY-ADDRESS-CAPABLE"))
            node_name.setEcuInstance(self.getChildElementOptionalIntegerValue(child_element, "ECU-INSTANCE"))
            node_name.setFunction(self.getChildElementOptionalIntegerValue(child_element, "FUNCTION"))
            node_name.setFunctionInstance(self.getChildElementOptionalIntegerValue(child_element, "FUNCTION-INSTANCE"))
            node_name.setIdentitiyNumber(self.getChildElementOptionalIntegerValue(child_element, "IDENTITIY-NUMBER"))
            node_name.setIndustryGroup(self.getChildElementOptionalIntegerValue(child_element, "INDUSTRY-GROUP"))
            node_name.setManufacturerCode(self.getChildElementOptionalIntegerValue(child_element, "MANUFACTURER-CODE"))
            node_name.setVehicleSystem(self.getChildElementOptionalIntegerValue(child_element, "VEHICLE-SYSTEM"))
            node_name.setVehicleSystemInstance(self.getChildElementOptionalIntegerValue(child_element, "VEHICLE-SYSTEM-INSTANCE"))
        return node_name

    def readSd(self, element: ET.Element, contents: SdgContents):
        for child_element in self.findall(element, "./SD"):
            sd = Sd()
            self.readARObject(child_element, sd)
            if "GID" in child_element.attrib:
                sd.setGID(NameToken().setValue(child_element.attrib["GID"]))
            self.readWhitespaceControlled(child_element, sd)
            if child_element.text is not None and child_element.text.strip() != "":
                sd.setValue(VerbatimStringPlain().setValue(child_element.text))
            contents.addSd(sd)

    def readSdf(self, element: ET.Element, contents: SdgContents):
        for child_element in self.findall(element, "./SDF"):
            sdf = Sdf()
            self.readARObject(child_element, sdf)
            if "GID" in child_element.attrib:
                sdf.setGID(NameToken().setValue(child_element.attrib["GID"]))
            if child_element.text is not None and child_element.text.strip() != "":
                sdf.setValue(Numerical().setValue(child_element.text))
            contents.addSdf(sdf)

    def readSdgCaption(self, element: ET.Element, sdg: Sdg):
        child_element = self.find(element, "SDG-CAPTION")
        if child_element is not None:
            sdg.createSdgCaption(self.getShortName(child_element))

    def readSdgSdxRefs(self, element: ET.Element, contents: SdgContents):
        for ref in self.getChildElementRefTypeList(element, "SDX-REF"):
            contents.addSdxRef(ref)

    def readSdgSdxfRefs(self, element: ET.Element, contents: SdgContents):
        for ref in self.getChildElementRefTypeList(element, "SDXF"):
            contents.addSdxfRef(ref)

    def getSdg(self, element: ET.Element) -> Sdg:
        sdg = Sdg()
        self.readARObject(element, sdg)
        if "GID" in element.attrib:
            sdg.setGID(NameToken().setValue(element.attrib["GID"]))
        self.readSdgCaption(element, sdg)
        contents = SdgContents()
        self.readSd(element, contents)
        self.readSdf(element, contents)
        for child_element in self.findall(element, "SDG"):
            contents.addSdg(self.getSdg(child_element))
        self.readSdgSdxRefs(element, contents)
        self.readSdgSdxfRefs(element, contents)
        if len(contents.getSds()) > 0 or len(contents.getSdfs()) > 0 or len(contents.getSdgs()) > 0 or len(contents.getSdxRefs()) > 0 or len(contents.getSdxfRefs()) > 0:
            sdg.setSdgContentsType(contents)
        return sdg

    def readBlueprintGenerator(self, element: ET.Element, generator: BlueprintGenerator) -> BlueprintGenerator:
        self.readARObject(element, generator)
        generator.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))
        expression_element = self.find(element, "EXPRESSION")
        if expression_element is not None:
            generator.setExpression(VerbatimString().setValue(expression_element.text))
        return generator

    def readConditionByFormula(self, element: ET.Element, condition: ConditionByFormula) -> ConditionByFormula:
        self.readARObject(element, condition)
        if "BINDING-TIME" in element.attrib:
            binding_time = None
            for camel, token in BINDING_TIME_XML_MAP.items():
                if token == element.attrib["BINDING-TIME"]:
                    binding_time = camel
                    break
            if binding_time is not None:
                condition.setBindingTime(BindingTimeEnum().setValue(binding_time))
            else:
                self.notImplemented("Unsupported BINDING-TIME <%s>" % element.attrib["BINDING-TIME"])
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, condition)
        if isinstance(condition, SwSystemconstDependentFormula):
            self.readSwSystemconstDependentFormula(element, condition)
        return condition

    def readSwSystemconstDependentFormula(self, element: ET.Element, formula: SwSystemconstDependentFormula) -> SwSystemconstDependentFormula:
        formula.setSyscRef(self.getChildElementOptionalRefType(element, "SYSC-REF"))
        formula.setSyscStringRef(self.getChildElementOptionalRefType(element, "SYSC-STRING-REF"))
        return formula

    def readBlueprintFormula(self, element: ET.Element, formula: BlueprintFormula) -> BlueprintFormula:
        self.readARObject(element, formula)
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, formula)
        formula.setEcucRef(self.getChildElementOptionalRefType(element, "ECUC-REF"))
        formula.setVerbatim(self.getMultiLanguageVerbatim(element, "VERBATIM"))
        if isinstance(formula, SwSystemconstDependentFormula):
            self.readSwSystemconstDependentFormula(element, formula)
        return formula

    def readFMFormulaByFeaturesAndAttributes(self, element: ET.Element, formula: FMFormulaByFeaturesAndAttributes) -> FMFormulaByFeaturesAndAttributes:
        formula.setAttributeRef(self.getChildElementOptionalRefType(element, "ATTRIBUTE-REF"))
        formula.setFeatureRef(self.getChildElementOptionalRefType(element, "FEATURE-REF"))
        return formula

    def readFMFormulaByFeaturesAndSwSystemconsts(self, element: ET.Element, formula: FMFormulaByFeaturesAndSwSystemconsts) -> FMFormulaByFeaturesAndSwSystemconsts:
        formula.setFeatureRef(self.getChildElementOptionalRefType(element, "FEATURE-REF"))
        return formula

    def readFMConditionByFeaturesAndSwSystemconsts(self, element: ET.Element, formula: FMConditionByFeaturesAndSwSystemconsts) -> FMConditionByFeaturesAndSwSystemconsts:
        self.readARObject(element, formula)
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, formula)
        if isinstance(formula, FMFormulaByFeaturesAndSwSystemconsts):
            self.readFMFormulaByFeaturesAndSwSystemconsts(element, formula)
        if isinstance(formula, SwSystemconstDependentFormula):
            self.readSwSystemconstDependentFormula(element, formula)
        return formula

    def readFMConditionByFeaturesAndAttributes(self, element: ET.Element, formula: FMConditionByFeaturesAndAttributes) -> FMConditionByFeaturesAndAttributes:
        self.readARObject(element, formula)
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, formula)
        if isinstance(formula, FMFormulaByFeaturesAndAttributes):
            self.readFMFormulaByFeaturesAndAttributes(element, formula)
        return formula

    def readPostBuildVariantCondition(self, element: ET.Element, condition: PostBuildVariantCondition) -> PostBuildVariantCondition:
        self.readARObject(element, condition)
        # MATCHING-CRITERION-REF and VALUE both carry minOccurs="0" in the XSD
        # (AUTOSAR_00052.xsd group POST-BUILD-VARIANT-CONDITION) — an empty
        # POST-BUILD-VARIANT-CONDITION is schema-legal and parses to an empty model.
        condition.setMatchingCriterionRef(self.getChildElementOptionalRefType(element, "MATCHING-CRITERION-REF"))
        condition.setValue(self.getChildElementOptionalIntegerValue(element, "VALUE"))
        return condition

    def readPostBuildVariantCriterionValue(self, element: ET.Element, value: PostBuildVariantCriterionValue) -> PostBuildVariantCriterionValue:
        self.readARObject(element, value)
        # VARIANT-CRITERION-REF, VALUE and ANNOTATIONS all carry minOccurs="0" in the XSD
        # (AUTOSAR_00052.xsd group POST-BUILD-VARIANT-CRITERION-VALUE) — an empty
        # POST-BUILD-VARIANT-CRITERION-VALUE is schema-legal and parses to an empty model.
        value.setVariantCriterionRef(self.getChildElementOptionalRefType(element, "VARIANT-CRITERION-REF"))
        value.setValue(self.getChildElementOptionalIntegerValue(element, "VALUE"))
        for annotation in self.getAnnotations(element):
            value.addAnnotation(annotation)
        return value

    def readVariationPoint(self, element: ET.Element, variation_point: VariationPoint) -> VariationPoint:
        self.readARObject(element, variation_point)
        variation_point.setShortLabel(self.getChildElementOptionalIdentifier(element, "SHORT-LABEL"))
        variation_point.setDesc(self.getMultiLanguageOverviewParagraph(element, "DESC"))
        variation_point.setBlueprintCondition(self.getDocumentationBlock(element, "BLUEPRINT-CONDITION"))
        # FORMAL-BLUEPRINT-CONDITION is removed (atp.Status="removed" in the R23-11
        # XSD, AUTOSAR_00052.xsd group VARIATION-POINT line 130012) and has no
        # model attribute — deliberately not read.
        formal_element = self.find(element, "FORMAL-BLUEPRINT-GENERATOR")
        if formal_element is not None:
            variation_point.setFormalBlueprintGenerator(self.readBlueprintGenerator(formal_element, BlueprintGenerator()))
        sw_syscond_element = self.find(element, "SW-SYSCOND")
        if sw_syscond_element is not None:
            variation_point.setSwSyscond(self.readConditionByFormula(sw_syscond_element, ConditionByFormula()))
        for child_element in self.findall(element, "POST-BUILD-VARIANT-CONDITIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "POST-BUILD-VARIANT-CONDITION":
                variation_point.addPostBuildVariantCondition(self.readPostBuildVariantCondition(child_element, PostBuildVariantCondition()))
            else:
                self.notImplemented("Unsupported POST-BUILD-VARIANT-CONDITIONS content <%s>" % tag_name)
        sdg_element = self.find(element, "SDG")
        if sdg_element is not None:
            variation_point.setSdg(self.getSdg(sdg_element))
        return variation_point

    def readVariationPointCapable(self, element: ET.Element, obj):
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(obj, VariationPointCapable):
                obj.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readAdminDataSdgs(self, element: ET.Element, admin_data: AdminData):
        for child_element in self.findall(element, "SDGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SDG":
                admin_data.addSdg(self.getSdg(child_element))
            else:
                self.notImplemented("Unsupported SDG <%s>" % tag_name)

    def readModification(self, element: ET.Element, modification: Modification):
        modification.setChange(self.getMultiLanguageOverviewParagraph(element, "CHANGE"))
        modification.setReason(self.getMultiLanguageOverviewParagraph(element, "REASON"))

    def readDocRevisionModifications(self, element: ET.Element, revision: DocRevision):
        for child_element in self.findall(element, "MODIFICATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODIFICATION":
                modification = Modification()
                self.readModification(child_element, modification)
                revision.addModification(modification)
            else:
                self.notImplemented("Unsupported Modification <%s>" % tag_name)

    def readDocRevision(self, element: ET.Element, revision: DocRevision):
        revision.setDate(self.getChildElementOptionalDateTime(element, "DATE"))
        revision.setIssuedBy(self.getChildElementOptionalLiteral(element, "ISSUED-BY"))
        revision.setRevisionLabel(self.getChildElementOptionalRevisionLabelString(element, "REVISION-LABEL"))
        revision.setRevisionLabelP1(self.getChildElementOptionalRevisionLabelString(element, "REVISION-LABEL-P-1"))
        revision.setRevisionLabelP2(self.getChildElementOptionalRevisionLabelString(element, "REVISION-LABEL-P-2"))
        revision.setState(self.getChildElementOptionalLiteral(element, "STATE"))

        self.readDocRevisionModifications(element, revision)

    def readAdminDataDocRevisions(self, element: ET.Element, admin_data: AdminData):
        for child_element in self.findall(element, "DOC-REVISIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DOC-REVISION":
                revision = DocRevision()
                self.readDocRevision(child_element, revision)
                admin_data.addDocRevision(revision)
            else:
                self.notImplemented("Unsupported DocRevision <%s>" % tag_name)

    def getAdminData(self, element: ET.Element, key: str) -> AdminData:
        admin_data = None
        child_element = self.find(element, key)
        if child_element is not None:
            # self.logger.debug("Read AdminData")
            admin_data = AdminData()
            self.readARObject(child_element, admin_data)
            admin_data.setLanguage(self.getChildElementOptionalLiteral(child_element, "LANGUAGE"))
            admin_data.setUsedLanguages(self.getMultiLanguagePlainText(child_element, "USED-LANGUAGES"))

            self.readAdminDataSdgs(child_element, admin_data)
            self.readAdminDataDocRevisions(child_element, admin_data)
        return admin_data

    def getFileInfoComment(self, element: ET.Element, key: str) -> FileInfoComment:
        file_info_comment = None
        child_element = self.find(element, key)
        if child_element is not None:
            file_info_comment = FileInfoComment()
            self.readARObject(child_element, file_info_comment)
            for sdg_element in self.findall(child_element, "SDGS/*"):
                tag_name = self.getTagName(sdg_element)
                if tag_name == "SDG":
                    file_info_comment.addSdg(self.getSdg(sdg_element))
                else:
                    self.notImplemented("Unsupported SDG <%s>" % tag_name)
        return file_info_comment

    def getShortNameFragments(self, element: ET.Element, key: str) -> List[ShortNameFragment]:
        fragments = []
        for child_element in self.findall(element, "%s/SHORT-NAME-FRAGMENT" % key):
            fragment = ShortNameFragment()
            self.readARObject(child_element, fragment)
            fragment.setRole(self.getChildElementOptionalString(child_element, "ROLE"))
            fragment.setFragment(self.getChildElementOptionalIdentifier(child_element, "FRAGMENT"))
            fragments.append(fragment)
        return fragments

    def readReferrable(self, element: ET.Element, referrable: Referrable):
        self.readARObject(element, referrable)

        if isinstance(referrable, Referrable):
            for fragment in self.getShortNameFragments(element, "SHORT-NAME-FRAGMENTS"):
                referrable.addShortNameFragment(fragment)

    def readMultilanguageReferrable(self, element: ET.Element, referrable: MultilanguageReferrable):
        self.readReferrable(element, referrable)
        referrable.setLongName(self.getMultilanguageLongName(element, "LONG-NAME"))

    def readSingleLanguageReferrable(self, element: ET.Element, referrable: SingleLanguageReferrable):
        self.readReferrable(element, referrable)
        referrable.setLongName1(self.getSingleLanguageLongName(element, "LONG-NAME-1"))

    def getCaption(self, element: ET.Element, key: str) -> Caption:
        caption = None
        child_element = self.find(element, key)
        if child_element is not None:
            caption = Caption(None, self.getShortName(child_element))
            self.readMultilanguageReferrable(child_element, caption)
            caption.setDesc(self.getMultiLanguageOverviewParagraph(child_element, "DESC"))
        return caption

    def readIdentifiable(self, element: ET.Element, identifiable: Identifiable):
        self.readMultilanguageReferrable(element, identifiable)

        for annotation in self.getAnnotations(element):
            identifiable.addAnnotation(annotation)

        identifiable.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        identifiable.setDesc(self.getMultiLanguageOverviewParagraph(element, "DESC"))
        identifiable.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))

        identifiable.setAdminData(self.getAdminData(element, "ADMIN-DATA"))

        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(identifiable, VariationPointCapable):
                identifiable.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

        # The uuid attribute (AUTOSAR_FO_TPS_GenericStructureTemplate, Table 4.4) is
        # owned by Identifiable. It is read here and populated *before* the object is
        # registered with the UUID manager via addARObject() (the registration moved
        # here from readARObject with the uuid move — see the ordering trap
        # in docs/plan/sync-todo/Group1.md "uuid move work order" step 3).
        uuid_value = self.readElementOptionalAttrib(element, "UUID")
        if uuid_value is not None:
            uuid = String()
            uuid.setValue(uuid_value)
            identifiable.setUuid(uuid)
        AUTOSAR.getInstance().addARObject(identifiable)

    def readARElement(self, element: ET.Element, ar_element: ARElement):
        self.readIdentifiable(element, ar_element)

    def readLLongName(self, element: ET.Element, long_name: MultilanguageLongName):
        for child_element in self.findall(element, "L-4"):
            l4 = LLongName()
            l4.setValue(child_element.text)
            if "L" in child_element.attrib:
                l4.setL(child_element.attrib["L"])  # noqa: E741
            self.readMixedContentForLongName(child_element, l4)
            long_name.addL4(l4)

    def readMixedContentForLongName(self, element: ET.Element, content: MixedContentForLongName):
        self.readARObject(element, content)
        if "SUP" in element.attrib:
            content.setSup(Superscript().setValue(element.attrib["SUP"]))
        if "SUB" in element.attrib:
            content.setSub(Superscript().setValue(element.attrib["SUB"]))
        for inline in element:
            tag_name = self.getTagName(inline)
            if tag_name == "E":
                content.setE(self.readEmphasisText(inline))
            elif tag_name == "IE":
                content.setIe(self.readIndexEntry(inline))
            elif tag_name == "TT":
                content.setTt(self.readTt(inline))

    def getBr(self, element: ET.Element, key: str) -> Br:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        br = Br()
        self.readARObject(child_element, br)
        return br

    def getStd(self, element: ET.Element, key: str) -> Std:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        std = Std(None, "STD")
        self.readSingleLanguageReferrable(child_element, std)
        if "DATE" in child_element.attrib:
            std.setDate(DateTime().setValue(child_element.attrib["DATE"]))
        if "POSITION" in child_element.attrib:
            std.setPosition(String().setValue(child_element.attrib["POSITION"]))
        if "STATE" in child_element.attrib:
            std.setState(String().setValue(child_element.attrib["STATE"]))
        if "SUBTITLE" in child_element.attrib:
            std.setSubtitle(String().setValue(child_element.attrib["SUBTITLE"]))
        std.setUrl(self.getUrl(child_element, "URL"))
        return std

    def getXdoc(self, element: ET.Element, key: str) -> Xdoc:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        xdoc = Xdoc(None, "XDOC")
        self.readSingleLanguageReferrable(child_element, xdoc)
        if "DATE" in child_element.attrib:
            xdoc.setDate(DateTime().setValue(child_element.attrib["DATE"]))
        if "NUMBER" in child_element.attrib:
            xdoc.setNumber(String().setValue(child_element.attrib["NUMBER"]))
        if "POSITION" in child_element.attrib:
            xdoc.setPosition(String().setValue(child_element.attrib["POSITION"]))
        if "PUBLISHER" in child_element.attrib:
            xdoc.setPublisher(String().setValue(child_element.attrib["PUBLISHER"]))
        if "STATE" in child_element.attrib:
            xdoc.setState(String().setValue(child_element.attrib["STATE"]))
        xdoc.setUrl(self.getUrl(child_element, "URL"))
        return xdoc

    def getXfile(self, element: ET.Element, key: str) -> Xfile:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        xfile = Xfile(None, "XFILE")
        self.readSingleLanguageReferrable(child_element, xfile)
        xfile.setUrl(self.getUrl(child_element, "URL"))
        xfile.setTool(self.getChildElementOptionalString(child_element, "TOOL"))
        xfile.setToolVersion(self.getChildElementOptionalString(child_element, "TOOL-VERSION"))
        return xfile

    def getXrefTarget(self, element: ET.Element, key: str) -> XrefTarget:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        target = XrefTarget(None, self.getShortName(child_element))
        self.readSingleLanguageReferrable(child_element, target)
        return target

    def getXref(self, element: ET.Element, key: str) -> Xref:
        child_element = self.find(element, key) if key != "." else element
        if child_element is None:
            return None

        xref = Xref()
        self.readARObject(child_element, xref)
        xref.setLabel1(self.getSingleLanguageLongName(child_element, "LABEL-1"))
        xref.setReferrableRef(self.getChildElementOptionalRefType(child_element, "REFERRABLE-REF"))
        if "RESOLUTION-POLICY" in child_element.attrib:
            xref.setResolutionPolicy(ResolutionPolicyEnum().setValue(child_element.attrib["RESOLUTION-POLICY"]))
        if "SHOW-CONTENT" in child_element.attrib:
            xref.setShowContent(ShowContentEnum().setValue(child_element.attrib["SHOW-CONTENT"]))
        if "SHOW-RESOURCE-ALIAS-NAME" in child_element.attrib:
            xref.setShowResourceAliasName(ShowResourceAliasNameEnum().setValue(child_element.attrib["SHOW-RESOURCE-ALIAS-NAME"]))
        if "SHOW-RESOURCE-CATEGORY" in child_element.attrib:
            xref.setShowResourceCategory(ShowResourceCategoryEnum().setValue(child_element.attrib["SHOW-RESOURCE-CATEGORY"]))
        if "SHOW-RESOURCE-LONG-NAME" in child_element.attrib:
            xref.setShowResourceLongName(ShowResourceLongNameEnum().setValue(child_element.attrib["SHOW-RESOURCE-LONG-NAME"]))
        if "SHOW-RESOURCE-NUMBER" in child_element.attrib:
            xref.setShowResourceNumber(ShowResourceNumberEnum().setValue(child_element.attrib["SHOW-RESOURCE-NUMBER"]))
        if "SHOW-RESOURCE-PAGE" in child_element.attrib:
            xref.setShowResourcePage(ShowResourcePageEnum().setValue(child_element.attrib["SHOW-RESOURCE-PAGE"]))
        if "SHOW-RESOURCE-SHORT-NAME" in child_element.attrib:
            xref.setShowResourceShortName(ShowResourceShortNameEnum().setValue(child_element.attrib["SHOW-RESOURCE-SHORT-NAME"]))
        if "SHOW-RESOURCE-TYPE" in child_element.attrib:
            xref.setShowResourceType(ShowResourceTypeEnum().setValue(child_element.attrib["SHOW-RESOURCE-TYPE"]))
        if "SHOW-SEE" in child_element.attrib:
            xref.setShowSee(ShowSeeEnum().setValue(child_element.attrib["SHOW-SEE"]))
        return xref

    def readMixedContentForParagraph(self, element: ET.Element, content):
        br = self.getBr(element, "BR")
        if br is not None:
            content.setBr(br)
        ft_element = self.find(element, "FT")
        if ft_element is not None:
            footnote = SlParagraph()
            self.readSlParagraph(ft_element, footnote)
            content.setFt(footnote)
        emphasis_element = self.find(element, "E")
        if emphasis_element is not None:
            content.setE(self.readEmphasisText(emphasis_element))
        index_element = self.find(element, "IE")
        if index_element is not None:
            content.setIe(self.readIndexEntry(index_element))
        std = self.getStd(element, "STD")
        if std is not None:
            content.setStd(std)
        if "SUB" in element.attrib:
            content.setSub(Superscript().setValue(element.attrib["SUB"]))
        if "SUP" in element.attrib:
            content.setSup(Superscript().setValue(element.attrib["SUP"]))
        content.setTraceRef(self.getChildElementOptionalRefType(element, "TRACE-REF"))
        tt_element = self.find(element, "TT")
        if tt_element is not None:
            content.setTt(self.readTt(tt_element))
        xdoc = self.getXdoc(element, "XDOC")
        if xdoc is not None:
            content.setXdoc(xdoc)
        xfile = self.getXfile(element, "XFILE")
        if xfile is not None:
            content.setXfile(xfile)
        xref = self.getXref(element, "XREF")
        if xref is not None:
            content.setXref(xref)
        xref_target = self.getXrefTarget(element, "XREF-TARGET")
        if xref_target is not None:
            content.setXrefTarget(xref_target)

    def readSlParagraph(self, element: ET.Element, paragraph: SlParagraph):
        self.readARObject(element, paragraph)
        self.readMixedContentForParagraph(element, paragraph)
        paragraph.setValue(element.text or "")
        if "L" in element.attrib:
            paragraph.setL(element.attrib["L"])

    def readEmphasisText(self, element: ET.Element) -> EmphasisText:
        emphasis = EmphasisText()
        if element.text is not None:
            emphasis.setValue(String().setValue(element.text))
        if "COLOR" in element.attrib:
            emphasis.setColor(String().setValue(element.attrib["COLOR"]))
        if "SUP" in element.attrib:
            emphasis.setSup(Superscript().setValue(element.attrib["SUP"]))
        if "SUB" in element.attrib:
            emphasis.setSub(Superscript().setValue(element.attrib["SUB"]))
        for inline in element:
            tag_name = self.getTagName(inline)
            if tag_name == "TT":
                emphasis.setTt(self.readTt(inline))
        return emphasis

    def readIndexEntry(self, element: ET.Element) -> IndexEntry:
        index_entry = IndexEntry()
        if element.text is not None:
            index_entry.setValue(String().setValue(element.text))
        if "SUP" in element.attrib:
            index_entry.setSup(Superscript().setValue(element.attrib["SUP"]))
        if "SUB" in element.attrib:
            index_entry.setSub(Superscript().setValue(element.attrib["SUB"]))
        return index_entry

    def readTt(self, element: ET.Element) -> Tt:
        tt = Tt()
        if element.text is not None:
            tt.setValue(String().setValue(element.text))
        if "TYPE" in element.attrib:
            tt.setType(NameToken().setValue(element.attrib["TYPE"]))
        if "TEX-RENDER" in element.attrib:
            tt.setTexRender(String().setValue(element.attrib["TEX-RENDER"]))
        return tt

    def getMultilanguageLongName(self, element: ET.Element, key: str) -> MultilanguageLongName:
        long_name = None
        child_element = self.find(element, "%s" % key)
        if child_element is not None:
            long_name = MultilanguageLongName()
            self.readARObject(child_element, long_name)
            self.readLLongName(child_element, long_name)
        return long_name

    def readSingleLanguageLongName(self, element: ET.Element, long_name: SingleLanguageLongName):
        self.readMixedStringText(element, long_name)
        self.readMixedContentForLongName(element, long_name)

    def getSingleLanguageLongName(self, element: ET.Element, key: str) -> SingleLanguageLongName:
        long_name = None
        child_element = self.find(element, key)
        if child_element is not None:
            long_name = SingleLanguageLongName()
            self.readSingleLanguageLongName(child_element, long_name)
        return long_name

    def readSingleLanguageUnitNames(self, element: ET.Element, unit_names: SingleLanguageUnitNames):
        self.readMixedStringText(element, unit_names)
        self.readMixedContentForUnitNames(element, unit_names)

    def getSingleLanguageUnitNames(self, element: ET.Element, key: str) -> SingleLanguageUnitNames:
        unit_names = None
        child_element = self.find(element, key)
        if child_element is not None:
            unit_names = SingleLanguageUnitNames()
            self.readSingleLanguageUnitNames(child_element, unit_names)
        return unit_names

    def readMixedContentForUnitNames(self, element: ET.Element, content: MixedContentForUnitNames):
        self.readARObject(element, content)
        if "SUP" in element.attrib:
            content.setSup(Superscript().setValue(element.attrib["SUP"]))
        if "SUB" in element.attrib:
            content.setSub(Superscript().setValue(element.attrib["SUB"]))

    def readMixedContentForOverviewParagraph(self, element: ET.Element, content: MixedContentForOverviewParagraph):
        br = self.getBr(element, "BR")
        if br is not None:
            content.setBr(br)
        ft_element = self.find(element, "FT")
        if ft_element is not None:
            footnote = SlOverviewParagraph()
            self.readSlOverviewParagraph(ft_element, footnote)
            content.setFt(footnote)
        emphasis_element = self.find(element, "E")
        if emphasis_element is not None:
            content.setE(self.readEmphasisText(emphasis_element))
        index_element = self.find(element, "IE")
        if index_element is not None:
            content.setIe(self.readIndexEntry(index_element))
        if "SUB" in element.attrib:
            content.setSub(Superscript().setValue(element.attrib["SUB"]))
        if "SUP" in element.attrib:
            content.setSup(Superscript().setValue(element.attrib["SUP"]))
        content.setTraceRef(self.getChildElementOptionalRefType(element, "TRACE-REF"))
        tt_element = self.find(element, "TT")
        if tt_element is not None:
            content.setTt(self.readTt(tt_element))
        xref = self.getXref(element, "XREF")
        if xref is not None:
            content.setXref(xref)
        xref_target = self.getXrefTarget(element, "XREF-TARGET")
        if xref_target is not None:
            content.setXrefTarget(xref_target)

    def readSlOverviewParagraph(self, element: ET.Element, paragraph: SlOverviewParagraph):
        self.readARObject(element, paragraph)
        self.readMixedContentForOverviewParagraph(element, paragraph)
        self.readMixedStringText(element, paragraph)
        if "L" in element.attrib:
            paragraph.setL(element.attrib["L"])

    def readMixedContentForVerbatim(self, element: ET.Element, content: MixedContentForVerbatim):
        br = self.getBr(element, "BR")
        if br is not None:
            content.setBr(br)
        emphasis_element = self.find(element, "E")
        if emphasis_element is not None:
            content.setE(self.readEmphasisText(emphasis_element))
        tt_element = self.find(element, "TT")
        if tt_element is not None:
            content.setTt(self.readTt(tt_element))
        xref = self.getXref(element, "XREF")
        if xref is not None:
            content.setXref(xref)

    def readLOverviewParagraph(self, element: ET.Element, paragraph: MultiLanguageOverviewParagraph):
        for child_element in self.findall(element, "L-2"):
            l2 = LOverviewParagraph()
            self.readARObject(child_element, l2)
            l2.setValue(child_element.text)
            if "L" in child_element.attrib:
                l2.setL(child_element.attrib["L"])  # noqa: E741
            if "BLUEPRINT-VALUE" in child_element.attrib:
                l2.setBlueprintValue(String().setValue(child_element.attrib["BLUEPRINT-VALUE"]))
            self.readMixedContentForOverviewParagraph(child_element, l2)
            paragraph.addL2(l2)

    def getMultiLanguageOverviewParagraph(self, element: ET.Element, key: str) -> MultiLanguageOverviewParagraph:
        paragraph = None
        child_element = self.find(element, key)
        if child_element is not None:
            paragraph = MultiLanguageOverviewParagraph()
            self.readARObject(child_element, paragraph)
            self.readLOverviewParagraph(child_element, paragraph)
        return paragraph

    def getVariableInAtomicSWCTypeInstanceRef(self, element: ET.Element) -> VariableInAtomicSWCTypeInstanceRef:
        instance_ref = None
        if element is not None:
            instance_ref = VariableInAtomicSWCTypeInstanceRef()
            self.readARObject(element, instance_ref)
            instance_ref.setPortPrototypeRef(self.getChildElementOptionalRefType(element, "PORT-PROTOTYPE-REF"))
            instance_ref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-REF"))
        return instance_ref

    def getComponentInSystemInstanceRef(self, element: ET.Element) -> ComponentInSystemInstanceRef:
        instance_ref = None
        if element is not None:
            instance_ref = ComponentInSystemInstanceRef()
            self.readARObject(element, instance_ref)
            instance_ref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
            instance_ref.setContextCompositionRef(self.getChildElementOptionalRefType(element, "CONTEXT-COMPOSITION-REF"))
            for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
                instance_ref.addContextComponentRef(ref)
            instance_ref.setTargetComponentRef(self.getChildElementOptionalRefType(element, "TARGET-COMPONENT-REF"))
        return instance_ref

    def getOperationInSystemInstanceRef(self, element: ET.Element) -> OperationInSystemInstanceRef:
        instance_ref = None
        if element is not None:
            instance_ref = OperationInSystemInstanceRef()
            self.readARObject(element, instance_ref)
            instance_ref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
            instance_ref.setContextCompositionRef(self.getChildElementOptionalRefType(element, "CONTEXT-COMPOSITION-REF"))
            for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
                instance_ref.addContextComponentRef(ref)
            instance_ref.setContextPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-REF"))
            instance_ref.setTargetOperationRef(self.getChildElementOptionalRefType(element, "TARGET-OPERATION-REF"))
        return instance_ref

    def getPortGroupInSystemInstanceRef(self, element: ET.Element) -> PortGroupInSystemInstanceRef:
        instance_ref = None
        if element is not None:
            instance_ref = PortGroupInSystemInstanceRef()
            self.readARObject(element, instance_ref)
            instance_ref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
            instance_ref.setContextCompositionRef(self.getChildElementOptionalRefType(element, "CONTEXT-COMPOSITION-REF"))
            for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
                instance_ref.addContextComponentRef(ref)
            instance_ref.setTargetRef(self.getChildElementOptionalRefType(element, "TARGET-REF"))
        return instance_ref

    def getAutosarVariableRef(self, element: ET.Element, key: str) -> AutosarVariableRef:
        child_element = self.find(element, key)
        instance_ref = None
        if child_element is not None:
            instance_ref = AutosarVariableRef()
            self.readARObject(child_element, instance_ref)
            implementation_ref_element = self.find(child_element, "AUTOSAR-VARIABLE-IN-IMPL-DATATYPE")
            if implementation_ref_element is not None:
                implementation_ref = ArVariableInImplementationDataInstanceRef()
                implementation_ref.setPortPrototypeRef(self.getChildElementOptionalRefType(implementation_ref_element, "PORT-PROTOTYPE-REF"))
                implementation_ref.setRootVariableDataPrototypeRef(self.getChildElementOptionalRefType(implementation_ref_element, "ROOT-VARIABLE-DATA-PROTOTYPE-REF"))
                for ref in self.getChildElementRefTypeList(implementation_ref_element, "CONTEXT-DATA-PROTOTYPE-REF"):
                    implementation_ref.addContextDataPrototypeRef(ref)
                implementation_ref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(implementation_ref_element, "TARGET-DATA-PROTOTYPE-REF"))
                instance_ref.setAutosarVariableInImplDatatype(implementation_ref)
            instance_ref.setAutosarVariableIRef(self.getVariableInAtomicSWCTypeInstanceRef(self.find(child_element, "AUTOSAR-VARIABLE-IREF")))
            instance_ref.setLocalVariableRef(self.getChildElementOptionalRefType(child_element, "LOCAL-VARIABLE-REF"))
        return instance_ref

    def getNvBlockDataMapping(self, element: ET.Element, key: str) -> NvBlockDataMapping:
        child_element = self.find(element, key)
        mapping = None
        if child_element is not None:
            mapping = NvBlockDataMapping()
            self.readNvBlockDataMapping(child_element, mapping)
        return mapping

    def readNvBlockDataMapping(self, element: ET.Element, mapping: NvBlockDataMapping):
        self.readARObject(element, mapping)
        mapping.setBitfieldTextTableMaskNvBlockDescriptor(self.getChildElementOptionalPositiveInteger(element, "BITFIELD-TEXT-TABLE-MASK-NV-BLOCK-DESCRIPTOR"))
        mapping.setBitfieldTextTableMaskPortPrototype(self.getChildElementOptionalPositiveInteger(element, "BITFIELD-TEXT-TABLE-MASK-PORT-PROTOTYPE"))
        mapping.setNvRamBlockElement(self.getAutosarVariableRef(element, "NV-RAM-BLOCK-ELEMENT"))
        mapping.setReadNvData(self.getAutosarVariableRef(element, "READ-NV-DATA"))
        mapping.setWrittenNvData(self.getAutosarVariableRef(element, "WRITTEN-NV-DATA"))
        mapping.setWrittenReadNvData(self.getAutosarVariableRef(element, "WRITTEN-READ-NV-DATA"))
        self.readVariationPointCapable(element, mapping)

    def readBulkNvDataDescriptor(self, element: ET.Element, descriptor: BulkNvDataDescriptor):
        self.readIdentifiable(element, descriptor)
        child_element = self.find(element, "BULK-NV-BLOCK")
        if child_element is not None:
            prototype_element = self.find(child_element, "VARIABLE-DATA-PROTOTYPE")
            block = descriptor.createBulkNvBlock(self.getShortName(prototype_element))
            self.readVariableDataPrototype(prototype_element, block)
        for child_element in self.findall(element, "NV-BLOCK-DATA-MAPPINGS/NV-BLOCK-DATA-MAPPING"):
            mapping = NvBlockDataMapping()
            self.readNvBlockDataMapping(child_element, mapping)
            descriptor.addNvBlockDataMapping(mapping)

    def readNvBlockDescriptor(self, element: ET.Element, descriptor: NvBlockDescriptor):
        self.readIdentifiable(element, descriptor)
        for child_element in self.findall(element, "CLIENT-SERVER-PORTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-PORT-ASSIGNMENT":
                descriptor.addClientServerPort(self.getRoleBasedPortAssignment(child_element))
            else:
                self.notImplemented("Unsupported client server port <%s>" % tag_name)
        for ref in self.getChildElementRefTypeList(element, "CONSTANT-VALUE-MAPPING-REFS/CONSTANT-VALUE-MAPPING-REF"):
            descriptor.addConstantValueMappingRef(ref)
        for ref in self.getChildElementRefTypeList(element, "DATA-TYPE-MAPPING-REFS/DATA-TYPE-MAPPING-REF"):
            descriptor.addDataTypeMappingRef(ref)
        for child_element in self.findall(element, "INSTANTIATION-DATA-DEF-PROPSS/INSTANTIATION-DATA-DEF-PROPS"):
            props = InstantiationDataDefProps()
            self.readARObject(child_element, props)
            props.setParameterInstance(self.getAutosarParameterRef(child_element, "PARAMETER-INSTANCE"))
            props.setSwDataDefProps(self.getSwDataDefProps(child_element, "SW-DATA-DEF-PROPS"))
            props.setVariableInstance(self.getAutosarVariableRef(child_element, "VARIABLE-INSTANCE"))
            self.readVariationPointCapable(child_element, props)
            descriptor.addInstantiationDataDefProps(props)
        for child_element in self.findall(element, "MODE-SWITCH-EVENT-TRIGGERED-ACTIVITYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODE-SWITCH-EVENT-TRIGGERED-ACTIVITY":
                descriptor.addModeSwitchEventTriggeredActivity(self.getModeSwitchEventTriggeredActivity(child_element))
            else:
                self.notImplemented("Unsupported mode switch event triggered activity <%s>" % tag_name)
        for child_element in self.findall(element, "NV-BLOCK-DATA-MAPPINGS/NV-BLOCK-DATA-MAPPING"):
            mapping = NvBlockDataMapping()
            self.readNvBlockDataMapping(child_element, mapping)
            descriptor.addNvBlockDataMapping(mapping)
        needs_element = self.find(element, "NV-BLOCK-NEEDS")
        if needs_element is not None:
            needs = descriptor.createNvBlockNeeds(self.getShortName(needs_element))
            self.readNvBlockNeeds(needs_element, needs)
        ram_block_element = self.find(element, "RAM-BLOCK")
        if ram_block_element is not None:
            ram_block = descriptor.createRamBlock(self.getShortName(ram_block_element))
            self.readVariableDataPrototype(ram_block_element, ram_block)
        rom_block_element = self.find(element, "ROM-BLOCK")
        if rom_block_element is not None:
            rom_block = descriptor.createRomBlock(self.getShortName(rom_block_element))
            self.readParameterDataPrototype(rom_block_element, rom_block)
        descriptor.setSupportDirtyFlag(self.getChildElementOptionalBooleanValue(element, "SUPPORT-DIRTY-FLAG"))
        descriptor.setTimingEventRef(self.getChildElementOptionalRefType(element, "TIMING-EVENT-REF"))
        for child_element in self.findall(element, "WRITING-STRATEGYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-DATA-ASSIGNMENT":
                descriptor.addWritingStrategy(self.getRoleBasedDataAssignment(child_element))
            else:
                self.notImplemented("Unsupported writing strategy <%s>" % tag_name)

    def readVariableAccesses(self, element: ET.Element, parent: RunnableEntity, key: str):
        for child_element in self.findall(element, "%s/VARIABLE-ACCESS" % key):
            short_name = self.getShortName(child_element)

            # self.logger.debug("Read VariableAccesses %s" % short_name)
            supported = True

            if key == "DATA-RECEIVE-POINT-BY-ARGUMENTS":
                variable_access = parent.createDataReceivePointByArgument(short_name)
            elif key == "DATA-RECEIVE-POINT-BY-VALUES":
                variable_access = parent.createDataReceivePointByValue(short_name)
            elif key == "DATA-READ-ACCESSS":
                variable_access = parent.createDataReadAccess(short_name)
            elif key == "DATA-WRITE-ACCESSS":
                variable_access = parent.createDataWriteAccess(short_name)
            elif key == "DATA-SEND-POINTS":
                variable_access = parent.createDataSendPoint(short_name)
            elif key == "WRITTEN-LOCAL-VARIABLES":
                variable_access = parent.createWrittenLocalVariable(short_name)
            elif key == "READ-LOCAL-VARIABLES":
                variable_access = parent.createReadLocalVariable(short_name)
            else:
                self.notImplemented("Unsupported Variable Accesss <%s>" % key)
                supported = False

            if supported:
                self.readVariableAccess(child_element, variable_access)

    def readBswModuleDescriptionImplementedEntryRefs(self, element: ET.Element, parent: BswModuleDescription):
        for child_element in self.findall(element, "PROVIDED-ENTRYS/BSW-MODULE-ENTRY-REF-CONDITIONAL"):
            ref = self.getChildElementOptionalRefType(child_element, "BSW-MODULE-ENTRY-REF")
            if ref is not None:
                parent.addImplementedEntryRef(ref)
            # self.logger.debug("ImplementedEntry <%s> of BswModuleDescription <%s> has been added", ref.value, parent.getShortName())

    def readModeDeclarationGroupPrototype(self, element: ET.Element, prototype: ModeDeclarationGroupPrototype):
        self.readIdentifiable(element, prototype)
        prototype.setTypeTRef(self.getChildElementOptionalRefType(element, "TYPE-TREF"))
        sw_calibration_access = self.getChildElementOptionalLiteral(element, "SW-CALIBRATION-ACCESS")
        if sw_calibration_access is not None:
            prototype.setSwCalibrationAccess(SwCalibrationAccessEnum().setValue(sw_calibration_access.getValue()))

    def readBswModuleDescriptionProvidedModeGroups(self, element: ET.Element, parent: BswModuleDescription):
        for child_element in self.findall(element, "PROVIDED-MODE-GROUPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODE-DECLARATION-GROUP-PROTOTYPE":
                mode_group = parent.createProvidedModeGroup(self.getShortName(child_element))
                self.readModeDeclarationGroupPrototype(child_element, mode_group)
            else:
                self.notImplemented("Unsupported ProvidedModeGroup <%s>" % tag_name)

    def readBswModuleDescriptionRequiredModeGroups(self, element: ET.Element, parent: BswModuleDescription):
        for child_element in self.findall(element, "REQUIRED-MODE-GROUPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODE-DECLARATION-GROUP-PROTOTYPE":
                prototype = parent.createRequiredModeGroup(self.getShortName(child_element))
                self.readModeDeclarationGroupPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported RequiredModeGroup <%s>" % tag_name)

    def readActivationReasons(self, element: ET.Element, entity: ExecutableEntity):
        for reason_element in self.findall(element, "ACTIVATION-REASONS/EXECUTABLE-ENTITY-ACTIVATION-REASON"):
            reason = entity.createActivationReason(self.getShortName(reason_element))
            self.readExecutableEntityActivationReason(reason_element, reason)

    def readExecutableEntityActivationReason(self, element: ET.Element, reason: ExecutableEntityActivationReason):
        self.readImplementationProps(element, reason)
        reason.setBitPosition(self.getChildElementOptionalPositiveInteger(element, "BIT-POSITION"))

    def readCanEnterRefs(self, element: ET.Element, entity: ExecutableEntity):
        for ref in self.getChildElementRefTypeList(element, "CAN-ENTER-EXCLUSIVE-AREA-REFS/CAN-ENTER-EXCLUSIVE-AREA-REF"):
            entity.addCanEnterRef(ref)

    def readExclusiveAreaNestingOrderRefs(self, element: ET.Element, entity: ExecutableEntity):
        for ref in self.getChildElementRefTypeList(element, "EXCLUSIVE-AREA-NESTING-ORDER-REFS/EXCLUSIVE-AREA-NESTING-ORDER-REF"):
            entity.addExclusiveAreaNestingOrderRef(ref)

    def readRunsInsideRefs(self, element: ET.Element, entity: ExecutableEntity):
        for ref in self.getChildElementRefTypeList(element, "RUNS-INSIDE-EXCLUSIVE-AREA-REFS/RUNS-INSIDE-EXCLUSIVE-AREA-REF"):
            entity.addRunsInsideRef(ref)

    def readExecutableEntity(self, element: ET.Element, entity: ExecutableEntity):
        # self.logger.debug("Read ExecutableEntity %s" % entity.getShortName())
        self.readIdentifiable(element, entity)
        self.readActivationReasons(element, entity)
        self.readCanEnterRefs(element, entity)
        self.readExclusiveAreaNestingOrderRefs(element, entity)
        entity.setMinimumStartInterval(self.getChildElementOptionalTimeValue(element, "MINIMUM-START-INTERVAL"))
        entity.setReentrancyLevel(self.getChildElementOptionalLiteral(element, "REENTRANCY-LEVEL"))
        self.readRunsInsideRefs(element, entity)
        entity.setSwAddrMethodRef(self.getChildElementOptionalRefType(element, "SW-ADDR-METHOD-REF"))

    def readBswModuleEntityManagedModeGroups(self, element: ET.Element, entity: BswModuleEntity):
        for child_element in self.findall(element, "MANAGED-MODE-GROUPS/MODE-DECLARATION-GROUP-PROTOTYPE-REF-CONDITIONAL"):
            ref_type = self.getChildElementOptionalRefType(child_element, "MODE-DECLARATION-GROUP-PROTOTYPE-REF")
            if ref_type is not None:
                entity.addManagedModeGroupRef(ref_type)

    def readBswModuleEntityAccessedModeGroups(self, element: ET.Element, entity: BswModuleEntity):
        for child_element in self.findall(element, "ACCESSED-MODE-GROUPS/MODE-DECLARATION-GROUP-PROTOTYPE-REF-CONDITIONAL"):
            ref_type = self.getChildElementOptionalRefType(child_element, "MODE-DECLARATION-GROUP-PROTOTYPE-REF")
            if ref_type is not None:
                entity.addAccessedModeGroupRef(ref_type)

    def readBswEvent(self, element: ET.Element, event: BswScheduleEvent):
        event.activationReasonRepresentationRef = self.getChildElementOptionalRefType(element, "ACTIVATION-REASON-REPRESENTATION-REF")
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-LIMITATION-REFS/CONTEXT-LIMITATION-REF"):
            event.addContextLimitationRef(ref)
        for child_element in self.findall(element, "DISABLED-IN-MODE-IREFS/DISABLED-IN-MODE-IREF"):
            event.addDisabledInModeIRef(self.getModeInBswModuleDescriptionInstanceRef(child_element))
        event.setStartsOnEventRef(self.getChildElementOptionalRefType(element, "STARTS-ON-EVENT-REF"))

    def readBswScheduleEvent(self, element, event: BswScheduleEvent):
        self.readBswEvent(element, event)

    def readBswModeSwitchEvent(self, element: ET.Element, event: BswModeSwitchEvent):
        # self.logger.debug("Read BswModeSwitchEvent <%s>" % event.getShortName())
        # Read the Inherit BswScheduleEvent
        self.readBswScheduleEvent(element, event)
        event.setActivation(self.getChildElementOptionalLiteral(element, "ACTIVATION"))
        for child_element in self.findall(element, "MODE-IREFS/MODE-IREF"):
            event.addModeIRef(self.getModeInBswModuleDescriptionInstanceRef(child_element))

    def readBswModeManagerErrorEvent(self, element: ET.Element, event: BswModeManagerErrorEvent):
        # self.logger.debug("Read BswModeManagerErrorEvent <%s>" % event.getShortName())
        # Read the Inherit BswScheduleEvent
        self.readBswScheduleEvent(element, event)
        event.setModeGroupRef(self.getChildElementOptionalRefType(element, "MODE-GROUP-REF"))

    def readBswModeSwitchedAckEvent(self, element: ET.Element, event: BswModeSwitchedAckEvent):
        self.readBswScheduleEvent(element, event)
        event.setModeGroupRef(self.getChildElementOptionalRefType(element, "MODE-GROUP-REF"))

    def readBswAsynchronousServerCallReturnsEvent(self, element: ET.Element, event: BswAsynchronousServerCallReturnsEvent):
        self.readBswScheduleEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def readBswTimingEvent(self, element: ET.Element, event: BswTimingEvent):
        self.logger.debug("Read BswTimingEvent <%s>" % event.getShortName())
        # Read the Inherit BswScheduleEvent
        self.readBswScheduleEvent(element, event)
        event.setPeriod(self.getChildElementOptionalTimeValue(element, "PERIOD"))
        if event.getPeriod() is None:
            self.logger.warning("Period of BswTimingEvent <%s> is invalid." % event.getShortName())
        else:
            self.logger.debug(" Period: <%f, %s>" % (event.getPeriod().getValue(), event.getPeriod().getText()))

    def readBswDataReceivedEvent(self, element: ET.Element, event: BswDataReceivedEvent):
        # self.logger.debug("Read BswDataReceivedEvent <%s>" % event.getShortName())
        # Read the Inherit BswScheduleEvent
        self.readBswScheduleEvent(element, event)
        event.setDataRef(self.getChildElementOptionalRefType(element, "DATA-REF"))

    def readBswInternalTriggerOccurredEvent(self, element: ET.Element, event: BswInternalTriggerOccurredEvent):
        # self.logger.debug("Read BswInternalTriggerOccurredEvent <%s>" % event.getShortName())
        # Read the Inherit BswScheduleEvent
        self.readBswScheduleEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def getBswModeSenderPolicy(self, element: ET.Element) -> BswModeSenderPolicy:
        policy = BswModeSenderPolicy()
        policy.setAckRequest(self.getBswModeSwitchAckRequest(element, "ACK-REQUEST"))
        policy.setEnhancedModeApi(self.getChildElementOptionalBooleanValue(element, "ENHANCED-MODE-API"))
        policy.setProvidedModeGroupRef(self.getChildElementOptionalRefType(element, "PROVIDED-MODE-GROUP-REF"))
        policy.setQueueLength(self.getChildElementOptionalPositiveInteger(element, "QUEUE-LENGTH"))
        self.readVariationPointCapable(element, policy)
        return policy

    def getBswModeSwitchAckRequest(self, element: ET.Element, key: str) -> BswModeSwitchAckRequest:
        request = None
        child_element = self.find(element, key)
        if child_element is not None:
            request = BswModeSwitchAckRequest()
            request.setTimeout(self.getChildElementOptionalTimeValue(child_element, "TIMEOUT"))
        return request

    def readBswInternalBehaviorModeSenderPolicy(self, element: ET.Element, parent: BswInternalBehavior):
        for child_element in self.findall(element, "MODE-SENDER-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MODE-SENDER-POLICY":
                parent.addModeSenderPolicy(self.getBswModeSenderPolicy(child_element))
            else:
                self.raiseError("Unsupported ModeSenderPolicy type <%s>." % tag_name)

    def readDataTypeMappingRefs(self, element: ET.Element, behavior: InternalBehavior):
        child_element = self.find(element, "DATA-TYPE-MAPPING-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "DATA-TYPE-MAPPING-REF"):
                behavior.addDataTypeMappingRef(ref)

    def readInternalBehaviorConstantMemories(self, element: ET.Element, behavior: InternalBehavior):
        for child_element in self.findall(element, "CONSTANT-MEMORYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PARAMETER-DATA-PROTOTYPE":
                prototype = behavior.createConstantMemory(self.getShortName(child_element))
                self.readParameterDataPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported constant memories <%s>" % tag_name)

    def readInternalBehaviorStaticMemories(self, element: ET.Element, behavior: InternalBehavior):
        for child_element in self.findall(element, "STATIC-MEMORYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-DATA-PROTOTYPE":
                prototype = behavior.createStaticMemory(self.getShortName(child_element))
                self.readVariableDataPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported static memories <%s>" % tag_name)

    def readInternalBehavior(self, element: ET.Element, behavior: InternalBehavior):
        self.readIdentifiable(element, behavior)
        self.readInternalBehaviorConstantMemories(element, behavior)
        self.readInternalBehaviorConstantValueMappingRefs(element, behavior)
        for child_element in self.findall(element, "EXCLUSIVE-AREAS/EXCLUSIVE-AREA"):
            short_name = self.getShortName(child_element)
            behavior.createExclusiveArea(short_name)
        self.readExclusiveAreaNestingOrders(element, behavior)
        self.readDataTypeMappingRefs(element, behavior)
        self.readInternalBehaviorStaticMemories(element, behavior)

    def readInternalBehaviorConstantValueMappingRefs(self, element: ET.Element, behavior: InternalBehavior):
        child_element = self.find(element, "CONSTANT-VALUE-MAPPING-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "CONSTANT-VALUE-MAPPING-REF"):
                behavior.addConstantValueMappingRef(ref)

    def readExclusiveAreaNestingOrders(self, element: ET.Element, behavior: InternalBehavior):
        for child_element in self.findall(element, "EXCLUSIVE-AREA-NESTING-ORDERS/EXCLUSIVE-AREA-NESTING-ORDER"):
            short_name = self.getShortName(child_element)
            nesting_order = behavior.createExclusiveAreaNestingOrder(short_name)
            for ref in self.getChildElementRefTypeList(child_element, "EXCLUSIVE-AREA-REFS/EXCLUSIVE-AREA-REF"):
                nesting_order.addExclusiveAreaRef(ref)

    def getRoleBasedDataAssignment(self, element: ET.Element) -> RoleBasedDataAssignment:
        assignment = RoleBasedDataAssignment()
        self.readARObject(element, assignment)
        assignment.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        assignment.setUsedDataElement(self.getAutosarVariableRef(element, "USED-DATA-ELEMENT"))
        assignment.setUsedParameterElement(self.getAutosarParameterRef(element, "USED-PARAMETER-ELEMENT"))
        assignment.setUsedPimRef(self.getChildElementOptionalRefType(element, "USED-PIM-REF"))
        self.readVariationPointCapable(element, assignment)
        return assignment

    def getModeSwitchEventTriggeredActivity(self, element: ET.Element) -> ModeSwitchEventTriggeredActivity:
        activity = ModeSwitchEventTriggeredActivity()
        self.readARObject(element, activity)
        activity.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        activity.setSwcModeSwitchEventRef(self.getChildElementOptionalRefType(element, "SWC-MODE-SWITCH-EVENT-REF"))
        self.readVariationPointCapable(element, activity)
        return activity

    def getRoleBasedPortAssignment(self, element: ET.Element) -> RoleBasedPortAssignment:
        assignment = RoleBasedPortAssignment()
        self.readARObject(element, assignment)
        assignment.setPortPrototypeRef(self.getChildElementOptionalRefType(element, "PORT-PROTOTYPE-REF"))
        assignment.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        return assignment

    def getRoleBasedDataTypeAssignment(self, element: ET.Element) -> RoleBasedDataTypeAssignment:
        assignment = RoleBasedDataTypeAssignment()
        assignment.setRole(self.getChildElementOptionalLiteral(element, "ROLE"))
        assignment.setUsedImplementationDataTypeRef(self.getChildElementOptionalRefType(element, "USED-IMPLEMENTATION-DATA-TYPE-REF"))
        return assignment

    def readServiceDependency(self, element: ET.Element, dependency: ServiceDependency):
        self.readIdentifiable(element, dependency)
        for child_element in self.findall(element, "ASSIGNED-DATA-TYPES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-DATA-TYPE-ASSIGNMENT":
                dependency.setAssignedDataType(self.getRoleBasedDataTypeAssignment(child_element))
            else:
                self.notImplemented("Unsupported assigned data type <%s>" % tag_name)
        dependency.setDiagnosticRelevance(self.getChildElementOptionalLiteral(element, "DIAGNOSTIC-RELEVANCE"))
        self.readSymbolicNameProps(element, dependency)

    def getBswServiceDependencyIdent(self, element: ET.Element, dependency: BswServiceDependency) -> BswServiceDependencyIdent:
        ident_element = self.find(element, "IDENT")
        if ident_element is not None:
            return BswServiceDependencyIdent(dependency, self.getShortName(ident_element))
        return None

    def readSymbolicNameProps(self, element: ET.Element, dependency: ServiceDependency):
        props_element = self.find(element, "SYMBOLIC-NAME-PROPS")
        if props_element is None:
            return
        props = SymbolicNameProps(dependency, self.getShortName(props_element))
        self.readImplementationProps(props_element, props)
        dependency.setSymbolicNameProps(props)

    def getRoleBasedBswModuleEntryAssignment(self, element: ET.Element) -> RoleBasedBswModuleEntryAssignment:
        assignment = RoleBasedBswModuleEntryAssignment()
        assignment.setAssignedEntryRef(self.getChildElementOptionalRefType(element, "ASSIGNED-ENTRY-REF"))
        assignment.setRole(self.getChildElementOptionalLiteral(element, "ROLE"))
        self.readVariationPointCapable(element, assignment)
        return assignment

    def readBswServiceDependencyAssignedData(self, element: ET.Element, dependency: BswServiceDependency):
        for child_element in self.findall(element, "ASSIGNED-DATAS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-DATA-ASSIGNMENT":
                dependency.addAssignedData(self.getRoleBasedDataAssignment(child_element))
            else:
                self.notImplemented("Unsupported assigned data <%s>" % tag_name)

    def readBswServiceDependencyAssignedEntryRoles(self, element: ET.Element, dependency: BswServiceDependency):
        for child_element in self.findall(element, "ASSIGNED-ENTRY-ROLES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-BSW-MODULE-ENTRY-ASSIGNMENT":
                dependency.addAssignedEntryRole(self.getRoleBasedBswModuleEntryAssignment(child_element))
            else:
                self.notImplemented("Unsupported assigned entry role <%s>" % tag_name)

    def readBswServiceDependencyServiceNeeds(self, element: ET.Element, dependency: BswServiceDependency):
        needs_element = self.find(element, "SERVICE-NEEDS")
        if needs_element is None:
            return
        for child_element in self.findall(needs_element, "*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MGR-NEEDS":
                short_name = self.getShortName(child_element)
                needs = BswMgrNeeds(dependency, short_name)
                self.readBswMgrNeeds(child_element, needs)
            elif tag_name == "CRYPTO-KEY-MANAGEMENT-NEEDS":
                short_name = self.getShortName(child_element)
                needs = CryptoKeyManagementNeeds(dependency, short_name)
                self.readCryptoKeyManagementNeeds(child_element, needs)
            elif tag_name == "CRYPTO-SERVICE-JOB-NEEDS":
                short_name = self.getShortName(child_element)
                needs = CryptoServiceJobNeeds(dependency, short_name)
                self.readCryptoServiceJobNeeds(child_element, needs)
            elif tag_name == "NV-BLOCK-NEEDS":
                short_name = self.getShortName(child_element)
                needs = NvBlockNeeds(dependency, short_name)
                self.readNvBlockNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-COMMUNICATION-MANAGER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticCommunicationManagerNeeds(dependency, short_name)
                self.readDiagnosticCommunicationManagerNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-COMPONENT-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticComponentNeeds(dependency, short_name)
                self.readDiagnosticComponentNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-CONTROL-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticControlNeeds(dependency, short_name)
                self.readDiagnosticControlNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-UPLOAD-DOWNLOAD-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticUploadDownloadNeeds(dependency, short_name)
                self.readDiagnosticUploadDownloadNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTICS-COMMUNICATION-SECURITY-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticsCommunicationSecurityNeeds(dependency, short_name)
                self.readDiagnosticsCommunicationSecurityNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-ROUTINE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticRoutineNeeds(dependency, short_name)
                self.readDiagnosticRoutineNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-VALUE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticValueNeeds(dependency, short_name)
                self.readDiagnosticValueNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-EVENT-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticEventNeeds(dependency, short_name)
                self.readDiagnosticEventNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-EVENT-INFO-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticEventInfoNeeds(dependency, short_name)
                self.readDiagnosticEventInfoNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-IO-CONTROL-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticIoControlNeeds(dependency, short_name)
                self.readDiagnosticIoControlNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-ENABLE-CONDITION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticEnableConditionNeeds(dependency, short_name)
                self.readDiagnosticEnableConditionNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-EVENT-MANAGER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticEventManagerNeeds(dependency, short_name)
                self.readDiagnosticEventManagerNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-OPERATION-CYCLE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticOperationCycleNeeds(dependency, short_name)
                self.readDiagnosticOperationCycleNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-REQUEST-FILE-TRANSFER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticRequestFileTransferNeeds(dependency, short_name)
                self.readDiagnosticRequestFileTransferNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-STORAGE-CONDITION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DiagnosticStorageConditionNeeds(dependency, short_name)
                self.readDiagnosticStorageConditionNeeds(child_element, needs)
            elif tag_name == "INDICATOR-STATUS-NEEDS":
                short_name = self.getShortName(child_element)
                needs = IndicatorStatusNeeds(dependency, short_name)
                self.readIndicatorStatusNeeds(child_element, needs)
            elif tag_name == "J-1939-DCM-DM-19-SUPPORT":
                short_name = self.getShortName(child_element)
                needs = J1939DcmDm19Support(dependency, short_name)
                self.readJ1939DcmDm19Support(child_element, needs)
            elif tag_name == "J-1939-RM-INCOMING-REQUEST-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = J1939RmIncomingRequestServiceNeeds(dependency, short_name)
                self.readJ1939RmIncomingRequestServiceNeeds(child_element, needs)
            elif tag_name == "J-1939-RM-OUTGOING-REQUEST-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = J1939RmOutgoingRequestServiceNeeds(dependency, short_name)
                self.readJ1939RmOutgoingRequestServiceNeeds(child_element, needs)
            elif tag_name == "FUNCTION-INHIBITION-AVAILABILITY-NEEDS":
                short_name = self.getShortName(child_element)
                needs = FunctionInhibitionAvailabilityNeeds(dependency, short_name)
                self.readFunctionInhibitionAvailabilityNeeds(child_element, needs)
            elif tag_name == "FUNCTION-INHIBITION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = FunctionInhibitionNeeds(dependency, short_name)
                self.readFunctionInhibitionNeeds(child_element, needs)
            elif tag_name == "FURTHER-ACTION-BYTE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = FurtherActionByteNeeds(dependency, short_name)
                self.readFurtherActionByteNeeds(child_element, needs)
            elif tag_name == "GLOBAL-SUPERVISION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = GlobalSupervisionNeeds(dependency, short_name)
                self.readGlobalSupervisionNeeds(child_element, needs)
            elif tag_name == "HARDWARE-TEST-NEEDS":
                short_name = self.getShortName(child_element)
                needs = HardwareTestNeeds(dependency, short_name)
                self.readHardwareTestNeeds(child_element, needs)
            elif tag_name == "CRYPTO-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = CryptoServiceNeeds(dependency, short_name)
                self.readCryptoServiceNeeds(child_element, needs)
            elif tag_name == "ECU-STATE-MGR-USER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = EcuStateMgrUserNeeds(dependency, short_name)
                self.readEcuStateMgrUserNeeds(child_element, needs)
            elif tag_name == "DTC-STATUS-CHANGE-NOTIFICATION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DtcStatusChangeNotificationNeeds(dependency, short_name)
                self.readDtcStatusChangeNotificationNeeds(child_element, needs)
            elif tag_name == "DLT-USER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DltUserNeeds(dependency, short_name)
                self.readDltUserNeeds(child_element, needs)
            elif tag_name == "COM-MGR-USER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ComMgrUserNeeds(dependency, short_name)
                self.readComMgrUserNeeds(child_element, needs)
            elif tag_name == "SUPERVISED-ENTITY-CHECKPOINT-NEEDS":
                short_name = self.getShortName(child_element)
                needs = SupervisedEntityCheckpointNeeds(dependency, short_name)
                self.readSupervisedEntityCheckpointNeeds(child_element, needs)
            elif tag_name == "SUPERVISED-ENTITY-NEEDS":
                short_name = self.getShortName(child_element)
                needs = SupervisedEntityNeeds(dependency, short_name)
                self.readSupervisedEntityNeeds(child_element, needs)
            elif tag_name == "SYNC-TIME-BASE-MGR-USER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = SyncTimeBaseMgrUserNeeds(dependency, short_name)
                self.readSyncTimeBaseMgrUserNeeds(child_element, needs)
            elif tag_name == "V-2-X-DATA-MANAGER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = V2xDataManagerNeeds(dependency, short_name)
                self.readV2xDataManagerNeeds(child_element, needs)
            elif tag_name == "V-2-X-FAC-USER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = V2xFacUserNeeds(dependency, short_name)
                self.readV2xFacUserNeeds(child_element, needs)
            elif tag_name == "V-2-X-M-USER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = V2xMUserNeeds(dependency, short_name)
                self.readV2xMUserNeeds(child_element, needs)
            elif tag_name == "VENDOR-SPECIFIC-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = VendorSpecificServiceNeeds(dependency, short_name)
                self.readVendorSpecificServiceNeeds(child_element, needs)
            elif tag_name == "WARNING-INDICATOR-REQUESTED-BIT-NEEDS":
                short_name = self.getShortName(child_element)
                needs = WarningIndicatorRequestedBitNeeds(dependency, short_name)
                self.readWarningIndicatorRequestedBitNeeds(child_element, needs)
            elif tag_name == "ERROR-TRACER-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ErrorTracerNeeds(dependency, short_name)
                self.readErrorTracerNeeds(child_element, needs)
            elif tag_name == "OBD-INFO-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ObdInfoServiceNeeds(dependency, short_name)
                self.readObdInfoServiceNeeds(child_element, needs)
            elif tag_name == "OBD-MONITOR-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ObdMonitorServiceNeeds(dependency, short_name)
                self.readObdMonitorServiceNeeds(child_element, needs)
            elif tag_name == "OBD-PID-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ObdPidServiceNeeds(dependency, short_name)
                self.readObdPidServiceNeeds(child_element, needs)
            elif tag_name == "OBD-CONTROL-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ObdControlServiceNeeds(dependency, short_name)
                self.readObdControlServiceNeeds(child_element, needs)
            elif tag_name == "OBD-RATIO-SERVICE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ObdRatioServiceNeeds(dependency, short_name)
                self.readObdRatioServiceNeeds(child_element, needs)
            elif tag_name == "OBD-RATIO-DENOMINATOR-NEEDS":
                short_name = self.getShortName(child_element)
                needs = ObdRatioDenominatorNeeds(dependency, short_name)
                self.readObdRatioDenominatorNeeds(child_element, needs)
            elif tag_name == "DO-IP-ACTIVATION-LINE-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DoIpActivationLineNeeds(dependency, short_name)
                self.readDoIpActivationLineNeeds(child_element, needs)
            elif tag_name == "DO-IP-GID-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DoIpGidNeeds(dependency, short_name)
                self.readDoIpGidNeeds(child_element, needs)
            elif tag_name == "DO-IP-GID-SYNCHRONIZATION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DoIpGidSynchronizationNeeds(dependency, short_name)
                self.readDoIpGidSynchronizationNeeds(child_element, needs)
            elif tag_name == "DO-IP-POWER-MODE-STATUS-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DoIpPowerModeStatusNeeds(dependency, short_name)
                self.readDoIpPowerModeStatusNeeds(child_element, needs)
            elif tag_name == "DO-IP-ROUTING-ACTIVATION-AUTHENTICATION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DoIpRoutingActivationAuthenticationNeeds(dependency, short_name)
                self.readDoIpRoutingActivationAuthenticationNeeds(child_element, needs)
            elif tag_name == "DO-IP-ROUTING-ACTIVATION-CONFIRMATION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = DoIpRoutingActivationConfirmationNeeds(dependency, short_name)
                self.readDoIpRoutingActivationConfirmationNeeds(child_element, needs)
            elif tag_name == "SECURE-ON-BOARD-COMMUNICATION-NEEDS":
                short_name = self.getShortName(child_element)
                needs = SecureOnBoardCommunicationNeeds(dependency, short_name)
                self.readSecureOnBoardCommunicationNeeds(child_element, needs)
            elif tag_name == "IDS-MGR-CUSTOM-TIMESTAMP-NEEDS":
                short_name = self.getShortName(child_element)
                needs = IdsMgrCustomTimestampNeeds(dependency, short_name)
                self.readIdsMgrCustomTimestampNeeds(child_element, needs)
            elif tag_name == "IDS-MGR-NEEDS":
                short_name = self.getShortName(child_element)
                needs = IdsMgrNeeds(dependency, short_name)
                self.readIdsMgrNeeds(child_element, needs)
            else:
                self.notImplemented("Unsupported service needs <%s>" % tag_name)
                continue
            dependency.setServiceNeeds(needs)

    def readBswServiceDependency(self, element: ET.Element, dependency: BswServiceDependency):
        self.readARObject(element, dependency)
        dependency.setIdent(self.getBswServiceDependencyIdent(element, dependency))
        for child_element in self.findall(element, "ASSIGNED-DATA-TYPES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-DATA-TYPE-ASSIGNMENT":
                dependency.setAssignedDataType(self.getRoleBasedDataTypeAssignment(child_element))
            else:
                self.notImplemented("Unsupported assigned data type <%s>" % tag_name)
        self.readBswServiceDependencyAssignedData(element, dependency)
        self.readBswServiceDependencyAssignedEntryRoles(element, dependency)
        self.readBswServiceDependencyServiceNeeds(element, dependency)
        self.readSymbolicNameProps(element, dependency)

    def readSwcServiceDependencyAssignedData(self, element: ET.Element, dependency: SwcServiceDependency):
        for child_element in self.findall(element, "ASSIGNED-DATAS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-DATA-ASSIGNMENT":
                dependency.AddAssignedData(self.getRoleBasedDataAssignment(child_element))
            else:
                self.raiseError("Unsupported assigned data <%s>" % tag_name)

    def readSwcServiceDependencyAssignedPorts(self, element: ET.Element, dependency: SwcServiceDependency):
        for child_element in self.findall(element, "ASSIGNED-PORTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROLE-BASED-PORT-ASSIGNMENT":
                dependency.AddAssignedPort(self.getRoleBasedPortAssignment(child_element))
            else:
                self.raiseError("Unsupported assigned ports <%s>" % tag_name)

    def readServiceNeeds(self, element: ET.Element, needs: ServiceNeeds):
        self.readIdentifiable(element, needs)

    def readBswMgrNeeds(self, element: ET.Element, needs: BswMgrNeeds):
        self.readServiceNeeds(element, needs)

    def readCryptoKeyManagementNeeds(self, element: ET.Element, needs: CryptoKeyManagementNeeds):
        self.readServiceNeeds(element, needs)

    def readCryptoServiceJobNeeds(self, element: ET.Element, needs: CryptoServiceJobNeeds):
        self.readServiceNeeds(element, needs)

    def readNvBlockNeeds(self, element: ET.Element, needs: NvBlockNeeds):
        # self.logger.debug("Read NvBlockNeeds <%s>" % needs.getShortName())
        self.readServiceNeeds(element, needs)
        needs.setCalcRamBlockCrc(self.getChildElementOptionalBooleanValue(element, "CALC-RAM-BLOCK-CRC"))
        needs.setCheckStaticBlockId(self.getChildElementOptionalBooleanValue(element, "CHECK-STATIC-BLOCK-ID"))
        needs.setCyclicWritingPeriod(self.getChildElementOptionalTimeValue(element, "CYCLIC-WRITING-PERIOD"))
        needs.setNDataSets(self.getChildElementOptionalPositiveInteger(element, "N-DATA-SETS"))
        needs.setNRomBlocks(self.getChildElementOptionalPositiveInteger(element, "N-ROM-BLOCKS"))
        needs.setRamBlockStatusControl(self.getChildElementOptionalLiteral(element, "RAM-BLOCK-STATUS-CONTROL"))
        needs.setReadonly(self.getChildElementOptionalBooleanValue(element, "READONLY"))
        needs.setReliability(self.getChildElementOptionalLiteral(element, "RELIABILITY"))
        needs.setResistantToChangedSw(self.getChildElementOptionalBooleanValue(element, "RESISTANT-TO-CHANGED-SW"))
        needs.setRestoreAtStart(self.getChildElementOptionalBooleanValue(element, "RESTORE-AT-START"))
        needs.setSelectBlockForFirstInitAll(self.getChildElementOptionalBooleanValue(element, "SELECT-BLOCK-FOR-FIRST-INIT-ALL"))
        needs.setStoreAtShutdown(self.getChildElementOptionalBooleanValue(element, "STORE-AT-SHUTDOWN"))
        needs.setStoreCyclic(self.getChildElementOptionalBooleanValue(element, "STORE-CYCLIC"))
        needs.setStoreEmergency(self.getChildElementOptionalBooleanValue(element, "STORE-EMERGENCY"))
        needs.setStoreImmediate(self.getChildElementOptionalBooleanValue(element, "STORE-IMMEDIATE"))
        needs.setStoreOnChange(self.getChildElementOptionalBooleanValue(element, "STORE-ON-CHANGE"))
        needs.setUseAutoValidationAtShutDown(self.getChildElementOptionalBooleanValue(element, "USE-AUTO-VALIDATION-AT-SHUT-DOWN"))
        needs.setUseCRCCompMechanism(self.getChildElementOptionalBooleanValue(element, "USE-CRC-COMP-MECHANISM"))
        needs.setWriteOnlyOnce(self.getChildElementOptionalBooleanValue(element, "WRITE-ONLY-ONCE"))
        needs.setWriteVerification(self.getChildElementOptionalBooleanValue(element, "WRITE-VERIFICATION"))
        needs.setWritingFrequency(self.getChildElementOptionalPositiveInteger(element, "WRITING-FREQUENCY"))
        needs.setWritingPriority(self.getChildElementOptionalLiteral(element, "WRITING-PRIORITY"))

    def readDiagnosticCapabilityElement(self, element: ET.Element, needs: DiagnosticCapabilityElement):
        self.readServiceNeeds(element, needs)
        if not isinstance(needs, DiagnosticCapabilityElement):
            return
        for audience_element in self.findall(element, "AUDIENCES/AUDIENCE"):
            token = audience_element.text
            camel = None
            for camel_value, map_token in DIAGNOSTIC_AUDIENCE_XML_MAP.items():
                if map_token == token:
                    camel = camel_value
                    break
            if camel is not None:
                needs.addAudience(DiagnosticAudienceEnum().setValue(camel))
            else:
                self.notImplemented("Unsupported AUDIENCE <%s>" % token)
        req_element = self.find(element, "DIAG-REQUIREMENT")
        if req_element is not None:
            needs.setDiagRequirement(DiagRequirementIdString().setValue(req_element.text))
        needs.setSecurityAccessLevel(self.getChildElementOptionalPositiveInteger(element, "SECURITY-ACCESS-LEVEL"))

    def readObdInfoServiceNeeds(self, element: ET.Element, needs: ObdInfoServiceNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readObdMonitorServiceNeeds(self, element: ET.Element, needs: ObdMonitorServiceNeeds):
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setApplicationDataTypeRef(self.getChildElementOptionalRefType(element, "APPLICATION-DATA-TYPE-REF"))
        needs.setEventNeedsRef(self.getChildElementOptionalRefType(element, "EVENT-NEEDS-REF"))
        needs.setUnitAndScalingId(self.getChildElementOptionalPositiveInteger(element, "UNIT-AND-SCALING-ID"))
        needs.setUpdateKind(self.getChildElementOptionalLiteral(element, "UPDATE-KIND"))

    def readObdPidServiceNeeds(self, element: ET.Element, needs: ObdPidServiceNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readObdControlServiceNeeds(self, element: ET.Element, needs: ObdControlServiceNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readObdRatioServiceNeeds(self, element: ET.Element, needs: ObdRatioServiceNeeds):
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setConnectionType(self.getChildElementOptionalLiteral(element, "CONNECTION-TYPE"))
        needs.setRateBasedMonitoredEventRef(self.getChildElementOptionalRefType(element, "RATE-BASED-MONITORED-EVENT-REF"))
        needs.setUsedFidRef(self.getChildElementOptionalRefType(element, "USED-FID-REF"))

    def readObdRatioDenominatorNeeds(self, element: ET.Element, needs: ObdRatioDenominatorNeeds):
        self.readServiceNeeds(element, needs)
        needs.setDenominatorCondition(self.getChildElementOptionalLiteral(element, "DENOMINATOR-CONDITION"))

    def readDoIpActivationLineNeeds(self, element: ET.Element, needs: DoIpActivationLineNeeds):
        self.readServiceNeeds(element, needs)

    def readDoIpGidNeeds(self, element: ET.Element, needs: DoIpGidNeeds):
        self.readServiceNeeds(element, needs)

    def readDoIpGidSynchronizationNeeds(self, element: ET.Element, needs: DoIpGidSynchronizationNeeds):
        self.readServiceNeeds(element, needs)

    def readDoIpPowerModeStatusNeeds(self, element: ET.Element, needs: DoIpPowerModeStatusNeeds):
        self.readServiceNeeds(element, needs)

    def readDoIpRoutingActivationAuthenticationNeeds(self, element: ET.Element, needs: DoIpRoutingActivationAuthenticationNeeds):
        self.readServiceNeeds(element, needs)
        needs.setDataLengthRequest(self.getChildElementOptionalPositiveInteger(element, "DATA-LENGTH-REQUEST"))
        needs.setDataLengthResponse(self.getChildElementOptionalPositiveInteger(element, "DATA-LENGTH-RESPONSE"))
        child_element = self.find(element, "ROUTING-ACTIVATION-TYPE")
        if child_element is not None:
            needs.setRoutingActivationType(NameToken().setValue(child_element.text or ""))

    def readDoIpRoutingActivationConfirmationNeeds(self, element: ET.Element, needs: DoIpRoutingActivationConfirmationNeeds):
        self.readServiceNeeds(element, needs)
        needs.setDataLengthRequest(self.getChildElementOptionalPositiveInteger(element, "DATA-LENGTH-REQUEST"))
        needs.setDataLengthResponse(self.getChildElementOptionalPositiveInteger(element, "DATA-LENGTH-RESPONSE"))
        child_element = self.find(element, "ROUTING-ACTIVATION-TYPE")
        if child_element is not None:
            needs.setRoutingActivationType(NameToken().setValue(child_element.text or ""))

    def readSecureOnBoardCommunicationNeeds(self, element: ET.Element, needs: SecureOnBoardCommunicationNeeds):
        self.readServiceNeeds(element, needs)
        needs.setVerificationStatusIndicationMode(self.getChildElementOptionalLiteral(element, "VERIFICATION-STATUS-INDICATION-MODE"))

    def readIdsMgrCustomTimestampNeeds(self, element: ET.Element, needs: IdsMgrCustomTimestampNeeds):
        self.readServiceNeeds(element, needs)

    def readIdsMgrNeeds(self, element: ET.Element, needs: IdsMgrNeeds):
        self.readServiceNeeds(element, needs)
        needs.setUseSmartSensorApi(self.getChildElementOptionalBooleanValue(element, "USE-SMART-SENSOR-API"))

    def _readEnumToken(self, element: ET.Element, tag: str, enum_cls, token_map: dict):
        literal = self.getChildElementOptionalLiteral(element, tag)
        if literal is None:
            return None
        for camel_value, token in token_map.items():
            if token == literal.getText():
                return enum_cls().setValue(camel_value)
        self.notImplemented("Unsupported %s <%s>" % (tag, literal.getText()))
        return None

    def readDiagnosticCommunicationManagerNeeds(self, element: ET.Element, needs: DiagnosticCommunicationManagerNeeds):
        # self.logger.debug("Read DiagnosticCommunicationManagerNeeds <%s>" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setServiceRequestCallbackType(self._readEnumToken(element, "SERVICE-REQUEST-CALLBACK-TYPE", DiagnosticServiceRequestCallbackTypeEnum, DIAGNOSTIC_SERVICE_REQUEST_CALLBACK_TYPE_XML_MAP))

    def readDiagnosticComponentNeeds(self, element: ET.Element, needs: DiagnosticComponentNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readDiagnosticControlNeeds(self, element: ET.Element, needs: DiagnosticControlNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readDiagnosticUploadDownloadNeeds(self, element: ET.Element, needs: DiagnosticUploadDownloadNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readDiagnosticsCommunicationSecurityNeeds(self, element: ET.Element, needs: DiagnosticsCommunicationSecurityNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readDiagnosticRoutineNeeds(self, element: ET.Element, needs: DiagnosticRoutineNeeds):
        # self.logger.debug("Read DiagnosticRoutineNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setDiagRoutineType(self._readEnumToken(element, "DIAG-ROUTINE-TYPE", DiagnosticRoutineTypeEnum, DIAGNOSTIC_ROUTINE_TYPE_XML_MAP))
        needs.setRidNumber(self.getChildElementOptionalIntegerValue(element, "RID-NUMBER"))

    def readDiagnosticValueNeeds(self, element: ET.Element, needs: DiagnosticValueNeeds):
        # self.logger.debug("Read DiagnosticValueNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setDataLength(self.getChildElementOptionalPositiveInteger(element, "DATA-LENGTH"))
        needs.setDiagnosticValueAccess(self._readEnumToken(element, "DIAGNOSTIC-VALUE-ACCESS", DiagnosticValueAccessEnum, DIAGNOSTIC_VALUE_ACCESS_XML_MAP))
        needs.setDidNumber(self.getChildElementOptionalIntegerValue(element, "DID-NUMBER"))
        needs.setFixedLength(self.getChildElementOptionalBooleanValue(element, "FIXED-LENGTH"))
        needs.setProcessingStyle(self._readEnumToken(element, "PROCESSING-STYLE", DiagnosticProcessingStyleEnum, DIAGNOSTIC_PROCESSING_STYLE_XML_MAP))

    def readDiagEventDebounceCounterBased(self, element: ET.Element, algorithm: DiagEventDebounceCounterBased):
        algorithm.setCounterBasedFdcThresholdStorageValue(self.getChildElementOptionalIntegerValue(element, "COUNTER-BASED-FDC-THRESHOLD-STORAGE-VALUE"))
        algorithm.setCounterDecrementStepSize(self.getChildElementOptionalIntegerValue(element, "COUNTER-DECREMENT-STEP-SIZE"))
        algorithm.setCounterFailedThreshold(self.getChildElementOptionalIntegerValue(element, "COUNTER-FAILED-THRESHOLD"))
        algorithm.setCounterIncrementStepSize(self.getChildElementOptionalIntegerValue(element, "COUNTER-INCREMENT-STEP-SIZE"))
        algorithm.setCounterJumpDown(self.getChildElementOptionalBooleanValue(element, "COUNTER-JUMP-DOWN"))
        algorithm.setCounterJumpDownValue(self.getChildElementOptionalIntegerValue(element, "COUNTER-JUMP-DOWN-VALUE"))
        algorithm.setCounterJumpUp(self.getChildElementOptionalBooleanValue(element, "COUNTER-JUMP-UP"))
        algorithm.setCounterJumpUpValue(self.getChildElementOptionalIntegerValue(element, "COUNTER-JUMP-UP-VALUE"))
        algorithm.setCounterPassedThreshold(self.getChildElementOptionalIntegerValue(element, "COUNTER-PASSED-THRESHOLD"))

    def readDiagEventDebounceMonitorInternal(self, element: ET.Element, algorithm: DiagEventDebounceMonitorInternal):
        self.readDiagnosticCapabilityElement(element, algorithm)

    def readDiagEventDebounceTimeBased(self, element: ET.Element, algorithm: DiagEventDebounceTimeBased):
        self.readDiagnosticCapabilityElement(element, algorithm)

    def readDiagEventDebounceAlgorithm(self, element: ET.Element, needs: DiagnosticEventNeeds):
        for child_element in self.findall(element, "DIAG-EVENT-DEBOUNCE-ALGORITHM/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DIAG-EVENT-DEBOUNCE-COUNTER-BASED":
                algorithm = needs.createDiagEventDebounceCounterBased(self.getShortName(child_element))
                self.readDiagEventDebounceCounterBased(child_element, algorithm)
            elif tag_name == "DIAG-EVENT-DEBOUNCE-MONITOR-INTERNAL":
                algorithm = needs.createDiagEventDebounceMonitorInternal(self.getShortName(child_element))
                self.readDiagEventDebounceMonitorInternal(child_element, algorithm)
            elif tag_name == "DIAG-EVENT-DEBOUNCE-TIME-BASED":
                algorithm = needs.createDiagEventDebounceTimeBased(self.getShortName(child_element))
                self.readDiagEventDebounceTimeBased(child_element, algorithm)
            else:
                self.notImplemented("Unsupported DiagEventDebounceAlgorithm <%s>" % tag_name)

    def readDiagnosticEventNeeds(self, element: ET.Element, needs: DiagnosticEventNeeds):
        # self.logger.debug("Read DiagnosticEventNeeds <%s>" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        for ref in self.getChildElementRefTypeList(element, "DEFERRING-FID-REFS/DEFERRING-FID-REF"):
            needs.addDeferringFidRef(ref)
        self.readDiagEventDebounceAlgorithm(element, needs)
        needs.setInhibitingFidRef(self.getChildElementOptionalRefType(element, "INHIBITING-FID-REF"))
        for ref in self.getChildElementRefTypeList(element, "INHIBITING-SECONDARY-FID-REFS/INHIBITING-SECONDARY-FID-REF"):
            needs.addInhibitingSecondaryFidRef(ref)
        needs.setPrestoredFreezeframeStoredInNvm(self.getChildElementOptionalBooleanValue(element, "PRESTORED-FREEZEFRAME-STORED-IN-NVM"))
        needs.setUsesMonitorData(self.getChildElementOptionalBooleanValue(element, "USES-MONITOR-DATA"))

    def readDiagnosticEventInfoNeeds(self, element: ET.Element, needs: DiagnosticEventInfoNeeds):
        # self.logger.debug("Read DiagnosticEventInfoNeeds <%s>" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setDtcKind(self._readEnumToken(element, "DTC-KIND", DtcKindEnum, DTC_KIND_XML_MAP))
        needs.setObdDtcNumber(self.getChildElementOptionalPositiveInteger(element, "OBD-DTC-NUMBER"))
        needs.setUdsDtcNumber(self.getChildElementOptionalPositiveInteger(element, "UDS-DTC-NUMBER"))

    def readDiagnosticIoControlNeeds(self, element: ET.Element, needs: DiagnosticIoControlNeeds):
        # self.logger.debug("Read DiagnosticIoControlNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setCurrentValueRef(self.getChildElementOptionalRefType(element, "CURRENT-VALUE-REF"))
        needs.setFreezeCurrentStateSupported(self.getChildElementOptionalBooleanValue(element, "FREEZE-CURRENT-STATE-SUPPORTED"))
        needs.setResetToDefaultSupported(self.getChildElementOptionalBooleanValue(element, "RESET-TO-DEFAULT-SUPPORTED"))
        needs.setShortTermAdjustmentSupported(self.getChildElementOptionalBooleanValue(element, "SHORT-TERM-ADJUSTMENT-SUPPORTED"))

    def readDiagnosticEnableConditionNeeds(self, element: ET.Element, needs: DiagnosticEnableConditionNeeds):
        # self.logger.debug("Read DiagnosticEnableConditionNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setInitialStatus(self.getChildElementOptionalLiteral(element, "INITIAL-STATUS"))

    def readDiagnosticEventManagerNeeds(self, element: ET.Element, needs: DiagnosticEventManagerNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readDiagnosticOperationCycleNeeds(self, element: ET.Element, needs: DiagnosticOperationCycleNeeds):
        # self.logger.debug("Read DiagnosticOperationCycleNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setOperationCycle(self.getChildElementOptionalLiteral(element, "OPERATION-CYCLE"))

    def readDiagnosticRequestFileTransferNeeds(self, element: ET.Element, needs: DiagnosticRequestFileTransferNeeds):
        self.readDiagnosticCapabilityElement(element, needs)

    def readDiagnosticStorageConditionNeeds(self, element: ET.Element, needs: DiagnosticStorageConditionNeeds):
        # self.logger.debug("Read DiagnosticStorageConditionNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setInitialStatus(self.getChildElementOptionalLiteral(element, "INITIAL-STATUS"))

    def readIndicatorStatusNeeds(self, element: ET.Element, needs: IndicatorStatusNeeds):
        # self.logger.debug("Read IndicatorStatusNeeds %s" % needs.getShortName())
        self.readServiceNeeds(element, needs)
        needs.setType(self.getChildElementOptionalLiteral(element, "TYPE"))

    def readJ1939DcmDm19Support(self, element: ET.Element, needs: J1939DcmDm19Support):
        self.readServiceNeeds(element, needs)

    def readJ1939RmIncomingRequestServiceNeeds(self, element: ET.Element, needs: J1939RmIncomingRequestServiceNeeds):
        self.readServiceNeeds(element, needs)

    def readJ1939RmOutgoingRequestServiceNeeds(self, element: ET.Element, needs: J1939RmOutgoingRequestServiceNeeds):
        self.readServiceNeeds(element, needs)

    def readFunctionInhibitionAvailabilityNeeds(self, element: ET.Element, needs: FunctionInhibitionAvailabilityNeeds):
        # self.logger.debug("Read FunctionInhibitionAvailabilityNeeds %s" % needs.getShortName())
        self.readServiceNeeds(element, needs)
        needs.setControlledFidRef(self.getChildElementOptionalRefType(element, "CONTROLLED-FID-REF"))

    def readFunctionInhibitionNeeds(self, element: ET.Element, needs: FunctionInhibitionNeeds):
        self.readServiceNeeds(element, needs)

    def readFurtherActionByteNeeds(self, element: ET.Element, needs: FurtherActionByteNeeds):
        self.readServiceNeeds(element, needs)

    def readGlobalSupervisionNeeds(self, element: ET.Element, needs: GlobalSupervisionNeeds):
        self.readServiceNeeds(element, needs)

    def readHardwareTestNeeds(self, element: ET.Element, needs: HardwareTestNeeds):
        self.readServiceNeeds(element, needs)

    def readCryptoServiceNeeds(self, element: ET.Element, needs: CryptoServiceNeeds):
        # self.logger.debug("Read CryptoServiceNeeds <%s>" % needs.getShortName())
        self.readServiceNeeds(element, needs)
        needs.setAlgorithmFamily(self.getChildElementOptionalString(element, "ALGORITHM-FAMILY"))
        needs.setAlgorithmMode(self.getChildElementOptionalString(element, "ALGORITHM-MODE"))
        needs.setCryptoKeyDescription(self.getChildElementOptionalString(element, "CRYPTO-KEY-DESCRIPTION"))
        needs.setMaximumKeyLength(self.getChildElementOptionalPositiveInteger(element, "MAXIMUM-KEY-LENGTH"))

    def readEcuStateMgrUserNeeds(self, element: ET.Element, needs: EcuStateMgrUserNeeds):
        # self.logger.debug("Read EcuStateMgrUserNeeds %s" % needs.getShortName())
        self.readServiceNeeds(element, needs)

    def readDtcStatusChangeNotificationNeeds(self, element: ET.Element, needs: DtcStatusChangeNotificationNeeds):
        # self.logger.debug("Read DtcStatusChangeNotificationNeeds %s" % needs.getShortName())
        self.readDiagnosticCapabilityElement(element, needs)
        needs.setDtcFormatType(self._readEnumToken(element, "DTC-FORMAT-TYPE", DtcFormatTypeEnum, DTC_FORMAT_TYPE_XML_MAP))
        needs.setNotificationTime(self._readEnumToken(element, "NOTIFICATION-TIME", DiagnosticClearDtcNotificationEnum, DIAGNOSTIC_CLEAR_DTC_NOTIFICATION_XML_MAP))

    def readDltUserNeeds(self, element: ET.Element, needs: DltUserNeeds):
        # self.logger.debug("Read DltUserNeeds %s" % needs.getShortName())
        self.readServiceNeeds(element, needs)

    def readComMgrUserNeeds(self, element: ET.Element, needs: ComMgrUserNeeds):
        # self.logger.debug("Read ComMgrUserNeeds %s" % needs.getShortName())
        self.readServiceNeeds(element, needs)
        needs.setMaxCommMode(self.getChildElementOptionalLiteral(element, "MAX-COMM-MODE"))

    def readSupervisedEntityCheckpointNeeds(self, element: ET.Element, needs: SupervisedEntityCheckpointNeeds):
        self.readServiceNeeds(element, needs)

    def readSyncTimeBaseMgrUserNeeds(self, element: ET.Element, needs: SyncTimeBaseMgrUserNeeds):
        self.readServiceNeeds(element, needs)

    def readV2xDataManagerNeeds(self, element: ET.Element, needs: V2xDataManagerNeeds):
        self.readServiceNeeds(element, needs)

    def readV2xFacUserNeeds(self, element: ET.Element, needs: V2xFacUserNeeds):
        self.readServiceNeeds(element, needs)

    def readV2xMUserNeeds(self, element: ET.Element, needs: V2xMUserNeeds):
        self.readServiceNeeds(element, needs)

    def readVendorSpecificServiceNeeds(self, element: ET.Element, needs: VendorSpecificServiceNeeds):
        self.readServiceNeeds(element, needs)

    def readWarningIndicatorRequestedBitNeeds(self, element: ET.Element, needs: WarningIndicatorRequestedBitNeeds):
        self.readServiceNeeds(element, needs)

    def readSupervisedEntityNeeds(self, element: ET.Element, needs: SupervisedEntityNeeds):
        self.readServiceNeeds(element, needs)
        needs.setActivateAtStart(self.getChildElementOptionalBooleanValue(element, "ACTIVATE-AT-START"))
        for ref in self.getChildElementRefTypeList(element, "CHECKPOINTSS/SUPERVISED-ENTITY-CHECKPOINT-NEEDS-REF-CONDITIONAL/SUPERVISED-ENTITY-CHECKPOINT-NEEDS-REF"):
            needs.addCheckpointsRef(ref)
        needs.setEnableDeactivation(self.getChildElementOptionalBooleanValue(element, "ENABLE-DEACTIVATION"))
        needs.setExpectedAliveCycle(self.getChildElementOptionalTimeValue(element, "EXPECTED-ALIVE-CYCLE"))
        needs.setMaxAliveCycle(self.getChildElementOptionalTimeValue(element, "MAX-ALIVE-CYCLE"))
        needs.setMinAliveCycle(self.getChildElementOptionalTimeValue(element, "MIN-ALIVE-CYCLE"))
        needs.setToleratedFailedCycles(self.getChildElementOptionalPositiveInteger(element, "TOLERATED-FAILED-CYCLES"))

    def readTracedFailure(self, element: ET.Element, failure: TracedFailure):
        self.readIdentifiable(element, failure)
        failure.setId(self.getChildElementOptionalPositiveInteger(element, "ID"))

    def readDevelopmentError(self, element: ET.Element, failure: DevelopmentError):
        self.readTracedFailure(element, failure)

    def readRuntimeError(self, element: ET.Element, failure: RuntimeError):
        self.readTracedFailure(element, failure)

    def readPossibleErrorReaction(self, element: ET.Element, reaction: PossibleErrorReaction):
        self.readIdentifiable(element, reaction)
        reaction.setReactionCode(self.getChildElementOptionalPositiveInteger(element, "REACTION-CODE"))

    def readTransientFault(self, element: ET.Element, failure: TransientFault):
        self.readTracedFailure(element, failure)
        for child_element in self.findall(element, "POSSIBLE-ERROR-REACTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "POSSIBLE-ERROR-REACTION":
                reaction = failure.createPossibleErrorReaction(self.getShortName(child_element))
                self.readPossibleErrorReaction(child_element, reaction)
            else:
                self.notImplemented("Unsupported PossibleErrorReaction <%s>" % tag_name)

    def readErrorTracerNeeds(self, element: ET.Element, needs: ErrorTracerNeeds):
        # self.logger.debug("Read ErrorTracerNeeds <%s>" % needs.getShortName())
        self.readServiceNeeds(element, needs)
        for child_element in self.findall(element, "TRACED-FAILURES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DEVELOPMENT-ERROR":
                failure = needs.createDevelopmentError(self.getShortName(child_element))
                self.readDevelopmentError(child_element, failure)
            elif tag_name == "RUNTIME-ERROR":
                failure = needs.createRuntimeError(self.getShortName(child_element))
                self.readRuntimeError(child_element, failure)
            elif tag_name == "TRANSIENT-FAULT":
                failure = needs.createTransientFault(self.getShortName(child_element))
                self.readTransientFault(child_element, failure)
            else:
                self.notImplemented("Unsupported traced failure <%s>" % tag_name)

    def readSwcServiceDependencyServiceNeeds(self, element: ET.Element, parent: SwcServiceDependency):
        for child_element in self.findall(element, "SERVICE-NEEDS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "NV-BLOCK-NEEDS":
                needs = parent.createNvBlockNeeds(self.getShortName(child_element))
                self.readNvBlockNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-COMMUNICATION-MANAGER-NEEDS":
                needs = parent.createDiagnosticCommunicationManagerNeeds(self.getShortName(child_element))
                self.readDiagnosticCommunicationManagerNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-COMPONENT-NEEDS":
                needs = parent.createDiagnosticComponentNeeds(self.getShortName(child_element))
                self.readDiagnosticComponentNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-CONTROL-NEEDS":
                needs = parent.createDiagnosticControlNeeds(self.getShortName(child_element))
                self.readDiagnosticControlNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-UPLOAD-DOWNLOAD-NEEDS":
                needs = parent.createDiagnosticUploadDownloadNeeds(self.getShortName(child_element))
                self.readDiagnosticUploadDownloadNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTICS-COMMUNICATION-SECURITY-NEEDS":
                needs = parent.createDiagnosticsCommunicationSecurityNeeds(self.getShortName(child_element))
                self.readDiagnosticsCommunicationSecurityNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-ROUTINE-NEEDS":
                needs = parent.createDiagnosticRoutineNeeds(self.getShortName(child_element))
                self.readDiagnosticRoutineNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-VALUE-NEEDS":
                needs = parent.createDiagnosticValueNeeds(self.getShortName(child_element))
                self.readDiagnosticValueNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-EVENT-NEEDS":
                needs = parent.createDiagnosticEventNeeds(self.getShortName(child_element))
                self.readDiagnosticEventNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-EVENT-INFO-NEEDS":
                needs = parent.createDiagnosticEventInfoNeeds(self.getShortName(child_element))
                self.readDiagnosticEventInfoNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-IO-CONTROL-NEEDS":
                needs = parent.createDiagnosticIoControlNeeds(self.getShortName(child_element))
                self.readDiagnosticIoControlNeeds(child_element, needs)
            elif tag_name == "CRYPTO-KEY-MANAGEMENT-NEEDS":
                needs = parent.createCryptoKeyManagementNeeds(self.getShortName(child_element))
                self.readCryptoKeyManagementNeeds(child_element, needs)
            elif tag_name == "CRYPTO-SERVICE-JOB-NEEDS":
                needs = parent.createCryptoServiceJobNeeds(self.getShortName(child_element))
                self.readCryptoServiceJobNeeds(child_element, needs)
            elif tag_name == "CRYPTO-SERVICE-NEEDS":
                needs = parent.createCryptoServiceNeeds(self.getShortName(child_element))
                self.readCryptoServiceNeeds(child_element, needs)
            elif tag_name == "ECU-STATE-MGR-USER-NEEDS":
                needs = parent.createEcuStateMgrUserNeeds(self.getShortName(child_element))
                self.readEcuStateMgrUserNeeds(child_element, needs)
            elif tag_name == "DTC-STATUS-CHANGE-NOTIFICATION-NEEDS":
                needs = parent.createDtcStatusChangeNotificationNeeds(self.getShortName(child_element))
                self.readDtcStatusChangeNotificationNeeds(child_element, needs)
            elif tag_name == "DLT-USER-NEEDS":
                needs = parent.createDltUserNeeds(self.getShortName(child_element))
                self.readDltUserNeeds(child_element, needs)
            elif tag_name == "COM-MGR-USER-NEEDS":
                needs = parent.createComMgrUserNeeds(self.getShortName(child_element))
                self.readComMgrUserNeeds(child_element, needs)
            elif tag_name == "ERROR-TRACER-NEEDS":
                needs = parent.createErrorTracerNeeds(self.getShortName(child_element))
                self.readErrorTracerNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-ENABLE-CONDITION-NEEDS":
                needs = parent.createDiagnosticEnableConditionNeeds(self.getShortName(child_element))
                self.readDiagnosticEnableConditionNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-EVENT-MANAGER-NEEDS":
                needs = parent.createDiagnosticEventManagerNeeds(self.getShortName(child_element))
                self.readDiagnosticEventManagerNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-OPERATION-CYCLE-NEEDS":
                needs = parent.createDiagnosticOperationCycleNeeds(self.getShortName(child_element))
                self.readDiagnosticOperationCycleNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-REQUEST-FILE-TRANSFER-NEEDS":
                needs = parent.createDiagnosticRequestFileTransferNeeds(self.getShortName(child_element))
                self.readDiagnosticRequestFileTransferNeeds(child_element, needs)
            elif tag_name == "DIAGNOSTIC-STORAGE-CONDITION-NEEDS":
                needs = parent.createDiagnosticStorageConditionNeeds(self.getShortName(child_element))
                self.readDiagnosticStorageConditionNeeds(child_element, needs)
            elif tag_name == "INDICATOR-STATUS-NEEDS":
                needs = parent.createIndicatorStatusNeeds(self.getShortName(child_element))
                self.readIndicatorStatusNeeds(child_element, needs)
            elif tag_name == "J-1939-DCM-DM-19-SUPPORT":
                needs = parent.createJ1939DcmDm19Support(self.getShortName(child_element))
                self.readJ1939DcmDm19Support(child_element, needs)
            elif tag_name == "J-1939-RM-INCOMING-REQUEST-SERVICE-NEEDS":
                needs = parent.createJ1939RmIncomingRequestServiceNeeds(self.getShortName(child_element))
                self.readJ1939RmIncomingRequestServiceNeeds(child_element, needs)
            elif tag_name == "J-1939-RM-OUTGOING-REQUEST-SERVICE-NEEDS":
                needs = parent.createJ1939RmOutgoingRequestServiceNeeds(self.getShortName(child_element))
                self.readJ1939RmOutgoingRequestServiceNeeds(child_element, needs)
            elif tag_name == "FUNCTION-INHIBITION-AVAILABILITY-NEEDS":
                needs = parent.createFunctionInhibitionAvailabilityNeeds(self.getShortName(child_element))
                self.readFunctionInhibitionAvailabilityNeeds(child_element, needs)
            elif tag_name == "FUNCTION-INHIBITION-NEEDS":
                needs = parent.createFunctionInhibitionNeeds(self.getShortName(child_element))
                self.readFunctionInhibitionNeeds(child_element, needs)
            elif tag_name == "FURTHER-ACTION-BYTE-NEEDS":
                needs = parent.createFurtherActionByteNeeds(self.getShortName(child_element))
                self.readFurtherActionByteNeeds(child_element, needs)
            elif tag_name == "GLOBAL-SUPERVISION-NEEDS":
                needs = parent.createGlobalSupervisionNeeds(self.getShortName(child_element))
                self.readGlobalSupervisionNeeds(child_element, needs)
            elif tag_name == "HARDWARE-TEST-NEEDS":
                needs = parent.createHardwareTestNeeds(self.getShortName(child_element))
                self.readHardwareTestNeeds(child_element, needs)
            elif tag_name == "SUPERVISED-ENTITY-CHECKPOINT-NEEDS":
                needs = parent.createSupervisedEntityCheckpointNeeds(self.getShortName(child_element))
                self.readSupervisedEntityCheckpointNeeds(child_element, needs)
            elif tag_name == "SYNC-TIME-BASE-MGR-USER-NEEDS":
                needs = parent.createSyncTimeBaseMgrUserNeeds(self.getShortName(child_element))
                self.readSyncTimeBaseMgrUserNeeds(child_element, needs)
            elif tag_name == "V-2-X-DATA-MANAGER-NEEDS":
                needs = parent.createV2xDataManagerNeeds(self.getShortName(child_element))
                self.readV2xDataManagerNeeds(child_element, needs)
            elif tag_name == "V-2-X-FAC-USER-NEEDS":
                needs = parent.createV2xFacUserNeeds(self.getShortName(child_element))
                self.readV2xFacUserNeeds(child_element, needs)
            elif tag_name == "V-2-X-M-USER-NEEDS":
                needs = parent.createV2xMUserNeeds(self.getShortName(child_element))
                self.readV2xMUserNeeds(child_element, needs)
            elif tag_name == "VENDOR-SPECIFIC-SERVICE-NEEDS":
                needs = parent.createVendorSpecificServiceNeeds(self.getShortName(child_element))
                self.readVendorSpecificServiceNeeds(child_element, needs)
            elif tag_name == "WARNING-INDICATOR-REQUESTED-BIT-NEEDS":
                needs = parent.createWarningIndicatorRequestedBitNeeds(self.getShortName(child_element))
                self.readWarningIndicatorRequestedBitNeeds(child_element, needs)
            elif tag_name == "OBD-INFO-SERVICE-NEEDS":
                needs = parent.createObdInfoServiceNeeds(self.getShortName(child_element))
                self.readObdInfoServiceNeeds(child_element, needs)
            elif tag_name == "OBD-MONITOR-SERVICE-NEEDS":
                needs = parent.createObdMonitorServiceNeeds(self.getShortName(child_element))
                self.readObdMonitorServiceNeeds(child_element, needs)
            elif tag_name == "OBD-PID-SERVICE-NEEDS":
                needs = parent.createObdPidServiceNeeds(self.getShortName(child_element))
                self.readObdPidServiceNeeds(child_element, needs)
            elif tag_name == "OBD-CONTROL-SERVICE-NEEDS":
                needs = parent.createObdControlServiceNeeds(self.getShortName(child_element))
                self.readObdControlServiceNeeds(child_element, needs)
            elif tag_name == "OBD-RATIO-SERVICE-NEEDS":
                needs = parent.createObdRatioServiceNeeds(self.getShortName(child_element))
                self.readObdRatioServiceNeeds(child_element, needs)
            elif tag_name == "OBD-RATIO-DENOMINATOR-NEEDS":
                needs = parent.createObdRatioDenominatorNeeds(self.getShortName(child_element))
                self.readObdRatioDenominatorNeeds(child_element, needs)
            elif tag_name == "DO-IP-ACTIVATION-LINE-NEEDS":
                needs = parent.createDoIpActivationLineNeeds(self.getShortName(child_element))
                self.readDoIpActivationLineNeeds(child_element, needs)
            elif tag_name == "DO-IP-GID-NEEDS":
                needs = parent.createDoIpGidNeeds(self.getShortName(child_element))
                self.readDoIpGidNeeds(child_element, needs)
            elif tag_name == "DO-IP-GID-SYNCHRONIZATION-NEEDS":
                needs = parent.createDoIpGidSynchronizationNeeds(self.getShortName(child_element))
                self.readDoIpGidSynchronizationNeeds(child_element, needs)
            elif tag_name == "DO-IP-POWER-MODE-STATUS-NEEDS":
                needs = parent.createDoIpPowerModeStatusNeeds(self.getShortName(child_element))
                self.readDoIpPowerModeStatusNeeds(child_element, needs)
            elif tag_name == "DO-IP-ROUTING-ACTIVATION-AUTHENTICATION-NEEDS":
                needs = parent.createDoIpRoutingActivationAuthenticationNeeds(self.getShortName(child_element))
                self.readDoIpRoutingActivationAuthenticationNeeds(child_element, needs)
            elif tag_name == "DO-IP-ROUTING-ACTIVATION-CONFIRMATION-NEEDS":
                needs = parent.createDoIpRoutingActivationConfirmationNeeds(self.getShortName(child_element))
                self.readDoIpRoutingActivationConfirmationNeeds(child_element, needs)
            elif tag_name == "SECURE-ON-BOARD-COMMUNICATION-NEEDS":
                needs = parent.createSecureOnBoardCommunicationNeeds(self.getShortName(child_element))
                self.readSecureOnBoardCommunicationNeeds(child_element, needs)
            elif tag_name == "IDS-MGR-CUSTOM-TIMESTAMP-NEEDS":
                needs = parent.createIdsMgrCustomTimestampNeeds(self.getShortName(child_element))
                self.readIdsMgrCustomTimestampNeeds(child_element, needs)
            elif tag_name == "IDS-MGR-NEEDS":
                needs = parent.createIdsMgrNeeds(self.getShortName(child_element))
                self.readIdsMgrNeeds(child_element, needs)
            else:
                self.notImplemented("Unsupported service needs <%s>" % tag_name)

    def readSwcServiceDependencyRepresentedPortGroup(self, element: ET.Element, dependency: SwcServiceDependency):
        ref = self.getChildElementOptionalRefType(element, "REPRESENTED-PORT-GROUP-REF")
        if ref is not None:
            dependency.setRepresentedPortGroupRef(ref)

    def readSwcServiceDependency(self, element: ET.Element, parent: SwcInternalBehavior):
        short_name = self.getShortName(element)
        dependency = parent.createSwcServiceDependency(short_name)
        # self.logger.debug("Read SwcServiceDependency %s" % short_name)
        self.readServiceDependency(element, dependency)
        self.readSwcServiceDependencyAssignedData(element, dependency)
        self.readSwcServiceDependencyAssignedPorts(element, dependency)
        self.readSwcServiceDependencyServiceNeeds(element, dependency)
        self.readSwcServiceDependencyRepresentedPortGroup(element, dependency)

    def readSwcInternalBehaviorServiceDependencies(self, element: ET.Element, parent: SwcInternalBehavior):
        for child_element in self.findall(element, "SERVICE-DEPENDENCYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SWC-SERVICE-DEPENDENCY":
                self.readSwcServiceDependency(child_element, parent)
            else:
                self.notImplemented("Unsupported Service Dependencies <%s>" % tag_name)

    def getIncludedDataTypeSets(self, element: ET.Element) -> List[IncludedDataTypeSet]:
        include_data_type_sets = []
        for child_element in self.findall(element, "INCLUDED-DATA-TYPE-SETS/INCLUDED-DATA-TYPE-SET"):
            include_data_type_set = IncludedDataTypeSet()
            self.readARObject(child_element, include_data_type_set)
            include_data_type_set.setLiteralPrefix(self.getChildElementOptionalLiteral(child_element, "LITERAL-PREFIX"))
            for ref_type in self.getChildElementRefTypeList(child_element, "DATA-TYPE-REFS/DATA-TYPE-REF"):
                include_data_type_set.addDataTypeRef(ref_type)
            include_data_type_sets.append(include_data_type_set)
        return include_data_type_sets

    def readSwcInternalBehaviorArTypedPerInstanceMemories(self, element: ET.Element, parent: SwcInternalBehavior):
        for child_element in self.findall(element, "AR-TYPED-PER-INSTANCE-MEMORYS/VARIABLE-DATA-PROTOTYPE"):
            short_name = self.getShortName(child_element)
            prototype = parent.createArTypedPerInstanceMemory(short_name)
            self.readVariableDataPrototype(child_element, prototype)

    def readSwcInternalBehaviorSharedParameters(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "SHARED-PARAMETERS/PARAMETER-DATA-PROTOTYPE"):
            short_name = self.getShortName(child_element)
            prototype = behavior.createSharedParameter(short_name)
            self.readParameterDataPrototype(child_element, prototype)

    def readVariationPointProxy(self, element: ET.Element, proxy: VariationPointProxy):
        self.readIdentifiable(element, proxy)
        condition_element = self.find(element, "CONDITION-ACCESS")
        if condition_element is not None:
            proxy.setConditionAccess(self.readConditionByFormula(condition_element, ConditionByFormula()))
        proxy.setImplementationDataTypeRef(self.getChildElementOptionalRefType(element, "IMPLEMENTATION-DATA-TYPE-REF"))
        proxy.setPostBuildValueAccessRef(self.getChildElementOptionalRefType(element, "POST-BUILD-VALUE-ACCESS-REF"))
        for child_element in self.findall(element, "POST-BUILD-VARIANT-CONDITIONS/POST-BUILD-VARIANT-CONDITION"):
            proxy.addPostBuildVariantCondition(self.readPostBuildVariantCondition(child_element, PostBuildVariantCondition()))
        value_access_element = self.find(element, "VALUE-ACCESS")
        if value_access_element is not None:
            for child_element in value_access_element:
                tag = self.getTagName(child_element)
                avp_class = VALUE_ACCESS_TAG_TO_CLASS.get(tag)
                if avp_class is not None:
                    proxy.setValueAccess(self.readAttributeValueVariationPoint(child_element, avp_class()))
                else:
                    self.notImplemented("Unsupported VALUE-ACCESS content <%s>" % tag)

    def readAttributeValueVariationPoint(self, element: ET.Element, avp: AttributeValueVariationPoint) -> AttributeValueVariationPoint:
        self.readARObject(element, avp)
        if "BINDING-TIME" in element.attrib:
            binding_time = None
            for camel, token in BINDING_TIME_XML_MAP.items():
                if token == element.attrib["BINDING-TIME"]:
                    binding_time = camel
                    break
            if binding_time is not None:
                avp.setBindingTime(BindingTimeEnum().setValue(binding_time))
            else:
                self.notImplemented("Unsupported BINDING-TIME <%s>" % element.attrib["BINDING-TIME"])
        if "BLUEPRINT-VALUE" in element.attrib:
            avp.setBlueprintValue(String().setValue(element.attrib["BLUEPRINT-VALUE"]))
        if "SD" in element.attrib:
            avp.setSd(String().setValue(element.attrib["SD"]))
        if "SHORT-LABEL" in element.attrib:
            avp.setShortLabel(PrimitiveIdentifier().setValue(element.attrib["SHORT-LABEL"]))
        if isinstance(avp, LimitValueVariationPoint) and "INTERVAL-TYPE" in element.attrib:
            interval_type = None
            for value, token in INTERVAL_TYPE_XML_MAP.items():
                if token == element.attrib["INTERVAL-TYPE"]:
                    interval_type = value
                    break
            if interval_type is not None:
                avp.setIntervalType(IntervalTypeEnum().setValue(interval_type))
            else:
                self.notImplemented("Unsupported INTERVAL-TYPE <%s>" % element.attrib["INTERVAL-TYPE"])
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, avp)
        if isinstance(avp, SwSystemconstDependentFormula):
            self.readSwSystemconstDependentFormula(element, avp)
        return avp

    def readAbstractEnumerationValueVariationPoint(self, element: ET.Element, obj: AbstractEnumerationValueVariationPoint) -> AbstractEnumerationValueVariationPoint:
        if "BASE" in element.attrib:
            obj.setBase(Identifier().setValue(element.attrib["BASE"]))
        if "ENUM-TABLE" in element.attrib:
            obj.setEnumTableRef(Ref().setValue(element.attrib["ENUM-TABLE"]))
        return obj

    def readTimingDescriptionEventChain(self, element: ET.Element, chain: TimingDescriptionEventChain):
        self.readIdentifiable(element, chain)
        pipelining_element = self.find(element, "IS-PIPELINING-PERMITTED")
        if pipelining_element is not None:
            chain.setIsPipeliningPermitted(Boolean().setValue(pipelining_element.text == "true"))
        chain.setStimulusRef(self.getChildElementOptionalRefType(element, "STIMULUS-REF"))
        chain.setResponseRef(self.getChildElementOptionalRefType(element, "RESPONSE-REF"))
        for ref in self.getChildElementRefTypeList(element, "SEGMENT-REFS/SEGMENT-REF"):
            chain.addSegmentRef(ref)

    def readTimingDescriptionEvent(self, element: ET.Element, event: TimingDescriptionEvent):
        self.readIdentifiable(element, event)
        event.setClockReferenceRef(self.getChildElementOptionalRefType(element, "CLOCK-REFERENCE-REF"))
        occurrence_element = self.find(element, "OCCURRENCE-EXPRESSION")
        if occurrence_element is not None:
            event.setOccurrenceExpression(self.readTDEventOccurrenceExpression(occurrence_element, event))

    def readTDEventCom(self, element: ET.Element, event: "TDEventCom"):
        self.readTimingDescriptionEvent(element, event)
        event.setEcuInstanceRef(self.getChildElementOptionalRefType(element, "ECU-INSTANCE-REF"))

    def readTDEventCycleStart(self, element: ET.Element, event: "TDEventCycleStart"):
        self.readTDEventCom(element, event)
        event.setCycleRepetition(self.getChildElementOptionalIntegerValue(element, "CYCLE-REPETITION"))

    def readTDEventFrClusterCycleStart(self, element: ET.Element, event: "TDEventFrClusterCycleStart"):
        self.readTDEventCycleStart(element, event)
        event.setFrClusterRef(self.getChildElementOptionalRefType(element, "FR-CLUSTER-REF"))

    def readTDEventTTCanCycleStart(self, element: ET.Element, event: "TDEventTTCanCycleStart"):
        self.readTDEventCycleStart(element, event)
        event.setTtCanClusterRef(self.getChildElementOptionalRefType(element, "TT-CAN-CLUSTER-REF"))

    def readTDEventISignal(self, element: ET.Element, event: "TDEventISignal"):
        self.readTDEventCom(element, event)
        event.setISignalRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-REF"))
        event.setPhysicalChannelRef(self.getChildElementOptionalRefType(element, "PHYSICAL-CHANNEL-REF"))
        type_element = self.find(element, "TD-EVENT-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventISignalTypeEnum()
            enum.value = type_element.text
            event.setTdEventType(enum)

    def readTDEventIPdu(self, element: ET.Element, event: "TDEventIPdu"):
        self.readTDEventCom(element, event)
        event.setIPduRef(self.getChildElementOptionalRefType(element, "I-PDU-REF"))
        event.setPhysicalChannelRef(self.getChildElementOptionalRefType(element, "PHYSICAL-CHANNEL-REF"))
        type_element = self.find(element, "TD-EVENT-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventIPduTypeEnum()
            enum.value = type_element.text
            event.setTdEventType(enum)

    def readTDEventFrame(self, element: ET.Element, event: "TDEventFrame"):
        self.readTDEventCom(element, event)
        event.setFrameRef(self.getChildElementOptionalRefType(element, "FRAME-REF"))
        event.setPhysicalChannelRef(self.getChildElementOptionalRefType(element, "PHYSICAL-CHANNEL-REF"))
        type_element = self.find(element, "TD-EVENT-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventFrameTypeEnum()
            enum.value = type_element.text
            event.setTdEventType(enum)

    def readTDHeaderIdRange(self, element: ET.Element, header_id_range: "TDHeaderIdRange"):
        header_id_range.setMinHeaderId(self.getChildElementOptionalIntegerValue(element, "MIN-HEADER-ID"))
        header_id_range.setMaxHeaderId(self.getChildElementOptionalIntegerValue(element, "MAX-HEADER-ID"))

    def readTDEventFrameEthernet(self, element: ET.Element, event: "TDEventFrameEthernet"):
        self.readTDEventCom(element, event)
        event.setStaticSocketConnectionRef(self.getChildElementOptionalRefType(element, "STATIC-SOCKET-CONNECTION-REF"))
        type_element = self.find(element, "TD-EVENT-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventFrameEthernetTypeEnum()
            enum.value = type_element.text
            event.setTdEventType(enum)
        filters_element = self.find(element, "TD-HEADER-ID-FILTERS")
        if filters_element is not None:
            for range_element in self.findall(filters_element, "TD-HEADER-ID-RANGE"):
                header_id_range = TDHeaderIdRange()
                self.readTDHeaderIdRange(range_element, header_id_range)
                event.addTDHeaderIdFilter(header_id_range)
        for ref in self.getChildElementRefTypeList(element, "TD-PDU-TRIGGERING-FILTER-REFS/TD-PDU-TRIGGERING-FILTER-REF"):
            event.addTdPduTriggeringFilterRef(ref)

    def readTimingDescriptions(self, element: ET.Element, extension: TimingExtension):
        for child_element in self.findall(element, "TIMING-DESCRIPTIONS/*"):
            tag_name = self.getTagName(child_element)
            short_name = self.getShortName(child_element)
            if tag_name == "TD-EVENT-VFB-REFERENCE":
                event = TDEventVfbReference(extension, short_name)
                self.readTDEventVfbReference(child_element, event)
            elif tag_name == "TD-EVENT-VFB":
                event = TDEventVfb(extension, short_name)
                self.readTDEventVfb(child_element, event)
            elif tag_name == "TD-EVENT-VARIABLE-DATA-PROTOTYPE":
                event = TDEventVariableDataPrototype(extension, short_name)
                self.readTDEventVariableDataPrototype(child_element, event)
            elif tag_name == "TD-EVENT-OPERATION":
                event = TDEventOperation(extension, short_name)
                self.readTDEventOperation(child_element, event)
            elif tag_name == "TD-EVENT-MODE-DECLARATION":
                event = TDEventModeDeclaration(extension, short_name)
                self.readTDEventModeDeclaration(child_element, event)
            elif tag_name == "TD-EVENT-TRIGGER":
                event = TDEventTrigger(extension, short_name)
                self.readTDEventTrigger(child_element, event)
            elif tag_name == "TD-EVENT-SWC-INTERNAL-BEHAVIOR":
                event = TDEventSwcInternalBehavior(extension, short_name)
                self.readTDEventSwcInternalBehavior(child_element, event)
            elif tag_name == "TD-EVENT-SWC-INTERNAL-BEHAVIOR-REFERENCE":
                event = TDEventSwcInternalBehaviorReference(extension, short_name)
                self.readTDEventSwcInternalBehaviorReference(child_element, event)
            elif tag_name == "TD-EVENT-BSW-INTERNAL-BEHAVIOR":
                event = TDEventBswInternalBehavior(extension, short_name)
                self.readTDEventBswInternalBehavior(child_element, event)
            elif tag_name == "TD-EVENT-BSW-MODULE":
                event = TDEventBswModule(extension, short_name)
                self.readTDEventBswModule(child_element, event)
            elif tag_name == "TD-EVENT-BSW-MODE-DECLARATION":
                event = TDEventBswModeDeclaration(extension, short_name)
                self.readTDEventBswModeDeclaration(child_element, event)
            elif tag_name == "TD-EVENT-COMPLEX":
                event = TDEventComplex(extension, short_name)
                self.readTDEventComplex(child_element, event)
            elif tag_name == "TD-EVENT-I-SIGNAL":
                event = TDEventISignal(extension, short_name)
                self.readTDEventISignal(child_element, event)
            elif tag_name == "TD-EVENT-I-PDU":
                event = TDEventIPdu(extension, short_name)
                self.readTDEventIPdu(child_element, event)
            elif tag_name == "TD-EVENT-FRAME":
                event = TDEventFrame(extension, short_name)
                self.readTDEventFrame(child_element, event)
            elif tag_name == "TD-EVENT-FRAME-ETHERNET":
                event = TDEventFrameEthernet(extension, short_name)
                self.readTDEventFrameEthernet(child_element, event)
            elif tag_name == "TD-EVENT-FR-CLUSTER-CYCLE-START":
                event = TDEventFrClusterCycleStart(extension, short_name)
                self.readTDEventFrClusterCycleStart(child_element, event)
            elif tag_name == "TD-EVENT-TT-CAN-CYCLE-START":
                event = TDEventTTCanCycleStart(extension, short_name)
                self.readTDEventTTCanCycleStart(child_element, event)
            elif tag_name == "TD-EVENT-SLLET-PORT":
                event = TDEventSLLETPort(extension, short_name)
                self.readTDEventSLLETPort(child_element, event)
            elif tag_name == "TIMING-DESCRIPTION-EVENT-CHAIN":
                event = TimingDescriptionEventChain(extension, short_name)
                self.readTimingDescriptionEventChain(child_element, event)
            else:
                self.notImplemented("Unsupported TIMING-DESCRIPTIONS item <%s>" % tag_name)
                continue
            extension.addElement(event)
            extension.addTimingDescription(event)

    def readTDEventVfb(self, element: ET.Element, event: TDEventVfb):
        self.readTimingDescriptionEvent(element, event)
        event.setComponentIRef(self.readEOCComponentIRef(element, "COMPONENT-IREF"))

    def readTDEventVfbReference(self, element: ET.Element, event: TDEventVfbReference):
        self.readTDEventVfb(element, event)
        event.setReferencedTDEventVfbRef(self.getChildElementOptionalRefType(element, "REFERENCED-TD-EVENT-VFB-REF"))

    def readTDEventVfbPort(self, element: ET.Element, event: TDEventVfbPort):
        self.readTDEventVfb(element, event)
        is_external = self.find(element, "IS-EXTERNAL")
        if is_external is not None:
            event.setIsExternal(Boolean().setValue(is_external.text == "true"))
        event.setPortRef(self.getChildElementOptionalRefType(element, "PORT-REF"))
        event.setPortPrototypeBlueprintRef(self.getChildElementOptionalRefType(element, "PORT-PROTOTYPE-BLUEPRINT-REF"))

    def readTDEventVariableDataPrototype(self, element: ET.Element, event: TDEventVariableDataPrototype):
        self.readTDEventVfbPort(element, event)
        event.setDataElementRef(self.getChildElementOptionalRefType(element, "DATA-ELEMENT-REF"))
        type_element = self.find(element, "TD-EVENT-VARIABLE-DATA-PROTOTYPE-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventVariableDataPrototypeTypeEnum()
            enum.value = type_element.text
            event.setTdEventVariableDataPrototypeType(enum)

    def readTDEventOperation(self, element: ET.Element, event: TDEventOperation):
        self.readTDEventVfbPort(element, event)
        event.setOperationRef(self.getChildElementOptionalRefType(element, "OPERATION-REF"))
        type_element = self.find(element, "TD-EVENT-OPERATION-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventOperationTypeEnum()
            enum.value = type_element.text
            event.setTdEventOperationType(enum)

    def readTDEventModeDeclaration(self, element: ET.Element, event: TDEventModeDeclaration):
        self.readTDEventVfbPort(element, event)
        event.setEntryModeDeclarationRef(self.getChildElementOptionalRefType(element, "ENTRY-MODE-DECLARATION-REF"))
        event.setExitModeDeclarationRef(self.getChildElementOptionalRefType(element, "EXIT-MODE-DECLARATION-REF"))
        event.setModeDeclarationRef(self.getChildElementOptionalRefType(element, "MODE-DECLARATION-REF"))
        type_element = self.find(element, "TD-EVENT-MODE-DECLARATION-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventModeDeclarationTypeEnum()
            enum.value = type_element.text
            event.setTdEventModeDeclarationType(enum)

    def readTDEventTrigger(self, element: ET.Element, event: TDEventTrigger):
        self.readTDEventVfbPort(element, event)
        event.setTriggerRef(self.getChildElementOptionalRefType(element, "TRIGGER-REF"))
        type_element = self.find(element, "TD-EVENT-TRIGGER-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventTriggerTypeEnum()
            enum.value = type_element.text
            event.setTdEventTriggerType(enum)

    def readTDEventSwc(self, element: ET.Element, event: TDEventSwc):
        self.readTimingDescriptionEvent(element, event)
        event.setComponentIRef(self.readEOCComponentIRef(element, "COMPONENT-IREF"))

    def readTDEventSwcInternalBehavior(self, element: ET.Element, event: TDEventSwcInternalBehavior):
        self.readTDEventSwc(element, event)
        event.setRunnableRef(self.getChildElementOptionalRefType(element, "RUNNABLE-REF"))
        type_element = self.find(element, "TD-EVENT-SWC-INTERNAL-BEHAVIOR-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventSwcInternalBehaviorTypeEnum()
            enum.value = type_element.text
            event.setTdEventSwcInternalBehaviorType(enum)
        event.setVariableAccessRef(self.getChildElementOptionalRefType(element, "VARIABLE-ACCESS-REF"))

    def readTDEventBswInternalBehavior(self, element: ET.Element, event: TDEventBswInternalBehavior):
        self.readTimingDescriptionEvent(element, event)
        event.setBswModuleEntityRef(self.getChildElementOptionalRefType(element, "BSW-MODULE-ENTITY-REF"))
        type_element = self.find(element, "TD-EVENT-BSW-INTERNAL-BEHAVIOR-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventBswInternalBehaviorTypeEnum()
            enum.value = type_element.text
            event.setTdEventBswInternalBehaviorType(enum)

    def readTDEventBsw(self, element: ET.Element, event: TDEventBsw):
        self.readTimingDescriptionEvent(element, event)
        event.setBswModuleDescriptionRef(self.getChildElementOptionalRefType(element, "BSW-MODULE-DESCRIPTION-REF"))

    def readTDEventBswModule(self, element: ET.Element, event: TDEventBswModule):
        self.readTDEventBsw(element, event)
        event.setBswModuleEntryRef(self.getChildElementOptionalRefType(element, "BSW-MODULE-ENTRY-REF"))
        type_element = self.find(element, "TD-EVENT-BSW-MODULE-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventBswModuleTypeEnum()
            enum.value = type_element.text
            event.setTdEventBswModuleType(enum)

    def readTDEventBswModeDeclaration(self, element: ET.Element, event: TDEventBswModeDeclaration):
        self.readTDEventBsw(element, event)
        event.setEntryModeDeclarationRef(self.getChildElementOptionalRefType(element, "ENTRY-MODE-DECLARATION-REF"))
        event.setExitModeDeclarationRef(self.getChildElementOptionalRefType(element, "EXIT-MODE-DECLARATION-REF"))
        event.setModeDeclarationRef(self.getChildElementOptionalRefType(element, "MODE-DECLARATION-REF"))
        type_element = self.find(element, "TD-EVENT-BSW-MODE-DECLARATION-TYPE")
        if type_element is not None and type_element.text is not None:
            enum = TDEventBswModeDeclarationTypeEnum()
            enum.value = type_element.text
            event.setTdEventBswModeDeclarationType(enum)

    def readTDEventComplex(self, element: ET.Element, event: TDEventComplex):
        self.readTimingDescriptionEvent(element, event)

    def readTDEventSLLET(self, element: ET.Element, event: TDEventSLLET):
        self.readTimingDescriptionEvent(element, event)

    def readTDEventSLLETPort(self, element: ET.Element, event: TDEventSLLETPort):
        self.readTDEventSLLET(element, event)
        event.setPortRef(self.getChildElementOptionalRefType(element, "PORT-REF"))

    def readTDEventSwcInternalBehaviorReference(self, element: ET.Element, event: TDEventSwcInternalBehaviorReference):
        self.readTDEventSwc(element, event)
        event.setReferencedTDEventSwcRef(self.getChildElementOptionalRefType(element, "REFERENCED-TD-EVENT-SWC-REF"))

    def readTDEventOccurrenceExpression(self, element: ET.Element, parent) -> TDEventOccurrenceExpression:
        expression = TDEventOccurrenceExpression()
        self.readARObject(element, expression)
        for child_element in self.findall(element, "ARGUMENTS/AUTOSAR-OPERATION-ARGUMENT-INSTANCE"):
            argument = expression.createArgument(parent, self.getShortName(child_element))
            self.readAutosarOperationArgumentInstance(child_element, argument)
        formula_element = self.find(element, "FORMULA")
        if formula_element is not None:
            expression.setFormula(self.readTDEventOccurrenceExpressionFormula(formula_element))
        for child_element in self.findall(element, "MODES/TIMING-MODE-INSTANCE"):
            mode = expression.createMode(parent, self.getShortName(child_element))
            self.readTimingModeInstance(child_element, mode)
        for child_element in self.findall(element, "VARIABLES/AUTOSAR-VARIABLE-INSTANCE"):
            variable = expression.createVariable(parent, self.getShortName(child_element))
            self.readAutosarVariableInstance(child_element, variable)
        return expression

    def readTDEventOccurrenceExpressionFormula(self, element: ET.Element) -> TDEventOccurrenceExpressionFormula:
        formula = TDEventOccurrenceExpressionFormula()
        formula.setArgumentRef(self.getChildElementOptionalRefType(element, "ARGUMENT-REF"))
        formula.setEventRef(self.getChildElementOptionalRefType(element, "EVENT-REF"))
        formula.setModeRef(self.getChildElementOptionalRefType(element, "MODE-REF"))
        formula.setVariableRef(self.getChildElementOptionalRefType(element, "VARIABLE-REF"))
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, formula)
        return formula

    def readTimingConditionFormula(self, element: ET.Element) -> TimingConditionFormula:
        tcf = TimingConditionFormula()
        tcf.setTimingArgumentRef(self.getChildElementOptionalRefType(element, "TIMING-ARGUMENT-REF"))
        tcf.setTimingConditionRef(self.getChildElementOptionalRefType(element, "TIMING-CONDITION-REF"))
        tcf.setTimingEventRef(self.getChildElementOptionalRefType(element, "TIMING-EVENT-REF"))
        tcf.setTimingModeRef(self.getChildElementOptionalRefType(element, "TIMING-MODE-REF"))
        tcf.setTimingVariableRef(self.getChildElementOptionalRefType(element, "TIMING-VARIABLE-REF"))
        if element.text is not None and element.text.strip() != "":
            self.readMixedStringText(element, tcf)
        return tcf

    def readTimingCondition(self, element: ET.Element, condition: TimingCondition):
        self.readIdentifiable(element, condition)
        formula_element = self.find(element, "TIMING-CONDITION-FORMULA")
        if formula_element is not None:
            condition.setTimingConditionFormula(self.readTimingConditionFormula(formula_element))

    def readModeInBswInstanceRef(self, element: ET.Element) -> ModeInBswInstanceRef:
        ref = ModeInBswInstanceRef()
        self.readARObject(element, ref)
        ref.setContextBswImplementationRef(self.getChildElementOptionalRefType(element, "CONTEXT-BSW-IMPLEMENTATION-REF"))
        ref.setContextModeDeclarationGroupPrototypeRef(self.getChildElementOptionalRefType(element, "CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF"))
        ref.setTargetModeDeclarationRef(self.getChildElementOptionalRefType(element, "TARGET-MODE-DECLARATION-REF"))
        return ref

    def readModeInSwcInstanceRef(self, element: ET.Element) -> ModeInSwcInstanceRef:
        ref = ModeInSwcInstanceRef()
        self.readARObject(element, ref)
        for component_ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
            ref.addContextComponentRef(component_ref)
        ref.setContextPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-REF"))
        ref.setContextModeDeclarationGroupPrototypeRef(self.getChildElementOptionalRefType(element, "CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF"))
        ref.setTargetModeDeclarationRef(self.getChildElementOptionalRefType(element, "TARGET-MODE-DECLARATION-REF"))
        return ref

    def readTimingModeInstance(self, element: ET.Element, instance: TimingModeInstance):
        self.readIdentifiable(element, instance)
        mode_instance_element = self.find(element, "MODE-INSTANCE")
        if mode_instance_element is not None:
            for child_element in mode_instance_element:
                tag_name = self.getTagName(child_element)
                if tag_name == "MODE-IN-BSW-INSTANCE-REF":
                    instance.setModeInstance(self.readModeInBswInstanceRef(child_element))
                elif tag_name == "MODE-IN-SWC-INSTANCE-REF":
                    instance.setModeInstance(self.readModeInSwcInstanceRef(child_element))
                else:
                    self.notImplemented("Unsupported TimingModeInstance.modeInstance <%s>" % tag_name)

    def readTimingExtensionResource(self, element: ET.Element, resource: TimingExtensionResource) -> TimingExtensionResource:
        self.readIdentifiable(element, resource)
        for child_element in self.findall(element, "TIMING-ARGUMENTS/AUTOSAR-OPERATION-ARGUMENT-INSTANCE"):
            argument = resource.createTimingArgument(self.getShortName(child_element))
            self.readAutosarOperationArgumentInstance(child_element, argument)
        for child_element in self.findall(element, "TIMING-MODES/TIMING-MODE-INSTANCE"):
            mode = resource.createTimingMode(self.getShortName(child_element))
            self.readTimingModeInstance(child_element, mode)
        for child_element in self.findall(element, "TIMING-VARIABLES/AUTOSAR-VARIABLE-INSTANCE"):
            variable = resource.createTimingVariable(self.getShortName(child_element))
            self.readAutosarVariableInstance(child_element, variable)
        return resource

    def readAutosarOperationArgumentInstance(self, element: ET.Element, instance: AutosarOperationArgumentInstance) -> AutosarOperationArgumentInstance:
        self.readIdentifiable(element, instance)
        iref_element = self.find(element, "OPERATION-ARGUMENT-INSTANCE-IREF")
        if iref_element is not None:
            instance.setOperationArgumentInstanceIRef(self.readOperationArgumentInComponentInstanceRef(iref_element))
        return instance

    def readComponentInCompositionInstanceRef(self, element: ET.Element) -> ComponentInCompositionInstanceRef:
        iref = ComponentInCompositionInstanceRef()
        self.readARObject(element, iref)
        iref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
            iref.addContextComponentRef(ref)
        iref.setTargetComponentRef(self.getChildElementOptionalRefType(element, "TARGET-COMPONENT-REF"))
        return iref

    def readOperationArgumentInComponentInstanceRef(self, element: ET.Element) -> OperationArgumentInComponentInstanceRef:
        iref = OperationArgumentInComponentInstanceRef()
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
            iref.addContextComponentRef(ref)
        iref.setContextPortPrototypeRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-PROTOTYPE-REF"))
        iref.setContextOperationRef(self.getChildElementOptionalRefType(element, "CONTEXT-OPERATION-REF"))
        iref.setRootArgumentDataPrototypeRef(self.getChildElementOptionalRefType(element, "ROOT-ARGUMENT-DATA-PROTOTYPE-REF"))
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-DATA-PROTOTYPE-REF"):
            iref.addContextDataPrototypeRef(ref)
        iref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-REF"))
        return iref

    def readAutosarVariableInstance(self, element: ET.Element, instance: AutosarVariableInstance) -> AutosarVariableInstance:
        self.readIdentifiable(element, instance)
        iref_element = self.find(element, "VARIABLE-INSTANCE-IREF")
        if iref_element is not None:
            instance.setVariableInstanceIRef(self.readVariableInComponentInstanceRef(iref_element))
        return instance

    def readVariableInComponentInstanceRef(self, element: ET.Element) -> VariableInComponentInstanceRef:
        iref = VariableInComponentInstanceRef()
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
            iref.addContextComponentRef(ref)
        iref.setContextPortPrototypeRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-PROTOTYPE-REF"))
        iref.setRootVariableDataPrototypeRef(self.getChildElementOptionalRefType(element, "ROOT-VARIABLE-DATA-PROTOTYPE-REF"))
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-DATA-PROTOTYPE-REF"):
            iref.addContextDataPrototypeRef(ref)
        iref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-REF"))
        return iref

    def readTimingConstraint(self, element: ET.Element, constraint: TimingConstraint):
        self.readIdentifiable(element, constraint)
        self.readTraceable(element, constraint)
        constraint.setTimingConditionRef(self.getChildElementOptionalRefType(element, "TIMING-CONDITION-REF"))

    def readSynchronizationTimingConstraint(self, element: ET.Element, constraint: SynchronizationTimingConstraint):
        self.logger.debug("readSynchronizationTimingConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        literal = self.getChildElementOptionalLiteral(element, "EVENT-OCCURRENCE-KIND")
        if literal is not None:
            constraint.setEventOccurrenceKind(EventOccurrenceKindEnum().setValue(literal.getText()))
        for ref in self.getChildElementRefTypeList(element, "SCOPE-EVENT-REFS/SCOPE-EVENT-REF"):
            constraint.addScopeEvent(ref)
        for ref in self.getChildElementRefTypeList(element, "SCOPE-REFS/SCOPE-REF"):
            constraint.addScope(ref)
        literal = self.getChildElementOptionalLiteral(element, "SYNCHRONIZATION-CONSTRAINT-TYPE")
        if literal is not None:
            constraint.setSynchronizationConstraintType(SynchronizationTypeEnum().setValue(literal.getText()))
        tolerance_element = self.find(element, "TOLERANCE")
        if tolerance_element is not None:
            tolerance = MultidimensionalTime()
            self.readMultidimensionalTime(tolerance_element, tolerance)
            constraint.setTolerance(tolerance)

    def readLatencyTimingConstraint(self, element: ET.Element, constraint: LatencyTimingConstraint):
        self.logger.debug("readLatencyTimingConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        literal = self.getChildElementOptionalLiteral(element, "LATENCY-CONSTRAINT-TYPE")
        if literal is not None:
            constraint.setLatencyConstraintType(LatencyConstraintTypeEnum().setValue(literal.getText()))
        constraint.setScopeRef(self.getChildElementOptionalRefType(element, "SCOPE-REF"))
        minimum_element = self.find(element, "MINIMUM")
        if minimum_element is not None:
            minimum = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_element, minimum)
            constraint.setMinimum(minimum)
        maximum_element = self.find(element, "MAXIMUM")
        if maximum_element is not None:
            maximum = MultidimensionalTime()
            self.readMultidimensionalTime(maximum_element, maximum)
            constraint.setMaximum(maximum)
        nominal_element = self.find(element, "NOMINAL")
        if nominal_element is not None:
            nominal = MultidimensionalTime()
            self.readMultidimensionalTime(nominal_element, nominal)
            constraint.setNominal(nominal)

    def readExecutionTimeConstraint(self, element: ET.Element, constraint: ExecutionTimeConstraint):
        self.logger.debug("readExecutionTimeConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        constraint.setComponentIRef(self.readEOCComponentIRef(element, "COMPONENT-IREF"))
        constraint.setExecutableRef(self.getChildElementOptionalRefType(element, "EXECUTABLE-REF"))
        literal = self.getChildElementOptionalLiteral(element, "EXECUTION-TIME-TYPE")
        if literal is not None:
            constraint.setExecutionTimeType(ExecutionTimeTypeEnum().setValue(literal.getText()))
        maximum_element = self.find(element, "MAXIMUM")
        if maximum_element is not None:
            maximum = MultidimensionalTime()
            self.readMultidimensionalTime(maximum_element, maximum)
            constraint.setMaximum(maximum)
        minimum_element = self.find(element, "MINIMUM")
        if minimum_element is not None:
            minimum = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_element, minimum)
            constraint.setMinimum(minimum)

    def readSynchronizationPointConstraint(self, element: ET.Element, constraint: SynchronizationPointConstraint):
        self.logger.debug("readSynchronizationPointConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        for ref in self.getChildElementRefTypeList(element, "SOURCE-EEC-REFS/SOURCE-EEC-REF"):
            constraint.addSourceEecRef(ref)
        for ref in self.getChildElementRefTypeList(element, "SOURCE-EVENT-REFS/SOURCE-EVENT-REF"):
            constraint.addSourceEventRef(ref)
        for ref in self.getChildElementRefTypeList(element, "TARGET-EEC-REFS/TARGET-EEC-REF"):
            constraint.addTargetEecRef(ref)
        for ref in self.getChildElementRefTypeList(element, "TARGET-EVENT-REFS/TARGET-EVENT-REF"):
            constraint.addTargetEventRef(ref)

    def readOffsetTimingConstraint(self, element: ET.Element, constraint: OffsetTimingConstraint):
        self.logger.debug("readOffsetTimingConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        constraint.setSourceRef(self.getChildElementOptionalRefType(element, "SOURCE-REF"))
        constraint.setTargetRef(self.getChildElementOptionalRefType(element, "TARGET-REF"))
        minimum_element = self.find(element, "MINIMUM")
        if minimum_element is not None:
            minimum = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_element, minimum)
            constraint.setMinimum(minimum)
        maximum_element = self.find(element, "MAXIMUM")
        if maximum_element is not None:
            maximum = MultidimensionalTime()
            self.readMultidimensionalTime(maximum_element, maximum)
            constraint.setMaximum(maximum)

    def readAgeConstraint(self, element: ET.Element, constraint: AgeConstraint):
        self.logger.debug("readAgeConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        maximum_element = self.find(element, "MAXIMUM")
        if maximum_element is not None:
            maximum = MultidimensionalTime()
            self.readMultidimensionalTime(maximum_element, maximum)
            constraint.setMaximum(maximum)
        minimum_element = self.find(element, "MINIMUM")
        if minimum_element is not None:
            minimum = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_element, minimum)
            constraint.setMinimum(minimum)
        constraint.setScopeRef(self.getChildElementOptionalRefType(element, "SCOPE-REF"))

    def readEventTriggeringConstraint(self, element: ET.Element, constraint: EventTriggeringConstraint):
        self.readTimingConstraint(element, constraint)
        constraint.setEventRef(self.getChildElementOptionalRefType(element, "EVENT-REF"))

    def readPeriodicEventTriggering(self, element: ET.Element, constraint: PeriodicEventTriggering):
        self.logger.debug("readPeriodicEventTriggering %s" % self.getShortName(element))
        self.readEventTriggeringConstraint(element, constraint)
        jitter_element = self.find(element, "JITTER")
        if jitter_element is not None:
            jitter = MultidimensionalTime()
            self.readMultidimensionalTime(jitter_element, jitter)
            constraint.setJitter(jitter)
        minimum_inter_arrival_time_element = self.find(element, "MINIMUM-INTER-ARRIVAL-TIME")
        if minimum_inter_arrival_time_element is not None:
            minimum_inter_arrival_time = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_inter_arrival_time_element, minimum_inter_arrival_time)
            constraint.setMinimumInterArrivalTime(minimum_inter_arrival_time)
        period_element = self.find(element, "PERIOD")
        if period_element is not None:
            period = MultidimensionalTime()
            self.readMultidimensionalTime(period_element, period)
            constraint.setPeriod(period)

    def readSporadicEventTriggering(self, element: ET.Element, constraint: SporadicEventTriggering):
        self.logger.debug("readSporadicEventTriggering %s" % self.getShortName(element))
        self.readEventTriggeringConstraint(element, constraint)
        jitter_element = self.find(element, "JITTER")
        if jitter_element is not None:
            jitter = MultidimensionalTime()
            self.readMultidimensionalTime(jitter_element, jitter)
            constraint.setJitter(jitter)
        maximum_inter_arrival_time_element = self.find(element, "MAXIMUM-INTER-ARRIVAL-TIME")
        if maximum_inter_arrival_time_element is not None:
            maximum_inter_arrival_time = MultidimensionalTime()
            self.readMultidimensionalTime(maximum_inter_arrival_time_element, maximum_inter_arrival_time)
            constraint.setMaximumInterArrivalTime(maximum_inter_arrival_time)
        minimum_inter_arrival_time_element = self.find(element, "MINIMUM-INTER-ARRIVAL-TIME")
        if minimum_inter_arrival_time_element is not None:
            minimum_inter_arrival_time = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_inter_arrival_time_element, minimum_inter_arrival_time)
            constraint.setMinimumInterArrivalTime(minimum_inter_arrival_time)
        period_element = self.find(element, "PERIOD")
        if period_element is not None:
            period = MultidimensionalTime()
            self.readMultidimensionalTime(period_element, period)
            constraint.setPeriod(period)

    def readConcretePatternEventTriggering(self, element: ET.Element, constraint: ConcretePatternEventTriggering):
        self.logger.debug("readConcretePatternEventTriggering %s" % self.getShortName(element))
        self.readEventTriggeringConstraint(element, constraint)
        offsets_element = self.find(element, "OFFSETS")
        if offsets_element is not None:
            for time_value_element in self.findall(offsets_element, "TIME-VALUE"):
                offset = MultidimensionalTime()
                self.readMultidimensionalTime(time_value_element, offset)
                constraint.addOffset(offset)
        pattern_jitter_element = self.find(element, "PATTERN-JITTER")
        if pattern_jitter_element is not None:
            pattern_jitter = MultidimensionalTime()
            self.readMultidimensionalTime(pattern_jitter_element, pattern_jitter)
            constraint.setPatternJitter(pattern_jitter)
        pattern_length_element = self.find(element, "PATTERN-LENGTH")
        if pattern_length_element is not None:
            pattern_length = MultidimensionalTime()
            self.readMultidimensionalTime(pattern_length_element, pattern_length)
            constraint.setPatternLength(pattern_length)
        pattern_period_element = self.find(element, "PATTERN-PERIOD")
        if pattern_period_element is not None:
            pattern_period = MultidimensionalTime()
            self.readMultidimensionalTime(pattern_period_element, pattern_period)
            constraint.setPatternPeriod(pattern_period)

    def readBurstPatternEventTriggering(self, element: ET.Element, constraint: BurstPatternEventTriggering):
        self.logger.debug("readBurstPatternEventTriggering %s" % self.getShortName(element))
        self.readEventTriggeringConstraint(element, constraint)
        constraint.setMaxNumberOfOccurrences(self.getChildElementOptionalPositiveInteger(element, "MAX-NUMBER-OF-OCCURRENCES"))
        minimum_inter_arrival_time_element = self.find(element, "MINIMUM-INTER-ARRIVAL-TIME")
        if minimum_inter_arrival_time_element is not None:
            minimum_inter_arrival_time = MultidimensionalTime()
            self.readMultidimensionalTime(minimum_inter_arrival_time_element, minimum_inter_arrival_time)
            constraint.setMinimumInterArrivalTime(minimum_inter_arrival_time)
        constraint.setMinNumberOfOccurrences(self.getChildElementOptionalPositiveInteger(element, "MIN-NUMBER-OF-OCCURRENCES"))
        pattern_jitter_element = self.find(element, "PATTERN-JITTER")
        if pattern_jitter_element is not None:
            pattern_jitter = MultidimensionalTime()
            self.readMultidimensionalTime(pattern_jitter_element, pattern_jitter)
            constraint.setPatternJitter(pattern_jitter)
        pattern_length_element = self.find(element, "PATTERN-LENGTH")
        if pattern_length_element is not None:
            pattern_length = MultidimensionalTime()
            self.readMultidimensionalTime(pattern_length_element, pattern_length)
            constraint.setPatternLength(pattern_length)
        pattern_period_element = self.find(element, "PATTERN-PERIOD")
        if pattern_period_element is not None:
            pattern_period = MultidimensionalTime()
            self.readMultidimensionalTime(pattern_period_element, pattern_period)
            constraint.setPatternPeriod(pattern_period)

    def readArbitraryEventTriggering(self, element: ET.Element, constraint: ArbitraryEventTriggering):
        self.logger.debug("readArbitraryEventTriggering %s" % self.getShortName(element))
        self.readEventTriggeringConstraint(element, constraint)
        minimum_distances_element = self.find(element, "MINIMUM-DISTANCES")
        if minimum_distances_element is not None:
            for time_value_element in self.findall(minimum_distances_element, "TIME-VALUE"):
                distance = MultidimensionalTime()
                self.readMultidimensionalTime(time_value_element, distance)
                constraint.addMinimumDistance(distance)
        maximum_distances_element = self.find(element, "MAXIMUM-DISTANCES")
        if maximum_distances_element is not None:
            for time_value_element in self.findall(maximum_distances_element, "TIME-VALUE"):
                distance = MultidimensionalTime()
                self.readMultidimensionalTime(time_value_element, distance)
                constraint.addMaximumDistance(distance)
        confidence_intervals_element = self.find(element, "CONFIDENCE-INTERVALS")
        if confidence_intervals_element is not None:
            for interval_element in self.findall(confidence_intervals_element, "CONFIDENCE-INTERVAL"):
                interval = ConfidenceInterval()
                self.readConfidenceInterval(interval_element, interval)
                constraint.addConfidenceInterval(interval)

    def readTimingClock(self, element: ET.Element, clock: TimingClock):
        self.readIdentifiable(element, clock)
        time_bases_element = self.find(element, "PLATFORM-TIME-BASES")
        if time_bases_element is not None:
            conditional_element = self.find(time_bases_element, "GLOBAL-TIME-DOMAIN-REF-CONDITIONAL")
            if conditional_element is not None:
                clock.setPlatformTimeBaseRef(self.getChildElementOptionalRefType(conditional_element, "GLOBAL-TIME-DOMAIN-REF"))

    def readTDLETZoneClock(self, element: ET.Element, clock: TDLETZoneClock):
        self.readTimingClock(element, clock)
        accuracy_ext_element = self.find(element, "ACCURACY-EXT")
        if accuracy_ext_element is not None:
            accuracy_ext = MultidimensionalTime()
            self.readMultidimensionalTime(accuracy_ext_element, accuracy_ext)
            clock.setAccuracyExt(accuracy_ext)
        accuracy_int_element = self.find(element, "ACCURACY-INT")
        if accuracy_int_element is not None:
            accuracy_int = MultidimensionalTime()
            self.readMultidimensionalTime(accuracy_int_element, accuracy_int)
            clock.setAccuracyInt(accuracy_int)

    def readTimingClockSyncAccuracy(self, element: ET.Element, sync_accuracy: TimingClockSyncAccuracy):
        self.readIdentifiable(element, sync_accuracy)
        accuracy_element = self.find(element, "ACCURACY")
        if accuracy_element is not None:
            accuracy = MultidimensionalTime()
            self.readMultidimensionalTime(accuracy_element, accuracy)
            sync_accuracy.setAccuracy(accuracy)
        sync_accuracy.setLowerRef(self.getChildElementOptionalRefType(element, "LOWER-REF"))
        sync_accuracy.setUpperRef(self.getChildElementOptionalRefType(element, "UPPER-REF"))

    def readEOCExecutableEntityRefAbstract(self, element: ET.Element, obj: EOCExecutableEntityRefAbstract):
        for ref in self.getChildElementRefTypeList(element, "DIRECT-SUCCESSOR-REFS/DIRECT-SUCCESSOR-REF"):
            obj.addDirectSuccessorRef(ref)

    def readEOCComponentIRef(self, element: ET.Element, key: str) -> Optional[ComponentInCompositionInstanceRef]:
        component_iref_element = self.find(element, key)
        if component_iref_element is not None:
            return self.readComponentInCompositionInstanceRef(component_iref_element)
        return None

    def readEOCExecutableEntityRef(self, element: ET.Element, entity_ref: EOCExecutableEntityRef):
        self.readIdentifiable(element, entity_ref)
        self.readEOCExecutableEntityRefAbstract(element, entity_ref)
        entity_ref.setBswModuleInstanceRef(self.getChildElementOptionalRefType(element, "BSW-MODULE-INSTANCE-REF"))
        entity_ref.setComponentIRef(self.readEOCComponentIRef(element, "COMPONENT-IREF"))
        entity_ref.setExecutableRef(self.getChildElementOptionalRefType(element, "EXECUTABLE-REF"))
        for ref in self.getChildElementRefTypeList(element, "SUCCESSOR-REFS/SUCCESSOR-REF"):
            entity_ref.addSuccessorRef(ref)

    def readEOCEventRef(self, element: ET.Element, event_ref: EOCEventRef):
        self.readIdentifiable(element, event_ref)
        self.readEOCExecutableEntityRefAbstract(element, event_ref)
        event_ref.setBswModuleInstanceRef(self.getChildElementOptionalRefType(element, "BSW-MODULE-INSTANCE-REF"))
        event_ref.setComponentIRef(self.readEOCComponentIRef(element, "COMPONENT-IREF"))
        event_ref.setEventRef(self.getChildElementOptionalRefType(element, "EVENT-REF"))
        for ref in self.getChildElementRefTypeList(element, "SUCCESSOR-REFS/SUCCESSOR-REF"):
            event_ref.addSuccessorRef(ref)

    def readEOCExecutableEntityRefGroup(self, element: ET.Element, group: EOCExecutableEntityRefGroup):
        self.readIdentifiable(element, group)
        self.readEOCExecutableEntityRefAbstract(element, group)
        literal = self.getChildElementOptionalLiteral(element, "LET-DATA-EXCHANGE-PARADIGM")
        if literal is not None:
            group.setLetDataExchangeParadigm(LetDataExchangeParadigmEnum().setValue(literal.getText()))
        for ref in self.getChildElementRefTypeList(element, "LET-INTERVAL-REFS/LET-INTERVAL-REF"):
            group.addLetIntervalRef(ref)
        group.setMaxCycleRepetitions(self.getChildElementOptionalPositiveInteger(element, "MAX-CYCLE-REPETITIONS"))
        group.setMaxCycles(self.getChildElementOptionalIntegerValue(element, "MAX-CYCLES"))
        group.setMaxSlots(self.getChildElementOptionalIntegerValue(element, "MAX-SLOTS"))
        group.setMaxSlotsPerCycle(self.getChildElementOptionalPositiveInteger(element, "MAX-SLOTS-PER-CYCLE"))
        for ref in self.getChildElementRefTypeList(element, "NESTED-ELEMENT-REFS/NESTED-ELEMENT-REF"):
            group.addNestedElementRef(ref)
        for ref in self.getChildElementRefTypeList(element, "SUCCESSOR-REFS/SUCCESSOR-REF"):
            group.addSuccessorRef(ref)
        group.setTriggeringEventRef(self.getChildElementOptionalRefType(element, "TRIGGERING-EVENT-REF"))

    def readSwcInternalBehaviorVariationPointProxies(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "VARIATION-POINT-PROXYS/VARIATION-POINT-PROXY"):
            short_name = self.getShortName(child_element)
            proxy = VariationPointProxy(behavior, short_name)
            self.readVariationPointProxy(child_element, proxy)
            behavior.addVariationPointProxy(proxy)

    def readIncludedModeDeclarationGroupSet(self, element: ET.Element, group_set: IncludedModeDeclarationGroupSet):
        for ref in self.getChildElementRefTypeList(element, "MODE-DECLARATION-GROUP-REFS/MODE-DECLARATION-GROUP-REF"):
            group_set.addModeDeclarationGroupRef(ref)
        group_set.setPrefix(self.getChildElementOptionalIdentifier(element, "PREFIX"))

    def readSwcInternalBehaviorIncludedModeDeclarationGroupSets(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "INCLUDED-MODE-DECLARATION-GROUP-SETS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "INCLUDED-MODE-DECLARATION-GROUP-SET":
                group_set = IncludedModeDeclarationGroupSet()
                self.readIncludedModeDeclarationGroupSet(child_element, group_set)
                behavior.addIncludedModeDeclarationGroupSet(group_set)
            else:
                self.notImplemented("Unsupported IncludedModeDeclarationGroupSet <%s>" % tag_name)

    def readSwcInternalBehaviorExclusiveAreaPolicies(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "EXCLUSIVE-AREA-POLICYS/SWC-EXCLUSIVE-AREA-POLICY"):
            policy = SwcExclusiveAreaPolicy()
            policy.setApiPrinciple(self.getChildElementOptionalLiteral(child_element, "API-PRINCIPLE"))
            policy.setExclusiveAreaRef(self.getChildElementOptionalRefType(child_element, "EXCLUSIVE-AREA-REF"))
            behavior.addExclusiveAreaPolicy(policy)

    def readSwcInternalBehavior(self, element: ET.Element, behavior: SwcInternalBehavior):
        # read the internal behavior
        self.readInternalBehavior(element, behavior)

        # read the extra SwcInternalBehavior
        self.readSwcInternalBehaviorArTypedPerInstanceMemories(element, behavior)
        self.readSwcInternalBehaviorExclusiveAreaPolicies(element, behavior)
        self.readSwcInternalBehaviorEvents(element, behavior)
        self.readSwcInternalBehaviorExplicitInterRunnableVariables(element, behavior)
        behavior.setHandleTerminationAndRestart(self.getChildElementOptionalLiteral(element, "HANDLE-TERMINATION-AND-RESTART"))
        self.readSwcInternalBehaviorImplicitInterRunnableVariables(element, behavior)
        self.readSwcInternalBehaviorIncludedModeDeclarationGroupSets(element, behavior)
        self.readSwcInternalBehaviorInstantiationDataDefProps(element, behavior)
        self.readSwcInternalBehaviorPerInstanceMemories(element, behavior)
        self.readSwcInternalBehaviorPerInstanceParameters(element, behavior)
        self.readSwcInternalBehaviorPortAPIOptions(element, behavior)
        self.readSwcInternalBehaviorRunnables(element, behavior)
        self.readSwcInternalBehaviorServiceDependencies(element, behavior)
        self.readSwcInternalBehaviorSharedParameters(element, behavior)
        self.readSwcInternalBehaviorVariationPointProxies(element, behavior)
        behavior.setSupportsMultipleInstantiation(self.getChildElementOptionalBooleanValue(element, "SUPPORTS-MULTIPLE-INSTANTIATION"))

    def readSwcInternalBehaviorInstantiationDataDefProps(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "INSTANTIATION-DATA-DEF-PROPSS/INSTANTIATION-DATA-DEF-PROPS"):
            props = InstantiationDataDefProps()
            self.readARObject(child_element, props)
            props.setParameterInstance(self.getAutosarParameterRef(child_element, "PARAMETER-INSTANCE"))
            props.setSwDataDefProps(self.getSwDataDefProps(child_element, "SW-DATA-DEF-PROPS"))
            props.setVariableInstance(self.getAutosarVariableRef(child_element, "VARIABLE-INSTANCE"))
            self.readVariationPointCapable(child_element, props)
            behavior.addInstantiationDataDefProps(props)

    def readAtomicSwComponentTypeSwcInternalBehavior(self, element: ET.Element, parent: AtomicSwComponentType):
        for child_element in self.findall(element, "INTERNAL-BEHAVIORS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SWC-INTERNAL-BEHAVIOR":
                behavior = parent.createSwcInternalBehavior(self.getShortName(child_element))
                self.readSwcInternalBehavior(child_element, behavior)
            else:
                self.notImplemented("Unsupported Internal Behaviors <%s>" % tag_name)

    def getIncludedModeDeclarationGroupSets(self, element: ET.Element) -> List[IncludedModeDeclarationGroupSet]:
        group_sets = []
        for child_element in self.findall(element, "INCLUDED-MODE-DECLARATION-GROUP-SETS/INCLUDED-MODE-DECLARATION-GROUP-SET"):
            group_set = IncludedModeDeclarationGroupSet()
            for ref_type in self.getChildElementRefTypeList(child_element, "MODE-DECLARATION-GROUP-REFS/MODE-DECLARATION-GROUP-REF"):
                group_set.addModeDeclarationGroupRef(ref_type)
            group_sets.append(group_set)
        return group_sets

    def readBswVariableAccess(self, element: ET.Element, access: BswVariableAccess):
        self.readReferrable(element, access)
        access.setAccessedVariableRef(self.getChildElementOptionalRefType(element, "ACCESSED-VARIABLE-REF"))
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-LIMITATION-REFS/CONTEXT-LIMITATION-REF"):
            access.addContextLimitationRef(ref)

    def readBswModuleEntityDataSendPoints(self, element: ET.Element, entity: BswModuleEntity):
        for child_element in self.findall(element, "DATA-SEND-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-VARIABLE-ACCESS":
                point = entity.createDataSendPoint(self.getShortName(child_element))
                self.readBswVariableAccess(child_element, point)
            else:
                self.notImplemented("Unsupported Data Send Point <%s>" % tag_name)

    def readBswModuleEntityDataReceiverPoints(self, element: ET.Element, entity: BswModuleEntity):
        for child_element in self.findall(element, "DATA-RECEIVE-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-VARIABLE-ACCESS":
                point = entity.createDataReceivePoint(self.getShortName(child_element))
                self.readBswVariableAccess(child_element, point)
            else:
                self.notImplemented("Unsupported Data Receive Point <%s>" % tag_name)

    def readBswModuleEntityIssuedTriggerRefs(self, element: ET.Element, entity: BswModuleEntity):
        for ref in self.getChildElementRefTypeList(element, "ISSUED-TRIGGERS/TRIGGER-REF-CONDITIONAL/TRIGGER-REF"):
            entity.addIssuedTriggerRef(ref)

    def readBswModuleEntityActivationPointRefs(self, element: ET.Element, entity: BswModuleEntity):
        for ref in self.getChildElementRefTypeList(element, "ACTIVATION-POINTS/BSW-INTERNAL-TRIGGERING-POINT-REF-CONDITIONAL/BSW-INTERNAL-TRIGGERING-POINT-REF"):  # noqa E501
            entity.addActivationPointRef(ref)

    def readBswModuleCallPoint(self, element: ET.Element, point: BswModuleCallPoint):
        self.readReferrable(element, point)
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-LIMITATION-REFS/CONTEXT-LIMITATION-REF"):
            point.addContextLimitationRef(ref)
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(point, VariationPointCapable):
                point.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswAsynchronousServerCallPoint(self, element: ET.Element, point: BswAsynchronousServerCallPoint):
        self.readBswModuleCallPoint(element, point)
        point.setCalledEntryRef(self.getChildElementOptionalRefType(element, "CALLED-ENTRY-REF"))

    def readBswAsynchronousServerCallResultPoint(self, element: ET.Element, point: BswAsynchronousServerCallResultPoint):
        self.readBswModuleCallPoint(element, point)
        point.setAsynchronousServerCallPointRef(self.getChildElementOptionalRefType(element, "ASYNCHRONOUS-SERVER-CALL-POINT-REF"))

    def readBswSynchronousServerCallPoint(self, element: ET.Element, point: BswSynchronousServerCallPoint):
        self.readBswModuleCallPoint(element, point)
        point.setCalledEntryRef(self.getChildElementOptionalRefType(element, "CALLED-ENTRY-REF"))
        point.setCalledFromWithinExclusiveAreaRef(self.getChildElementOptionalRefType(element, "CALLED-FROM-WITHIN-EXCLUSIVE-AREA-REF"))

    def readBswDirectCallPoint(self, element: ET.Element, point: BswDirectCallPoint):
        self.readBswModuleCallPoint(element, point)
        point.setCalledEntryRef(self.getChildElementOptionalRefType(element, "CALLED-ENTRY-REF"))
        point.setCalledFromWithinExclusiveAreaRef(self.getChildElementOptionalRefType(element, "CALLED-FROM-WITHIN-EXCLUSIVE-AREA-REF"))

    def readBswModuleEntityCallPoints(self, element: ET.Element, entity: BswModuleEntity):
        for child_element in self.findall(element, "CALL-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-ASYNCHRONOUS-SERVER-CALL-POINT":
                point = entity.createBswAsynchronousServerCallPoint(self.getShortName(child_element))
                self.readBswAsynchronousServerCallPoint(child_element, point)
            elif tag_name == "BSW-ASYNCHRONOUS-SERVER-CALL-RESULT-POINT":
                point = entity.createBswAsynchronousServerCallResultPoint(self.getShortName(child_element))
                self.readBswAsynchronousServerCallResultPoint(child_element, point)
            elif tag_name == "BSW-SYNCHRONOUS-SERVER-CALL-POINT":
                point = entity.createBswSynchronousServerCallPoint(self.getShortName(child_element))
                self.readBswSynchronousServerCallPoint(child_element, point)
            elif tag_name == "BSW-DIRECT-CALL-POINT":
                point = entity.createBswDirectCallPoint(self.getShortName(child_element))
                self.readBswDirectCallPoint(child_element, point)
            else:
                self.notImplemented("Unsupported Call Point <%s>" % tag_name)

    def readBswModuleEntity(self, element: ET.Element, entity: BswModuleEntity):
        self.readExecutableEntity(element, entity)
        self.readBswModuleEntityActivationPointRefs(element, entity)
        self.readBswModuleEntityCallPoints(element, entity)
        self.readBswModuleEntityDataReceiverPoints(element, entity)
        self.readBswModuleEntityDataSendPoints(element, entity)
        entity.setImplementedEntryRef(self.getChildElementRefType(entity.getShortName(), element, "IMPLEMENTED-ENTRY-REF"))
        entity.setSchedulerNamePrefixRef(self.getChildElementOptionalRefType(element, "SCHEDULER-NAME-PREFIX-REF"))
        self.readBswModuleEntityAccessedModeGroups(element, entity)
        self.readBswModuleEntityManagedModeGroups(element, entity)
        self.readBswModuleEntityIssuedTriggerRefs(element, entity)

    def readBswCalledEntity(self, element: ET.Element, entity: BswCalledEntity):
        # self.logger.debug("Read BswCalledEntity %s" % entity.getShortName())
        self.readBswModuleEntity(element, entity)

    def readBswSchedulableEntity(self, element: ET.Element, entity: BswSchedulableEntity):
        # self.logger.debug("Read BswSchedulableEntity %s" % entity.getShortName())
        self.readBswModuleEntity(element, entity)

    def readBswInterruptEntity(self, element: ET.Element, entity: BswInterruptEntity):
        # self.logger.debug("Read BswInterruptEntity %s" % entity.getShortName())
        self.readBswModuleEntity(element, entity)
        literal = self.getChildElementOptionalLiteral(element, "INTERRUPT-CATEGORY")
        if literal is not None:
            camel = None
            for camel_value, token in BSW_INTERRUPT_CATEGORY_XML_MAP.items():
                if token == literal.getText():
                    camel = camel_value
                    break
            if camel is not None:
                entity.setInterruptCategory(BswInterruptCategory().setValue(camel))
            else:
                self.notImplemented("Unsupported INTERRUPT-CATEGORY <%s>" % literal.getText())
        entity.setInterruptSource(self.getChildElementOptionalString(element, "INTERRUPT-SOURCE"))

    def readBswInternalBehaviorEntities(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "ENTITYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-CALLED-ENTITY":
                entity = behavior.createBswCalledEntity(self.getShortName(child_element))
                self.readBswCalledEntity(child_element, entity)
            elif tag_name == "BSW-SCHEDULABLE-ENTITY":
                entity = behavior.createBswSchedulableEntity(self.getShortName(child_element))
                self.readBswSchedulableEntity(child_element, entity)
            elif tag_name == "BSW-INTERRUPT-ENTITY":
                entity = behavior.createBswInterruptEntity(self.getShortName(child_element))
                self.readBswInterruptEntity(child_element, entity)
            else:
                self.notImplemented("Unsupported BswModuleEntity <%s>" % tag_name)

    def readBswBackgroundEvent(self, element: ET.Element, event: BswBackgroundEvent):
        self.readBswScheduleEvent(element, event)

    def readBswExternalTriggerOccurredEvent(self, element: ET.Element, event: BswExternalTriggerOccurredEvent):
        self.readBswScheduleEvent(element, event)
        event.setTriggerRef(self.getChildElementOptionalRefType(element, "TRIGGER-REF"))

    def readBswOperationInvokedEvent(self, element: ET.Element, event: BswOperationInvokedEvent):
        self.readBswEvent(element, event)
        event.setEntryRef(self.getChildElementOptionalRefType(element, "ENTRY-REF"))

    def readBswInternalBehaviorEvents(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "EVENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MODE-SWITCH-EVENT":
                event = behavior.createBswModeSwitchEvent(self.getShortName(child_element))
                self.readBswModeSwitchEvent(child_element, event)
            elif tag_name == "BSW-MODE-MANAGER-ERROR-EVENT":
                event = behavior.createBswModeManagerErrorEvent(self.getShortName(child_element))
                self.readBswModeManagerErrorEvent(child_element, event)
            elif tag_name == "BSW-MODE-SWITCHED-ACK-EVENT":
                event = behavior.createBswModeSwitchedAckEvent(self.getShortName(child_element))
                self.readBswModeSwitchedAckEvent(child_element, event)
            elif tag_name == "BSW-TIMING-EVENT":
                event = behavior.createBswTimingEvent(self.getShortName(child_element))
                self.readBswTimingEvent(child_element, event)
            elif tag_name == "BSW-DATA-RECEIVED-EVENT":
                event = behavior.createBswDataReceivedEvent(self.getShortName(child_element))
                self.readBswDataReceivedEvent(child_element, event)
            elif tag_name == "BSW-INTERNAL-TRIGGER-OCCURRED-EVENT":
                event = behavior.createBswInternalTriggerOccurredEvent(self.getShortName(child_element))
                self.readBswInternalTriggerOccurredEvent(child_element, event)
            elif tag_name == "BSW-BACKGROUND-EVENT":
                event = behavior.createBswBackgroundEvent(self.getShortName(child_element))
                self.readBswBackgroundEvent(child_element, event)
            elif tag_name == "BSW-EXTERNAL-TRIGGER-OCCURRED-EVENT":
                event = behavior.createBswExternalTriggerOccurredEvent(self.getShortName(child_element))
                self.readBswExternalTriggerOccurredEvent(child_element, event)
            elif tag_name == "BSW-OPERATION-INVOKED-EVENT":
                event = behavior.createBswOperationInvokedEvent(self.getShortName(child_element))
                self.readBswOperationInvokedEvent(child_element, event)
            elif tag_name == "BSW-ASYNCHRONOUS-SERVER-CALL-RETURNS-EVENT":
                event = behavior.createBswAsynchronousServerCallReturnsEvent(self.getShortName(child_element))
                self.readBswAsynchronousServerCallReturnsEvent(child_element, event)
            elif tag_name == "BSW-INTERRUPT-EVENT":
                event = behavior.createBswInterruptEvent(self.getShortName(child_element))
                self.readBswEvent(child_element, event)
            elif tag_name == "BSW-OS-TASK-EXECUTION-EVENT":
                event = behavior.createBswOsTaskExecutionEvent(self.getShortName(child_element))
                self.readBswEvent(child_element, event)
            else:
                self.notImplemented("Unsupported BswModuleEntity <%s>" % tag_name)

    def readBswApiOptions(self, element: ET.Element, options: BswApiOptions):
        self.readARObject(element, options)
        options.setEnableTakeAddress(self.getChildElementOptionalBooleanValue(element, "ENABLE-TAKE-ADDRESS"))

    def readBswDataReceptionPolicy(self, element: ET.Element, policy: BswDataReceptionPolicy):
        self.readBswApiOptions(element, policy)
        policy.setReceivedDataRef(self.getChildElementOptionalRefType(element, "RECEIVED-DATA-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswQueuedDataReceptionPolicy(self, element: ET.Element, policy: BswQueuedDataReceptionPolicy):
        self.readBswDataReceptionPolicy(element, policy)
        policy.setQueueLength(self.getChildElementOptionalPositiveInteger(element, "QUEUE-LENGTH"))

    def readBswInternalBehaviorReceptionPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "RECEPTION-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-QUEUED-DATA-RECEPTION-POLICY":
                policy = BswQueuedDataReceptionPolicy()
                self.readBswQueuedDataReceptionPolicy(child_element, policy)
                behavior.addReceptionPolicy(policy)
            else:
                self.notImplemented("Unsupported Reception Policies <%s>" % tag_name)

    def readBswPerInstanceMemoryPolicy(self, element: ET.Element, policy: BswPerInstanceMemoryPolicy):
        self.readBswApiOptions(element, policy)
        policy.setArTypedPerInstanceMemoryRef(self.getChildElementOptionalRefType(element, "AR-TYPED-PER-INSTANCE-MEMORY-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswInternalBehaviorBswPerInstanceMemoryPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "BSW-PER-INSTANCE-MEMORY-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-PER-INSTANCE-MEMORY-POLICY":
                policy = BswPerInstanceMemoryPolicy()
                self.readBswPerInstanceMemoryPolicy(child_element, policy)
                behavior.addBswPerInstanceMemoryPolicy(policy)
            else:
                self.notImplemented("Unsupported Per Instance Memory Policies <%s>" % tag_name)

    def readBswClientPolicy(self, element: ET.Element, policy: BswClientPolicy):
        self.readBswApiOptions(element, policy)
        policy.setRequiredClientServerEntryRef(self.getChildElementOptionalRefType(element, "REQUIRED-CLIENT-SERVER-ENTRY-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswInternalBehaviorClientPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "CLIENT-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-CLIENT-POLICY":
                policy = BswClientPolicy()
                self.readBswClientPolicy(child_element, policy)
                behavior.addClientPolicy(policy)
            else:
                self.notImplemented("Unsupported Client Policies <%s>" % tag_name)

    def readBswInternalTriggeringPointPolicy(self, element: ET.Element, policy: BswInternalTriggeringPointPolicy):
        self.readBswApiOptions(element, policy)
        policy.setBswInternalTriggeringPointRef(self.getChildElementOptionalRefType(element, "BSW-INTERNAL-TRIGGERING-POINT-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswInternalBehaviorInternalTriggeringPointPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "INTERNAL-TRIGGERING-POINT-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-INTERNAL-TRIGGERING-POINT-POLICY":
                policy = BswInternalTriggeringPointPolicy()
                self.readBswInternalTriggeringPointPolicy(child_element, policy)
                behavior.addInternalTriggeringPointPolicy(policy)
            else:
                self.notImplemented("Unsupported Internal Triggering Point Policies <%s>" % tag_name)

    def readBswParameterPolicy(self, element: ET.Element, policy: BswParameterPolicy):
        self.readBswApiOptions(element, policy)
        policy.setPerInstanceParameterRef(self.getChildElementOptionalRefType(element, "PER-INSTANCE-PARAMETER-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswInternalBehaviorParameterPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "PARAMETER-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-PARAMETER-POLICY":
                policy = BswParameterPolicy()
                self.readBswParameterPolicy(child_element, policy)
                behavior.addParameterPolicy(policy)
            else:
                self.notImplemented("Unsupported Parameter Policies <%s>" % tag_name)

    def readBswReleasedTriggerPolicy(self, element: ET.Element, policy: BswReleasedTriggerPolicy):
        self.readBswApiOptions(element, policy)
        policy.setReleasedTriggerRef(self.getChildElementOptionalRefType(element, "RELEASED-TRIGGER-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswInternalBehaviorReleasedTriggerPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "RELEASED-TRIGGER-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-RELEASED-TRIGGER-POLICY":
                policy = BswReleasedTriggerPolicy()
                self.readBswReleasedTriggerPolicy(child_element, policy)
                behavior.addReleasedTriggerPolicy(policy)
            else:
                self.notImplemented("Unsupported Released Trigger Policies <%s>" % tag_name)

    def readBswDataSendPolicy(self, element: ET.Element, policy: BswDataSendPolicy):
        self.readBswApiOptions(element, policy)
        policy.setProvidedDataRef(self.getChildElementOptionalRefType(element, "PROVIDED-DATA-REF"))
        policy.setProviedeDataRef(self.getChildElementOptionalRefType(element, "PROVIEDE-DATA-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(policy, VariationPointCapable):
                policy.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswInternalBehaviorDataSendPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "SEND-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-DATA-SEND-POLICY":
                policy = BswDataSendPolicy()
                self.readBswDataSendPolicy(child_element, policy)
                behavior.addSendPolicy(policy)
            else:
                self.notImplemented("Unsupported Data Send Policies <%s>" % tag_name)

    def readBswInternalBehaviorArTypedPerInstanceMemories(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "AR-TYPED-PER-INSTANCE-MEMORYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-DATA-PROTOTYPE":
                memory = VariableDataPrototype(self, self.getShortName(child_element))
                self.readVariableDataPrototype(child_element, memory)
                behavior.addArTypedPerInstanceMemory(memory)
            else:
                self.notImplemented("Unsupported ArTypedPerInstanceMemory <%s>" % tag_name)

    def getBswExclusiveAreaPolicy(self, element: ET.Element) -> BswExclusiveAreaPolicy:
        policy = BswExclusiveAreaPolicy()
        self.readBswApiOptions(element, policy)
        policy.setApiPrinciple(self.getChildElementOptionalLiteral(element, "API-PRINCIPLE"))
        policy.setExclusiveAreaRef(self.getChildElementOptionalRefType(element, "EXCLUSIVE-AREA-REF"))
        self.readVariationPointCapable(element, policy)
        return policy

    def readBswInternalBehaviorExclusiveAreaPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "EXCLUSIVE-AREA-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-EXCLUSIVE-AREA-POLICY":
                behavior.addExclusiveAreaPolicy(self.getBswExclusiveAreaPolicy(child_element))
            else:
                self.notImplemented("Unsupported ExclusiveAreaPolicy <%s>" % tag_name)

    def readBswInternalBehaviorIncludedDataTypeSets(self, element: ET.Element, behavior: BswInternalBehavior):
        for data_type_set in self.getIncludedDataTypeSets(element):
            behavior.addIncludedDataTypeSet(data_type_set)

    def getBswModeReceiverPolicy(self, element: ET.Element) -> BswModeReceiverPolicy:
        policy = BswModeReceiverPolicy()
        policy.setEnhancedModeApi(self.getChildElementOptionalBooleanValue(element, "ENHANCED-MODE-API"))
        policy.setRequiredModeGroupRef(self.getChildElementOptionalRefType(element, "REQUIRED-MODE-GROUP-REF"))
        policy.setSupportsAsynchronousModeSwitch(self.getChildElementOptionalBooleanValue(element, "SUPPORTS-ASYNCHRONOUS-MODE-SWITCH"))
        self.readVariationPointCapable(element, policy)
        return policy

    def readBswInternalBehaviorModeReceiverPolicies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "MODE-RECEIVER-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MODE-RECEIVER-POLICY":
                behavior.addModeReceiverPolicy(self.getBswModeReceiverPolicy(child_element))
            else:
                self.notImplemented("Unsupported ModeReceiverPolicy <%s>" % tag_name)

    def readBswInternalBehaviorPerInstanceParameters(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "PER-INSTANCE-PARAMETERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PARAMETER-DATA-PROTOTYPE":
                parameter = ParameterDataPrototype(self, self.getShortName(child_element))
                self.readParameterDataPrototype(child_element, parameter)
                behavior.addPerInstanceParameter(parameter)
            else:
                self.notImplemented("Unsupported PerInstanceParameter <%s>" % tag_name)

    def getBswTriggerDirectImplementation(self, element: ET.Element) -> BswTriggerDirectImplementation:
        implementation = BswTriggerDirectImplementation()
        implementation.setCat2Isr(self.getChildElementOptionalIdentifier(element, "CAT-2-ISR"))
        implementation.setMasteredTriggerRef(self.getChildElementOptionalRefType(element, "MASTERED-TRIGGER-REF"))
        implementation.setTask(self.getChildElementOptionalIdentifier(element, "TASK"))
        self.readVariationPointCapable(element, implementation)
        return implementation

    def readBswInternalBehaviorTriggerDirectImplementations(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "TRIGGER-DIRECT-IMPLEMENTATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-TRIGGER-DIRECT-IMPLEMENTATION":
                behavior.addTriggerDirectImplementation(self.getBswTriggerDirectImplementation(child_element))
            else:
                self.notImplemented("Unsupported TriggerDirectImplementation <%s>" % tag_name)

    def readBswInternalBehaviorVariationPointProxies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "VARIATION-POINT-PROXYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIATION-POINT-PROXY":
                proxy = VariationPointProxy(behavior, self.getShortName(child_element))
                self.readVariationPointProxy(child_element, proxy)
                behavior.addVariationPointProxy(proxy)
            else:
                self.notImplemented("Unsupported VariationPointProxy <%s>" % tag_name)

    def readBswInternalTriggeringPoint(self, element: ET.Element, point: BswInternalTriggeringPoint):
        self.readIdentifiable(element, point)
        literal = self.getChildElementOptionalLiteral(element, "SW-IMPL-POLICY")
        if literal is not None:
            camel = None
            for camel_value, token in SW_IMPL_POLICY_XML_MAP.items():
                if token == literal.getText():
                    camel = camel_value
                    break
            if camel is not None:
                point.setSwImplPolicy(SwImplPolicyEnum().setValue(camel))
            else:
                self.notImplemented("Unsupported SW-IMPL-POLICY <%s>" % literal.getText())

    def readBswInternalBehaviorInternalTriggeringPoints(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "INTERNAL-TRIGGERING-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-INTERNAL-TRIGGERING-POINT":
                point = behavior.createBswInternalTriggeringPoint(self.getShortName(child_element))
                self.readBswInternalTriggeringPoint(child_element, point)
            else:
                self.notImplemented("Unsupported Internal Triggering Points <%s>" % tag_name)

    def readBswInternalBehaviorServiceDependencies(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "SERVICE-DEPENDENCYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-SERVICE-DEPENDENCY":
                dependency = BswServiceDependency()
                self.readBswServiceDependency(child_element, dependency)
                behavior.addServiceDependency(dependency)
            else:
                self.notImplemented("Unsupported Service Dependencies <%s>" % tag_name)

    def readBswInternalBehavior(self, element: ET.Element, behavior: BswInternalBehavior):
        self.logger.debug("Read BswInternalBehavior <%s>" % behavior.full_name)

        # read the internal behavior
        self.readInternalBehavior(element, behavior)
        self.readBswInternalBehaviorArTypedPerInstanceMemories(element, behavior)
        self.readBswInternalBehaviorBswPerInstanceMemoryPolicies(element, behavior)
        self.readBswInternalBehaviorClientPolicies(element, behavior)
        self.readBswInternalBehaviorExclusiveAreaPolicies(element, behavior)
        self.readBswInternalBehaviorIncludedDataTypeSets(element, behavior)
        self.readBswInternalBehaviorInternalTriggeringPoints(element, behavior)
        self.readBswInternalBehaviorEntities(element, behavior)
        self.readBswInternalBehaviorEvents(element, behavior)
        self.readBswInternalBehaviorModeReceiverPolicies(element, behavior)
        self.readBswInternalBehaviorModeSenderPolicy(element, behavior)
        self.readBswInternalBehaviorPerInstanceParameters(element, behavior)
        for group_set in self.getIncludedModeDeclarationGroupSets(element):
            behavior.addIncludedModeDeclarationGroupSet(group_set)
        self.readBswInternalBehaviorInternalTriggeringPointPolicies(element, behavior)
        self.readBswInternalBehaviorParameterPolicies(element, behavior)
        self.readBswInternalBehaviorReleasedTriggerPolicies(element, behavior)
        self.readBswInternalBehaviorDataSendPolicies(element, behavior)
        self.readBswInternalBehaviorVariationPointProxies(element, behavior)
        self.readBswInternalBehaviorReceptionPolicies(element, behavior)
        self.readBswInternalBehaviorSchedulerNamePrefixes(element, behavior)
        self.readBswInternalBehaviorDistinguishedPartitions(element, behavior)
        self.readBswInternalBehaviorServiceDependencies(element, behavior)
        self.readBswInternalBehaviorTriggerDirectImplementations(element, behavior)

    def readBswInternalBehaviorSchedulerNamePrefixes(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "SCHEDULER-NAME-PREFIXS/BSW-SCHEDULER-NAME-PREFIX"):
            prefix = behavior.createSchedulerNamePrefix(self.getShortName(child_element))
            self.readImplementationProps(child_element, prefix)

    def readBswInternalBehaviorDistinguishedPartitions(self, element: ET.Element, behavior: BswInternalBehavior):
        for child_element in self.findall(element, "DISTINGUISHED-PARTITIONS/BSW-DISTINGUISHED-PARTITION"):
            behavior.createDistinguishedPartition(self.getShortName(child_element))

    def readBswModuleDescriptionBswInternalBehaviors(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "INTERNAL-BEHAVIORS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-INTERNAL-BEHAVIOR":
                behavior = desc.createBswInternalBehavior(self.getShortName(child_element))
                self.readBswInternalBehavior(child_element, behavior)
            else:
                self.notImplemented("Unsupported Internal Behavior <%s>" % tag_name)

    def readTrigger(self, element: ET.Element, trigger: Trigger):
        self.readIdentifiable(element, trigger)
        literal = self.getChildElementOptionalLiteral(element, "SW-IMPL-POLICY")
        if literal is not None:
            camel = None
            for camel_value, token in SW_IMPL_POLICY_XML_MAP.items():
                if token == literal.getText():
                    camel = camel_value
                    break
            if camel is not None:
                trigger.setSwImplPolicy(SwImplPolicyEnum().setValue(camel))
            else:
                self.notImplemented("Unsupported SW-IMPL-POLICY <%s>" % literal.getText())
        period_element = self.find(element, "TRIGGER-PERIOD")
        if period_element is not None:
            period = MultidimensionalTime()
            self.readMultidimensionalTime(period_element, period)
            trigger.setTriggerPeriod(period)

    def readBswModuleDescriptionReleasedTriggers(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "RELEASED-TRIGGERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TRIGGER":
                trigger = desc.createReleasedTrigger(self.getShortName(child_element))
                self.readTrigger(child_element, trigger)
            else:
                self.notImplemented("Unsupported Released Trigger <%s>" % tag_name)

    def readBswModuleDescriptionRequiredTriggers(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "REQUIRED-TRIGGERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TRIGGER":
                trigger = desc.createRequiredTrigger(self.getShortName(child_element))
                self.readTrigger(child_element, trigger)
            else:
                self.notImplemented("Unsupported Required Trigger <%s>" % tag_name)

    def readBswModuleDescriptionProvidedDatas(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "PROVIDED-DATAS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-DATA-PROTOTYPE":
                data = desc.createProvidedData(self.getShortName(child_element))
                self.readVariableDataPrototype(child_element, data)
            else:
                self.notImplemented("Unsupported Provided Data <%s>" % tag_name)

    def readBswModuleDescriptionRequiredDatas(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "REQUIRED-DATAS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-DATA-PROTOTYPE":
                data = desc.createRequiredData(self.getShortName(child_element))
                self.readVariableDataPrototype(child_element, data)
            else:
                self.notImplemented("Unsupported Required Data <%s>" % tag_name)

    def readBswEntryRelationshipSet(self, element: ET.Element, entry_set: BswEntryRelationshipSet):
        self.readIdentifiable(element, entry_set)
        for child_element in self.findall(element, "BSW-ENTRY-RELATIONSHIPS/BSW-ENTRY-RELATIONSHIP"):
            relationship = BswEntryRelationship()
            self.readBswEntryRelationship(child_element, relationship)
            entry_set.addBswEntryRelationship(relationship)

    def readBswEntryRelationship(self, element: ET.Element, relationship: BswEntryRelationship):
        relationship.setFromRef(self.getChildElementOptionalRefType(element, "FROM-REF"))
        relationship.setToRef(self.getChildElementOptionalRefType(element, "TO-REF"))
        literal = self.getChildElementOptionalLiteral(element, "BSW-ENTRY-RELATIONSHIP-TYPE")
        if literal is not None:
            camel = None
            for camel_value, token in BSW_ENTRY_RELATIONSHIP_XML_MAP.items():
                if token == literal.getText():
                    camel = camel_value
                    break
            if camel is not None:
                relationship.setBswEntryRelationshipType(BswEntryRelationshipEnum().setValue(camel))
            else:
                self.notImplemented("Unsupported BSW-ENTRY-RELATIONSHIP-TYPE <%s>" % literal.getText())

    def readBswModuleClientServerEntry(self, element: ET.Element, entry: BswModuleClientServerEntry):
        self.readReferrable(element, entry)
        entry.setEncapsulatedEntryRef(self.getChildElementOptionalRefType(element, "ENCAPSULATED-ENTRY-REF"))
        entry.setIsReentrant(self.getChildElementOptionalBooleanValue(element, "IS-REENTRANT"))
        entry.setIsSynchronous(self.getChildElementOptionalBooleanValue(element, "IS-SYNCHRONOUS"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(entry, VariationPointCapable):
                entry.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readBswModuleDescriptionProvidedClientServerEntries(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "PROVIDED-CLIENT-SERVER-ENTRYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MODULE-CLIENT-SERVER-ENTRY":
                entry = desc.createProvidedClientServerEntry(self.getShortName(child_element))
                self.readBswModuleClientServerEntry(child_element, entry)
            else:
                self.notImplemented("Unsupported Provided Client Server Entry <%s>" % tag_name)

    def readBswModuleDescriptionRequiredClientServerEntries(self, element: ET.Element, desc: BswModuleDescription):
        for child_element in self.findall(element, "REQUIRED-CLIENT-SERVER-ENTRYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MODULE-CLIENT-SERVER-ENTRY":
                entry = desc.createRequiredClientServerEntry(self.getShortName(child_element))
                self.readBswModuleClientServerEntry(child_element, entry)
            else:
                self.notImplemented("Unsupported Required Client Server Entry <%s>" % tag_name)

    def readBswModuleDescription(self, element: ET.Element, desc: BswModuleDescription):
        self.logger.debug("Read BswModuleDescription <%s>" % desc.getShortName())

        self.readIdentifiable(element, desc)
        desc.setModuleId(self.getChildElementOptionalNumericalValue(element, "MODULE-ID"))
        self.readBswModuleDescriptionExpectedEntryRefs(element, desc)
        self.readBswModuleDescriptionImplementedEntryRefs(element, desc)
        self.readBswModuleDescriptionProvidedModeGroups(element, desc)
        self.readBswModuleDescriptionRequiredModeGroups(element, desc)
        self.readBswModuleDescriptionProvidedClientServerEntries(element, desc)
        self.readBswModuleDescriptionRequiredClientServerEntries(element, desc)
        self.readBswModuleDescriptionProvidedDatas(element, desc)
        self.readBswModuleDescriptionRequiredDatas(element, desc)
        self.readBswModuleDescriptionBswInternalBehaviors(element, desc)
        self.readBswModuleDescriptionReleasedTriggers(element, desc)
        self.readBswModuleDescriptionRequiredTriggers(element, desc)
        self.readBswModuleDescriptionBswModuleDependencies(element, desc)
        self.readBswModuleDescriptionBswModuleDocumentation(element, desc)

    def readBswModuleDescriptionExpectedEntryRefs(self, element: ET.Element, parent: BswModuleDescription):
        for child_element in self.findall(element, "EXPECTED-ENTRYS/BSW-MODULE-ENTRY-REF-CONDITIONAL"):
            ref = self.getChildElementOptionalRefType(child_element, "BSW-MODULE-ENTRY-REF")
            if ref is not None:
                parent.addExpectedEntryRef(ref)

    def readBswModuleDescriptionBswModuleDependencies(self, element: ET.Element, parent: BswModuleDescription):
        for child_element in self.findall(element, "BSW-MODULE-DEPENDENCYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BSW-MODULE-DEPENDENCY":
                dependency = parent.createBswModuleDependency(self.getShortName(child_element))
                dependency.setTargetModuleId(self.getChildElementOptionalPositiveInteger(child_element, "TARGET-MODULE-ID"))
                for ref_conditional in self.findall(child_element, "TARGET-MODULE-REFS/BSW-MODULE-DESCRIPTION-REF-CONDITIONAL"):
                    ref = self.getChildElementOptionalRefType(ref_conditional, "BSW-MODULE-DESCRIPTION-REF")
                    if ref is not None:
                        dependency.setTargetModuleRef(ref)
                        break
            else:
                self.notImplemented("Unsupported BswModuleDependency <%s>" % tag_name)

    def readBswModuleDescriptionBswModuleDocumentation(self, element: ET.Element, parent: BswModuleDescription):
        container = self.find(element, "BSW-MODULE-DOCUMENTATIONS")
        if container is None:
            return
        child_element = self.find(container, "SW-COMPONENT-DOCUMENTATION")
        if child_element is None:
            return
        parent.setBswModuleDocumentation(self.readSwComponentDocumentationElement(child_element))

    def readSwServiceArg(self, element: ET.Element, arg: SwServiceArg):
        self.readIdentifiable(element, arg)
        arg.setDirection(self.getChildElementOptionalLiteral(element, "DIRECTION"))
        arg.setSwArraysize(self.getValueList(element, "SW-ARRAYSIZE"))
        arg.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))

    def readBswModuleEntryArguments(self, element: ET.Element, entry: BswModuleEntry):
        for child_element in self.findall(element, "ARGUMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SW-SERVICE-ARG":
                arg = entry.createArgument(self.getShortName(child_element))
                self.readSwServiceArg(child_element, arg)
            else:
                self.notImplemented("Unsupported Argument <%s>" % tag_name)

    def readBswModuleEntryReturnType(self, element: ET.Element, entry: BswModuleEntry):
        child_element = self.find(element, "RETURN-TYPE")
        if child_element is not None:
            self.logger.debug("Read ReturnType of BswModuleEntry <%s>" % entry.getShortName())
            return_type = entry.createReturnType(self.getShortName(child_element))
            self.readSwServiceArg(child_element, return_type)

    def readBswModuleEntry(self, element: ET.Element, entry: BswModuleEntry):
        self.logger.debug("Read BswModuleEntry <%s>" % entry.getShortName())
        self.readIdentifiable(element, entry)
        self.readBswModuleEntryArguments(element, entry)
        entry.setIsReentrant(self.getChildElementOptionalBooleanValue(element, "IS-REENTRANT"))
        entry.setIsSynchronous(self.getChildElementOptionalBooleanValue(element, "IS-SYNCHRONOUS"))
        entry.setServiceId(self.getChildElementOptionalNumericalValue(element, "SERVICE-ID"))
        entry.setCallType(self.getChildElementOptionalLiteral(element, "CALL-TYPE"))
        entry.setExecutionContext(self.getChildElementOptionalLiteral(element, "EXECUTION-CONTEXT"))
        entry.setSwServiceImplPolicy(self.getChildElementOptionalLiteral(element, "SW-SERVICE-IMPL-POLICY"))
        entry.setBswEntryKind(self.getChildElementOptionalLiteral(element, "BSW-ENTRY-KIND"))
        entry.setRole(self.getChildElementOptionalLiteral(element, "ROLE"))
        entry.setFunctionPrototypeEmitter(self.getChildElementOptionalLiteral(element, "FUNCTION-PROTOTYPE-EMITTER"))
        self.readBswModuleEntryReturnType(element, entry)

    def readEngineeringObject(self, element: ET.Element, engineering_obj: EngineeringObject):
        self.readARObject(element, engineering_obj)
        engineering_obj.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        engineering_obj.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        for child_element in self.findall(element, "REVISION-LABELS/REVISION-LABEL"):
            engineering_obj.addRevisionLabel(self.getChildElementOptionalRevisionLabelString(child_element, "."))
        engineering_obj.setDomain(self.getChildElementOptionalLiteral(element, "DOMAIN"))

    def getAutosarEngineeringObject(self, element: ET.Element) -> AutosarEngineeringObject:
        obj = AutosarEngineeringObject()
        self.readEngineeringObject(element, obj)
        # self.logger.debug("Get AutosarEngineeringObject %s", obj.shortLabel)
        return obj

    def readArtifactDescriptor(self, element: ET.Element, code_desc: Code):
        for child_element in self.findall(element, "ARTIFACT-DESCRIPTORS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "AUTOSAR-ENGINEERING-OBJECT":
                code_desc.addArtifactDescriptor(self.getAutosarEngineeringObject(child_element))
            else:
                self.notImplemented("Unsupported Artifact Descriptor <%s>" % tag_name)

    def readCodeDescriptor(self, element: ET.Element, impl: Implementation):
        for child_element in self.findall(element, "CODE-DESCRIPTORS/CODE"):
            short_name = self.getShortName(child_element)
            # self.logger.debug("Read CodeDescriptor %s" % short_name)
            code_desc = impl.createCodeDescriptor(short_name)
            self.readIdentifiable(child_element, code_desc)
            self.readArtifactDescriptor(child_element, code_desc)
            self.readCallbackHeaderRefs(child_element, code_desc)

    def readCallbackHeaderRefs(self, element: ET.Element, code_desc: Code):
        child_element = self.find(element, "CALLBACK-HEADER-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "CALLBACK-HEADER-REF"):
                code_desc.addCallbackHeaderRef(ref)

    def readCompiler(self, element: ET.Element, impl: Implementation):
        child_element = self.find(element, "COMPILERS")
        if child_element is not None:
            for compiler_element in self.findall(child_element, "COMPILER"):
                compiler = impl.createCompiler(self.getShortName(compiler_element))
                self.readIdentifiable(compiler_element, compiler)
                compiler.setName(self.getChildElementOptionalLiteral(compiler_element, "NAME"))
                compiler.setOptions(self.getChildElementOptionalLiteral(compiler_element, "OPTIONS"))
                compiler.setVendor(self.getChildElementOptionalLiteral(compiler_element, "VENDOR"))
                compiler.setVersion(self.getChildElementOptionalLiteral(compiler_element, "VERSION"))

    def readLinker(self, element: ET.Element, impl: Implementation):
        child_element = self.find(element, "LINKERS")
        if child_element is not None:
            for linker in self.findall(child_element, "LINKER"):
                linker_obj = impl.createLinker(self.getShortName(linker))
                self.readIdentifiable(linker, linker_obj)
                linker_obj.setName(self.getChildElementOptionalLiteral(linker, "NAME"))
                linker_obj.setOptions(self.getChildElementOptionalLiteral(linker, "OPTIONS"))
                linker_obj.setVendor(self.getChildElementOptionalLiteral(linker, "VENDOR"))
                linker_obj.setVersion(self.getChildElementOptionalLiteral(linker, "VERSION"))

    def readDependencyOnArtifact(self, element: ET.Element, impl: Implementation, key: str, create):
        child_element = self.find(element, key)
        if child_element is not None:
            for dependency_element in self.findall(child_element, "DEPENDENCY-ON-ARTIFACT"):
                dependency = create(self.getShortName(dependency_element))
                self.readIdentifiable(dependency_element, dependency)
                descriptor_element = self.find(dependency_element, "ARTIFACT-DESCRIPTOR")
                if descriptor_element is not None:
                    dependency.setArtifactDescriptor(self.getAutosarEngineeringObject(descriptor_element))
                usages_element = self.find(dependency_element, "USAGES")
                if usages_element is not None:
                    for usage_element in self.findall(usages_element, "USAGE"):
                        usage = DependencyUsageEnum()
                        usage.setValue(usage_element.text)
                        dependency.addUsage(usage)

    def readMemorySectionOptions(self, element: ET.Element, section: MemorySection):
        child_element = self.find(element, "OPTIONS")
        if child_element is not None:
            for value in self.getChildElementIdentifierValueList(child_element, "OPTION"):
                section.addOption(value)

    def readMemorySections(self, element: ET.Element, consumption: ResourceConsumption):
        for child_element in self.findall(element, "MEMORY-SECTIONS/MEMORY-SECTION"):
            memory_section = consumption.createMemorySection(self.getShortName(child_element))
            self.readIdentifiable(child_element, memory_section)
            memory_section.setAlignment(self.getChildElementOptionalAlignmentType(child_element, "ALIGNMENT"))
            memory_section.setMemClassSymbol(self.getChildElementOptionalCIdentifier(child_element, "MEM-CLASS-SYMBOL"))
            self.readMemorySectionOptions(child_element, memory_section)
            memory_section.setSize(self.getChildElementOptionalPositiveInteger(child_element, "SIZE"))
            memory_section.setSwAddrMethodRef(self.getChildElementOptionalRefType(child_element, "SW-ADDRMETHOD-REF"))
            memory_section.setSymbol(self.getChildElementOptionalIdentifier(child_element, "SYMBOL"))
            memory_section.setPrefixRef(self.getChildElementOptionalRefType(child_element, "PREFIX-REF"))
            for ref in self.getChildElementRefTypeList(child_element, "EXECUTABLE-ENTITY-REFS/EXECUTABLE-ENTITY-REF"):
                memory_section.addExecutableEntityRef(ref)
            # self.logger.debug("read MemorySections %s" % memory_section.getShortName())

    def readMultidimensionalTime(self, element: ET.Element, time: MultidimensionalTime):
        time.setCseCode(self.getChildElementOptionalCseCodeType(element, "CSE-CODE"))
        time.setCseCodeFactor(self.getChildElementOptionalIntegerValue(element, "CSE-CODE-FACTOR"))

    def readConfidenceInterval(self, element: ET.Element, interval: ConfidenceInterval):
        self.readARObject(element, interval)
        lower_bound_element = self.find(element, "LOWER-BOUND")
        if lower_bound_element is not None:
            lower_bound = MultidimensionalTime()
            self.readMultidimensionalTime(lower_bound_element, lower_bound)
            interval.setLowerBound(lower_bound)
        interval.setPropability(self.getChildElementOptionalFloatValue(element, "PROPABILITY"))
        upper_bound_element = self.find(element, "UPPER-BOUND")
        if upper_bound_element is not None:
            upper_bound = MultidimensionalTime()
            self.readMultidimensionalTime(upper_bound_element, upper_bound)
            interval.setUpperBound(upper_bound)

    def readHardwareConfiguration(self, element: ET.Element, config: HardwareConfiguration):
        config.setAdditionalInformation(self.getChildElementOptionalLiteral(element, "ADDITIONAL-INFORMATION"))
        config.setProcessorMode(self.getChildElementOptionalLiteral(element, "PROCESSOR-MODE"))
        config.setProcessorSpeed(self.getChildElementOptionalLiteral(element, "PROCESSOR-SPEED"))

    def readSoftwareContext(self, element: ET.Element, context: SoftwareContext):
        context.setInput(self.getChildElementOptionalLiteral(element, "INPUT"))
        context.setState(self.getChildElementOptionalLiteral(element, "STATE"))

    def readMemorySectionLocation(self, element: ET.Element, location):
        location.setProvidedMemoryRef(self.getChildElementOptionalRefType(element, "PROVIDED-MEMORY-REF"))
        location.setSoftwareMemorySectionRef(self.getChildElementOptionalRefType(element, "SOFTWARE-MEMORY-SECTION-REF"))

    def readExecutionTime(self, element: ET.Element, execution_time):
        self.readIdentifiable(element, execution_time)
        execution_time.setExclusiveAreaRef(self.getChildElementOptionalRefType(element, "EXCLUSIVE-AREA-REF"))
        execution_time.setExecutableEntityRef(self.getChildElementOptionalRefType(element, "EXECUTABLE-ENTITY-REF"))
        execution_time.setHwElementRef(self.getChildElementOptionalRefType(element, "HW-ELEMENT-REF"))
        hardware_configuration_element = self.find(element, "HARDWARE-CONFIGURATION")
        if hardware_configuration_element is not None:
            config = HardwareConfiguration()
            self.readHardwareConfiguration(hardware_configuration_element, config)
            execution_time.setHardwareConfiguration(config)
        for ref in self.getChildElementRefTypeList(element, "INCLUDED-LIBRARY-REFS/INCLUDED-LIBRARY-REF"):
            execution_time.addIncludedLibraryRef(ref)
        for location_element in self.findall(element, "MEMORY-SECTION-LOCATIONS/MEMORY-SECTION-LOCATION"):
            location = MemorySectionLocation()
            execution_time.addMemorySectionLocation(location)
            self.readMemorySectionLocation(location_element, location)
        software_context_element = self.find(element, "SOFTWARE-CONTEXT")
        if software_context_element is not None:
            context = SoftwareContext()
            self.readSoftwareContext(software_context_element, context)
            execution_time.setSoftwareContext(context)

    def readAnalyzedExecutionTime(self, element: ET.Element, execution_time: AnalyzedExecutionTime):
        self.readExecutionTime(element, execution_time)
        best_element = self.find(element, "BEST-CASE-EXECUTION-TIME")
        if best_element is not None:
            best = MultidimensionalTime()
            self.readMultidimensionalTime(best_element, best)
            execution_time.setBestCaseExecutionTime(best)
        worst_element = self.find(element, "WORST-CASE-EXECUTION-TIME")
        if worst_element is not None:
            worst = MultidimensionalTime()
            self.readMultidimensionalTime(worst_element, worst)
            execution_time.setWorstCaseExecutionTime(worst)

    def readMeasuredExecutionTime(self, element: ET.Element, execution_time: MeasuredExecutionTime):
        self.readExecutionTime(element, execution_time)
        for key, setter in (
            ("MAXIMUM-EXECUTION-TIME", execution_time.setMaximumExecutionTime),
            ("MINIMUM-EXECUTION-TIME", execution_time.setMinimumExecutionTime),
            ("NOMINAL-EXECUTION-TIME", execution_time.setNominalExecutionTime),
        ):
            child_element = self.find(element, key)
            if child_element is not None:
                value = MultidimensionalTime()
                self.readMultidimensionalTime(child_element, value)
                setter(value)

    def readSimulatedExecutionTime(self, element: ET.Element, execution_time: SimulatedExecutionTime):
        self.readExecutionTime(element, execution_time)
        for key, setter in (
            ("MAXIMUM-EXECUTION-TIME", execution_time.setMaximumExecutionTime),
            ("MINIMUM-EXECUTION-TIME", execution_time.setMinimumExecutionTime),
            ("NOMINAL-EXECUTION-TIME", execution_time.setNominalExecutionTime),
        ):
            child_element = self.find(element, key)
            if child_element is not None:
                value = MultidimensionalTime()
                self.readMultidimensionalTime(child_element, value)
                setter(value)

    def readRoughEstimateOfExecutionTime(self, element: ET.Element, execution_time: RoughEstimateOfExecutionTime):
        self.readExecutionTime(element, execution_time)
        execution_time.setAdditionalInformation(self.getChildElementOptionalLiteral(element, "ADDITIONAL-INFORMATION"))
        estimated_element = self.find(element, "ESTIMATED-EXECUTION-TIME")
        if estimated_element is not None:
            estimated = MultidimensionalTime()
            self.readMultidimensionalTime(estimated_element, estimated)
            execution_time.setEstimatedExecutionTime(estimated)

    def readExecutionTimes(self, element: ET.Element, consumption: ResourceConsumption):
        for child_element in self.findall(element, "EXECUTION-TIMES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ANALYZED-EXECUTION-TIME":
                execution_time = consumption.createAnalyzedExecutionTime(self.getShortName(child_element))
                self.readAnalyzedExecutionTime(child_element, execution_time)
            elif tag_name == "MEASURED-EXECUTION-TIME":
                execution_time = consumption.createMeasuredExecutionTime(self.getShortName(child_element))
                self.readMeasuredExecutionTime(child_element, execution_time)
            elif tag_name == "ROUGH-ESTIMATE-OF-EXECUTION-TIME":
                execution_time = consumption.createRoughEstimateOfExecutionTime(self.getShortName(child_element))
                self.readRoughEstimateOfExecutionTime(child_element, execution_time)
            elif tag_name == "SIMULATED-EXECUTION-TIME":
                execution_time = consumption.createSimulatedExecutionTime(self.getShortName(child_element))
                self.readSimulatedExecutionTime(child_element, execution_time)
            else:
                self.notImplemented("Unsupported Execution Time: <%s>" % tag_name)

    def readHeapUsage(self, element: ET.Element, usage):
        self.readIdentifiable(element, usage)
        usage.setHwElementRef(self.getChildElementOptionalRefType(element, "HW-ELEMENT-REF"))
        hardware_configuration_element = self.find(element, "HARDWARE-CONFIGURATION")
        if hardware_configuration_element is not None:
            config = HardwareConfiguration()
            self.readHardwareConfiguration(hardware_configuration_element, config)
            usage.setHardwareConfiguration(config)
        software_context_element = self.find(element, "SOFTWARE-CONTEXT")
        if software_context_element is not None:
            context = SoftwareContext()
            self.readSoftwareContext(software_context_element, context)
            usage.setSoftwareContext(context)

    def readMeasuredHeapUsage(self, element: ET.Element, usage: MeasuredHeapUsage):
        self.readHeapUsage(element, usage)
        usage.setAverageMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "AVERAGE-MEMORY-CONSUMPTION"))
        usage.setMaximumMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MAXIMUM-MEMORY-CONSUMPTION"))
        usage.setMinimumMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MINIMUM-MEMORY-CONSUMPTION"))
        usage.setTestPattern(self.getChildElementOptionalLiteral(element, "TEST-PATTERN"))

    def readRoughEstimateHeapUsage(self, element: ET.Element, usage: RoughEstimateHeapUsage):
        self.readHeapUsage(element, usage)
        usage.setMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MEMORY-CONSUMPTION"))

    def readWorstCaseHeapUsage(self, element: ET.Element, usage: WorstCaseHeapUsage):
        self.readHeapUsage(element, usage)
        usage.setMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MEMORY-CONSUMPTION"))

    def readHeapUsages(self, element: ET.Element, consumption: ResourceConsumption):
        for child_element in self.findall(element, "HEAP-USAGES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MEASURED-HEAP-USAGE":
                usage = consumption.createMeasuredHeapUsage(self.getShortName(child_element))
                self.readMeasuredHeapUsage(child_element, usage)
            elif tag_name == "ROUGH-ESTIMATE-HEAP-USAGE":
                usage = consumption.createRoughEstimateHeapUsage(self.getShortName(child_element))
                self.readRoughEstimateHeapUsage(child_element, usage)
            elif tag_name == "WORST-CASE-HEAP-USAGE":
                usage = consumption.createWorstCaseHeapUsage(self.getShortName(child_element))
                self.readWorstCaseHeapUsage(child_element, usage)
            else:
                self.notImplemented("Unsupported Heap Usage: <%s>" % tag_name)

    def readSectionNamePrefixes(self, element: ET.Element, consumption: ResourceConsumption):
        for child_element in self.findall(element, "SECTION-NAME-PREFIXS/SECTION-NAME-PREFIX"):
            prefix = consumption.createSectionNamePrefix(self.getShortName(child_element))
            self.readImplementationProps(child_element, prefix)
            prefix.setImplementedInRef(self.getChildElementOptionalRefType(child_element, "IMPLEMENTED-IN-REF"))
            variation_point_element = self.find(child_element, "VARIATION-POINT")
            if variation_point_element is not None:
                if isinstance(prefix, VariationPointCapable):
                    prefix.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
                else:
                    self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(child_element.tag))

    def readAccessCountSets(self, element: ET.Element, consumption: ResourceConsumption):
        for child_element in self.findall(element, "ACCESS-COUNT-SETS/ACCESS-COUNT-SET"):
            access_count_set = AccessCountSet()
            consumption.addAccessCountSet(access_count_set)
            access_count_set.setCountProfile(self.getChildElementOptionalLiteral(child_element, "COUNT-PROFILE"))
            for count_element in self.findall(child_element, "ACCESS-COUNTS/ACCESS-COUNT"):
                count = AccessCount()
                count.setAccessPointRef(self.getChildElementOptionalRefType(count_element, "ACCESS-POINT-REF"))
                count.setValue(self.getChildElementOptionalPositiveInteger(count_element, "VALUE"))
                access_count_set.addAccessCount(count)

    def readStackUsage(self, element: ET.Element, usage: StackUsage):
        self.logger.debug("read StackUsage %s" % usage.getShortName())
        self.readIdentifiable(element, usage)
        usage.setExecutableEntityRef(self.getChildElementOptionalRefType(element, "EXECUTABLE-ENTITY-REF"))
        hardware_configuration_element = self.find(element, "HARDWARE-CONFIGURATION")
        if hardware_configuration_element is not None:
            config = HardwareConfiguration()
            self.readHardwareConfiguration(hardware_configuration_element, config)
            usage.setHardwareConfiguration(config)
        usage.setHwElementRef(self.getChildElementOptionalRefType(element, "HW-ELEMENT-REF"))
        software_context_element = self.find(element, "SOFTWARE-CONTEXT")
        if software_context_element is not None:
            context = SoftwareContext()
            self.readSoftwareContext(software_context_element, context)
            usage.setSoftwareContext(context)

    def readRoughEstimateStackUsage(self, element: ET.Element, usage: RoughEstimateStackUsage):
        self.readStackUsage(element, usage)
        usage.setMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MEMORY-CONSUMPTION"))

    def readMeasuredStackUsage(self, element: ET.Element, usage: MeasuredStackUsage):
        self.readStackUsage(element, usage)
        usage.setAverageMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "AVERAGE-MEMORY-CONSUMPTION"))
        usage.setMaximumMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MAXIMUM-MEMORY-CONSUMPTION"))
        usage.setMinimumMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MINIMUM-MEMORY-CONSUMPTION"))
        usage.setTestPattern(self.getChildElementOptionalLiteral(element, "TEST-PATTERN"))

    def readWorstCaseStackUsage(self, element: ET.Element, usage: WorstCaseStackUsage):
        self.readStackUsage(element, usage)
        usage.setMemoryConsumption(self.getChildElementOptionalPositiveInteger(element, "MEMORY-CONSUMPTION"))

    def readStackUsages(self, element: ET.Element, consumption: ResourceConsumption):
        for child_element in self.findall(element, "STACK-USAGES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ROUGH-ESTIMATE-STACK-USAGE":
                usage = consumption.createRoughEstimateStackUsage(self.getShortName(child_element))
                self.readRoughEstimateStackUsage(child_element, usage)
            elif tag_name == "MEASURED-STACK-USAGE":
                usage = consumption.createMeasuredStackUsage(self.getShortName(child_element))
                self.readMeasuredStackUsage(child_element, usage)
            elif tag_name == "WORST-CASE-STACK-USAGE":
                usage = consumption.createWorstCaseStackUsage(self.getShortName(child_element))
                self.readWorstCaseStackUsage(child_element, usage)
            else:
                self.notImplemented("Unsupported Stack Usages: <%s>" % tag_name)

    def readResourceConsumption(self, element: ET.Element, impl: Implementation):
        child_element = self.find(element, "RESOURCE-CONSUMPTION")
        if child_element is not None:
            consumption = impl.createResourceConsumption(self.getShortName(child_element))
            self.readIdentifiable(child_element, consumption)
            self.readAccessCountSets(child_element, consumption)
            self.readExecutionTimes(child_element, consumption)
            self.readHeapUsages(child_element, consumption)
            self.readMemorySections(child_element, consumption)
            self.readSectionNamePrefixes(child_element, consumption)
            self.readStackUsages(child_element, consumption)

    def readImplementation(self, element: ET.Element, impl: Implementation):
        self.readIdentifiable(element, impl)
        self.readCodeDescriptor(element, impl)
        programming_language = self.getChildElementOptionalLiteral(element, "PROGRAMMING-LANGUAGE")
        if programming_language is not None:
            enum_value = ProgramminglanguageEnum()
            enum_value.setValue(programming_language.getText())
            impl.setProgrammingLanguage(enum_value)
        self.readResourceConsumption(element, impl)
        self.readBuildActionManifests(element, impl)
        self.readCompiler(element, impl)
        self.readLinker(element, impl)
        self.readDependencyOnArtifact(element, impl, "GENERATED-ARTIFACTS", impl.createGeneratedArtifact)
        self.readDependencyOnArtifact(element, impl, "REQUIRED-ARTIFACTS", impl.createRequiredArtifact)
        self.readDependencyOnArtifact(element, impl, "REQUIRED-GENERATOR-TOOLS", impl.createRequiredGeneratorTool)
        for ref in self.getChildElementRefTypeList(element, "HW-ELEMENT-REFS/HW-ELEMENT-REF"):
            impl.addHwElementRef(ref)
        impl.setBuildActionManifestRef(self.getChildElementOptionalRefType(element, "BUILD-ACTION-MANIFESTS/BUILD-ACTION-MANIFEST-REF-CONDITIONAL/BUILD-ACTION-MANIFEST-REF"))
        impl.setSwVersion(self.getChildElementOptionalLiteral(element, "SW-VERSION"))
        impl.setSwcBswMappingRef(self.getChildElementOptionalRefType(element, "SWC-BSW-MAPPING-REF"))
        impl.setUsedCodeGenerator(self.getChildElementOptionalLiteral(element, "USED-CODE-GENERATOR"))
        impl.setVendorId(self.getChildElementOptionalPositiveInteger(element, "VENDOR-ID"))
        mc_support_element = self.find(element, "MC-SUPPORT")
        if mc_support_element is not None:
            support = McSupportData()
            self.readMcSupportData(mc_support_element, support)
            impl.setMcSupport(support)

    def readMcSupportData(self, element: ET.Element, support: McSupportData):
        for child_element in self.findall(element, "EMULATION-SUPPORTS/MC-SW-EMULATION-METHOD-SUPPORT"):
            emulation_support = McSwEmulationMethodSupport()
            self.readMcSwEmulationMethodSupport(child_element, emulation_support)
            support.addEmulationSupport(emulation_support)
        for child_element in self.findall(element, "MC-PARAMETER-INSTANCES/MC-DATA-INSTANCE"):
            instance = support.createMcParameterInstance(self.getShortName(child_element))
            self.readMcDataInstance(child_element, instance)
        for child_element in self.findall(element, "MC-VARIABLE-INSTANCES/MC-DATA-INSTANCE"):
            instance = support.createMcVariableInstance(self.getShortName(child_element))
            self.readMcDataInstance(child_element, instance)
        for ref in self.getChildElementRefTypeList(element, "MEASURABLE-SYSTEM-CONSTANT-VALUES-REFS/MEASURABLE-SYSTEM-CONSTANT-VALUES-REF"):
            support.addMeasurableSystemConstantValuesRef(ref)
        rpt_support_data_element = self.find(element, "RPT-SUPPORT-DATA")
        if rpt_support_data_element is not None:
            rpt_support_data = RptSupportData()
            self.readRptSupportData(rpt_support_data_element, rpt_support_data)
            support.setRptSupportData(rpt_support_data)

    def readMcSwEmulationMethodSupport(self, element: ET.Element, support: McSwEmulationMethodSupport):
        support.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        support.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        support.setBaseReferenceRef(self.getChildElementOptionalRefType(element, "BASE-REFERENCE-REF"))
        for child_element in self.findall(element, "ELEMENT-GROUPS/MC-PARAMETER-ELEMENT-GROUP"):
            group = McParameterElementGroup()
            self.readMcParameterElementGroup(child_element, group)
            support.addElementGroup(group)
        support.setReferenceTableRef(self.getChildElementOptionalRefType(element, "REFERENCE-TABLE-REF"))
        self.readVariationPointCapable(element, support)

    def readMcParameterElementGroup(self, element: ET.Element, group: McParameterElementGroup):
        group.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        group.setRamLocationRef(self.getChildElementOptionalRefType(element, "RAM-LOCATION-REF"))
        group.setRomLocationRef(self.getChildElementOptionalRefType(element, "ROM-LOCATION-REF"))

    def readImplementationElementInParameterInstanceRef(self, element: ET.Element, instance_in_memory: ImplementationElementInParameterInstanceRef):
        instance_in_memory.setContextRef(self.getChildElementOptionalRefType(element, "CONTEXT-REF"))
        instance_in_memory.setTargetRef(self.getChildElementOptionalRefType(element, "TARGET-REF"))

    def readRteEventInEcuInstanceRef(self, element: ET.Element, iref: RteEventInEcuInstanceRef):
        iref.setContextRootCompositionRef(self.getChildElementOptionalRefType(element, "CONTEXT-ROOT-COMPOSITION-REF"))
        iref.setContextAtomicComponentRef(self.getChildElementOptionalRefType(element, "CONTEXT-ATOMIC-COMPONENT-REF"))
        iref.setTargetRteEventRef(self.getChildElementOptionalRefType(element, "TARGET-RTE-EVENT-REF"))

    def readVariableAccessInEcuInstanceRef(self, element: ET.Element, iref: VariableAccessInEcuInstanceRef):
        iref.setContextRootCompositionRef(self.getChildElementOptionalRefType(element, "CONTEXT-ROOT-COMPOSITION-REF"))
        iref.setContextAtomicComponentRef(self.getChildElementOptionalRefType(element, "CONTEXT-ATOMIC-COMPONENT-REF"))
        iref.setTargetVariableAccessRef(self.getChildElementOptionalRefType(element, "TARGET-VARIABLE-ACCESS-REF"))

    def readMcDataAccessDetails(self, element: ET.Element, details: McDataAccessDetails):
        for child_element in self.findall(element, "RTE-EVENT-IREFS/RTE-EVENT-IREF"):
            iref = RteEventInEcuInstanceRef()
            self.readRteEventInEcuInstanceRef(child_element, iref)
            details.addRteEventIRef(iref)
        for child_element in self.findall(element, "VARIABLE-ACCESS-IREFS/VARIABLE-ACCESS-IREF"):
            iref = VariableAccessInEcuInstanceRef()
            self.readVariableAccessInEcuInstanceRef(child_element, iref)
            details.addVariableAccessIRef(iref)

    def readMcDataInstance(self, element: ET.Element, instance: McDataInstance):
        instance.setArraySize(self.getChildElementOptionalPositiveInteger(element, "ARRAY-SIZE"))
        instance.setDisplayIdentifier(self.getChildElementOptionalLiteral(element, "DISPLAY-IDENTIFIER"))
        instance.setFlatMapEntryRef(self.getChildElementOptionalRefType(element, "FLAT-MAP-ENTRY-REF"))
        instance_in_memory_element = self.find(element, "INSTANCE-IN-MEMORY")
        if instance_in_memory_element is not None:
            instance_in_memory = ImplementationElementInParameterInstanceRef()
            self.readImplementationElementInParameterInstanceRef(instance_in_memory_element, instance_in_memory)
            instance.setInstanceInMemory(instance_in_memory)
        instance.setRole(self.getChildElementOptionalLiteral(element, "ROLE"))
        instance.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))
        mc_data_access_details_element = self.find(element, "MC-DATA-ACCESS-DETAILS")
        if mc_data_access_details_element is not None:
            details = McDataAccessDetails()
            self.readMcDataAccessDetails(mc_data_access_details_element, details)
            instance.setMcDataAccessDetails(details)
        if self.find(element, "RESULTING-PROPERTIES") is not None:
            instance.setResultingProperties(SwDataDefProps())
        rpt_sw_prototyping_access_element = self.find(element, "RESULTING-RPT-SW-PROTOTYPING-ACCESS")
        if rpt_sw_prototyping_access_element is not None:
            access = RptSwPrototypingAccess()
            self.readRptSwPrototypingAccess(rpt_sw_prototyping_access_element, access)
            instance.setResultingRptSwPrototypingAccess(access)
        rpt_impl_policy_element = self.find(element, "RPT-IMPL-POLICY")
        if rpt_impl_policy_element is not None:
            policy = RptImplPolicy()
            self.readRptImplPolicy(rpt_impl_policy_element, policy)
            instance.setRptImplPolicy(policy)
        for assignment_element in self.findall(element, "MC-DATA-ASSIGNMENTS/ROLE-BASED-MC-DATA-ASSIGNMENT"):
            assignment = RoleBasedMcDataAssignment()
            self.readRoleBasedMcDataAssignment(assignment_element, assignment)
            instance.addMcDataAssignment(assignment)
        for sub_element in self.findall(element, "SUB-ELEMENTS/MC-DATA-INSTANCE"):
            self.readMcDataInstance(sub_element, instance.createSubElement(self.getShortName(sub_element)))

    def readRoleBasedMcDataAssignment(self, element: ET.Element, assignment: RoleBasedMcDataAssignment):
        for ref in self.getChildElementRefTypeList(element, "EXECUTION-CONTEXT-REFS/EXECUTION-CONTEXT-REF"):
            assignment.addExecutionContextRef(ref)
        for ref in self.getChildElementRefTypeList(element, "MC-DATA-INSTANCE-REFS/MC-DATA-INSTANCE-REF"):
            assignment.addMcDataInstanceRef(ref)
        assignment.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        self.readVariationPointCapable(element, assignment)

    def readRptSwPrototypingAccess(self, element: ET.Element, access: RptSwPrototypingAccess):
        access.setRptHookAccess(self.getChildElementOptionalLiteral(element, "RPT-HOOK-ACCESS"))
        access.setRptReadAccess(self.getChildElementOptionalLiteral(element, "RPT-READ-ACCESS"))
        access.setRptWriteAccess(self.getChildElementOptionalLiteral(element, "RPT-WRITE-ACCESS"))

    def readRptImplPolicy(self, element: ET.Element, policy: RptImplPolicy):
        policy.setRptEnablerImplType(self.getChildElementOptionalLiteral(element, "RPT-ENABLER-IMPL-TYPE"))
        policy.setRptPreparationLevel(self.getChildElementOptionalLiteral(element, "RPT-PREPARATION-LEVEL"))

    def readRptExecutableEntityProperties(self, element: ET.Element, properties: RptExecutableEntityProperties):
        properties.setMaxRptEventId(self.getChildElementOptionalPositiveInteger(element, "MAX-RPT-EVENT-ID"))
        properties.setMinRptEventId(self.getChildElementOptionalPositiveInteger(element, "MIN-RPT-EVENT-ID"))
        properties.setRptExecutionControl(self.getChildElementOptionalLiteral(element, "RPT-EXECUTION-CONTROL"))
        properties.setRptServicePoint(self.getChildElementOptionalLiteral(element, "RPT-SERVICE-POINT"))

    def readRptServicePoint(self, element: ET.Element, service_point: RptServicePoint):
        service_point.setServiceId(self.getChildElementOptionalPositiveInteger(element, "SERVICE-ID"))
        service_point.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))

    def readRptExecutableEntityEvent(self, element: ET.Element, event: RptExecutableEntityEvent):
        for ref in self.getChildElementRefTypeList(element, "EXECUTION-CONTEXT-REFS/EXECUTION-CONTEXT-REF"):
            event.addExecutionContextRef(ref)
        for assignment_element in self.findall(element, "MC-DATA-ASSIGNMENTS/ROLE-BASED-MC-DATA-ASSIGNMENT"):
            assignment = RoleBasedMcDataAssignment()
            self.readRoleBasedMcDataAssignment(assignment_element, assignment)
            event.addMcDataAssignment(assignment)
        event.setRptEventId(self.getChildElementOptionalPositiveInteger(element, "RPT-EVENT-ID"))
        rpt_executable_entity_properties_element = self.find(element, "RPT-EXECUTABLE-ENTITY-PROPERTIES")
        if rpt_executable_entity_properties_element is not None:
            properties = RptExecutableEntityProperties()
            self.readRptExecutableEntityProperties(rpt_executable_entity_properties_element, properties)
            event.setRptExecutableEntityProperties(properties)
        rpt_impl_policy_element = self.find(element, "RPT-IMPL-POLICY")
        if rpt_impl_policy_element is not None:
            policy = RptImplPolicy()
            self.readRptImplPolicy(rpt_impl_policy_element, policy)
            event.setRptImplPolicy(policy)
        for ref in self.getChildElementRefTypeList(element, "RPT-SERVICE-POINT-POST-REFS/RPT-SERVICE-POINT-POST-REF"):
            event.addRptServicePointPostRef(ref)
        for ref in self.getChildElementRefTypeList(element, "RPT-SERVICE-POINT-PRE-REFS/RPT-SERVICE-POINT-PRE-REF"):
            event.addRptServicePointPreRef(ref)

    def readRptExecutableEntity(self, element: ET.Element, entity: RptExecutableEntity):
        for event_element in self.findall(element, "RPT-EXECUTABLE-ENTITY-EVENTS/RPT-EXECUTABLE-ENTITY-EVENT"):
            event = entity.createRptExecutableEntityEvent(self.getShortName(event_element))
            self.readRptExecutableEntityEvent(event_element, event)
        for assignment_element in self.findall(element, "RPT-READS/ROLE-BASED-MC-DATA-ASSIGNMENT"):
            assignment = RoleBasedMcDataAssignment()
            self.readRoleBasedMcDataAssignment(assignment_element, assignment)
            entity.addRptRead(assignment)
        for assignment_element in self.findall(element, "RPT-WRITES/ROLE-BASED-MC-DATA-ASSIGNMENT"):
            assignment = RoleBasedMcDataAssignment()
            self.readRoleBasedMcDataAssignment(assignment_element, assignment)
            entity.addRptWrite(assignment)
        entity.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))

    def readRptComponent(self, element: ET.Element, component: RptComponent):
        for assignment_element in self.findall(element, "MC-DATA-ASSIGNMENTS/ROLE-BASED-MC-DATA-ASSIGNMENT"):
            assignment = RoleBasedMcDataAssignment()
            self.readRoleBasedMcDataAssignment(assignment_element, assignment)
            component.addMcDataAssignment(assignment)
        rp_impl_policy_element = self.find(element, "RP-IMPL-POLICY")
        if rp_impl_policy_element is not None:
            policy = RptImplPolicy()
            self.readRptImplPolicy(rp_impl_policy_element, policy)
            component.setRpImplPolicy(policy)
        for entity_element in self.findall(element, "RPT-EXECUTABLE-ENTITYS/RPT-EXECUTABLE-ENTITY"):
            entity = component.createRptExecutableEntity(self.getShortName(entity_element))
            self.readRptExecutableEntity(entity_element, entity)

    def readRptSupportData(self, element: ET.Element, rpt_support_data: RptSupportData):
        for context_element in self.findall(element, "EXECUTION-CONTEXTS/RPT-EXECUTION-CONTEXT"):
            rpt_support_data.createExecutionContext(self.getShortName(context_element))
        for component_element in self.findall(element, "RPT-COMPONENTS/RPT-COMPONENT"):
            component = rpt_support_data.createRptComponent(self.getShortName(component_element))
            self.readRptComponent(component_element, component)
        for service_point_element in self.findall(element, "RPT-SERVICE-POINTS/RPT-SERVICE-POINT"):
            service_point = rpt_support_data.createRptServicePoint(self.getShortName(service_point_element))
            self.readRptServicePoint(service_point_element, service_point)

    def readBuildActionManifests(self, element: ET.Element, impl: Implementation):
        child_element = self.find(element, "BUILD-ACTION-MANIFESTS")
        if child_element is not None:
            ref = self.getChildElementOptionalRefType(child_element, "BUILD-ACTION-MANIFEST-REF-CONDITIONAL/BUILD-ACTION-MANIFEST-REF")
            if ref is not None:
                impl.setBuildActionManifestRef(ref)

    def readBuildActionInvocator(self, element: ET.Element, invocator: BuildActionInvocator) -> BuildActionInvocator:
        invocator.setCommand(self.getChildElementOptionalVerbatimString(element, "COMMAND"))
        sdgs_element = self.find(element, "SDGS")
        if sdgs_element is not None:
            for child in self.findall(sdgs_element, "SDG"):
                invocator.addSdg(self.getSdg(child))
        return invocator

    def readBuildEngineeringObject(self, element: ET.Element, engineering_object: BuildEngineeringObject) -> BuildEngineeringObject:
        engineering_object.setFileType(self.getChildElementOptionalLiteral(element, "FILE-TYPE"))
        engineering_object.setIntendedFilename(self.getChildElementOptionalUriString(element, "INTENDED-FILENAME"))
        engineering_object.setParentCategory(self.getChildElementOptionalLiteral(element, "PARENT-CATEGORY"))
        engineering_object.setParentShortLabel(self.getChildElementOptionalLiteral(element, "PARENT-SHORT-LABEL"))
        engineering_object.setShortLabelPattern(self.getChildElementOptionalLiteral(element, "SHORT-LABEL-PATTERN"))
        engineering_object.setFileTypePattern(self.getChildElementOptionalLiteral(element, "FILE-TYPE-PATTERN"))
        return engineering_object

    def readBuildActionIoElement(self, element: ET.Element, io_element: BuildActionIoElement) -> BuildActionIoElement:
        io_element.setCategory(self.getChildElementOptionalNameToken(element, "CATEGORY"))
        sdgs_element = self.find(element, "SDGS")
        if sdgs_element is not None:
            for child in self.findall(sdgs_element, "SDG"):
                io_element.addSdg(self.getSdg(child))
        io_element.setEcucDefinitionRef(self.getChildElementOptionalRefType(element, "ECUC-DEFINITION-REF"))
        engineering_object_element = self.find(element, "ENGINEERING-OBJECT")
        if engineering_object_element is not None:
            io_element.setEngineeringObject(self.readBuildEngineeringObject(engineering_object_element, BuildEngineeringObject()))
        io_element.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        return io_element

    def readBuildActionEnvironment(self, element: ET.Element, environment: BuildActionEnvironment) -> BuildActionEnvironment:
        self.readIdentifiable(element, environment)
        sdgs_element = self.find(element, "SDGS")
        if sdgs_element is not None:
            for child in self.findall(sdgs_element, "SDG"):
                environment.addSdg(self.getSdg(child))
        return environment

    def readBuildAction(self, element: ET.Element, action: BuildAction) -> BuildAction:
        self.readBuildActionEntity(element, action)
        predecessors_element = self.find(element, "PREDECESSOR-ACTION-REFS")
        if predecessors_element is not None:
            for ref in self.getChildElementRefTypeList(predecessors_element, "PREDECESSOR-ACTION-REF"):
                action.addPredecessorActionRef(ref)
        follow_ups_element = self.find(element, "FOLLOW-UP-ACTION-REFS")
        if follow_ups_element is not None:
            for ref in self.getChildElementRefTypeList(follow_ups_element, "FOLLOW-UP-ACTION-REF"):
                action.addFollowUpActionRef(ref)
        created_datas_element = self.find(element, "CREATED-DATAS")
        if created_datas_element is not None:
            for child in self.findall(created_datas_element, "BUILD-ACTION-IO-ELEMENT"):
                action.addCreatedData(self.readBuildActionIoElement(child, BuildActionIoElement()))
        input_datas_element = self.find(element, "INPUT-DATAS")
        if input_datas_element is not None:
            for child in self.findall(input_datas_element, "BUILD-ACTION-IO-ELEMENT"):
                action.addInputData(self.readBuildActionIoElement(child, BuildActionIoElement()))
        modified_datas_element = self.find(element, "MODIFIED-DATAS")
        if modified_datas_element is not None:
            for child in self.findall(modified_datas_element, "BUILD-ACTION-IO-ELEMENT"):
                action.addModifiedData(self.readBuildActionIoElement(child, BuildActionIoElement()))
        action.setRequiredEnvironmentRef(self.getChildElementOptionalRefType(element, "REQUIRED-ENVIRONMENT-REF"))
        return action

    def readBuildActionManifest(self, element: ET.Element, manifest: BuildActionManifest) -> BuildActionManifest:
        self.readIdentifiable(element, manifest)
        for ref in self.getChildElementRefTypeList(element, "START-ACTION-REFS/START-ACTION-REF"):
            manifest.addStartActionRef(ref)
        for ref in self.getChildElementRefTypeList(element, "TEAR-DOWN-ACTION-REFS/TEAR-DOWN-ACTION-REF"):
            manifest.addTearDownActionRef(ref)
        for child in self.findall(element, "BUILD-ACTIONS/BUILD-ACTION"):
            action = manifest.createBuildAction(self.getShortName(child))
            self.readBuildAction(child, action)
        for child in self.findall(element, "BUILD-ACTION-ENVIRONMENTS/BUILD-ACTION-ENVIRONMENT"):
            environment = manifest.createBuildActionEnvironment(self.getShortName(child))
            self.readBuildActionEnvironment(child, environment)
        for ref in self.getChildElementRefTypeList(element, "DYNAMIC-ACTION-REFS/DYNAMIC-ACTION-REF"):
            manifest.addDynamicActionRef(ref)
        return manifest

    def readBuildActionEntity(self, element: ET.Element, entity: BuildActionEntity):
        self.readIdentifiable(element, entity)
        delivery = self.find(element, "DELIVERY-ARTIFACTS")
        if delivery is not None:
            for child in self.findall(delivery, "AUTOSAR-ENGINEERING-OBJECT"):
                entity.addDeliveryArtifact(self.getAutosarEngineeringObject(child))
        invocation_element = self.find(element, "INVOCATION")
        if invocation_element is not None:
            entity.setInvocation(self.readBuildActionInvocator(invocation_element, BuildActionInvocator()))

    def readBswImplementationVendorSpecificModuleDefRefs(self, element: ET.Element, impl: BswImplementation):
        child_element = self.find(element, "VENDOR-SPECIFIC-MODULE-DEF-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "VENDOR-SPECIFIC-MODULE-DEF-REF"):
                impl.addVendorSpecificModuleDefRef(ref)

    def readBswImplementationPreconfiguredConfigurationRefs(self, element: ET.Element, impl: BswImplementation):
        child_element = self.find(element, "PRECONFIGURED-CONFIGURATION-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "PRECONFIGURED-CONFIGURATION-REF"):
                impl.addPreconfiguredConfigurationRef(ref)

    def readBswImplementationRecommendedConfigurationRefs(self, element: ET.Element, impl: BswImplementation):
        child_element = self.find(element, "RECOMMENDED-CONFIGURATION-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "RECOMMENDED-CONFIGURATION-REF"):
                impl.addRecommendedConfigurationRef(ref)

    def readBswImplementation(self, element: ET.Element, impl: BswImplementation):
        self.logger.debug("Read BswImplementation <%s>" % impl.getShortName())
        self.readImplementation(element, impl)
        impl.setArReleaseVersion(self.getChildElementOptionalLiteral(element, "AR-RELEASE-VERSION"))
        impl.setBehaviorRef(self.getChildElementOptionalRefType(element, "BEHAVIOR-REF"))
        impl.setVendorApiInfix(self.getChildElementOptionalLiteral(element, "VENDOR-API-INFIX"))
        self.readBswImplementationPreconfiguredConfigurationRefs(element, impl)
        self.readBswImplementationRecommendedConfigurationRefs(element, impl)
        self.readBswImplementationVendorSpecificModuleDefRefs(element, impl)
        behavior_ref = impl.getBehaviorRef()
        if behavior_ref is not None:
            document = AUTOSAR.getInstance()
            document.addImplementationBehaviorMap(impl.getFullName(), behavior_ref.getValue())

    def readPerInstanceMemorySize(self, element: ET.Element, value: PerInstanceMemorySize):
        self.readARObject(element, value)
        value.setAlignment(self.getChildElementOptionalPositiveInteger(element, "ALIGNMENT"))
        value.setPerInstanceMemoryRef(self.getChildElementOptionalRefType(element, "PER-INSTANCE-MEMORY-REF"))
        value.setSize(self.getChildElementOptionalPositiveInteger(element, "SIZE"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            value.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))

    def readSwcImplementation(self, element: ET.Element, impl: SwcImplementation):
        self.logger.debug("Read SwcImplementation <%s>" % impl.getShortName())
        self.readImplementation(element, impl)
        impl.setBehaviorRef(self.getChildElementOptionalRefType(element, "BEHAVIOR-REF"))
        for child_element in self.findall(element, "PER-INSTANCE-MEMORY-SIZES/PER-INSTANCE-MEMORY-SIZE"):
            value = PerInstanceMemorySize()
            self.readPerInstanceMemorySize(child_element, value)
            impl.addPerInstanceMemorySize(value)
        impl.setRequiredRTEVendor(self.getChildElementOptionalString(element, "REQUIRED-RTE-VENDOR"))
        behavior_ref = impl.getBehaviorRef()
        if behavior_ref is not None:
            document = AUTOSAR.getInstance()
            document.addImplementationBehaviorMap(impl.getFullName(), behavior_ref.getValue())

    def readRunnableEntityDataReceivePointByArguments(self, element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "DATA-RECEIVE-POINT-BY-ARGUMENTS")

    def readRunnableEntityDataReceivePointByValues(self, element: ET.Element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "DATA-RECEIVE-POINT-BY-VALUES")

    def readRunnableEntityDataReadAccesses(self, element: ET.Element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "DATA-READ-ACCESSS")

    def readRunnableEntityDataWriteAccesses(self, element: ET.Element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "DATA-WRITE-ACCESSS")

    def readRunnableEntityDataSendPoints(self, element: ET.Element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "DATA-SEND-POINTS")

    def getRunnableEntityArgument(self, element: ET.Element) -> RunnableEntityArgument:
        argument = RunnableEntityArgument()
        argument.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))
        return argument

    def getParameterInAtomicSWCTypeInstanceRef(self, element: ET.Element, key: str) -> ParameterInAtomicSWCTypeInstanceRef:
        parameter_iref = None
        child_element = self.find(element, key)
        if child_element is not None:
            parameter_iref = ParameterInAtomicSWCTypeInstanceRef()
            for ref in self.getChildElementRefTypeList(child_element, "CONTEXT-DATA-PROTOTYPE-REF"):
                parameter_iref.addContextDataPrototypeRef(ref)
            parameter_iref.setPortPrototypeRef(self.getChildElementOptionalRefType(child_element, "PORT-PROTOTYPE-REF"))
            parameter_iref.setRootParameterDataPrototypeRef(self.getChildElementOptionalRefType(child_element, "ROOT-PARAMETER-DATA-PROTOTYPE-REF"))
            parameter_iref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(child_element, "TARGET-DATA-PROTOTYPE-REF"))
        return parameter_iref

    def getAutosarParameterRef(self, element: ET.Element, key: str) -> AutosarParameterRef:
        parameter = None
        child_element = self.find(element, key)
        if child_element is not None:
            parameter = AutosarParameterRef()
            self.readARObject(child_element, parameter)
            parameter.setAutosarParameterIRef(self.getParameterInAtomicSWCTypeInstanceRef(child_element, "AUTOSAR-PARAMETER-IREF"))
            parameter.setLocalParameterRef(self.getChildElementOptionalRefType(child_element, "LOCAL-PARAMETER-REF"))
        return parameter

    def readParameterAccess(self, element: ET.Element, access: ParameterAccess):
        self.readIdentifiable(element, access)
        access.setAccessedParameter(self.getAutosarParameterRef(element, "ACCESSED-PARAMETER"))
        access.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))

    def readRunnableEntityParameterAccesses(self, element: ET.Element, parent: RunnableEntity):
        for child_element in self.findall(element, "PARAMETER-ACCESSS/PARAMETER-ACCESS"):
            short_name = self.getShortName(child_element)
            self.logger.debug("readParameterAccesses %s" % short_name)
            parameter_access = parent.createParameterAccess(short_name)
            self.readParameterAccess(child_element, parameter_access)

    def readRunnableEntityWrittenLocalVariables(self, element: ET.Element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "WRITTEN-LOCAL-VARIABLES")

    def readRunnableEntityReadLocalVariables(self, element: ET.Element, parent: RunnableEntity):
        self.readVariableAccesses(element, parent, "READ-LOCAL-VARIABLES")

    def readROperationIRef(self, element: ET.Element, key: str, parent: ServerCallPoint):
        child_element = self.find(element, key)
        if child_element is not None:
            operation_iref = ROperationInAtomicSwcInstanceRef()
            self.readARObject(child_element, operation_iref)
            operation_iref.setContextRPortRef(self.getChildElementOptionalRefType(child_element, "CONTEXT-R-PORT-REF"))
            operation_iref.setTargetRequiredOperationRef(self.getChildElementOptionalRefType(child_element, "TARGET-REQUIRED-OPERATION-REF"))
            parent.setOperationIRef(operation_iref)

    def readRVariableInAtomicSwcInstanceRef(self, element: ET.Element, parent: Union[DataReceivedEvent, DataReceiveErrorEvent]):
        child_element = self.find(element, "DATA-IREF")
        if child_element is not None:
            data_iref = RVariableInAtomicSwcInstanceRef()
            data_iref.setContextRPortRef(self.getChildElementOptionalRefType(child_element, "CONTEXT-R-PORT-REF"))
            data_iref.setTargetDataElementRef(self.getChildElementOptionalRefType(child_element, "TARGET-DATA-ELEMENT-REF"))
            parent.setDataIRef(data_iref)

    def readRModeInAtomicSwcInstanceRef(self, element: ET.Element, parent: SwcModeSwitchEvent):
        for child_element in self.findall(element, "MODE-IREFS/MODE-IREF"):
            mode_iref = RModeInAtomicSwcInstanceRef()
            mode_iref.setContextPortRef(self.getChildElementOptionalRefType(child_element, "CONTEXT-PORT-REF"))
            mode_iref.setContextModeDeclarationGroupPrototypeRef(self.getChildElementOptionalRefType(child_element, "CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF"))
            mode_iref.setTargetModeDeclarationRef(self.getChildElementOptionalRefType(child_element, "TARGET-MODE-DECLARATION-REF"))  # NOQA E501
            parent.addModeIRef(mode_iref)

    def readSynchronousServerCallPoint(self, element: ET.Element, parent: RunnableEntity):
        # self.logger.debug("readSynchronousServerCallPoint %s" % short_name)
        short_name = self.getShortName(element)
        server_call_point = parent.createSynchronousServerCallPoint(short_name)
        self.readIdentifiable(element, server_call_point)
        server_call_point.setTimeout(self.getChildElementOptionalTimeValue(element, "TIMEOUT"))
        self.readROperationIRef(element, "OPERATION-IREF", server_call_point)
        server_call_point.setCalledFromWithinExclusiveAreaRef(self.getChildElementOptionalRefType(element, "CALLED-FROM-WITHIN-EXCLUSIVE-AREA-REF"))

    def readAsynchronousServerCallPoint(self, element: ET.Element, parent: RunnableEntity):
        # self.logger.debug("readAsynchronousServerCallPoint %s" % short_name)
        short_name = self.getShortName(element)
        server_call_point = parent.createAsynchronousServerCallPoint(short_name)
        self.readIdentifiable(element, server_call_point)
        server_call_point.setTimeout(self.getChildElementOptionalTimeValue(element, "TIMEOUT"))
        self.readROperationIRef(element, "OPERATION-IREF", server_call_point)

    def readRunnableEntityInternalBehaviorServerCallPoint(self, element: ET.Element, parent: RunnableEntity):
        for child_element in self.findall(element, "SERVER-CALL-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SYNCHRONOUS-SERVER-CALL-POINT":
                self.readSynchronousServerCallPoint(child_element, parent)
            elif tag_name == "ASYNCHRONOUS-SERVER-CALL-POINT":
                self.readAsynchronousServerCallPoint(child_element, parent)
            else:
                self.raiseError("Unsupported server call point type <%s>" % tag_name)

    def readInternalTriggeringPoint(self, element: ET.Element, point: InternalTriggeringPoint):
        self.readIdentifiable(element, point)
        literal = self.getChildElementOptionalLiteral(element, "SW-IMPL-POLICY")
        if literal is not None:
            camel = None
            for camel_value, token in SW_IMPL_POLICY_XML_MAP.items():
                if token == literal.getText():
                    camel = camel_value
                    break
            if camel is not None:
                point.setSwImplPolicy(SwImplPolicyEnum().setValue(camel))
            else:
                self.notImplemented("Unsupported SW-IMPL-POLICY <%s>" % literal.getText())

    def readRunnableEntityInternalTriggeringPoints(self, element: ET.Element, parent: RunnableEntity):
        for child_element in self.findall(element, "INTERNAL-TRIGGERING-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "INTERNAL-TRIGGERING-POINT":
                point = parent.createInternalTriggeringPoint(self.getShortName(child_element))
                self.readInternalTriggeringPoint(child_element, point)
            else:
                self.notImplemented("Unsupported Internal Triggering Point <%s>" % tag_name)

    def readRunnableEntityExternalTriggeringPoints(self, element: ET.Element, parent: RunnableEntity):
        for child_element in self.findall(element, "EXTERNAL-TRIGGERING-POINTS/EXTERNAL-TRIGGERING-POINT"):
            point = ExternalTriggeringPoint()
            ident_element = self.find(child_element, "IDENT")
            if ident_element is not None:
                point.createIdent(self.getShortName(ident_element))
            trigger_element = self.find(child_element, "TRIGGER-IREF")
            if trigger_element is not None:
                trigger = PTriggerInAtomicSwcTypeInstanceRef()
                self.readPTriggerInAtomicSwcTypeInstanceRef(trigger_element, trigger)
                point.setTrigger(trigger)
            parent.addExternalTriggeringPoint(point)

    def readModeGroupInAtomicSwcInstanceRef(self, element: ET.Element, instance_ref: ModeGroupInAtomicSwcInstanceRef):
        instance_ref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
        instance_ref.setContextPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-REF"))

    def readRModeGroupInAtomicSWCInstanceRef(self, element: ET.Element, instance_ref: RModeGroupInAtomicSWCInstanceRef):
        self.readModeGroupInAtomicSwcInstanceRef(element, instance_ref)
        instance_ref.setContextRPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-R-PORT-REF"))
        instance_ref.setTargetModeGroupRef(self.getChildElementOptionalRefType(element, "TARGET-MODE-GROUP-REF"))

    def readPModeGroupInAtomicSWCInstanceRef(self, element: ET.Element, instance_ref: PModeGroupInAtomicSwcInstanceRef):
        self.readModeGroupInAtomicSwcInstanceRef(element, instance_ref)
        instance_ref.setContextPPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-P-PORT-REF"))
        instance_ref.setTargetModeGroupRef(self.getChildElementOptionalRefType(element, "TARGET-MODE-GROUP-REF"))

    def readPTriggerInAtomicSwcTypeInstanceRef(self, element: ET.Element, instance_ref: PTriggerInAtomicSwcTypeInstanceRef):
        instance_ref.setContextPPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-P-PORT-REF"))
        instance_ref.setTargetTriggerRef(self.getChildElementOptionalRefType(element, "TARGET-TRIGGER-REF"))

    def readInnerDataPrototypeGroupInCompositionInstanceRef(self, element: ET.Element, instance_ref: InnerDataPrototypeGroupInCompositionInstanceRef):
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-SW-COMPONENT-PROTOTYPE-REF"):
            instance_ref.addContextSwComponentPrototypeRef(ref)
        instance_ref.setTargetDataPrototypeGroupRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-GROUP-REF"))

    def readInnerRunnableEntityGroupInCompositionInstanceRef(self, element: ET.Element, instance_ref: InnerRunnableEntityGroupInCompositionInstanceRef):
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-SW-COMPONENT-PROTOTYPE-REF"):
            instance_ref.addContextSwComponentPrototypeRef(ref)
        instance_ref.setTargetRunnableEntityGroupRef(self.getChildElementOptionalRefType(element, "TARGET-RUNNABLE-ENTITY-GROUP-REF"))

    def readRunnableEntityInCompositionInstanceRef(self, element: ET.Element, instance_ref: RunnableEntityInCompositionInstanceRef):
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-SW-COMPONENT-PROTOTYPE-REF"):
            instance_ref.addContextSwComponentPrototypeRef(ref)
        instance_ref.setTargetRunnableEntityRef(self.getChildElementOptionalRefType(element, "TARGET-RUNNABLE-ENTITY-REF"))

    def readVariableDataPrototypeInCompositionInstanceRef(self, element: ET.Element, instance_ref: VariableDataPrototypeInCompositionInstanceRef):
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-SW-COMPONENT-PROTOTYPE-REF"):
            instance_ref.addContextSwComponentPrototypeRef(ref)
        instance_ref.setContextPortPrototypeRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-PROTOTYPE-REF"))
        instance_ref.setTargetVariableDataPrototypeRef(self.getChildElementOptionalRefType(element, "TARGET-VARIABLE-DATA-PROTOTYPE-REF"))

    def readDataPrototypeGroupDataPrototypeGroupIRefs(self, element: ET.Element, parent: DataPrototypeGroup):
        for child_element in self.findall(element, "DATA-PROTOTYPE-GROUP-IREFS/DATA-PROTOTYPE-GROUP-IREF"):
            instance_ref = InnerDataPrototypeGroupInCompositionInstanceRef()
            self.readInnerDataPrototypeGroupInCompositionInstanceRef(child_element, instance_ref)
            parent.addDataPrototypeGroupIRef(instance_ref)

    def readDataPrototypeGroupImplicitDataAccessIRefs(self, element: ET.Element, parent: DataPrototypeGroup):
        for child_element in self.findall(element, "IMPLICIT-DATA-ACCESS-IREFS/IMPLICIT-DATA-ACCESS-IREF"):
            instance_ref = VariableDataPrototypeInCompositionInstanceRef()
            self.readVariableDataPrototypeInCompositionInstanceRef(child_element, instance_ref)
            parent.addImplicitDataAccessIRef(instance_ref)

    def readDataPrototypeGroup(self, element: ET.Element, data_group: DataPrototypeGroup):
        self.logger.debug("readDataPrototypeGroup %s" % data_group.getShortName())
        self.readIdentifiable(element, data_group)
        self.readDataPrototypeGroupDataPrototypeGroupIRefs(element, data_group)
        self.readDataPrototypeGroupImplicitDataAccessIRefs(element, data_group)

    def readRunnableEntityGroupRunnableEntityGroupIRefs(self, element: ET.Element, parent: RunnableEntityGroup):
        for child_element in self.findall(element, "RUNNABLE-ENTITY-GROUP-IREFS/RUNNABLE-ENTITY-GROUP-IREF"):
            instance_ref = InnerRunnableEntityGroupInCompositionInstanceRef()
            self.readInnerRunnableEntityGroupInCompositionInstanceRef(child_element, instance_ref)
            parent.addRunnableEntityGroupIRef(instance_ref)

    def readRunnableEntityGroupRunnableEntityIRefs(self, element: ET.Element, parent: RunnableEntityGroup):
        for child_element in self.findall(element, "RUNNABLE-ENTITY-IREFS/RUNNABLE-ENTITY-IREF"):
            instance_ref = RunnableEntityInCompositionInstanceRef()
            self.readRunnableEntityInCompositionInstanceRef(child_element, instance_ref)
            parent.addRunnableEntityIRef(instance_ref)

    def readRunnableEntityGroup(self, element: ET.Element, runnable_group: RunnableEntityGroup):
        self.logger.debug("readRunnableEntityGroup %s" % runnable_group.getShortName())
        self.readIdentifiable(element, runnable_group)
        self.readRunnableEntityGroupRunnableEntityGroupIRefs(element, runnable_group)
        self.readRunnableEntityGroupRunnableEntityIRefs(element, runnable_group)

    def readConsistencyNeedsDpgDoesNotRequireCoherencys(self, element: ET.Element, parent: ConsistencyNeeds):
        for child_element in self.findall(element, "DPG-DOES-NOT-REQUIRE-COHERENCYS/DATA-PROTOTYPE-GROUP"):
            data_group = parent.createDpgDoesNotRequireCoherency(self.getShortName(child_element))
            self.readDataPrototypeGroup(child_element, data_group)

    def readConsistencyNeedsDpgRequiresCoherencys(self, element: ET.Element, parent: ConsistencyNeeds):
        for child_element in self.findall(element, "DPG-REQUIRES-COHERENCYS/DATA-PROTOTYPE-GROUP"):
            data_group = parent.createDpgRequiresCoherency(self.getShortName(child_element))
            self.readDataPrototypeGroup(child_element, data_group)

    def readConsistencyNeedsRegDoesNotRequireStabilitys(self, element: ET.Element, parent: ConsistencyNeeds):
        for child_element in self.findall(element, "REG-DOES-NOT-REQUIRE-STABILITYS/RUNNABLE-ENTITY-GROUP"):
            runnable_group = parent.createRegDoesNotRequireStability(self.getShortName(child_element))
            self.readRunnableEntityGroup(child_element, runnable_group)

    def readConsistencyNeedsRegRequiresStabilitys(self, element: ET.Element, parent: ConsistencyNeeds):
        for child_element in self.findall(element, "REG-REQUIRES-STABILITYS/RUNNABLE-ENTITY-GROUP"):
            runnable_group = parent.createRegRequiresStability(self.getShortName(child_element))
            self.readRunnableEntityGroup(child_element, runnable_group)

    def readConsistencyNeeds(self, element: ET.Element, consistency_needs: ConsistencyNeeds):
        self.logger.debug("readConsistencyNeeds %s" % consistency_needs.getShortName())
        self.readIdentifiable(element, consistency_needs)
        self.readConsistencyNeedsDpgDoesNotRequireCoherencys(element, consistency_needs)
        self.readConsistencyNeedsDpgRequiresCoherencys(element, consistency_needs)
        self.readConsistencyNeedsRegDoesNotRequireStabilitys(element, consistency_needs)
        self.readConsistencyNeedsRegRequiresStabilitys(element, consistency_needs)

    def getModeGroupIRef(self, element: ET.Element, key: str) -> ModeGroupInAtomicSwcInstanceRef:
        instance_ref = None
        for child_element in self.findall(element, "%s/*" % key):
            tag_name = self.getTagName(child_element)
            if tag_name == "P-MODE-GROUP-IN-ATOMIC-SWC-INSTANCE-REF":
                instance_ref = PModeGroupInAtomicSwcInstanceRef()
                self.readPModeGroupInAtomicSWCInstanceRef(child_element, instance_ref)
            elif tag_name == "R-MODE-GROUP-IN-ATOMIC-SWC-INSTANCE-REF":
                instance_ref = RModeGroupInAtomicSWCInstanceRef()
                self.readRModeGroupInAtomicSWCInstanceRef(child_element, instance_ref)
            else:
                self.notImplemented("Unsupported Mode Group IRef <%s>" % tag_name)
        return instance_ref

    def readModeAccessPointIdent(self, element: ET.Element, ident: ModeAccessPointIdent):
        self.readIdentifiable(element, ident)

    def readModeAccessPoint(self, element: ET.Element, point: ModeAccessPoint):
        self.readARObject(element, point)
        ident_element = self.find(element, "IDENT")
        if ident_element is not None:
            ident = point.createIdent(self.getShortName(ident_element))
            self.readModeAccessPointIdent(ident_element, ident)
        point.setModeGroupIRef(self.getModeGroupIRef(element, "MODE-GROUP-IREF"))
        self.readVariationPointCapable(element, point)

    def readRunnableEntityModeAccessPoints(self, element: ET.Element, entity: RunnableEntity):
        for child_element in self.findall(element, "MODE-ACCESS-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODE-ACCESS-POINT":
                point = ModeAccessPoint()
                self.readModeAccessPoint(child_element, point)
                entity.addModeAccessPoint(point)
            else:
                self.notImplemented("Unsupported Mode Access Point <%s>" % tag_name)

    def readModeSwitchPointModeGroupIRef(self, element: ET.Element, point: ModeSwitchPoint):
        child_element = self.find(element, "MODE-GROUP-IREF")
        if child_element is not None:
            instance_ref = PModeGroupInAtomicSwcInstanceRef()
            self.readPModeGroupInAtomicSWCInstanceRef(child_element, instance_ref)
            point.setModeGroupIRef(instance_ref)

    def readModeSwitchPoint(self, element: ET.Element, point: ModeSwitchPoint):
        self.readIdentifiable(element, point)
        self.readModeSwitchPointModeGroupIRef(element, point)

    def readRunnableEntityModeSwitchPoints(self, element: ET.Element, parent: RunnableEntity):
        for child_element in self.findall(element, "MODE-SWITCH-POINTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODE-SWITCH-POINT":
                point = parent.createModeSwitchPoint(self.getShortName(child_element))
                self.readModeSwitchPoint(child_element, point)
            else:
                self.notImplemented("Unsupported Mode Switch Point <%s>" % tag_name)

    def readRunnableEntityArguments(self, element: ET.Element, entity: RunnableEntity):
        for child_element in self.findall(element, "ARGUMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "RUNNABLE-ENTITY-ARGUMENT":
                entity.addArgument(self.getRunnableEntityArgument(child_element))
            else:
                self.notImplemented("Unsupported Arguments of runnable entity <%s>" % tag_name)

    def readRunnableEntityAsynchronousServerCallResultPoint(self, element: ET.Element, entity: RunnableEntity):
        for child_element in self.findall(element, "ASYNCHRONOUS-SERVER-CALL-RESULT-POINTS/ASYNCHRONOUS-SERVER-CALL-RESULT-POINT"):
            point = entity.createAsynchronousServerCallResultPoint(self.getShortName(child_element))
            self.readIdentifiable(child_element, point)
            point.setAsynchronousServerCallPointRef(self.getChildElementOptionalRefType(child_element, "ASYNCHRONOUS-SERVER-CALL-POINT-REF"))

    def readRunnableEntityWaitPoints(self, element: ET.Element, entity: RunnableEntity):
        for child_element in self.findall(element, "WAIT-POINTS/WAIT-POINT"):
            point = entity.createWaitPoint(self.getShortName(child_element))
            self.readIdentifiable(child_element, point)
            point.setTimeout(self.getChildElementOptionalTimeValue(child_element, "TIMEOUT"))
            point.setTriggerRef(self.getChildElementOptionalRefType(child_element, "TRIGGER"))

    def readRunnableEntity(self, element: ET.Element, entity: RunnableEntity):
        self.readExecutableEntity(element, entity)
        self.readRunnableEntityArguments(element, entity)

        self.readRunnableEntityAsynchronousServerCallResultPoint(element, entity)
        entity.setCanBeInvokedConcurrently(self.getChildElementOptionalBooleanValue(element, "CAN-BE-INVOKED-CONCURRENTLY"))
        self.readRunnableEntityDataReadAccesses(element, entity)
        self.readRunnableEntityDataReceivePointByArguments(element, entity)
        self.readRunnableEntityDataReceivePointByValues(element, entity)
        self.readRunnableEntityDataWriteAccesses(element, entity)
        self.readRunnableEntityDataSendPoints(element, entity)
        self.readRunnableEntityInternalBehaviorServerCallPoint(element, entity)
        self.readRunnableEntityInternalTriggeringPoints(element, entity)
        self.readRunnableEntityExternalTriggeringPoints(element, entity)
        self.readRunnableEntityModeAccessPoints(element, entity)
        self.readRunnableEntityModeSwitchPoints(element, entity)
        self.readRunnableEntityParameterAccesses(element, entity)
        self.readRunnableEntityReadLocalVariables(element, entity)
        self.readRunnableEntityWaitPoints(element, entity)
        self.readRunnableEntityWrittenLocalVariables(element, entity)

        entity.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))

    def readSwcInternalBehaviorRunnables(self, element: ET.Element, parent: SwcInternalBehavior):
        for child_element in self.findall(element, "RUNNABLES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "RUNNABLE-ENTITY":
                entity = parent.createRunnableEntity(self.getShortName(child_element))
                self.readRunnableEntity(child_element, entity)
            else:
                self.notImplemented("Unsupported Runnables <%s>" % tag_name)

    def getRModeInAtomicSwcInstanceRef(self, element: ET.Element) -> RModeInAtomicSwcInstanceRef:
        instance_ref = RModeInAtomicSwcInstanceRef()
        instance_ref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
        instance_ref.setContextPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-REF"))
        instance_ref.setContextModeDeclarationGroupPrototypeRef(self.getChildElementOptionalRefType(element, "CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF"))
        instance_ref.setTargetModeDeclarationRef(self.getChildElementOptionalRefType(element, "TARGET-MODE-DECLARATION-REF"))  # NOQA E501
        return instance_ref

    def getModeInBswModuleDescriptionInstanceRef(self, element: ET.Element) -> ModeInBswModuleDescriptionInstanceRef:
        instance_ref = ModeInBswModuleDescriptionInstanceRef()
        self.readARObject(element, instance_ref)
        instance_ref.setContextModeDeclarationGroupRef(self.getChildElementOptionalRefType(element, "CONTEXT-MODE-DECLARATION-GROUP-REF"))
        instance_ref.setTargetModeRef(self.getChildElementOptionalRefType(element, "TARGET-MODE-REF"))  # NOQA E501
        return instance_ref

    def readRTEEvent(self, element: ET.Element, event: RTEEvent):
        self.readIdentifiable(element, event)
        event.setActivationReasonRepresentationRef(self.getChildElementOptionalRefType(element, "ACTIVATION-REASON-REPRESENTATION-REF"))
        event.setStartOnEventRef(self.getChildElementOptionalRefType(element, "START-ON-EVENT-REF"))
        for child_element in self.findall(element, "DISABLED-MODE-IREFS/DISABLED-MODE-IREF"):
            iref = self.getRModeInAtomicSwcInstanceRef(child_element)
            event.addDisabledModeIRef(iref)

    def readPOperationIRef(self, element: ET.Element, key: str, parent: OperationInvokedEvent):
        child_element = self.find(element, key)
        if child_element is not None:
            operation_iref = POperationInAtomicSwcInstanceRef()
            self.readARObject(child_element, operation_iref)
            operation_iref.setContextPPortRef(self.getChildElementRefType(parent.getShortName(), child_element, "CONTEXT-P-PORT-REF"))
            operation_iref.setTargetProvidedOperationRef(self.getChildElementRefType(parent.getShortName(), child_element, "TARGET-PROVIDED-OPERATION-REF"))  # NOQA E501
            parent.setOperationIRef(operation_iref)

    def readOperationInvokedEvent(self, element: ET.Element, event: OperationInvokedEvent):
        # self.logger.debug("Read OperationInvokedEvent <%s>" % event.getShortName())
        self.readPOperationIRef(element, "OPERATION-IREF", event)
        self.readRTEEvent(element, event)

    def readVariableDataPrototype(self, element: ET.Element, prototype: VariableDataPrototype):
        self.readAutosarDataPrototype(element, prototype)
        prototype.setInitValue(self.getInitValue(element))

    def readSwcInternalBehaviorExplicitInterRunnableVariables(self, element: ET.Element, parent: SwcInternalBehavior):
        for child_element in self.findall(element, "EXPLICIT-INTER-RUNNABLE-VARIABLES/VARIABLE-DATA-PROTOTYPE"):
            short_name = self.getShortName(child_element)
            prototype = parent.createExplicitInterRunnableVariable(short_name)
            self.readVariableDataPrototype(child_element, prototype)

    def readSwcInternalBehaviorImplicitInterRunnableVariables(self, element: ET.Element, parent: SwcInternalBehavior):
        for child_element in self.findall(element, "IMPLICIT-INTER-RUNNABLE-VARIABLES/VARIABLE-DATA-PROTOTYPE"):
            short_name = self.getShortName(child_element)
            prototype = parent.createImplicitInterRunnableVariable(short_name)
            self.readVariableDataPrototype(child_element, prototype)

    def readSwcInternalBehaviorPerInstanceMemories(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "PER-INSTANCE-MEMORYS/PER-INSTANCE-MEMORY"):
            short_name = self.getShortName(child_element)
            memory = behavior.createPerInstanceMemory(short_name)
            self.readIdentifiable(child_element, memory)
            memory.setInitValue(self.getChildElementOptionalString(child_element, "INIT-VALUE"))
            memory.setSwDataDefProps(self.getSwDataDefProps(child_element, "SW-DATA-DEF-PROPS"))
            type_element = self.find(child_element, "TYPE")
            if type_element is not None:
                type_value = CIdentifier()
                self.readARType(type_element, type_value)
                type_value.setValue(type_element.text or "")
                memory.setType(type_value)
            memory.setTypeDefinition(self.getChildElementOptionalString(child_element, "TYPE-DEFINITION"))

    def readAutosarDataPrototype(self, element: ET.Element, prototype: AutosarDataPrototype):
        self.readDataPrototype(element, prototype)
        prototype.setTypeTRef(self.getChildElementOptionalRefType(element, "TYPE-TREF"))

    def readParameterDataPrototype(self, element: ET.Element, prototype: ParameterDataPrototype):
        self.readAutosarDataPrototype(element, prototype)
        prototype.setInitValue(self.getInitValue(element))

    def readSwcInternalBehaviorPerInstanceParameters(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "PER-INSTANCE-PARAMETERS/PARAMETER-DATA-PROTOTYPE"):
            short_name = self.getShortName(child_element)
            prototype = behavior.createPerInstanceParameter(short_name)
            self.readParameterDataPrototype(child_element, prototype)

    def readPortDefinedArgumentValue(self, element: ET.Element) -> PortDefinedArgumentValue:
        argument_value = PortDefinedArgumentValue()
        child_element = self.find(element, "VALUE/*")
        if child_element is not None:
            argument_value.setValue(self.getValueSpecification(child_element, self.getTagName(child_element)))
        argument_value.setValueTypeTRef(self.getChildElementOptionalRefType(element, "VALUE-TYPE-TREF"))
        return argument_value

    def readSwcInternalBehaviorPortAPIOptions(self, element: ET.Element, behavior: SwcInternalBehavior):
        for child_element in self.findall(element, "PORT-API-OPTIONS/PORT-API-OPTION"):
            option = PortAPIOption()
            option.setEnableTakeAddress(self.getChildElementOptionalBooleanValue(child_element, "ENABLE-TAKE-ADDRESS"))
            error_handling = self.getChildElementOptionalLiteral(child_element, "ERROR-HANDLING")
            if error_handling is not None:
                option.setErrorHandling(DataTransformationErrorHandlingEnum().setValue(error_handling.getValue()))
            option.setIndirectAPI(self.getChildElementOptionalBooleanValue(child_element, "INDIRECT-API"))
            option.setPortRef(self.getChildElementOptionalRefType(child_element, "PORT-REF"))
            for argument_value_tag in self.findall(child_element, "PORT-ARG-VALUES/PORT-DEFINED-ARGUMENT-VALUE"):
                option.addPortArgValue(self.readPortDefinedArgumentValue(argument_value_tag))
            for feature_tag in self.findall(child_element, "SUPPORTED-FEATURES/COMMUNICATION-BUFFER-LOCKING"):
                option.addSupportedFeature(self.readCommunicationBufferLocking(feature_tag))
            transformer_status_forwarding = self.getChildElementOptionalLiteral(child_element, "TRANSFORMER-STATUS-FORWARDING")
            if transformer_status_forwarding is not None:
                option.setTransformerStatusForwarding(DataTransformationStatusForwardingEnum().setValue(transformer_status_forwarding.getValue()))
            behavior.addPortAPIOption(option)

    def readCommunicationBufferLocking(self, element: ET.Element) -> CommunicationBufferLocking:
        feature = CommunicationBufferLocking()
        self.readARObject(element, feature)
        support_buffer_locking = self.getChildElementOptionalLiteral(element, "SUPPORT-BUFFER-LOCKING")
        if support_buffer_locking is not None:
            feature.setSupportBufferLocking(SupportBufferLockingEnum().setValue(support_buffer_locking.getValue()))
        return feature

    def readTimingEvent(self, element: ET.Element, event: TimingEvent):
        # self.logger.debug("Read TimingEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        event.setOffset(self.getChildElementOptionalTimeValue(element, "OFFSET"))
        event.setPeriod(self.getChildElementOptionalTimeValue(element, "PERIOD"))

    def readDataReceivedEvent(self, element: ET.Element, event: DataReceivedEvent):
        # self.logger.debug("Read DataReceivedEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        self.readRVariableInAtomicSwcInstanceRef(element, event)

    def readDataReceiveErrorEvent(self, element: ET.Element, event: DataReceiveErrorEvent):
        # self.logger.debug("Read DataReceiveErrorEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        self.readRVariableInAtomicSwcInstanceRef(element, event)

    def readSwcModeSwitchEvent(self, element: ET.Element, event: SwcModeSwitchEvent):
        # self.logger.debug("Read SwcModeSwitchEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        activation = self.getChildElementOptionalLiteral(element, "ACTIVATION")
        if activation is not None:
            event.setActivation(ModeActivationKind().setValue(activation.getValue()))
        self.readRModeInAtomicSwcInstanceRef(element, event)

    def readInternalTriggerOccurredEvent(self, element: ET.Element, event: InternalTriggerOccurredEvent):
        # self.logger.debug("Read InternalTriggerOccurredEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def readInitEvent(self, element, event: InitEvent):
        # self.logger.debug("Read InitEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)

    def readAsynchronousServerCallReturnsEvent(self, element, event: AsynchronousServerCallReturnsEvent):
        # self.logger.debug("Read AsynchronousServerCallReturnsEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def readModeSwitchedAckEvent(self, element, event: ModeSwitchedAckEvent):
        # self.logger.debug("Read ModeSwitchedAckEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def readBackgroundEvent(self, element, event: BackgroundEvent):
        # self.logger.debug("Read BackgroundEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)

    def readDataSendCompletedEvent(self, element, event: DataSendCompletedEvent):
        # self.logger.debug("Read DataSendCompletedEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def readDataWriteCompletedEvent(self, element, event: DataWriteCompletedEvent):
        # self.logger.debug("Read DataWriteCompletedEvent <%s>" % event.getShortName())
        self.readRTEEvent(element, event)
        event.setEventSourceRef(self.getChildElementOptionalRefType(element, "EVENT-SOURCE-REF"))

    def readSwcInternalBehaviorEvents(self, element: ET.Element, parent: SwcInternalBehavior):
        for child_element in self.findall(element, "EVENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TIMING-EVENT":
                event = parent.createTimingEvent(self.getShortName(child_element))
                self.readTimingEvent(child_element, event)
            elif tag_name == "SWC-MODE-SWITCH-EVENT":
                event = parent.createSwcModeSwitchEvent(self.getShortName(child_element))
                self.readSwcModeSwitchEvent(child_element, event)
            elif tag_name == "OPERATION-INVOKED-EVENT":
                event = parent.createOperationInvokedEvent(self.getShortName(child_element))
                self.readOperationInvokedEvent(child_element, event)
            elif tag_name == "DATA-RECEIVED-EVENT":
                event = parent.createDataReceivedEvent(self.getShortName(child_element))
                self.readDataReceivedEvent(child_element, event)
            elif tag_name == "DATA-RECEIVE-ERROR-EVENT":
                event = parent.createDataReceiveErrorEvent(self.getShortName(child_element))
                self.readDataReceiveErrorEvent(child_element, event)
            elif tag_name == "INTERNAL-TRIGGER-OCCURRED-EVENT":
                event = parent.createInternalTriggerOccurredEvent(self.getShortName(child_element))
                self.readInternalTriggerOccurredEvent(child_element, event)
            elif tag_name == "INIT-EVENT":
                event = parent.createInitEvent(self.getShortName(child_element))
                self.readInitEvent(child_element, event)
            elif tag_name == "ASYNCHRONOUS-SERVER-CALL-RETURNS-EVENT":
                event = parent.createAsynchronousServerCallReturnsEvent(self.getShortName(child_element))
                self.readAsynchronousServerCallReturnsEvent(child_element, event)
            elif tag_name == "MODE-SWITCHED-ACK-EVENT":
                event = parent.createModeSwitchedAckEvent(self.getShortName(child_element))
                self.readModeSwitchedAckEvent(child_element, event)
            elif tag_name == "BACKGROUND-EVENT":
                event = parent.createBackgroundEvent(self.getShortName(child_element))
                self.readBackgroundEvent(child_element, event)
            elif tag_name == "DATA-SEND-COMPLETED-EVENT":
                event = parent.createDataSendCompletedEvent(self.getShortName(child_element))
                self.readDataSendCompletedEvent(child_element, event)
            elif tag_name == "DATA-WRITE-COMPLETED-EVENT":
                event = parent.createDataWriteCompletedEvent(self.getShortName(child_element))
                self.readDataWriteCompletedEvent(child_element, event)
            else:
                self.notImplemented("Unsupported SwcInternalBehavior Event <%s>" % tag_name)

    def getSwPointerTargetProps(self, element: ET.Element, key: str) -> SwPointerTargetProps:
        child_element = self.find(element, key)
        props = None
        if child_element is not None:
            props = SwPointerTargetProps()
            props.setTargetCategory(self.getChildElementOptionalLiteral(child_element, "TARGET-CATEGORY"))
            props.setSwDataDefProps(self.getSwDataDefProps(child_element, "SW-DATA-DEF-PROPS"))
            props.setFunctionPointerSignatureRef(self.getChildElementOptionalRefType(child_element, "FUNCTION-POINTER-SIGNATURE-REF"))
        return props

    def readSwPointerTargetProps(self, element: ET.Element, parent: SwDataDefProps):
        child_element = self.find(element, "SW-POINTER-TARGET-PROPS")
        if child_element is not None:
            sw_pointer_target_props = SwPointerTargetProps()
            sw_pointer_target_props.setTargetCategory(self.getChildElementOptionalLiteral(child_element, "TARGET-CATEGORY"))
            sw_pointer_target_props.setSwDataDefProps(self.getSwDataDefProps(child_element, "SW-DATA-DEF-PROPS"))
            sw_pointer_target_props.setFunctionPointerSignatureRef(self.getChildElementOptionalRefType(child_element, "FUNCTION-POINTER-SIGNATURE-REF"))
            parent.swPointerTargetProps = sw_pointer_target_props

    def getSwTextProps(self, element: ET.Element, key: str) -> SwTextProps:
        child_element = self.find(element, key)
        props = None
        if child_element is not None:
            props = SwTextProps()
            props.setArraySizeSemantics(self.getChildElementOptionalLiteral(child_element, "ARRAY-SIZE-SEMANTICS"))
            props.setBaseTypeRef(self.getChildElementOptionalRefType(child_element, "BASE-TYPE-REF"))
            props.setSwFillCharacter(self.getChildElementOptionalIntegerValue(child_element, "SW-FILL-CHARACTER"))
            props.setSwMaxTextSize(self.getChildElementOptionalIntegerValue(child_element, "SW-MAX-TEXT-SIZE"))
        return props

    def readLanguageSpecific(self, element: ET.Element, specific: LanguageSpecific):
        self.readARObject(element, specific)
        specific.setValue(element.text)
        if "L" in element.attrib:
            specific.setL(element.attrib["L"])  # noqa E741

    def readWhitespaceControlled(self, element: ET.Element, specific: Union[Sd, WhitespaceControlled]):
        xml_space = element.attrib.get("{http://www.w3.org/XML/1998/namespace}space")
        if xml_space is not None:
            specific.setXmlSpace(XmlSpaceEnum().setValue(xml_space))

    def getLParagraphs(self, element: ET.Element, key: str) -> List[LParagraph]:
        results = []
        for child_element in self.findall(element, key):
            l1 = LParagraph()
            self.readARObject(child_element, l1)
            self.readMixedContentForParagraph(child_element, l1)
            l1.setValue(child_element.text or "")
            if "L" in child_element.attrib:
                l1.setL(child_element.attrib["L"])  # noqa E741
            results.append(l1)
        return results

    def getMultiLanguageParagraphs(self, element: ET.Element, key: str) -> List[MultiLanguageParagraph]:
        paragraphs = []
        for child_element in self.findall(element, key):
            paragraph = MultiLanguageParagraph()
            self.readPaginateable(child_element, paragraph)
            help_entry = child_element.get("HELP-ENTRY")
            if help_entry is not None:
                paragraph.setHelpEntry(String().setValue(help_entry))
            for l1 in self.getLParagraphs(child_element, "L-1"):
                paragraph.addL1(l1)
            paragraphs.append(paragraph)
        return paragraphs

    def getLPlainTexts(self, element: ET.Element, key: str) -> List[LPlainText]:
        results = []
        for child_element in self.findall(element, key):
            l10 = LPlainText()
            self.readLanguageSpecific(child_element, l10)
            self.readWhitespaceControlled(child_element, l10)
            results.append(l10)
        return results

    def getListElements(self, element: ET.Element, key: str) -> List[ARList]:
        """
        Read the DocumentationBlock List
        """
        result = []
        for child_element in self.findall(element, key):
            list = ARList()
            self.readPaginateable(child_element, list)
            if "TYPE" in child_element.attrib:
                list.setType(ListEnum().setValue(child_element.attrib["TYPE"].lower()))
            for item_element in self.findall(child_element, "ITEM"):
                item = Item()
                self.readPaginateable(item_element, item)
                block = DocumentationBlock()
                self.readDocumentationBlock(item_element, block)
                item.setItemContents(block)
                list.addItem(item)
            result.append(list)
        return result

    def getGraphic(self, element: ET.Element, key: str) -> Graphic:
        graphic = None
        child_element = self.find(element, key)
        if child_element is not None:
            graphic = Graphic()
            if "EDITFIT" in child_element.attrib:
                graphic.setEditfit(GraphicFitEnum().setValue(child_element.attrib["EDITFIT"]))
            if "EDIT-HEIGHT" in child_element.attrib:
                graphic.setEditHeight(String().setValue(child_element.attrib["EDIT-HEIGHT"]))
            if "EDITSCALE" in child_element.attrib:
                graphic.setEditscale(String().setValue(child_element.attrib["EDITSCALE"]))
            if "EDIT-WIDTH" in child_element.attrib:
                graphic.setEditWidth(String().setValue(child_element.attrib["EDIT-WIDTH"]))
            if "FILENAME" in child_element.attrib:
                graphic.setFilename(String().setValue(child_element.attrib["FILENAME"]))
            if "FIT" in child_element.attrib:
                graphic.setFit(GraphicFitEnum().setValue(child_element.attrib["FIT"]))
            if "GENERATOR" in child_element.attrib:
                graphic.setGenerator(NameToken().setValue(child_element.attrib["GENERATOR"]))
            if "HEIGHT" in child_element.attrib:
                graphic.setHeight(String().setValue(child_element.attrib["HEIGHT"]))
            if "HTML-FIT" in child_element.attrib:
                graphic.setHtmlFit(GraphicFitEnum().setValue(child_element.attrib["HTML-FIT"]))
            if "HTML-HEIGHT" in child_element.attrib:
                graphic.setHtmlHeight(String().setValue(child_element.attrib["HTML-HEIGHT"]))
            if "HTML-SCALE" in child_element.attrib:
                graphic.setHtmlScale(String().setValue(child_element.attrib["HTML-SCALE"]))
            if "HTML-WIDTH" in child_element.attrib:
                graphic.setHtmlWidth(String().setValue(child_element.attrib["HTML-WIDTH"]))
            if "NOTATION" in child_element.attrib:
                graphic.setNotation(GraphicNotationEnum().setValue(child_element.attrib["NOTATION"]))
            if "SCALE" in child_element.attrib:
                graphic.setScale(String().setValue(child_element.attrib["SCALE"]))
            if "WIDTH" in child_element.attrib:
                graphic.setWidth(String().setValue(child_element.attrib["WIDTH"]))
        return graphic

    def readArea(self, element: ET.Element, area: Area):
        self.readARObject(element, area)
        if "ACCESSKEY" in element.attrib:
            area.setAccesskey(String().setValue(element.attrib["ACCESSKEY"]))
        if "ALT" in element.attrib:
            area.setAlt(String().setValue(element.attrib["ALT"]))
        if "CLASS" in element.attrib:
            area.setClass(String().setValue(element.attrib["CLASS"]))
        if "COORDS" in element.attrib:
            area.setCoords(String().setValue(element.attrib["COORDS"]))
        if "HREF" in element.attrib:
            area.setHref(String().setValue(element.attrib["HREF"]))
        if "NOHREF" in element.attrib:
            area.setNohref(AreaEnumNohref().setValue(element.attrib["NOHREF"]))
        if "ONBLUR" in element.attrib:
            area.setOnblur(String().setValue(element.attrib["ONBLUR"]))
        if "ONCLICK" in element.attrib:
            area.setOnclick(String().setValue(element.attrib["ONCLICK"]))
        if "ONDBLCLICK" in element.attrib:
            area.setOndblclick(String().setValue(element.attrib["ONDBLCLICK"]))
        if "ONFOCUS" in element.attrib:
            area.setOnfocus(String().setValue(element.attrib["ONFOCUS"]))
        if "ONKEYDOWN" in element.attrib:
            area.setOnkeydown(String().setValue(element.attrib["ONKEYDOWN"]))
        if "ONKEYPRESS" in element.attrib:
            area.setOnkeypress(String().setValue(element.attrib["ONKEYPRESS"]))
        if "ONKEYUP" in element.attrib:
            area.setOnkeyup(String().setValue(element.attrib["ONKEYUP"]))
        if "ONMOUSEDOWN" in element.attrib:
            area.setOnmousedown(String().setValue(element.attrib["ONMOUSEDOWN"]))
        if "ONMOUSEMOVE" in element.attrib:
            area.setOnmousemove(String().setValue(element.attrib["ONMOUSEMOVE"]))
        if "ONMOUSEOUT" in element.attrib:
            area.setOnmouseout(String().setValue(element.attrib["ONMOUSEOUT"]))
        if "ONMOUSEOVER" in element.attrib:
            area.setOnmouseover(String().setValue(element.attrib["ONMOUSEOVER"]))
        if "ONMOUSEUP" in element.attrib:
            area.setOnmouseup(String().setValue(element.attrib["ONMOUSEUP"]))
        if "SHAPE" in element.attrib:
            area.setShape(AreaEnumShape().setValue(element.attrib["SHAPE"]))
        if "STYLE" in element.attrib:
            area.setStyle(String().setValue(element.attrib["STYLE"]))
        if "TABINDEX" in element.attrib:
            area.setTabindex(String().setValue(element.attrib["TABINDEX"]))
        if "TITLE" in element.attrib:
            area.setTitle(String().setValue(element.attrib["TITLE"]))

    def getArea(self, element: ET.Element, key: str) -> Area:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        area = Area()
        self.readArea(child_element, area)
        return area

    def readMap(self, element: ET.Element, map_obj: Map):
        self.readARObject(element, map_obj)
        for child_element in self.findall(element, "AREA"):
            area = Area()
            self.readArea(child_element, area)
            map_obj.addArea(area)
        if "CLASS" in element.attrib:
            map_obj.setClass(String().setValue(element.attrib["CLASS"]))
        if "NAME" in element.attrib:
            map_obj.setName(NameToken().setValue(element.attrib["NAME"]))
        if "ONCLICK" in element.attrib:
            map_obj.setOnclick(String().setValue(element.attrib["ONCLICK"]))
        if "ONDBLCLICK" in element.attrib:
            map_obj.setOndblclick(String().setValue(element.attrib["ONDBLCLICK"]))
        if "ONKEYDOWN" in element.attrib:
            map_obj.setOnkeydown(String().setValue(element.attrib["ONKEYDOWN"]))
        if "ONKEYPRESS" in element.attrib:
            map_obj.setOnkeypress(String().setValue(element.attrib["ONKEYPRESS"]))
        if "ONKEYUP" in element.attrib:
            map_obj.setOnkeyup(String().setValue(element.attrib["ONKEYUP"]))
        if "ONMOUSEDOWN" in element.attrib:
            map_obj.setOnmousedown(String().setValue(element.attrib["ONMOUSEDOWN"]))
        if "ONMOUSEMOVE" in element.attrib:
            map_obj.setOnmousemove(String().setValue(element.attrib["ONMOUSEMOVE"]))
        if "ONMOUSEOUT" in element.attrib:
            map_obj.setOnmouseout(String().setValue(element.attrib["ONMOUSEOUT"]))
        if "ONMOUSEOVER" in element.attrib:
            map_obj.setOnmouseover(String().setValue(element.attrib["ONMOUSEOVER"]))
        if "ONMOUSEUP" in element.attrib:
            map_obj.setOnmouseup(String().setValue(element.attrib["ONMOUSEUP"]))
        if "TITLE" in element.attrib:
            map_obj.setTitle(String().setValue(element.attrib["TITLE"]))

    def getMap(self, element: ET.Element, key: str) -> Map:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        map_obj = Map()
        self.readMap(child_element, map_obj)
        return map_obj

    def getUrl(self, element: ET.Element, key: str) -> Url:
        child_element = self.find(element, key)
        if child_element is None:
            return None

        url = Url()
        self.readARObject(child_element, url)
        if "MIME-TYPE" in child_element.attrib:
            url.setMimeType(MimeTypeString().setValue(child_element.attrib["MIME-TYPE"]))
        if child_element.text is not None:
            url.setValue(UriString().setValue(child_element.text))
        return url

    def readLGraphic(self, element: ET.Element, graphic: LGraphic):
        self.readARObject(element, graphic)
        if "L" in element.attrib:
            graphic.setL(element.attrib["L"])  # noqa E741
        graphic.setGraphic(self.getGraphic(element, "GRAPHIC"))
        graphic.setMap(self.getMap(element, "MAP"))

    def getLGraphic(self, element: ET.Element, key: str) -> LGraphic:
        graphic = None
        child_element = self.find(element, key)
        if child_element is not None:
            graphic = LGraphic()
            self.readLGraphic(child_element, graphic)
        return graphic

    def readMlFigureLGraphics(self, element: ET.Element, figure: MlFigure):
        for child_element in self.findall(element, "L-GRAPHIC"):
            graphic = LGraphic()
            self.readLGraphic(child_element, graphic)
            figure.addLGraphics(graphic)

    def readDocumentViewSelectable(self, element: ET.Element, selectable: DocumentViewSelectable):
        self.readARObject(element, selectable)
        if "SI" in element.attrib:
            selectable.setSi(NameTokens().setValue(element.attrib["SI"]))
        if "VIEW" in element.attrib:
            selectable.setView(ViewTokens().setValue(element.attrib["VIEW"]))

    def readColspec(self, element: ET.Element, colspec: Colspec):
        self.readARObject(element, colspec)
        if "ALIGN" in element.attrib:
            colspec.setAlign(AlignEnum().setValue(element.attrib["ALIGN"]))
        if "COLNAME" in element.attrib:
            colspec.setColname(String().setValue(element.attrib["COLNAME"]))
        if "COLNUM" in element.attrib:
            colspec.setColnum(String().setValue(element.attrib["COLNUM"]))
        if "COLSEP" in element.attrib:
            colspec.setColsep(TableSeparatorString().setValue(element.attrib["COLSEP"]))
        if "COLWIDTH" in element.attrib:
            colspec.setColwidth(String().setValue(element.attrib["COLWIDTH"]))
        if "ROWSEP" in element.attrib:
            colspec.setRowsep(TableSeparatorString().setValue(element.attrib["ROWSEP"]))

    def readEntry(self, element: ET.Element, entry: Entry):
        self.readARObject(element, entry)
        if "ALIGN" in element.attrib:
            entry.setAlign(AlignEnum().setValue(element.attrib["ALIGN"]))
        if "BGCOLOR" in element.attrib:
            entry.setBgcolor(String().setValue(element.attrib["BGCOLOR"]))
        if "COLNAME" in element.attrib:
            entry.setColname(String().setValue(element.attrib["COLNAME"]))
        if "COLSEP" in element.attrib:
            entry.setColsep(TableSeparatorString().setValue(element.attrib["COLSEP"]))
        entry.setEntryContents(self.getDocumentationBlock(element, "DOCUMENTATION-BLOCK"))
        if "MOREROWS" in element.attrib:
            entry.setMorerows(String().setValue(element.attrib["MOREROWS"]))
        if "NAMEEND" in element.attrib:
            entry.setNameend(String().setValue(element.attrib["NAMEEND"]))
        if "NAMEST" in element.attrib:
            entry.setNamest(String().setValue(element.attrib["NAMEST"]))
        if "ROTATE" in element.attrib:
            entry.setRotate(String().setValue(element.attrib["ROTATE"]))
        if "ROWSEP" in element.attrib:
            entry.setRowsep(TableSeparatorString().setValue(element.attrib["ROWSEP"]))
        if "SPANNAME" in element.attrib:
            entry.setSpanname(String().setValue(element.attrib["SPANNAME"]))
        if "VALIGN" in element.attrib:
            entry.setValign(ValignEnum().setValue(element.attrib["VALIGN"]))

    def readRow(self, element: ET.Element, row: Row):
        self.readPaginateable(element, row)
        for child_element in self.findall(element, "ENTRY"):
            entry = Entry()
            self.readEntry(child_element, entry)
            row.addEntry(entry)
        if "ROWSEP" in element.attrib:
            row.setRowsep(TableSeparatorString().setValue(element.attrib["ROWSEP"]))
        if "VALIGN" in element.attrib:
            row.setValign(ValignEnum().setValue(element.attrib["VALIGN"]))

    def readTbody(self, element: ET.Element, tbody: Tbody):
        self.readARObject(element, tbody)
        for child_element in self.findall(element, "ROW"):
            row = Row()
            self.readRow(child_element, row)
            tbody.addRow(row)
        if "VALIGN" in element.attrib:
            tbody.setValign(ValignEnum().setValue(element.attrib["VALIGN"]))

    def readTgroup(self, element: ET.Element, tgroup: Tgroup):
        self.readARObject(element, tgroup)
        for child_element in self.findall(element, "COLSPEC"):
            colspec = Colspec()
            self.readColspec(child_element, colspec)
            tgroup.addColspec(colspec)
        thead_element = self.find(element, "THEAD")
        if thead_element is not None:
            thead = Tbody()
            self.readTbody(thead_element, thead)
            tgroup.setThead(thead)
        tfoot_element = self.find(element, "TFOOT")
        if tfoot_element is not None:
            tfoot = Tbody()
            self.readTbody(tfoot_element, tfoot)
            tgroup.setTfoot(tfoot)
        tbody_element = self.find(element, "TBODY")
        if tbody_element is not None:
            tbody = Tbody()
            self.readTbody(tbody_element, tbody)
            tgroup.setTbody(tbody)
        if "ALIGN" in element.attrib:
            tgroup.setAlign(AlignEnum().setValue(element.attrib["ALIGN"]))
        if "COLS" in element.attrib:
            tgroup.setCols(Integer().setValue(element.attrib["COLS"]))
        if "COLSEP" in element.attrib:
            tgroup.setColsep(TableSeparatorString().setValue(element.attrib["COLSEP"]))
        if "ROWSEP" in element.attrib:
            tgroup.setRowsep(TableSeparatorString().setValue(element.attrib["ROWSEP"]))

    def readTable(self, element: ET.Element, table: Table):
        self.readPaginateable(element, table)
        table.setTableCaption(self.getCaption(element, "TABLE-CAPTION"))
        for child_element in self.findall(element, "TGROUP"):
            tgroup = Tgroup()
            self.readTgroup(child_element, tgroup)
            table.addTgroup(tgroup)
        if "COLSEP" in element.attrib:
            table.setColsep(TableSeparatorString().setValue(element.attrib["COLSEP"]))
        if "FLOAT" in element.attrib:
            table.setFloat(FloatEnum().setValue(element.attrib["FLOAT"]))
        if "FRAME" in element.attrib:
            table.setFrame(FrameEnum().setValue(element.attrib["FRAME"]))
        if "HELP-ENTRY" in element.attrib:
            table.setHelpEntry(String().setValue(element.attrib["HELP-ENTRY"]))
        if "ORIENT" in element.attrib:
            table.setOrient(OrientEnum().setValue(element.attrib["ORIENT"]))
        if "PGWIDE" in element.attrib:
            table.setPgwide(NameToken().setValue(element.attrib["PGWIDE"]))
        if "ROWSEP" in element.attrib:
            table.setRowsep(TableSeparatorString().setValue(element.attrib["ROWSEP"]))
        if "TABSTYLE" in element.attrib:
            table.setTabstyle(NameToken().setValue(element.attrib["TABSTYLE"]))

    def readPaginateable(self, element: ET.Element, paginateable: Paginateable):
        self.readDocumentViewSelectable(element, paginateable)
        if "BREAK" in element.attrib:
            paginateable.setBreak(ChapterEnumBreak().setValue(element.attrib["BREAK"]))
        if "KEEP-WITH-PREVIOUS" in element.attrib:
            paginateable.setKeepWithPrevious(KeepWithPreviousEnum().setValue(element.attrib["KEEP-WITH-PREVIOUS"]))

    def readMlFigure(self, element: ET.Element, figure: MlFigure):
        self.readPaginateable(element, figure)
        if "FRAME" in element.attrib:
            figure.setFrame(FrameEnum().setValue(element.attrib["FRAME"]))
        if "HELP-ENTRY" in element.attrib:
            figure.setHelpEntry(String().setValue(element.attrib["HELP-ENTRY"]))
        if "PGWIDE" in element.attrib:
            figure.setPgwide(PgwideEnum().setValue(element.attrib["PGWIDE"]))
        figure.setFigureCaption(self.getCaption(element, "FIGURE-CAPTION"))
        self.readMlFigureLGraphics(element, figure)
        figure.setVerbatim(self.getMultiLanguageVerbatim(element, "VERBATIM"))

    def getMlFigures(self, element: ET.Element, key: str) -> List[MlFigure]:
        result = []
        for child_element in self.findall(element, key):
            figure = MlFigure()
            self.readMlFigure(child_element, figure)
            result.append(figure)
        return result

    def getMultiLanguagePlainText(self, element: ET.Element, key: str) -> MultiLanguagePlainText:
        paragraph = None
        child_element = self.find(element, key)
        if child_element is not None:
            paragraph = MultiLanguagePlainText()
            self.readARObject(child_element, paragraph)
            for l10 in self.getLPlainTexts(child_element, "L-10"):
                paragraph.addL10(l10)
        return paragraph

    def getNote(self, element: ET.Element, key: str) -> Note:
        note = None
        child_element = self.find(element, key)
        if child_element is not None:
            note = Note()
            self.readARObject(child_element, note)
            note.setLabel(self.getMultilanguageLongName(child_element, "LABEL"))
            note.setNoteText(self.getDocumentationBlock(child_element, "NOTE-TEXT"))
            if "NOTETYPE" in child_element.attrib:
                note.setNoteType(NoteTypeEnum().setValue(child_element.attrib["NOTETYPE"]))
        return note

    def readTraceable(self, element: ET.Element, traceable: Traceable):
        for trace_ref in self.findall(element, "TRACE-REFS/TRACE-REF"):
            ref = RefType().setValue(trace_ref.text)
            if "BASE" in trace_ref.attrib:
                ref.setBase(trace_ref.attrib["BASE"])
            if "DEST" in trace_ref.attrib:
                ref.setDest(trace_ref.attrib["DEST"])
            traceable.addTraceRef(ref)

    def getTraceableText(self, element: ET.Element, key: str, block: "DocumentationBlock" = None) -> TraceableText:
        traceable_text = None
        child_element = self.find(element, key)
        if child_element is not None:
            short_name_element = self.find(child_element, "SHORT-NAME")
            short_name = short_name_element.text if short_name_element is not None else key
            traceable_text = TraceableText(block, short_name)
            self.readARObject(child_element, traceable_text)
            traceable_text.setText(self.getDocumentationBlock(child_element, "TEXT"))
            self.readTraceable(child_element, traceable_text)
        return traceable_text

    def readTraceableTable(self, element: ET.Element, traceable_table: TraceableTable):
        self.readIdentifiable(element, traceable_table)
        # SI/VIEW (DOCUMENT-VIEW-SELECTABLE) and BREAK/KEEP-WITH-PREVIOUS (PAGINATEABLE) are read
        # as plain attributes: readDocumentViewSelectable/readPaginateable would re-invoke
        # readARObject on top of readIdentifiable (duplicate UUIDMgr registration, Rule 0013.1).
        if "SI" in element.attrib:
            traceable_table.setSi(NameTokens().setValue(element.attrib["SI"]))
        if "VIEW" in element.attrib:
            traceable_table.setView(ViewTokens().setValue(element.attrib["VIEW"]))
        self.readTraceable(element, traceable_table)
        if "BREAK" in element.attrib:
            traceable_table.setBreak(ChapterEnumBreak().setValue(element.attrib["BREAK"]))
        if "KEEP-WITH-PREVIOUS" in element.attrib:
            traceable_table.setKeepWithPrevious(KeepWithPreviousEnum().setValue(element.attrib["KEEP-WITH-PREVIOUS"]))
        table_element = self.find(element, "TABLE")
        if table_element is not None:
            table = Table()
            self.readTable(table_element, table)
            traceable_table.setTable(table)

    def getTraceableTable(self, element: ET.Element, key: str, parent: ARObject = None) -> TraceableTable:
        traceable_table = None
        child_element = self.find(element, key)
        if child_element is not None:
            short_name_element = self.find(child_element, "SHORT-NAME")
            short_name = short_name_element.text if short_name_element is not None else key
            traceable_table = TraceableTable(parent, short_name)
            self.readTraceableTable(child_element, traceable_table)
        return traceable_table

    def getStructuredReq(self, element: ET.Element, key: str, block: "DocumentationBlock" = None) -> StructuredReq:
        structured_req = None
        child_element = self.find(element, key)
        if child_element is not None:
            short_name_element = self.find(child_element, "SHORT-NAME")
            short_name = short_name_element.text if short_name_element is not None else key
            structured_req = StructuredReq(block, short_name)
            self.readIdentifiable(child_element, structured_req)
            self.readTraceable(child_element, structured_req)
            date = self.getChildElementOptionalLiteral(child_element, "DATE")
            if date is not None:
                structured_req.setDate(DateTime().setValue(date.getValue()))
            structured_req.setImportance(self.getChildElementOptionalLiteral(child_element, "IMPORTANCE"))
            structured_req.setIssuedBy(self.getChildElementOptionalLiteral(child_element, "ISSUED-BY"))
            structured_req.setType(self.getChildElementOptionalLiteral(child_element, "TYPE"))
            structured_req.setDescription(self.getDocumentationBlock(child_element, "DESCRIPTION"))
            structured_req.setRationale(self.getDocumentationBlock(child_element, "RATIONALE"))
            for applies_to in self.findall(child_element, "APPLIES-TO-DEPENDENCIES/APPLIES-TO"):
                from armodel.models.M2.AUTOSARTemplates.GenericStructure.DocumentationOnM1 import StandardNameEnum

                structured_req.addAppliesTo(StandardNameEnum().setValue(applies_to.text))
            structured_req.setDependencies(self.getDocumentationBlock(child_element, "DEPENDENCIES"))
            structured_req.setUseCase(self.getDocumentationBlock(child_element, "USE-CASE"))
            structured_req.setConflicts(self.getDocumentationBlock(child_element, "CONFLICTS"))
            structured_req.setSupportingMaterial(self.getDocumentationBlock(child_element, "SUPPORTING-MATERIAL"))
            structured_req.setRemark(self.getDocumentationBlock(child_element, "REMARK"))
            for tested_item_ref in self.findall(child_element, "TESTED-ITEM-REFS/TESTED-ITEM-REF"):
                ref = RefType().setValue(tested_item_ref.text)
                if "DEST" in tested_item_ref.attrib:
                    ref.setDest(tested_item_ref.attrib["DEST"])
                structured_req.addTestedItemRef(ref)
        return structured_req

    def getDefItem(self, element: ET.Element) -> DefItem:
        def_item = DefItem()
        self.readARObject(element, def_item)
        def_item.setDef(self.getDocumentationBlock(element, "DEF"))
        if "HELPENTRY" in element.attrib:
            def_item.setHelpEntry(String().setValue(element.attrib["HELPENTRY"]))
        return def_item

    def getDefList(self, element: ET.Element, key: str) -> DefList:
        def_list = None
        child_element = self.find(element, key)
        if child_element is not None:
            def_list = DefList()
            self.readARObject(child_element, def_list)
            for def_item in self.findall(child_element, "DEF-ITEM"):
                def_list.addDefItem(self.getDefItem(def_item))
        return def_list

    def getIndentSample(self, element: ET.Element) -> IndentSample:
        indent_sample = IndentSample()
        self.readARObject(element, indent_sample)
        if "ITEMLABELPOS" in element.attrib:
            indent_sample.setItemLabelPos(ItemLabelPosEnum().setValue(element.attrib["ITEMLABELPOS"]))
        for l2 in self.getLOverviewParagraphs(element, "L-2"):
            indent_sample.addL2(l2)
        return indent_sample

    def getLabeledItem(self, element: ET.Element) -> LabeledItem:
        labeled_item = LabeledItem()
        self.readARObject(element, labeled_item)
        if "HELPENTRY" in element.attrib:
            labeled_item.setHelpEntry(String().setValue(element.attrib["HELPENTRY"]))
        labeled_item.setItemContents(self.getDocumentationBlock(element, "ITEM-CONTENTS"))
        labeled_item.setItemLabel(self.getMultiLanguageOverviewParagraph(element, "ITEM-LABEL"))
        return labeled_item

    def getLabeledList(self, element: ET.Element, key: str) -> LabeledList:
        labeled_list = None
        child_element = self.find(element, key)
        if child_element is not None:
            labeled_list = LabeledList()
            self.readARObject(child_element, labeled_list)
            indent_sample = self.find(child_element, "INDENT-SAMPLE")
            if indent_sample is not None:
                labeled_list.setIndentSample(self.getIndentSample(indent_sample))
            for labeled_item in self.findall(child_element, "LABELED-ITEM"):
                labeled_list.addLabeledItem(self.getLabeledItem(labeled_item))
        return labeled_list

    def getLOverviewParagraphs(self, element: ET.Element, key: str) -> List[LOverviewParagraph]:
        results = []
        for child_element in self.findall(element, key):
            l2 = LOverviewParagraph()
            self.readLanguageSpecific(child_element, l2)
            if "BLUEPRINT-VALUE" in child_element.attrib:
                l2.setBlueprintValue(String().setValue(child_element.attrib["BLUEPRINT-VALUE"]))
            self.readMixedContentForOverviewParagraph(child_element, l2)
            results.append(l2)
        return results

    def getMultiLanguageVerbatim(self, element: ET.Element, key: str) -> MultiLanguageVerbatim:
        verbatim = None
        child_element = self.find(element, key)
        if child_element is not None:
            verbatim = MultiLanguageVerbatim()
            self.readARObject(child_element, verbatim)
            if "ALLOWBREAK" in child_element.attrib:
                verbatim.setAllowBreak(NameToken().setValue(child_element.attrib["ALLOWBREAK"]))
            if "FLOAT" in child_element.attrib:
                verbatim.setFloat(FloatEnum().setValue(child_element.attrib["FLOAT"]))
            if "HELPENTRY" in child_element.attrib:
                verbatim.setHelpEntry(String().setValue(child_element.attrib["HELPENTRY"]))
            if "PGWIDE" in child_element.attrib:
                verbatim.setPgwide(PgwideEnum().setValue(child_element.attrib["PGWIDE"]))
            for l5 in self.findall(child_element, "L-5"):
                verbatim_l5 = LVerbatim()
                self.readLanguageSpecific(l5, verbatim_l5)
                self.readWhitespaceControlled(l5, verbatim_l5)
                self.readMixedContentForVerbatim(l5, verbatim_l5)
                verbatim.addL5(verbatim_l5)
        return verbatim

    def getMsrQueryArg(self, element: ET.Element) -> MsrQueryArg:
        msr_query_arg = MsrQueryArg()
        self.readARObject(element, msr_query_arg)
        msr_query_arg.setArg(self.getChildElementOptionalLiteral(element, "ARG"))
        if "SI" in element.attrib:
            msr_query_arg.setSi(NameToken().setValue(element.attrib["SI"]))
        return msr_query_arg

    def getMsrQueryProps(self, element: ET.Element) -> MsrQueryProps:
        msr_query_props = MsrQueryProps()
        self.readARObject(element, msr_query_props)
        msr_query_props.setComment(self.getChildElementOptionalLiteral(element, "COMMENT"))
        msr_query_props.setMsrQueryName(self.getChildElementOptionalLiteral(element, "MSR-QUERY-NAME"))
        for msr_query_arg in self.findall(element, "MSR-QUERY-ARG"):
            msr_query_props.addMsrQueryArg(self.getMsrQueryArg(msr_query_arg))
        return msr_query_props

    def getMsrQueryP2(self, element: ET.Element, key: str) -> MsrQueryP2:
        msr_query_p2 = None
        child_element = self.find(element, key)
        if child_element is not None:
            msr_query_p2 = MsrQueryP2()
            self.readARObject(child_element, msr_query_p2)
            msr_query_props = self.find(child_element, "MSR-QUERY-PROPS")
            if msr_query_props is not None:
                msr_query_p2.setMsrQueryProps(self.getMsrQueryProps(msr_query_props))
            msr_query_p2.setMsrQueryResultP2(self.getDocumentationBlock(child_element, "MSR-QUERY-RESULT-P2"))
        return msr_query_p2

    def getMlFormula(self, element: ET.Element, key: str) -> MlFormula:
        formula = None
        child_element = self.find(element, key)
        if child_element is not None:
            formula = MlFormula()
            self.readPaginateable(child_element, formula)
            formula.setFormulaCaption(self.getCaption(child_element, "FORMULA-CAPTION"))
            for l_graphic in self.findall(child_element, "L-GRAPHIC"):
                graphic = LGraphic()
                self.readLGraphic(l_graphic, graphic)
                formula.addLGraphic(graphic)
            formula.setVerbatim(self.getMultiLanguageVerbatim(child_element, "VERBATIM"))
            formula.setTexMath(self.getMultiLanguagePlainText(child_element, "TEX-MATH"))
            formula.setGenericMath(self.getMultiLanguagePlainText(child_element, "GENERIC-MATH"))
        return formula

    def readDocumentationBlock(self, element: ET.Element, block: DocumentationBlock):
        self.readARObject(element, block)
        for paragraph in self.getMultiLanguageParagraphs(element, "P"):
            block.addP(paragraph)
        for list in self.getListElements(element, "LIST"):
            block.addList(list)
        for figure in self.getMlFigures(element, "FIGURE"):
            block.addFigure(figure)
        block.setDefList(self.getDefList(element, "DEF-LIST"))
        block.setFormula(self.getMlFormula(element, "FORMULA"))
        block.setLabeledList(self.getLabeledList(element, "LABELED-LIST"))
        block.setMsrQueryP2(self.getMsrQueryP2(element, "MSR-QUERY-P2"))
        block.setNote(self.getNote(element, "NOTE"))
        block.setStructuredReq(self.getStructuredReq(element, "STRUCTURED-REQ", block))
        block.setTrace(self.getTraceableText(element, "TRACE", block))
        block.setVerbatim(self.getMultiLanguageVerbatim(element, "VERBATIM"))

    def getDocumentationBlock(self, element: ET.Element, key: str) -> DocumentationBlock:
        block = None
        child_element = self.find(element, key)
        if child_element is not None:
            block = DocumentationBlock()
            self.readDocumentationBlock(child_element, block)
        return block

    def getDocumentationBlockList(self, element: ET.Element, key: str) -> List[DocumentationBlock]:
        blocks = []
        for child_element in self.findall(element, key):
            block = DocumentationBlock()
            self.readDocumentationBlock(child_element, block)
            blocks.append(block)
        return blocks

    def readGeneralAnnotation(self, element: ET.Element, annotation: GeneralAnnotation):
        annotation.setAnnotationOrigin(self.getChildElementOptionalString(element, "ANNOTATION-ORIGIN"))
        annotation.setAnnotationText(self.getDocumentationBlock(element, "ANNOTATION-TEXT"))
        annotation.setLabel(self.getMultilanguageLongName(element, "LABEL"))

    def getAnnotations(self, element: ET.Element) -> List[Annotation]:
        annotations = []
        for child_element in self.findall(element, "ANNOTATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ANNOTATION":
                annotation = Annotation()
                self.readGeneralAnnotation(child_element, annotation)
                annotations.append(annotation)
            else:
                self.notImplemented("Unsupported Annotation <%s>" % tag_name)
        return annotations

    def getSwAxisIndividual(self, element: ET.Element) -> SwAxisIndividual:
        props = SwAxisIndividual()
        self.readARObject(element, props)
        for proxy_element in self.findall(element, "SW-VARIABLE-REFS/SW-VARIABLE-REF-PROXY"):
            props.addSwVariableRef(self.readSwVariableRefProxy(proxy_element))
        props.setMaxGradient(self.getChildElementOptionalFloatValue(element, "MAX-GRADIENT"))
        props.setMonotony(self.getChildElementOptionalLiteral(element, "MONOTONY"))
        props.setInputVariableTypeRef(self.getChildElementOptionalRefType(element, "INPUT-VARIABLE-TYPE-REF"))
        props.setCompuMethodRef(self.getChildElementOptionalRefType(element, "COMPU-METHOD-REF"))
        props.setUnitRef(self.getChildElementOptionalRefType(element, "UNIT-REF"))
        props.setSwMaxAxisPoints(self.getChildElementOptionalNumericalValue(element, "SW-MAX-AXIS-POINTS"))
        props.setSwMinAxisPoints(self.getChildElementOptionalNumericalValue(element, "SW-MIN-AXIS-POINTS"))
        props.setDataConstrRef(self.getChildElementOptionalRefType(element, "DATA-CONSTR-REF"))
        child_element = self.find(element, "SW-AXIS-GENERIC")
        if child_element is not None:
            props.setSwAxisGeneric(self.getSwAxisGeneric(child_element))
        return props

    def getSwAxisGeneric(self, element: ET.Element) -> SwAxisGeneric:
        axis = SwAxisGeneric()
        self.readARObject(element, axis)
        axis.setSwAxisTypeRef(self.getChildElementOptionalRefType(element, "SW-AXIS-TYPE-REF"))
        params_wrapper = self.find(element, "SW-GENERIC-AXIS-PARAMS")
        if params_wrapper is not None:
            for param_element in self.findall(params_wrapper, "SW-GENERIC-AXIS-PARAM"):
                axis.addSwGenericAxisParam(self.getSwGenericAxisParam(param_element))
        return axis

    def getSwGenericAxisParam(self, element: ET.Element) -> SwGenericAxisParam:
        param = SwGenericAxisParam()
        self.readARObject(element, param)
        param.setSwGenericAxisParamTypeRef(self.getChildElementOptionalRefType(element, "SW-GENERIC-AXIS-PARAM-TYPE-REF"))
        for vf in self.getChildElementNumericalValueList(element, "VF"):
            param.addVf(vf)
        return param

    def getSwGenericAxisParamType(self, element: ET.Element, parent: ET.Element, short_name: str) -> SwGenericAxisParamType:
        param_type = SwGenericAxisParamType(parent, short_name)
        self.readIdentifiable(element, param_type)
        param_type.setDataConstrRef(self.getChildElementOptionalRefType(element, "DATA-CONSTR-REF"))
        return param_type

    def getSwAxisGrouped(self, element: ET.Element) -> SwAxisGrouped:
        props = SwAxisGrouped()
        props.setMaxGradient(self.getChildElementOptionalFloatValue(element, "MAX-GRADIENT"))
        props.setMonotony(self.getChildElementOptionalLiteral(element, "MONOTONY"))
        props.setSharedAxisTypeRef(self.getChildElementOptionalRefType(element, "SHARED-AXIS-TYPE-REF"))
        props.setSwAxisIndex(self.getChildElementOptionalLiteral(element, "SW-AXIS-INDEX"))
        child_element = self.find(element, "SW-CALPRM-REF-PROXY")
        if child_element is not None:
            props.setSwCalprmRef(self.readSwCalprmRefProxy(child_element))
        return props

    def getSwCalprmAxis(self, element: ET.Element) -> SwCalprmAxis:
        axis = SwCalprmAxis()
        axis.setSwAxisIndex(self.getChildElementOptionalLiteral(element, "SW-AXIS-INDEX"))
        axis.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        child_element = self.find(element, "SW-AXIS-INDIVIDUAL")
        if child_element is not None:
            axis.setSwCalprmAxisTypeProps(self.getSwAxisIndividual(child_element))
        child_element = self.find(element, "SW-AXIS-GROUPED")
        if child_element is not None:
            axis.setSwCalprmAxisTypeProps(self.getSwAxisGrouped(child_element))
        axis.setSwCalibrationAccess(self.getChildElementOptionalLiteral(element, "SW-CALIBRATION-ACCESS"))
        axis.setDisplayFormat(self.getChildElementOptionalLiteral(element, "DISPLAY-FORMAT"))

        return axis

    def getSwCalprmAxisSet(self, element: ET.Element, key: str) -> SwCalprmAxisSet:
        set = SwCalprmAxisSet()
        for child_element in self.findall(element, "%s/*" % key):
            tag_name = self.getTagName(child_element)
            if tag_name == "SW-CALPRM-AXIS":
                set.addSwCalprmAxis(self.getSwCalprmAxis(child_element))
        return set

    def readSwDataDefProsInvalidValue(self, element: ET.Element, props: SwDataDefProps):
        child_element = self.find(element, "INVALID-VALUE/*")
        if child_element is not None:
            props.setInvalidValue(self.getValueSpecification(child_element, self.getTagName(child_element)))

    def getSwDataDefProps(self, element: ET.Element, key: str) -> SwDataDefProps:
        child_element = self.find(element, key)
        sw_data_def_props = None
        if child_element is not None:
            conditional_tag = self.find(child_element, "SW-DATA-DEF-PROPS-VARIANTS/SW-DATA-DEF-PROPS-CONDITIONAL")
            if conditional_tag is None:
                sw_data_def_props = SwDataDefProps()
                self.readARObject(child_element, sw_data_def_props)
                return sw_data_def_props
            if conditional_tag is not None:
                sw_data_def_props = SwDataDefProps()
                self.readARObject(child_element, sw_data_def_props)

                for annotation in self.getAnnotations(conditional_tag):
                    sw_data_def_props.addAnnotation(annotation)

                sw_data_def_props.setDisplayPresentation(self.getChildElementOptionalLiteral(conditional_tag, "DISPLAY-PRESENTATION"))
                sw_data_def_props.setBaseTypeRef(self.getChildElementOptionalRefType(conditional_tag, "BASE-TYPE-REF"))
                sw_data_def_props.setDataConstrRef(self.getChildElementOptionalRefType(conditional_tag, "DATA-CONSTR-REF"))
                sw_data_def_props.setCompuMethodRef(self.getChildElementOptionalRefType(conditional_tag, "COMPU-METHOD-REF"))
                sw_data_def_props.setSwAddrMethodRef(self.getChildElementOptionalRefType(conditional_tag, "SW-ADDR-METHOD-REF"))
                sw_data_def_props.setSwAlignment(self.getChildElementOptionalLiteral(conditional_tag, "SW-ALIGNMENT"))
                sw_data_def_props.setSwImplPolicy(self.getChildElementOptionalLiteral(conditional_tag, "SW-IMPL-POLICY"))
                sw_data_def_props.setSwIntendedResolution(self.getChildElementOptionalNumericalValue(conditional_tag, "SW-INTENDED-RESOLUTION"))
                sw_data_def_props.setImplementationDataTypeRef(self.getChildElementOptionalRefType(conditional_tag, "IMPLEMENTATION-DATA-TYPE-REF"))
                sw_data_def_props.setStepSize(self.getChildElementOptionalFloatValue(conditional_tag, "STEP-SIZE"))
                sw_data_def_props.setSwCalibrationAccess(self.getChildElementOptionalLiteral(conditional_tag, "SW-CALIBRATION-ACCESS"))
                sw_data_def_props.setSwCalprmAxisSet(self.getSwCalprmAxisSet(conditional_tag, "SW-CALPRM-AXIS-SET"))
                sw_data_def_props.setSwPointerTargetProps(self.getSwPointerTargetProps(conditional_tag, "SW-POINTER-TARGET-PROPS"))
                sw_data_def_props.setSwTextProps(self.getSwTextProps(conditional_tag, "SW-TEXT-PROPS"))
                sw_data_def_props.setSwRecordLayoutRef(self.getChildElementOptionalRefType(conditional_tag, "SW-RECORD-LAYOUT-REF"))
                sw_data_def_props.setValueAxisDataTypeRef(self.getChildElementOptionalRefType(conditional_tag, "VALUE-AXIS-DATA-TYPE-REF"))
                sw_data_def_props.setUnitRef(self.getChildElementOptionalRefType(conditional_tag, "UNIT-REF"))
                sw_data_def_props.setDisplayFormat(self.getChildElementOptionalLiteral(conditional_tag, "DISPLAY-FORMAT"))
                sw_data_def_props.setAdditionalNativeTypeQualifier(self.getChildElementOptionalLiteral(conditional_tag, "ADDITIONAL-NATIVE-TYPE-QUALIFIER"))
                sw_data_def_props.setSwInterpolationMethod(self.getChildElementOptionalLiteral(conditional_tag, "SW-INTERPOLATION-METHOD"))
                sw_data_def_props.setSwIsVirtual(self.getChildElementOptionalBooleanValue(conditional_tag, "SW-IS-VIRTUAL"))
                self.readSwDataDefProsInvalidValue(conditional_tag, sw_data_def_props)
                self.readSwDataDefPropsBits(conditional_tag, sw_data_def_props)
                self.readSwComparisonVariables(conditional_tag, sw_data_def_props)
                self.readSwDataDependency(conditional_tag, sw_data_def_props)
                self.readSwHostVariable(conditional_tag, sw_data_def_props)
                self.readSwRefTiming(conditional_tag, sw_data_def_props)
                # self.readSwPointerTargetProps(conditional_tag, sw_data_def_props)
        return sw_data_def_props

    def readSwDataDefPropsBits(self, element: ET.Element, props: SwDataDefProps):
        bit_representation_element = self.find(element, "SW-BIT-REPRESENTATION")
        if bit_representation_element is not None:
            bit_representation = SwBitRepresentation()
            bit_representation.setBitPosition(self.getChildElementOptionalIntegerValue(bit_representation_element, "BIT-POSITION"))
            bit_representation.setNumberOfBits(self.getChildElementOptionalIntegerValue(bit_representation_element, "NUMBER-OF-BITS"))
            props.setSwBitRepresentation(bit_representation)
        value_block_size = self.getChildElementOptionalNumericalValue(element, "SW-VALUE-BLOCK-SIZE")
        props.setSwValueBlockSize(value_block_size)
        for mult_element in self.findall(element, "SW-VALUE-BLOCK-SIZE-MULTS/NUMERICAL-VALUE-VARIATION-POINT"):
            value = self.getChildElementOptionalNumericalValue(mult_element, "VALUE")
            if value is None:
                value = self.getChildElementOptionalNumericalValue(mult_element, "V")
            props.addSwValueBlockSizeMult(value)

    def readSwComparisonVariables(self, element: ET.Element, props: SwDataDefProps):
        for proxy_element in self.findall(element, "SW-COMPARISON-VARIABLES/SW-VARIABLE-REF-PROXY"):
            props.addSwComparisonVariable(self.readSwVariableRefProxy(proxy_element))

    def readSwHostVariable(self, element: ET.Element, props: SwDataDefProps):
        host_variable_element = self.find(element, "SW-HOST-VARIABLE")
        if host_variable_element is not None:
            props.setSwHostVariable(self.readSwVariableRefProxy(host_variable_element))

    def readSwVariableRefProxy(self, element: ET.Element) -> SwVariableRefProxy:
        proxy = SwVariableRefProxy()
        proxy.setAutosarVariable(self.getAutosarVariableRef(element, "AUTOSAR-VARIABLE"))
        proxy.setMcDataInstanceVarRef(self.getChildElementOptionalRefType(element, "MC-DATA-INSTANCE-VAR-REF"))
        return proxy

    def readSwDataDependency(self, element: ET.Element, props: SwDataDefProps):
        dependency_element = self.find(element, "SW-DATA-DEPENDENCY")
        if dependency_element is not None:
            dependency = SwDataDependency()
            self.readARObject(dependency_element, dependency)
            formula_element = self.find(dependency_element, "SW-DATA-DEPENDENCY-FORMULA")
            if formula_element is not None:
                formula = CompuGenericMath()
                self.readARObject(formula_element, formula)
                if formula_element.text is not None and formula_element.text.strip() != "":
                    self.readMixedStringText(formula_element, formula)
                level = formula_element.attrib.get("LEVEL")
                if level is not None:
                    formula.setLevel(PrimitiveIdentifier().setValue(level))
                dependency.setSwDataDependencyFormula(formula)
            args_element = self.find(dependency_element, "SW-DATA-DEPENDENCY-ARGS")
            if args_element is not None:
                args = SwDataDependencyArgs()
                self.readARObject(args_element, args)
                calprm_element = self.find(args_element, "SW-CALPRM-REF-PROXY")
                if calprm_element is not None:
                    args.setSwCalprmRef(self.readSwCalprmRefProxy(calprm_element))
                variable_element = self.find(args_element, "SW-VARIABLE-REF-PROXY")
                if variable_element is not None:
                    args.setSwVariable(self.readSwVariableRefProxy(variable_element))
                dependency.setSwDataDependencyArgs(args)
            props.setSwDataDependency(dependency)

    def readSwCalprmRefProxy(self, element: ET.Element) -> SwCalprmRefProxy:
        proxy = SwCalprmRefProxy()
        proxy.setArParameter(self.getAutosarParameterRef(element, "AR-PARAMETER"))
        proxy.setMcDataInstanceRef(self.getChildElementOptionalRefType(element, "MC-DATA-INSTANCE-REF"))
        return proxy

    def readSwRefTiming(self, element: ET.Element, props: SwDataDefProps):
        refresh_timing_element = self.find(element, "SW-REFRESH-TIMING")
        if refresh_timing_element is not None:
            refresh_timing = MultidimensionalTime()
            self.readMultidimensionalTime(refresh_timing_element, refresh_timing)
            props.setSwRefreshTiming(refresh_timing)

    def readAutosarDataType(self, element: ET.Element, data_type: AutosarDataType):
        self.readIdentifiable(element, data_type)
        data_type.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))

    def readApplicationDeferredDataType(self, element: ET.Element, data_type: ApplicationDeferredDataType):
        self.logger.debug("Read ApplicationDeferredDataType <%s>" % data_type.getShortName())
        self.readAutosarDataType(element, data_type)

    def readApplicationPrimitiveDataType(self, element: ET.Element, data_type: ApplicationPrimitiveDataType):
        self.logger.debug("Read ApplicationPrimitiveDataType <%s>" % data_type.getShortName())
        self.readAutosarDataType(element, data_type)

    def readApplicationRecordElement(self, element: ET.Element, record_element: ApplicationRecordElement):
        # self.logger.debug("Read ApplicationRecordElement %s" % record_element.getShortName())
        self.readApplicationCompositeElementDataPrototype(element, record_element)
        record_element.setIsOptional(self.getChildElementOptionalBooleanValue(element, "IS-OPTIONAL"))

    def readApplicationRecordDataTypeElements(self, element: ET.Element, parent: ApplicationRecordDataType):
        for child_element in self.findall(element, "ELEMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "APPLICATION-RECORD-ELEMENT":
                record_element = parent.createApplicationRecordElement(self.getShortName(child_element))
                self.readApplicationRecordElement(child_element, record_element)
            else:
                self.notImplemented("Unsupported ApplicationRecordDataType Element <%s>" % tag_name)

    def readApplicationRecordDataType(self, element: ET.Element, data_type: ApplicationRecordDataType):
        self.logger.debug("Read ApplicationRecordDataType <%s>" % data_type.getShortName())
        self.readIdentifiable(element, data_type)
        data_type.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))
        self.readApplicationRecordDataTypeElements(element, data_type)

    def readImplementationDataTypeElement(self, element: ET.Element, impl_data_type_element: ImplementationDataTypeElement):
        self.readAutosarDataType(element, impl_data_type_element)
        impl_data_type_element.setArrayImplPolicy(self.getChildElementOptionalLiteral(element, "ARRAY-IMPL-POLICY"))
        impl_data_type_element.setArraySize(self.getChildElementOptionalPositiveInteger(element, "ARRAY-SIZE"))
        impl_data_type_element.setArraySizeHandling(self.getChildElementOptionalLiteral(element, "ARRAY-SIZE-HANDLING"))
        impl_data_type_element.setArraySizeSemantics(self.getChildElementOptionalLiteral(element, "ARRAY-SIZE-SEMANTICS"))
        impl_data_type_element.setIsOptional(self.getChildElementOptionalBooleanValue(element, "IS-OPTIONAL"))
        self.readImplementationDataTypeSubElements(element, impl_data_type_element)

    def readImplementationDataTypeSubElements(self, element: ET.Element, parent: ImplementationDataType):
        for child_element in self.findall(element, "SUB-ELEMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "IMPLEMENTATION-DATA-TYPE-ELEMENT":
                impl_data_type_element = parent.createImplementationDataTypeElement(self.getShortName(child_element))
                self.readImplementationDataTypeElement(child_element, impl_data_type_element)
            else:
                self.notImplemented("Unsupported ImplementationDataType SubElement <%s>" % tag_name)

    def readImplementationDataType(self, element: ET.Element, data_type: ImplementationDataType):
        self.logger.debug("Read ImplementationDataType <%s>" % data_type.getShortName())
        self.readAutosarDataType(element, data_type)
        data_type.setDynamicArraySizeProfile(self.getChildElementOptionalLiteral(element, "DYNAMIC-ARRAY-SIZE-PROFILE"))
        data_type.setIsStructWithOptionalElement(self.getChildElementOptionalBooleanValue(element, "IS-STRUCT-WITH-OPTIONAL-ELEMENT"))
        self.readImplementationDataTypeSubElements(element, data_type)
        self.readImplementationDataTypeSymbolProps(element, data_type)
        data_type.setTypeEmitter(self.getChildElementOptionalLiteral(element, "TYPE-EMITTER"))

    def readBaseTypeDirectDefinition(self, element: ET.Element, definition: BaseTypeDirectDefinition):
        definition.setBaseTypeSize(self.getChildElementOptionalPositiveInteger(element, "BASE-TYPE-SIZE"))
        definition.setBaseTypeEncoding(self.getChildElementOptionalLiteral(element, "BASE-TYPE-ENCODING"))
        definition.setMemAlignment(self.getChildElementOptionalPositiveInteger(element, "MEM-ALIGNMENT"))
        definition.setByteOrder(self.getChildElementOptionalLiteral(element, "BYTE-ORDER"))
        definition.setNativeDeclaration(self.getChildElementOptionalLiteral(element, "NATIVE-DECLARATION"))

    def readSwBaseType(self, element: ET.Element, data_type: SwBaseType):
        self.logger.debug("Read SwBaseType <%s>" % data_type.getShortName())
        self.readIdentifiable(element, data_type)
        self.readBaseTypeDirectDefinition(element, data_type.getBaseTypeDefinition())

    def getApplicationCompositeElementInPortInterfaceInstanceRef(self, element: ET.Element, key: str) -> ApplicationCompositeElementInPortInterfaceInstanceRef:  # noqa E501
        child_element = self.find(element, key)
        iref = None
        if child_element is not None:
            iref = ApplicationCompositeElementInPortInterfaceInstanceRef()
            iref.setRootDataPrototypeRef(self.getChildElementOptionalRefType(child_element, "ROOT-DATA-PROTOTYPE-REF"))
            for ref in self.getChildElementRefTypeList(child_element, "CONTEXT-DATA-PROTOTYPE-REF"):
                iref.addContextDataPrototypeRef(ref)
            iref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(child_element, "TARGET-DATA-PROTOTYPE-REF"))
        return iref

    def getCompositeNetworkRepresentation(self, element: ET.Element) -> CompositeNetworkRepresentation:
        # self.logger.debug("getCompositeNetworkRepresentation")
        representation = CompositeNetworkRepresentation()
        self.readARObject(element, representation)
        representation.setLeafElementIRef(self.getApplicationCompositeElementInPortInterfaceInstanceRef(element, "LEAF-ELEMENT-IREF"))
        representation.setNetworkRepresentation(self.getSwDataDefProps(element, "NETWORK-REPRESENTATION"))
        return representation

    def readReceiverComSpec(self, element: ET.Element, com_spec: ReceiverComSpec):
        self.readRPortComSpec(element, com_spec)
        for child_element in self.findall(element, "COMPOSITE-NETWORK-REPRESENTATIONS/COMPOSITE-NETWORK-REPRESENTATION"):
            com_spec.addCompositeNetworkRepresentation(self.getCompositeNetworkRepresentation(child_element))
        com_spec.setDataElementRef(self.getChildElementOptionalRefType(element, "DATA-ELEMENT-REF"))
        com_spec.setNetworkRepresentation(self.getSwDataDefProps(element, "NETWORK-REPRESENTATION"))
        com_spec.setHandleOutOfRange(self.getChildElementOptionalLiteral(element, "HANDLE-OUT-OF-RANGE"))
        com_spec.setHandleOutOfRangeStatus(self.getChildElementOptionalLiteral(element, "HANDLE-OUT-OF-RANGE-STATUS"))
        com_spec.setMaxDeltaCounterInit(self.getChildElementOptionalPositiveInteger(element, "MAX-DELTA-COUNTER-INIT"))
        com_spec.setMaxNoNewOrRepeatedData(self.getChildElementOptionalPositiveInteger(element, "MAX-NO-NEW-OR-REPEATED-DATA"))
        com_spec.setUsesEndToEndProtection(self.getChildElementOptionalBooleanValue(element, "USES-END-TO-END-PROTECTION"))
        reception_props = self.getReceptionComSpecProps(element, "RECEPTION-PROPS")
        if reception_props is not None:
            com_spec.setReceptionProps(reception_props)
        replace_with = self.find(element, "REPLACE-WITH")
        if replace_with is not None:
            variable_access = VariableAccess(None, self.getShortName(replace_with))
            self.readVariableAccess(replace_with, variable_access)
            com_spec.setReplaceWith(variable_access)
        com_spec.setSyncCounterInit(self.getChildElementOptionalPositiveInteger(element, "SYNC-COUNTER-INIT"))
        self.readTransformationComSpecPropss(element, com_spec)

    def getReceptionComSpecProps(self, element: ET.Element, key: str) -> ReceptionComSpecProps:
        child_element = self.find(element, key)
        if child_element is None:
            return None
        props = ReceptionComSpecProps()
        self.readARObject(child_element, props)
        props.setDataUpdatePeriod(self.getChildElementOptionalTimeValue(child_element, "DATA-UPDATE-PERIOD"))
        props.setTimeout(self.getChildElementOptionalTimeValue(child_element, "TIMEOUT"))
        return props

    def readVariableAccess(self, element: ET.Element, access: VariableAccess):
        self.readIdentifiable(element, access)
        access.setAccessedVariable(self.getAutosarVariableRef(element, "ACCESSED-VARIABLE"))
        literal = self.getChildElementOptionalLiteral(element, "SCOPE")
        if literal is not None:
            camel = None
            for camel_value, token in VARIABLE_ACCESS_SCOPE_XML_MAP.items():
                if token == literal.getText():
                    camel = camel_value
                    break
            if camel is not None:
                access.setScope(VariableAccessScopeEnum().setValue(camel))
            else:
                self.notImplemented("Unsupported SCOPE <%s>" % literal.getText())

    def getTransformationComSpecProps(self, element: ET.Element) -> Optional[TransformationComSpecProps]:
        child = self.find(element, "*")
        if child is None:
            return None
        tag_name = self.getTagName(child)
        if tag_name == "END-TO-END-TRANSFORMATION-COM-SPEC-PROPS":
            props = EndToEndTransformationComSpecProps()
            self.readTransformationComSpecProps(child, props)
            return props
        elif tag_name == "USER-DEFINED-TRANSFORMATION-COM-SPEC-PROPS":
            props = UserDefinedTransformationComSpecProps()
            self.readUserDefinedTransformationComSpecProps(child, props)
            return props
        self.notImplemented("Unsupported TransformationComSpecProps <%s>" % tag_name)
        return None

    def getSwValues(self, element: ET.Element, key: str) -> Optional[SwValues]:
        child_element = self.find(element, key)
        if child_element is None:
            return None
        sw_values = SwValues()
        self.readARObject(child_element, sw_values)
        for vf in self.getChildElementNumericalList(child_element, "VF"):
            sw_values.addVf(vf)
        sw_values.setVt(self.getChildElementOptionalVerbatimString(child_element, "VT"))
        sw_values.setVg(self.getValueGroup(child_element, "VG"))
        for v in self.getChildElementNumericalList(child_element, "V"):
            sw_values.addV(v)
        for vtf_element in self.findall(child_element, "VTF"):
            sw_values.addVtf(self.getNumericalOrText(vtf_element))
        return sw_values

    def getValueGroup(self, element: ET.Element, key: str) -> Optional[ValueGroup]:
        value_group = None
        child_element = self.find(element, key)
        if child_element is not None:
            value_group = ValueGroup()
            self.readARObject(child_element, value_group)
            value_group.setLabel(self.getMultilanguageLongName(child_element, "LABEL"))
            has_v = self.find(child_element, "V") is not None
            has_vf = self.find(child_element, "VF") is not None
            has_vt = self.find(child_element, "VT") is not None
            has_vtf = self.find(child_element, "VTF") is not None
            if has_v or has_vf or has_vt or has_vtf:
                contents = SwValues()
                for vf in self.getChildElementNumericalList(child_element, "VF"):
                    contents.addVf(vf)
                for v in self.getChildElementNumericalList(child_element, "V"):
                    contents.addV(v)
                contents.setVt(self.getChildElementOptionalVerbatimString(child_element, "VT"))
                for vtf_element in self.findall(child_element, "VTF"):
                    contents.addVtf(self.getNumericalOrText(vtf_element))
                value_group.setVgContents(contents)
        return value_group

    def getValueList(self, element: ET.Element, key: str) -> Optional[ValueList]:
        value_list = None
        child_element = self.find(element, key)
        if child_element is not None:
            # self.logger.debug("Get ValueList %s" % key)
            value_list = ValueList()
            self.readARObject(child_element, value_list)
            value_list.setV(self.getChildElementOptionalNumerical(child_element, "V"))
            for vf_element in self.findall(child_element, "VF"):
                vf = self.getChildElementOptionalNumerical(vf_element, "V")
                if vf is not None:
                    value_list.addVf(vf)
        return value_list

    def getSwValueCont(self, element: ET.Element) -> Optional[SwValueCont]:
        cont = None
        child_element = self.find(element, "SW-VALUE-CONT")
        if child_element is not None:
            # self.logger.debug("Get SwValueCont")
            cont = SwValueCont()
            self.readARObject(child_element, cont)
            cont.setUnitRef(self.getChildElementOptionalRefType(child_element, "UNIT-REF"))
            cont.setSwArraysize(self.getValueList(child_element, "SW-ARRAYSIZE"))
            cont.setSwValuesPhys(self.getSwValues(child_element, "SW-VALUES-PHYS"))
            cont.setUnitDisplayName(self.getSingleLanguageUnitNames(child_element, "UNIT-DISPLAY-NAME"))
        return cont

    def readApplicationValueSpecification(self, element: ET.Element, value_spec: ApplicationValueSpecification):
        self.readValueSpecification(element, value_spec)
        value_spec.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        value_spec.setSwValueCont(self.getSwValueCont(element))

        self.logger.debug("readApplicationValueSpecification Category %s" % value_spec.category)

    def getChildValueSpecification(self, element: ET.Element, key: str) -> ValueSpecification:
        value_spec = None
        child_element = self.find(element, key + "/*")
        if child_element is not None:
            value_spec = self.getValueSpecification(child_element, self.getTagName(child_element))
        return value_spec

    def getInitValue(self, element: ET.Element) -> ValueSpecification:
        return self.getChildValueSpecification(element, "INIT-VALUE")

    def readRPortComSpec(self, element: ET.Element, com_spec: RPortComSpec):
        self.readARObject(element, com_spec)

    def getClientComSpec(self, element: ET.Element) -> ClientComSpec:
        com_spec = ClientComSpec()
        self.readRPortComSpec(element, com_spec)
        com_spec.setEndToEndCallResponseTimeout(self.getChildElementOptionalTimeValue(element, "END-TO-END-CALL-RESPONSE-TIMEOUT"))
        com_spec.setOperationRef(self.getChildElementOptionalRefType(element, "OPERATION-REF"))
        self.readTransformationComSpecPropss(element, com_spec)
        return com_spec

    def getParameterRequireComSpec(self, element: ET.Element) -> ParameterRequireComSpec:
        com_spec = ParameterRequireComSpec()
        self.readRPortComSpec(element, com_spec)
        com_spec.setInitValue(self.getChildValueSpecification(element, "INIT-VALUE"))
        com_spec.setParameterRef(self.getChildElementOptionalRefType(element, "PARAMETER-REF"))
        return com_spec

    def getNvRequireComSpec(self, element: ET.Element) -> NvRequireComSpec:
        com_spec = NvRequireComSpec()
        self.readRPortComSpec(element, com_spec)
        com_spec.setInitValue(self.getChildValueSpecification(element, "INIT-VALUE"))
        com_spec.setVariableRef(self.getChildElementOptionalRefType(element, "VARIABLE-REF"))
        return com_spec

    def getQueuedReceiverComSpec(self, element: ET.Element) -> QueuedReceiverComSpec:
        com_spec = QueuedReceiverComSpec()
        self.readReceiverComSpec(element, com_spec)
        com_spec.setQueueLength(self.getChildElementOptionalPositiveInteger(element, "QUEUE-LENGTH"))
        return com_spec

    def getModeSwitchReceiverComSpec(self, element: ET.Element) -> ModeSwitchReceiverComSpec:
        com_spec = ModeSwitchReceiverComSpec()
        self.readRPortComSpec(element, com_spec)
        com_spec.setEnhancedModeApi(self.getChildElementOptionalBooleanValue(element, "ENHANCED-MODE-API"))
        com_spec.setModeGroupRef(self.getChildElementOptionalRefType(element, "MODE-GROUP-REF"))
        com_spec.setSupportsAsynchronousModeSwitch(self.getChildElementOptionalBooleanValue(element, "SUPPORTS-ASYNCHRONOUS-MODE-SWITCH"))
        return com_spec

    def getNonqueuedReceiverComSpec(self, element: ET.Element) -> NonqueuedReceiverComSpec:
        com_spec = NonqueuedReceiverComSpec()
        self.readARObject(element, com_spec)
        self.readReceiverComSpec(element, com_spec)
        com_spec.setAliveTimeout(self.getChildElementOptionalFloatValue(element, "ALIVE-TIMEOUT"))
        com_spec.setEnableUpdate(self.getChildElementOptionalBooleanValue(element, "ENABLE-UPDATE"))
        com_spec.setHandleDataStatus(self.getChildElementOptionalBooleanValue(element, "HANDLE-DATA-STATUS"))
        com_spec.setHandleNeverReceived(self.getChildElementOptionalBooleanValue(element, "HANDLE-NEVER-RECEIVED"))
        com_spec.setFilter(self.getDataFilter(element, "FILTER"))
        com_spec.setHandleTimeoutType(self.getChildElementOptionalLiteral(element, "HANDLE-TIMEOUT-TYPE"))
        com_spec.setInitValue(self.getInitValue(element))
        com_spec.setTimeoutSubstitutionValue(self.getChildValueSpecification(element, "TIMEOUT-SUBSTITUTION-VALUE"))
        return com_spec

    def readRequiredComSpec(self, element: ET.Element, parent: RPortPrototype):
        for child_element in self.findall(element, "REQUIRED-COM-SPECS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "NONQUEUED-RECEIVER-COM-SPEC":
                parent.addRequiredComSpec(self.getNonqueuedReceiverComSpec(child_element))
            elif tag_name == "CLIENT-COM-SPEC":
                parent.addRequiredComSpec(self.getClientComSpec(child_element))
            elif tag_name == "QUEUED-RECEIVER-COM-SPEC":
                parent.addRequiredComSpec(self.getQueuedReceiverComSpec(child_element))
            elif tag_name == "MODE-SWITCH-RECEIVER-COM-SPEC":
                parent.addRequiredComSpec(self.getModeSwitchReceiverComSpec(child_element))
            elif tag_name == "PARAMETER-REQUIRE-COM-SPEC":
                parent.addRequiredComSpec(self.getParameterRequireComSpec(child_element))
            elif tag_name == "NV-REQUIRE-COM-SPEC":
                parent.addRequiredComSpec(self.getNvRequireComSpec(child_element))
            else:
                self.raiseError("Unsupported RequiredComSpec <%s>" % tag_name)

    def readAbstractRequiredPortPrototype(self, element: ET.Element, prototype: AbstractRequiredPortPrototype):
        self.readRequiredComSpec(element, prototype)

    def readPPortPrototype(self, element: ET.Element, prototype: PPortPrototype):
        # self.logger.debug("Read PPortPrototype %s" % prototype.getShortName())
        self.readIdentifiable(element, prototype)
        self.readAbstractProvidedPortPrototype(element, prototype)
        prototype.setProvidedInterfaceTRef(self.getChildElementOptionalRefType(element, "PROVIDED-INTERFACE-TREF"))
        self.readPortPrototype(element, prototype)

    def readAbstractProvidedPortPrototype(self, element: ET.Element, prototype: AbstractProvidedPortPrototype):
        self.readProvidedComSpec(element, prototype)

    def readRPortPrototype(self, element: ET.Element, prototype: RPortPrototype):
        # self.logger.debug("Read RPortPrototype %s" % prototype.getShortName())
        self.readIdentifiable(element, prototype)
        self.readAbstractRequiredPortPrototype(element, prototype)
        prototype.setMayBeUnconnected(self.getChildElementOptionalBooleanValue(element, "MAY-BE-UNCONNECTED"))
        prototype.setRequiredInterfaceTRef(self.getChildElementOptionalRefType(element, "REQUIRED-INTERFACE-TREF"))
        self.readPortPrototype(element, prototype)

    def readPRPortPrototype(self, element: ET.Element, prototype: PRPortPrototype):
        # self.logger.debug("Read PRPortPrototype %s" % prototype.getShortName())
        self.readIdentifiable(element, prototype)
        self.readAbstractRequiredPortPrototype(element, prototype)
        self.readAbstractProvidedPortPrototype(element, prototype)
        prototype.setProvidedRequiredInterfaceTRef(self.getChildElementOptionalRefType(element, "PROVIDED-REQUIRED-INTERFACE-TREF"))
        self.readPortPrototype(element, prototype)

    def readPortPrototype(self, element: ET.Element, prototype: PortPrototype):
        for child in self.findall(element, "CLIENT-SERVER-ANNOTATIONS/CLIENT-SERVER-ANNOTATION"):
            annotation = ClientServerAnnotation()
            annotation.setOperationRef(self.getChildElementOptionalRefType(child, "OPERATION-REF"))
            prototype.addClientServerAnnotation(annotation)
        child = self.find(element, "DELEGATED-PORT-ANNOTATION")
        if child is not None:
            annotation = DelegatedPortAnnotation()
            signal_fan = self.getChildElementOptionalLiteral(child, "SIGNAL-FAN")
            if signal_fan is not None:
                annotation.setSignalFan(SignalFanEnum().setValue(signal_fan.getValue()))
            prototype.setDelegatedPortAnnotation(annotation)
        for child in self.findall(element, "IO-HW-ABSTRACTION-SERVER-ANNOTATIONS/IO-HW-ABSTRACTION-SERVER-ANNOTATION"):
            annotation = IoHwAbstractionServerAnnotation()
            filtering_debouncing = self.getChildElementOptionalLiteral(child, "FILTERING-DEBOUNCING")
            if filtering_debouncing is not None:
                annotation.setFilteringDebouncing(FilterDebouncingEnum().setValue(filtering_debouncing.getValue()))
            pulse_test = self.getChildElementOptionalLiteral(child, "PULSE-TEST")
            if pulse_test is not None:
                annotation.setPulseTest(PulseTestEnum().setValue(pulse_test.getValue()))
            annotation.setTriggerRef(self.getChildElementOptionalRefType(child, "TRIGGER-REF"))
            prototype.addIoHwAbstractionServerAnnotation(annotation)
        for child in self.findall(element, "MODE-PORT-ANNOTATIONS/MODE-PORT-ANNOTATION"):
            annotation = ModePortAnnotation()
            annotation.setModeGroupRef(self.getChildElementOptionalRefType(child, "MODE-GROUP-REF"))
            prototype.addModePortAnnotation(annotation)
        for child in self.findall(element, "NV-DATA-PORT-ANNOTATIONS/NV-DATA-PORT-ANNOTATION"):
            annotation = NvDataPortAnnotation()
            annotation.setVariableRef(self.getChildElementOptionalRefType(child, "VARIABLE-REF"))
            prototype.addNvDataPortAnnotation(annotation)
        for child in self.findall(element, "PARAMETER-PORT-ANNOTATIONS/PARAMETER-PORT-ANNOTATION"):
            annotation = ParameterPortAnnotation()
            annotation.setParameterRef(self.getChildElementOptionalRefType(child, "PARAMETER-REF"))
            prototype.addParameterPortAnnotation(annotation)
        for child in self.findall(element, "SENDER-RECEIVER-ANNOTATIONS/SENDER-RECEIVER-ANNOTATION"):
            annotation = SenderReceiverAnnotation()
            annotation.setComputed(self.getChildElementOptionalBooleanValue(child, "COMPUTED"))
            annotation.setDataElementRef(self.getChildElementOptionalRefType(child, "DATA-ELEMENT-REF"))
            limit_kind = self.getChildElementOptionalLiteral(child, "LIMIT-KIND")
            if limit_kind is not None:
                annotation.setLimitKind(DataLimitKindEnum().setValue(limit_kind.getValue()))
            processing_kind = self.getChildElementOptionalLiteral(child, "PROCESSING-KIND")
            if processing_kind is not None:
                annotation.setProcessingKind(ProcessingKindEnum().setValue(processing_kind.getValue()))
            prototype.addSenderReceiverAnnotation(annotation)
        for child in self.findall(element, "TRIGGER-PORT-ANNOTATIONS/TRIGGER-PORT-ANNOTATION"):
            annotation = TriggerPortAnnotation()
            annotation.setTriggerRef(self.getChildElementOptionalRefType(child, "TRIGGER-REF"))
            prototype.addTriggerPortAnnotation(annotation)

    def readSwComponentTypePorts(self, element: ET.Element, sw_component: SwComponentType):
        for child_element in self.findall(element, "PORTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "P-PORT-PROTOTYPE":
                prototype = sw_component.createPPortPrototype(self.getShortName(child_element))
                self.readPPortPrototype(child_element, prototype)
            elif tag_name == "R-PORT-PROTOTYPE":
                prototype = sw_component.createRPortPrototype(self.getShortName(child_element))
                self.readRPortPrototype(child_element, prototype)
            elif tag_name == "PR-PORT-PROTOTYPE":
                prototype = sw_component.createPRPortPrototype(self.getShortName(child_element))
                self.readPRPortPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported Port Prototype <%s>" % tag_name)

    def readTransmissionAcknowledgementRequest(self, element: ET.Element) -> TransmissionAcknowledgementRequest:
        child_element = self.find(element, "TRANSMISSION-ACKNOWLEDGE")
        if child_element is not None:
            acknowledge = TransmissionAcknowledgementRequest()
            self.readARObject(child_element, acknowledge)
            acknowledge.setTimeout(self.getChildElementOptionalTimeValue(child_element, "TIMEOUT"))
            return acknowledge
        return None

    def getTransmissionComSpecProps(self, element: ET.Element, key: str) -> TransmissionComSpecProps:
        child_element = self.find(element, key)
        if child_element is not None:
            props = TransmissionComSpecProps()
            self.readARObject(child_element, props)
            props.setDataUpdatePeriod(self.getChildElementOptionalTimeValue(child_element, "DATA-UPDATE-PERIOD"))
            props.setMinimumSendInterval(self.getChildElementOptionalTimeValue(child_element, "MINIMUM-SEND-INTERVAL"))
            props.setTransmissionMode(self.getChildElementOptionalLiteral(child_element, "TRANSMISSION-MODE"))
            return props
        return None

    def readSenderComSpec(self, element: ET.Element, com_spec: SenderComSpec):
        self.readARObject(element, com_spec)
        for child_element in self.findall(element, "COMPOSITE-NETWORK-REPRESENTATIONS/COMPOSITE-NETWORK-REPRESENTATION"):
            com_spec.addCompositeNetworkRepresentation(self.getCompositeNetworkRepresentation(child_element))
        com_spec.setDataElementRef(self.getChildElementOptionalRefType(element, "DATA-ELEMENT-REF"))
        com_spec.setHandleOutOfRange(self.getChildElementOptionalLiteral(element, "HANDLE-OUT-OF-RANGE"))
        com_spec.setNetworkRepresentation(self.getSwDataDefProps(element, "NETWORK-REPRESENTATION"))
        com_spec.setTransmissionAcknowledge(self.readTransmissionAcknowledgementRequest(element))
        com_spec.setTransmissionProps(self.getTransmissionComSpecProps(element, "TRANSMISSION-PROPS"))
        com_spec.setUsesEndToEndProtection(self.getChildElementOptionalBooleanValue(element, "USES-END-TO-END-PROTECTION"))

    def getNonqueuedSenderComSpec(self, element: ET.Element) -> NonqueuedSenderComSpec:
        com_spec = NonqueuedSenderComSpec()
        self.readSenderComSpec(element, com_spec)
        com_spec.setDataFilter(self.getDataFilter(element, "DATA-FILTER"))
        com_spec.setInitValue(self.getInitValue(element))
        return com_spec

    def readTransformationComSpecProps(self, element: ET.Element, props: TransformationComSpecProps):
        self.readARObject(element, props)

    def readUserDefinedTransformationComSpecProps(self, element: ET.Element, props: UserDefinedTransformationComSpecProps):
        self.readTransformationComSpecProps(element, props)

    def readEndToEndTransformationComSpecProps(self, element: ET.Element, props: EndToEndTransformationComSpecProps):
        self.readTransformationComSpecProps(element, props)
        props.setClearFromValidToInvalid(self.getChildElementOptionalBooleanValue(element, "CLEAR-FROM-VALID-TO-INVALID"))
        props.setDisableEndToEndCheck(self.getChildElementOptionalBooleanValue(element, "DISABLE-END-TO-END-CHECK"))
        props.setDisableEndToEndStateMachine(self.getChildElementOptionalBooleanValue(element, "DISABLE-END-TO-END-STATE-MACHINE"))
        props.setE2eProfileCompatibilityPropsRef(self.getChildElementOptionalRefType(element, "E2E-PROFILE-COMPATIBILITY-PROPS-REF"))
        props.setMaxDeltaCounter(self.getChildElementOptionalPositiveInteger(element, "MAX-DELTA-COUNTER"))
        props.setMaxErrorStateInit(self.getChildElementOptionalPositiveInteger(element, "MAX-ERROR-STATE-INIT"))
        props.setMaxErrorStateInvalid(self.getChildElementOptionalPositiveInteger(element, "MAX-ERROR-STATE-INVALID"))
        props.setMaxErrorStateValid(self.getChildElementOptionalPositiveInteger(element, "MAX-ERROR-STATE-VALID"))
        props.setMaxNoNewOrRepeatedData(self.getChildElementOptionalPositiveInteger(element, "MAX-NO-NEW-OR-REPEATED-DATA"))
        props.setMinOkStateInit(self.getChildElementOptionalPositiveInteger(element, "MIN-OK-STATE-INIT"))
        props.setMinOkStateInvalid(self.getChildElementOptionalPositiveInteger(element, "MIN-OK-STATE-INVALID"))
        props.setMinOkStateValid(self.getChildElementOptionalPositiveInteger(element, "MIN-OK-STATE-VALID"))
        props.setSyncCounterInit(self.getChildElementOptionalPositiveInteger(element, "SYNC-COUNTER-INIT"))
        props.setWindowSizeInit(self.getChildElementOptionalPositiveInteger(element, "WINDOW-SIZE-INIT"))
        props.setWindowSizeInvalid(self.getChildElementOptionalPositiveInteger(element, "WINDOW-SIZE-INVALID"))
        props.setWindowSizeValid(self.getChildElementOptionalPositiveInteger(element, "WINDOW-SIZE-VALID"))

    def readTransformationComSpecPropss(self, element: ET.Element, com_spec):
        for child_element in self.findall(element, "TRANSFORMATION-COM-SPEC-PROPSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-TRANSFORMATION-COM-SPEC-PROPS":
                props = EndToEndTransformationComSpecProps()
                self.readEndToEndTransformationComSpecProps(child_element, props)
                com_spec.addTransformationComSpecProps(props)
            elif tag_name == "USER-DEFINED-TRANSFORMATION-COM-SPEC-PROPS":
                props = UserDefinedTransformationComSpecProps()
                self.readUserDefinedTransformationComSpecProps(child_element, props)
                com_spec.addTransformationComSpecProps(props)
            else:
                self.notImplemented("Unsupported TransformationComSpecProps <%s>" % tag_name)

    def readPPortComSpec(self, element: ET.Element, com_spec: PPortComSpec):
        self.readARObject(element, com_spec)

    def getServerComSpec(self, element: ET.Element) -> ServerComSpec:
        com_spec = ServerComSpec()
        self.readPPortComSpec(element, com_spec)
        com_spec.setOperationRef(self.getChildElementOptionalRefType(element, "OPERATION-REF"))
        com_spec.setQueueLength(self.getChildElementOptionalPositiveInteger(element, "QUEUE-LENGTH"))
        self.readTransformationComSpecPropss(element, com_spec)
        return com_spec

    def getParameterProvideComSpec(self, element: ET.Element) -> ParameterProvideComSpec:
        com_spec = ParameterProvideComSpec()
        self.readPPortComSpec(element, com_spec)
        com_spec.setInitValue(self.getInitValue(element))
        com_spec.setParameterRef(self.getChildElementOptionalRefType(element, "PARAMETER-REF"))
        return com_spec

    def getQueuedSenderComSpec(self, element: ET.Element) -> QueuedSenderComSpec:
        com_spec = QueuedSenderComSpec()
        self.readSenderComSpec(element, com_spec)
        return com_spec

    def getModeSwitchedAckRequest(self, element: ET.Element, key: str) -> ModeSwitchedAckRequest:
        request = None
        child_element = self.find(element, key)
        if child_element is not None:
            request = ModeSwitchedAckRequest()
            self.readARObject(child_element, request)
            request.setTimeout(self.getChildElementOptionalTimeValue(child_element, "TIMEOUT"))
        return request

    def getModeSwitchSenderComSpec(self, element) -> ModeSwitchSenderComSpec:
        com_spec = ModeSwitchSenderComSpec()
        self.readPPortComSpec(element, com_spec)
        com_spec.setEnhancedModeApi(self.getChildElementOptionalBooleanValue(element, "ENHANCED-MODE-API"))
        com_spec.setModeGroupRef(self.getChildElementOptionalRefType(element, "MODE-GROUP-REF"))
        com_spec.setModeSwitchedAck(self.getModeSwitchedAckRequest(element, "MODE-SWITCHED-ACK"))
        com_spec.setQueueLength(self.getChildElementOptionalPositiveInteger(element, "QUEUE-LENGTH"))
        return com_spec

    def getNvProvideComSpec(self, element: ET.Element) -> NvProvideComSpec:
        com_spec = NvProvideComSpec()
        self.readPPortComSpec(element, com_spec)
        com_spec.setRamBlockInitValue(self.getChildValueSpecification(element, "RAM-BLOCK-INIT-VALUE"))
        com_spec.setRomBlockInitValue(self.getChildValueSpecification(element, "ROM-BLOCK-INIT-VALUE"))
        com_spec.setVariableRef(self.getChildElementOptionalRefType(element, "VARIABLE-REF"))
        return com_spec

    def readProvidedComSpec(self, element: ET.Element, parent: PPortPrototype):
        for child_element in self.findall(element, "PROVIDED-COM-SPECS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "NONQUEUED-SENDER-COM-SPEC":
                parent.addProvidedComSpec(self.getNonqueuedSenderComSpec(child_element))
            elif tag_name == "SERVER-COM-SPEC":
                parent.addProvidedComSpec(self.getServerComSpec(child_element))
            elif tag_name == "QUEUED-SENDER-COM-SPEC":
                parent.addProvidedComSpec(self.getQueuedSenderComSpec(child_element))
            elif tag_name == "MODE-SWITCH-SENDER-COM-SPEC":
                parent.addProvidedComSpec(self.getModeSwitchSenderComSpec(child_element))
            elif tag_name == "NV-PROVIDE-COM-SPEC":
                parent.addProvidedComSpec(self.getNvProvideComSpec(child_element))
            elif tag_name == "PARAMETER-PROVIDE-COM-SPEC":
                parent.addProvidedComSpec(self.getParameterProvideComSpec(child_element))
            else:
                self.raiseError("Unsupported RequiredComSpec <%s>" % tag_name)

    def readPortGroupInnerGroupIRefs(self, element: ET.Element, parent: PortGroup):
        for child_element in self.findall(element, "INNER-GROUP-IREFS/INNER-GROUP-IREF"):
            inner_group_iref = InnerPortGroupInCompositionInstanceRef()
            for context_ref in self.getChildElementRefTypeList(child_element, "CONTEXT-REF"):
                inner_group_iref.addContextRef(context_ref)
            inner_group_iref.setTargetRef(self.getChildElementOptionalRefType(child_element, "TARGET-REF"))
            parent.addInnerGroupIRef(inner_group_iref)

    def readPortGroupOuterPortRefs(self, element: ET.Element, parent: PortGroup):
        for child_element in self.findall(element, "OUTER-PORTS/PORT-PROTOTYPE-REF-CONDITIONAL"):
            parent.addOuterPortRef(self.getChildElementOptionalRefType(child_element, "PORT-PROTOTYPE-REF"))

    def readPortGroup(self, element: ET.Element, parent: SwComponentType):
        short_name = self.getShortName(element)
        self.logger.debug("readPortGroup %s" % short_name)
        port_group = parent.createPortGroup(short_name)
        self.readIdentifiable(element, port_group)
        self.readPortGroupInnerGroupIRefs(element, port_group)
        self.readPortGroupOuterPortRefs(element, port_group)

    def readSwComponentTypePortGroups(self, element: ET.Element, parent: SwComponentType):
        for child_element in self.findall(element, "PORT-GROUPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PORT-GROUP":
                self.readPortGroup(child_element, parent)
            else:
                self.raiseError("Unsupported Port Group type: %s" % tag_name)

    def readSwComponentTypeSwcMappingConstraints(self, element: ET.Element, parent: SwComponentType):
        for ref in self.getChildElementRefTypeList(element, "SWC-MAPPING-CONSTRAINT-REFS/SWC-MAPPING-CONSTRAINT-REF"):
            parent.addSwcMappingConstraintRef(ref)

    def readSwComponentTypeUnitGroups(self, element: ET.Element, parent: SwComponentType):
        for ref in self.getChildElementRefTypeList(element, "UNIT-GROUP-REFS/UNIT-GROUP-REF"):
            parent.addUnitGroupRef(ref)

    def readSwComponentTypeConsistencyNeeds(self, element: ET.Element, parent: SwComponentType):
        for child_element in self.findall(element, "CONSISTENCY-NEEDSS/CONSISTENCY-NEEDS"):
            self.readConsistencyNeeds(child_element, parent.createConsistencyNeeds(self.getShortName(child_element)))

    def readSwComponentDocumentationElement(self, child_element: ET.Element) -> SwComponentDocumentation:
        documentation = SwComponentDocumentation()
        predefined_chapter_map = [
            ("SW-FEATURE-DEF", documentation.createSwFeatureDef),
            ("SW-FEATURE-DESC", documentation.createSwFeatureDesc),
            ("SW-TEST-DESC", documentation.createSwTestDesc),
            ("SW-CALIBRATION-NOTES", documentation.createSwCalibrationNotes),
            ("SW-MAINTENANCE-NOTES", documentation.createSwMaintenanceNotes),
            ("SW-DIAGNOSTICS-NOTES", documentation.createSwDiagnosticsNotes),
            ("SW-CARB-DOC", documentation.createSwCarbDoc),
        ]
        for tag_name, creator in predefined_chapter_map:
            chapter_element = self.find(child_element, tag_name)
            if chapter_element is not None:
                chapter = creator(self.getShortName(chapter_element))
                self.readChapterBody(chapter_element, chapter)
        for chapter_element in self.findall(child_element, "CHAPTER"):
            chapter = documentation.createChapter(self.getShortName(chapter_element))
            self.readChapterBody(chapter_element, chapter)
        return documentation

    def readSwComponentTypeSwComponentDocumentation(self, element: ET.Element, parent: SwComponentType):
        child_element = self.find(element, "SW-COMPONENT-DOCUMENTATION")
        if child_element is None:
            return
        parent.setSwComponentDocumentation(self.readSwComponentDocumentationElement(child_element))

    def readChapter(self, element: ET.Element, parent: ARObject) -> Chapter:
        chapter = Chapter(parent, self.getShortName(element))
        self.readChapterBody(element, chapter)
        return chapter

    def readChapterBody(self, element: ET.Element, chapter: Chapter):
        self.readIdentifiable(element, chapter)
        help_entry = element.get("HELP-ENTRY")
        if help_entry is not None:
            chapter.setHelpEntry(String().setValue(help_entry))
        chapter_model_element = self.find(element, "CHAPTER-MODEL")
        if chapter_model_element is not None:
            chapter.setChapterModel(self.readChapterModel(chapter_model_element, chapter))

    def readChapterModel(self, element: ET.Element, parent: Chapter) -> ChapterModel:
        chapter_model = ChapterModel()
        chapter_content_element = self.find(element, "CHAPTER-CONTENT")
        if chapter_content_element is not None:
            chapter_model.setChapterContent(self.readChapterContent(chapter_content_element, parent))
        topic_elements = self.findall(element, "TOPIC-1")
        msr_query_topic1_element = self.find(element, "MSR-QUERY-TOPIC-1")
        if len(topic_elements) > 0 or msr_query_topic1_element is not None:
            topic_or_msr_query = TopicOrMsrQuery()
            for topic_element in topic_elements:
                topic_or_msr_query.addTopic1(self.readTopic1(topic_element, parent))
            if msr_query_topic1_element is not None:
                topic_or_msr_query.setMsrQueryTopic1(self.readMsrQueryTopic1(msr_query_topic1_element, parent))
            chapter_model.setTopic1(topic_or_msr_query)
        chapter_elements = self.findall(element, "CHAPTER")
        msr_query_chapter_element = self.find(element, "MSR-QUERY-CHAPTER")
        if len(chapter_elements) > 0 or msr_query_chapter_element is not None:
            chapter_or_msr_query = ChapterOrMsrQuery()
            for chapter_element in chapter_elements:
                chapter_or_msr_query.addChapter(self.readChapter(chapter_element, parent))
            if msr_query_chapter_element is not None:
                chapter_or_msr_query.setMsrQueryChapter(self.readMsrQueryChapter(msr_query_chapter_element, parent))
            chapter_model.setChapter(chapter_or_msr_query)
        return chapter_model

    def readPredefinedChapter(self, element: ET.Element) -> PredefinedChapter:
        predefined = PredefinedChapter()
        chapter_model_element = self.find(element, "CHAPTER-MODEL")
        if chapter_model_element is not None:
            predefined.setChapterModel(self.readChapterModel(chapter_model_element, None))
        return predefined

    def readDocumentationContext(self, element: ET.Element, parent: ARObject) -> DocumentationContext:
        context = DocumentationContext(parent, self.getShortName(element))
        self.readMultilanguageReferrable(element, context)
        context.setFeatureIRef(self.getAnyInstanceRef(element, "FEATURE-IREF"))
        context.setIdentifiableRef(self.getChildElementOptionalRefType(element, "IDENTIFIABLE-REF"))
        return context

    def readDocumentation(self, element: ET.Element, documentation: Documentation):
        self.readARElement(element, documentation)
        for context_element in self.findall(element, "CONTEXTS/DOCUMENTATION-CONTEXT"):
            documentation.addContext(self.readDocumentationContext(context_element, documentation))
        documentation_content_element = self.find(element, "DOCUMENTATION-CONTENT")
        if documentation_content_element is not None:
            documentation.setDocumentationContent(self.readPredefinedChapter(documentation_content_element))
        return documentation

    def readChapterContent(self, element: ET.Element, parent: Chapter) -> ChapterContent:
        chapter_content = ChapterContent()
        topic_content_or_msr_query = self.readTopicContentOrMsrQuery(element, chapter_content)
        if topic_content_or_msr_query is not None:
            chapter_content.setTopicContent(topic_content_or_msr_query)
        prms_element = self.find(element, "PRMS")
        if prms_element is not None:
            chapter_content.setPrms(self.readPrms(prms_element, chapter_content))
        return chapter_content

    def readPrms(self, element: ET.Element, parent: ARObject) -> Prms:
        prms = Prms()
        self.readPaginateable(element, prms)
        label = self.getMultilanguageLongName(element, "LABEL")
        if label is not None:
            prms.setLabel(label)
        for prm_element in self.findall(element, "PRM"):
            prm = GeneralParameter(prms, self.getShortName(prm_element))
            self.readGeneralParameter(prm_element, prm)
            prms.addPrm(prm)
        return prms

    def readGeneralParameter(self, element: ET.Element, prm: GeneralParameter) -> GeneralParameter:
        self.readIdentifiable(element, prm)
        for prm_char_element in self.findall(element, "PRM-CHAR"):
            prm.addPrmChar(self.readPrmChar(prm_char_element))
        return prm

    def readPrmChar(self, element: ET.Element) -> PrmChar:
        prm_char = PrmChar()
        prm_char.setCond(self.getDocumentationBlock(element, "COND"))
        abs_element = self.find(element, "ABS")
        min_element = self.find(element, "MIN")
        text_element = self.find(element, "TEXT")
        if abs_element is not None or min_element is not None or self.find(element, "PRM-UNIT") is not None:
            numerical = PrmCharNumericalContents()
            if abs_element is not None or self.find(element, "TOL") is not None:
                numerical.setAbsTol(self.readPrmCharAbsTol(element))
            if min_element is not None or self.find(element, "TYP") is not None or self.find(element, "MAX") is not None:
                numerical.setMinTypMax(self.readPrmCharMinTypMax(element))
            numerical.setPrmUnit(self.getSingleLanguageUnitNames(element, "PRM-UNIT"))
            prm_char.setNumericalContents(numerical)
        if text_element is not None:
            textual = PrmCharTextualContents()
            textual.setText(String().setValue(text_element.text))
            prm_char.setTextualContents(textual)
        prm_char.setRemark(self.getDocumentationBlock(element, "REMARK"))
        return prm_char

    def readPrmCharAbsTol(self, element: ET.Element) -> PrmCharAbsTol:
        abs_tol = PrmCharAbsTol()
        abs_element = self.find(element, "ABS")
        if abs_element is not None:
            abs_tol.setAbs(Numerical().setValue(abs_element.text))
        tol_element = self.find(element, "TOL")
        if tol_element is not None:
            abs_tol.setTol(Numerical().setValue(tol_element.text))
        return abs_tol

    def readPrmCharMinTypMax(self, element: ET.Element) -> PrmCharMinTypMax:
        min_typ_max = PrmCharMinTypMax()
        min_element = self.find(element, "MIN")
        if min_element is not None:
            min_typ_max.setMin(Numerical().setValue(min_element.text))
        typ_element = self.find(element, "TYP")
        if typ_element is not None:
            min_typ_max.setTyp(Numerical().setValue(typ_element.text))
        max_element = self.find(element, "MAX")
        if max_element is not None:
            min_typ_max.setMax(Numerical().setValue(max_element.text))
        return min_typ_max

    def readTopicContentOrMsrQuery(self, element: ET.Element, parent: ARObject) -> "TopicContentOrMsrQuery":
        result = None
        msr_query_p1_element = self.find(element, "MSR-QUERY-P-1")
        topic_content_element = self.find(element, "TOPIC-CONTENT")
        if msr_query_p1_element is not None or topic_content_element is not None:
            result = TopicContentOrMsrQuery()
            if msr_query_p1_element is not None:
                result.setMsrQueryP1(self.readMsrQueryP1(msr_query_p1_element, parent))
            if topic_content_element is not None:
                result.setTopicContent(self.readTopicContent(topic_content_element, parent))
        return result

    def readMsrQueryP1(self, element: ET.Element, parent: ARObject) -> MsrQueryP1:
        msr_query_p1 = MsrQueryP1()
        self.readPaginateable(element, msr_query_p1)
        msr_query_props = self.find(element, "MSR-QUERY-PROPS")
        if msr_query_props is not None:
            msr_query_p1.setMsrQueryProps(self.getMsrQueryProps(msr_query_props))
        topic_content = self.find(element, "TOPIC-CONTENT")
        if topic_content is not None:
            msr_query_p1.setMsrQueryResultP1(self.readTopicContent(topic_content, msr_query_p1))
        return msr_query_p1

    def getMsrQueryP1(self, element: ET.Element, key: str) -> MsrQueryP1:
        child_element = self.find(element, key)
        if child_element is None:
            return None
        return self.readMsrQueryP1(child_element, None)

    def readTopicContent(self, element: ET.Element, parent: ARObject) -> TopicContent:
        topic_content = TopicContent()
        self.readARObject(element, topic_content)
        block_level_content = self.getDocumentationBlock(element, "DOCUMENTATION-BLOCK")
        if block_level_content is not None:
            topic_content.setBlockLevelContent(block_level_content)
        table_element = self.find(element, "TABLE")
        if table_element is not None:
            table = Table()
            self.readTable(table_element, table)
            topic_content.setTable(table)
        traceable_table_element = self.find(element, "TRACEABLE-TABLE")
        if traceable_table_element is not None:
            short_name_element = self.find(traceable_table_element, "SHORT-NAME")
            short_name = short_name_element.text if short_name_element is not None else "TRACEABLE-TABLE"
            traceable_table = topic_content.createTraceableTable(short_name)
            self.readTraceableTable(traceable_table_element, traceable_table)
        return topic_content

    def readTopic1(self, element: ET.Element, parent: Chapter) -> Topic1:
        topic1 = Topic1(parent, self.getShortName(element))
        self.readIdentifiable(element, topic1)
        help_entry = element.get("HELP-ENTRY")
        if help_entry is not None:
            topic1.setHelpEntry(String().setValue(help_entry))
        topic_content_or_msr_query = self.readTopicContentOrMsrQuery(element, topic1)
        if topic_content_or_msr_query is not None:
            topic1.setTopicContent(topic_content_or_msr_query)
        return topic1

    def readMsrQueryTopic1(self, element: ET.Element, parent: Chapter) -> MsrQueryTopic1:
        msr_query_topic1 = MsrQueryTopic1()
        self.readPaginateable(element, msr_query_topic1)
        msr_query_props = self.find(element, "MSR-QUERY-PROPS")
        if msr_query_props is not None:
            msr_query_topic1.setMsrQueryProps(self.getMsrQueryProps(msr_query_props))
        msr_query_result_topic1 = self.find(element, "MSR-QUERY-RESULT-TOPIC-1")
        if msr_query_result_topic1 is not None:
            result = MsrQueryResultTopic1()
            msr_query_topic1.setMsrQueryResultTopic1(result)
            self.readMsrQueryResultTopic1(msr_query_result_topic1, msr_query_topic1, result)
        return msr_query_topic1

    def getMsrQueryTopic1(self, element: ET.Element, key: str) -> MsrQueryTopic1:
        result = None
        child_element = self.find(element, key)
        if child_element is not None:
            result = self.readMsrQueryTopic1(child_element, None)
        return result

    def readMsrQueryResultChapter(self, element: ET.Element, parent: ARObject, result: MsrQueryResultChapter):
        self.readARObject(element, result)
        for child_element in self.findall(element, "CHAPTER"):
            result.addChapter(self.readChapter(child_element, parent))

    def readMsrQueryResultTopic1(self, element: ET.Element, parent: ARObject, result: MsrQueryResultTopic1):
        self.readARObject(element, result)
        for child_element in self.findall(element, "TOPIC-1"):
            result.addTopic1(self.readTopic1(child_element, parent))

    def getMsrQueryResultChapter(self, element: ET.Element, key: str) -> MsrQueryResultChapter:
        result = None
        child_element = self.find(element, key)
        if child_element is not None:
            result = MsrQueryResultChapter()
            self.readMsrQueryResultChapter(child_element, result, result)
        return result

    def getMsrQueryResultTopic1(self, element: ET.Element, key: str) -> MsrQueryResultTopic1:
        result = None
        child_element = self.find(element, key)
        if child_element is not None:
            result = MsrQueryResultTopic1()
            self.readMsrQueryResultTopic1(child_element, result, result)
        return result

    def readMsrQueryChapter(self, element: ET.Element, parent: Chapter) -> MsrQueryChapter:
        msr_query_chapter = MsrQueryChapter()
        self.readPaginateable(element, msr_query_chapter)
        msr_query_props = self.find(element, "MSR-QUERY-PROPS")
        if msr_query_props is not None:
            msr_query_chapter.setMsrQueryProps(self.getMsrQueryProps(msr_query_props))
        msr_query_result_chapter = self.find(element, "MSR-QUERY-RESULT-CHAPTER")
        if msr_query_result_chapter is not None:
            result = MsrQueryResultChapter()
            msr_query_chapter.setMsrQueryResultChapter(result)
            self.readMsrQueryResultChapter(msr_query_result_chapter, msr_query_chapter, result)
        return msr_query_chapter

    def readSwComponentType(self, element: ET.Element, parent: SwComponentType):
        self.readIdentifiable(element, parent)
        self.readSwComponentTypeSwComponentDocumentation(element, parent)
        self.readSwComponentTypeConsistencyNeeds(element, parent)
        self.readSwComponentTypePorts(element, parent)
        self.readSwComponentTypePortGroups(element, parent)
        self.readSwComponentTypeSwcMappingConstraints(element, parent)
        self.readSwComponentTypeUnitGroups(element, parent)

    def readAtomicSwComponentTypeSymbolProps(self, element: ET.Element, sw_component: AtomicSwComponentType):
        child_element = self.find(element, "SYMBOL-PROPS")
        if child_element is not None:
            props = sw_component.createSymbolProps(self.getShortName(child_element))
            self.readSymbolProps(child_element, props)

    def readAtomicSwComponentType(self, element, parent: AtomicSwComponentType):
        self.readSwComponentType(element, parent)
        self.readAtomicSwComponentTypeSwcInternalBehavior(element, parent)
        self.readAtomicSwComponentTypeSymbolProps(element, parent)

    def readEcuAbstractionSwComponentType(self, element, sw_component: EcuAbstractionSwComponentType):
        self.logger.debug("Read EcuAbstractionSwComponentType <%s>" % sw_component.getShortName())
        self.readAtomicSwComponentType(element, sw_component)
        self.readEcuAbstractionSwComponentTypeHardwareElementRefs(element, sw_component)

    def readEcuAbstractionSwComponentTypeHardwareElementRefs(self, element, sw_component: EcuAbstractionSwComponentType):
        for ref in self.getChildElementRefTypeList(element, "HARDWARE-ELEMENT-REFS/HARDWARE-ELEMENT-REF"):
            sw_component.addHardwareElementRef(ref)

    def readApplicationSwComponentType(self, element: ET.Element, sw_component: ApplicationSwComponentType):
        self.logger.debug("Read ApplicationSwComponentType <%s>" % sw_component.getShortName())
        self.readAtomicSwComponentType(element, sw_component)

    def readComplexDeviceDriverSwComponentType(self, element: ET.Element, type: ComplexDeviceDriverSwComponentType):
        self.logger.debug("Read ComplexDeviceDriverSwComponentType <%s>" % type.getShortName())
        self.readAtomicSwComponentType(element, type)
        for ref in self.getChildElementRefTypeList(element, "HARDWARE-ELEMENT-REFS/HARDWARE-ELEMENT-REF"):
            type.addHardwareElementRef(ref)

    def readSensorActuatorSwComponentType(self, element: ET.Element, sw_component: SensorActuatorSwComponentType):
        self.logger.debug("Read SensorActuatorSwComponentType <%s>" % sw_component.getShortName())
        self.readAtomicSwComponentType(element, sw_component)
        sw_component.setSensorActuatorRef(self.getChildElementOptionalRefType(element, "SENSOR-ACTUATOR-REF"))

    def readServiceSwComponentType(self, element: ET.Element, sw_component: ServiceSwComponentType):
        self.logger.debug("Read ServiceSwComponentType <%s>" % sw_component.getShortName())
        self.readAtomicSwComponentType(element, sw_component)

    def readServiceProxySwComponentType(self, element: ET.Element, sw_component: ServiceProxySwComponentType):
        self.logger.debug("Read ServiceProxySwComponentType <%s>" % sw_component.getShortName())
        self.readAtomicSwComponentType(element, sw_component)

    def readNvBlockSwComponentType(self, element: ET.Element, sw_component: NvBlockSwComponentType):
        self.logger.debug("Read NvBlockSwComponentType <%s>" % sw_component.getShortName())
        self.readAtomicSwComponentType(element, sw_component)
        for child_element in self.findall(element, "BULK-NV-DATA-DESCRIPTORS/BULK-NV-DATA-DESCRIPTOR"):
            descriptor = sw_component.createBulkNvDataDescriptor(self.getShortName(child_element))
            self.readBulkNvDataDescriptor(child_element, descriptor)
        for child_element in self.findall(element, "NV-BLOCK-DESCRIPTORS/NV-BLOCK-DESCRIPTOR"):
            descriptor = sw_component.createNvBlockDescriptor(self.getShortName(child_element))
            self.readNvBlockDescriptor(child_element, descriptor)

    def readPPortInCompositionInstanceRef(self, element: ET.Element, p_port_in_composition_instance_ref: PPortInCompositionInstanceRef):
        self.readARObject(element, p_port_in_composition_instance_ref)
        p_port_in_composition_instance_ref.setContextComponentRef(self.getChildElementOptionalRefType(element, "CONTEXT-COMPONENT-REF"))
        p_port_in_composition_instance_ref.setTargetPPortRef(self.getChildElementOptionalRefType(element, "TARGET-P-PORT-REF"))

        """
        self.logger.debug("PPortInCompositionInstanceRef")
        self.logger.debug("  CONTEXT-COMPONENT-REF DEST: %s, %s"
                          % (p_port_in_composition_instance_ref.getContextComponentRef().getDest(),
                             p_port_in_composition_instance_ref.getContextComponentRef().getValue()))
        self.logger.debug("  TARGET-P-PORT-REF DEST: %s, %s"
                          % (p_port_in_composition_instance_ref.getTargetPPortRef().getDest(),
                             p_port_in_composition_instance_ref.getTargetPPortRef().getValue()))
        """

    def readRPortInCompositionInstanceRef(self, element, r_port_in_composition_instance_ref: RPortInCompositionInstanceRef):
        self.readARObject(element, r_port_in_composition_instance_ref)
        r_port_in_composition_instance_ref.setContextComponentRef(self.getChildElementOptionalRefType(element, "CONTEXT-COMPONENT-REF"))
        r_port_in_composition_instance_ref.setTargetRPortRef(self.getChildElementOptionalRefType(element, "TARGET-R-PORT-REF"))

        """
        self.logger.debug("RPortInCompositionInstanceRef")
        self.logger.debug("  CONTEXT-COMPONENT-REF DEST: %s, %s"
                          % (r_port_in_composition_instance_ref.getContextComponentRef().getDest(),
                             r_port_in_composition_instance_ref.getContextComponentRef().getValue()))
        self.logger.debug("  TARGET-P-PORT-REF DEST: %s, %s"
                          % (r_port_in_composition_instance_ref.getTargetRPortRef().getDest(),
                             r_port_in_composition_instance_ref.getTargetRPortRef().getValue()))
        """

    def readAssemblySwConnectorProviderIRef(self, element: ET.Element, parent: AssemblySwConnector):
        child_element = self.find(element, "PROVIDER-IREF")
        if child_element is not None:
            provide_iref = PPortInCompositionInstanceRef()
            self.readPPortInCompositionInstanceRef(child_element, provide_iref)
            parent.setProviderIRef(provide_iref)

    def readAssemblySwConnectorRequesterIRef(self, element: ET.Element, parent: AssemblySwConnector):
        child_element = self.find(element, "REQUESTER-IREF")
        if child_element is not None:
            requester_iref = RPortInCompositionInstanceRef()
            self.readRPortInCompositionInstanceRef(child_element, requester_iref)
            parent.setRequesterIRef(requester_iref)

    def readSwConnector(self, element: ET.Element, connector: SwConnector):
        self.readIdentifiable(element, connector)
        connector.setMappingRef(self.getChildElementOptionalRefType(element, "MAPPING-REF"))

    def readAssemblySwConnector(self, element: ET.Element, connector: AssemblySwConnector):
        # self.logger.debug("Read AssemblySwConnectors %s" % connector.getShortName())
        self.readSwConnector(element, connector)
        self.readAssemblySwConnectorProviderIRef(element, connector)
        self.readAssemblySwConnectorRequesterIRef(element, connector)

    def readCompositionSwComponentTypeSwConnectors(self, element: ET.Element, parent: CompositionSwComponentType):
        for child_element in self.findall(element, "CONNECTORS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ASSEMBLY-SW-CONNECTOR":
                connector = parent.createAssemblySwConnector(self.getShortName(child_element))
                self.readAssemblySwConnector(child_element, connector)
            elif tag_name == "DELEGATION-SW-CONNECTOR":
                connector = parent.createDelegationSwConnector(self.getShortName(child_element))
                self.readDelegationSwConnector(child_element, connector)
            elif tag_name == "PASS-THROUGH-SW-CONNECTOR":
                connector = parent.createPassThroughSwConnector(self.getShortName(child_element))
                self.readPassThroughSwConnector(child_element, connector)
            else:
                self.notImplemented("Unsupported SwConnector <%s>" % tag_name)

    def readPassThroughSwConnector(self, element: ET.Element, connector: PassThroughSwConnector):
        self.readSwConnector(element, connector)
        connector.setProvidedOuterPortRef(self.getChildElementOptionalRefType(element, "PROVIDED-OUTER-PORT-REF"))
        connector.setRequiredOuterPortRef(self.getChildElementOptionalRefType(element, "REQUIRED-OUTER-PORT-REF"))

    def readDelegationSwConnectorInnerPortIRef(self, element, parent: DelegationSwConnector):
        inner_port_iref_element = self.find(element, "INNER-PORT-IREF")
        if inner_port_iref_element is not None:
            child_element = self.find(inner_port_iref_element, "R-PORT-IN-COMPOSITION-INSTANCE-REF")
            if child_element is not None:
                r_port_in_composition_instance_ref = RPortInCompositionInstanceRef()
                self.readRPortInCompositionInstanceRef(child_element, r_port_in_composition_instance_ref)
                parent.setInnerPortIRef(r_port_in_composition_instance_ref)
                return

            child_element = self.find(inner_port_iref_element, "P-PORT-IN-COMPOSITION-INSTANCE-REF")
            if child_element is not None:
                p_port_in_composition_instance_ref = PPortInCompositionInstanceRef()
                self.readPPortInCompositionInstanceRef(child_element, p_port_in_composition_instance_ref)
                parent.setInnerPortIRef(p_port_in_composition_instance_ref)
                return

            self.raiseError("Unsupported child element of INNER-PORT-IREF")

    def readDelegationSwConnector(self, element, connector: DelegationSwConnector):
        # self.logger.debug("Read DelegationSwConnectors %s" % connector.getShortName())
        self.readSwConnector(element, connector)
        self.readDelegationSwConnectorInnerPortIRef(element, connector)
        connector.setOuterPortRef(self.getChildElementOptionalRefType(element, "OUTER-PORT-REF"))

        if connector.getInnerPortIRef() is None and connector.getOuterPortRef() is None:
            self.raiseError("Invalid PortPrototype of DELEGATION-SW-CONNECTOR")
        # self.logger.debug("OUTER-PORT-REF DEST: %s, %s" % (connector.getOuterPortRef().getDest(), connector.getOuterPortRef().getValue()))

    def readSwComponentPrototype(self, element: ET.Element, prototype: SwComponentPrototype):
        self.logger.debug("Read SwComponentPrototypes <%s>" % prototype.getShortName())
        self.readIdentifiable(element, prototype)
        prototype.setTypeTRef(self.getChildElementOptionalRefType(element, "TYPE-TREF"))

    def readCompositionSwComponentTypeComponents(self, element: ET.Element, parent: CompositionSwComponentType):
        for child_element in self.findall(element, "COMPONENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SW-COMPONENT-PROTOTYPE":
                prototype = parent.createSwComponentPrototype(self.getShortName(child_element))
                self.readSwComponentPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported Component <%s>" % tag_name)

    def readCompositionSwComponentTypeDataTypeMappingSet(self, element: ET.Element, parent: CompositionSwComponentType):
        child_element = self.find(element, "DATA-TYPE-MAPPING-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "DATA-TYPE-MAPPING-REF"):
                parent.addDataTypeMappingRef(ref)

    def readCompositionSwComponentTypeConstantValueMappingSet(self, element: ET.Element, parent: CompositionSwComponentType):
        child_element = self.find(element, "CONSTANT-VALUE-MAPPING-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "CONSTANT-VALUE-MAPPING-REF"):
                parent.addConstantValueMappingRef(ref)

    def readInstanceEventInCompositionInstanceRef(self, element: ET.Element, instance_ref: InstanceEventInCompositionInstanceRef):
        for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-PROTOTYPE-REF"):
            instance_ref.addContextComponentPrototypeRef(ref)
        instance_ref.setTargetEventRef(self.getChildElementOptionalRefType(element, "TARGET-EVENT-REF"))

    def readInstantiationRTEEventProps(self, element: ET.Element, props: InstantiationTimingEventProps):
        refined_event_element = self.find(element, "REFINED-EVENT-IREF")
        if refined_event_element is not None:
            refined_event = InstanceEventInCompositionInstanceRef()
            self.readARObject(refined_event_element, refined_event)
            self.readInstanceEventInCompositionInstanceRef(refined_event_element, refined_event)
            props.setRefinedEventIRef(refined_event)
        props.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        self.readVariationPointCapable(element, props)

    def readInstantiationTimingEventProps(self, element: ET.Element, props: InstantiationTimingEventProps):
        self.readInstantiationRTEEventProps(element, props)
        props.setPeriod(self.getChildElementOptionalTimeValue(element, "PERIOD"))

    def readCompositionSwComponentTypeInstantiationRTEEventProps(self, element: ET.Element, parent: CompositionSwComponentType):
        child_element = self.find(element, "INSTANTIATION-RTE-EVENT-PROPSS")
        if child_element is not None:
            for props_element in self.findall(child_element, "INSTANTIATION-TIMING-EVENT-PROPS"):
                props = InstantiationTimingEventProps()
                self.readARObject(props_element, props)
                self.readInstantiationTimingEventProps(props_element, props)
                parent.addInstantiationRTEEventProps(props)

    def readCompositionSwComponentTypePhysicalDimensionMapping(self, element: ET.Element, parent: CompositionSwComponentType):
        parent.setPhysicalDimensionMappingRef(self.getChildElementOptionalRefType(element, "PHYSICAL-DIMENSION-MAPPING-REF"))

    def readCompositionSwComponentType(self, element: ET.Element, type: CompositionSwComponentType):
        self.logger.debug("Read CompositionSwComponentType: <%s>" % type.getShortName())
        self.readSwComponentType(element, type)
        self.readCompositionSwComponentTypeComponents(element, type)
        self.readCompositionSwComponentTypeSwConnectors(element, type)
        self.readCompositionSwComponentTypeDataTypeMappingSet(element, type)
        self.readCompositionSwComponentTypeConstantValueMappingSet(element, type)
        self.readCompositionSwComponentTypeInstantiationRTEEventProps(element, type)
        self.readCompositionSwComponentTypePhysicalDimensionMapping(element, type)
        document = AUTOSAR.getInstance()
        document.addCompositionSwComponentType(type)

    def readDataTypeMaps(self, element: ET.Element, parent: DataTypeMappingSet):
        for child_element in element.findall("./xmlns:DATA-TYPE-MAPS/xmlns:DATA-TYPE-MAP", self.nsmap):
            data_type_map = DataTypeMap()
            self.readARObject(child_element, data_type_map)
            data_type_map.setApplicationDataTypeRef(self.getChildElementOptionalRefType(child_element, "APPLICATION-DATA-TYPE-REF"))
            data_type_map.setImplementationDataTypeRef(self.getChildElementOptionalRefType(child_element, "IMPLEMENTATION-DATA-TYPE-REF"))
            parent.addDataTypeMap(data_type_map)
            # add the data type map to global namespace
            document = AUTOSAR.getInstance()
            document.addDataTypeMap(data_type_map)

    def readModeRequestTypeMaps(self, element: ET.Element, parent: DataTypeMappingSet):
        for child_element in element.findall("./xmlns:MODE-REQUEST-TYPE-MAPS/xmlns:MODE-REQUEST-TYPE-MAP", self.nsmap):
            map = ModeRequestTypeMap()
            self.readARObject(child_element, map)
            map.setImplementationDataTypeRef(self.getChildElementOptionalRefType(child_element, "IMPLEMENTATION-DATA-TYPE-REF"))
            map.setModeGroupRef(self.getChildElementOptionalRefType(child_element, "MODE-GROUP-REF"))
            parent.addModeRequestTypeMap(map)

    def readDataTypeMappingSet(self, element: ET.Element, mapping_set: DataTypeMappingSet):
        self.logger.debug("Read DataTypeMappingSet: <%s>" % mapping_set.getShortName())
        self.readIdentifiable(element, mapping_set)
        self.readDataTypeMaps(element, mapping_set)
        self.readModeRequestTypeMaps(element, mapping_set)

    def readSenderReceiverInterfaceDataElements(self, element: ET.Element, sr_interface: SenderReceiverInterface):
        for child_element in self.findall(element, "DATA-ELEMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-DATA-PROTOTYPE":
                prototype = sr_interface.createDataElement(self.getShortName(child_element))
                self.readVariableDataPrototype(child_element, prototype)
                # prototype.swDataDefProps = self.getSwDataDefProps(child_element, "SW-DATA-DEF-PROPS")
                # self.readAutosarDataPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported Data Element <%s>" % tag_name)

    def readSenderReceiverInterfaceInvalidationPolicies(self, element: ET.Element, sr_interface: SenderReceiverInterface):
        for child_element in self.findall(element, "INVALIDATION-POLICYS/INVALIDATION-POLICY"):
            policy = InvalidationPolicy()
            policy.setDataElementRef(self.getChildElementOptionalRefType(child_element, "DATA-ELEMENT-REF"))
            policy.setHandleInvalid(self.getChildElementOptionalLiteral(child_element, "HANDLE-INVALID"))
            sr_interface.addInvalidationPolicy(policy)

    def readSenderReceiverInterfaceMetaDataItemSets(self, element: ET.Element, sr_interface: SenderReceiverInterface):
        for child_element in self.findall(element, "META-DATA-ITEM-SETS/META-DATA-ITEM-SET"):
            mapping_set = MetaDataItemSet()
            self.readMetaDataItemSet(child_element, mapping_set)
            sr_interface.addMetaDataItemSet(mapping_set)

    def readMetaDataItemSet(self, element: ET.Element, mapping_set: MetaDataItemSet):
        for ref in self.getChildElementRefTypeList(element, "DATA-ELEMENT-REFS/DATA-ELEMENT-REF"):
            mapping_set.addDataElementRef(ref)
        for child_element in self.findall(element, "META-DATA-ITEMS/META-DATA-ITEM"):
            item = MetaDataItem()
            self.readMetaDataItem(child_element, item)
            mapping_set.addMetaDataItem(item)

    def readMetaDataItem(self, element: ET.Element, item: MetaDataItem):
        item.setLength(self.getChildElementOptionalPositiveInteger(element, "LENGTH"))
        type_element = self.find(element, "META-DATA-ITEM-TYPE")
        if type_element is not None:
            item.setMetaDataItemType(self.getTextValueSpecification(type_element))

    def readSenderReceiverInterface(self, element, sr_interface: SenderReceiverInterface):
        self.logger.debug("Read SenderReceiverInterface <%s>" % sr_interface.getShortName())
        self.readIdentifiable(element, sr_interface)
        sr_interface.setIsService(self.getChildElementOptionalBooleanValue(element, "IS-SERVICE"))
        self.readSenderReceiverInterfaceDataElements(element, sr_interface)
        self.readSenderReceiverInterfaceInvalidationPolicies(element, sr_interface)
        self.readSenderReceiverInterfaceMetaDataItemSets(element, sr_interface)

    def readArgumentDataPrototype(self, element: ET.Element, prototype: ArgumentDataPrototype):
        self.readAutosarDataPrototype(element, prototype)
        prototype.setDirection(self.getChildElementOptionalLiteral(element, "DIRECTION"))
        prototype.setServerArgumentImplPolicy(self.getChildElementOptionalLiteral(element, "SERVER-ARGUMENT-IMPL-POLICY"))

    def readClientServerOperationArguments(self, element: ET.Element, operation: ClientServerOperation):
        for child_element in self.findall(element, "ARGUMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ARGUMENT-DATA-PROTOTYPE":
                prototype = operation.createArgumentDataPrototype(self.getShortName(child_element))
                self.readArgumentDataPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported Argument <%s>" % tag_name)

    def readPossibleErrorRefs(self, element: ET.Element, parent: ClientServerOperation):
        child_element = self.find(element, "POSSIBLE-ERROR-REFS")
        if child_element is not None:
            for ref in self.getChildElementRefTypeList(child_element, "POSSIBLE-ERROR-REF"):
                parent.addPossibleErrorRef(ref)

    def readClientServerOperation(self, element: ET.Element, operation: ClientServerOperation):
        self.readIdentifiable(element, operation)
        self.readClientServerOperationArguments(element, operation)
        operation.setDiagArgIntegrity(self.getChildElementOptionalBooleanValue(element, "DIAG-ARG-INTEGRITY"))
        self.readPossibleErrorRefs(element, operation)

    def readClientServerInterfaceOperations(self, element: ET.Element, parent: ClientServerInterface):
        for child_element in self.findall(element, "OPERATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CLIENT-SERVER-OPERATION":
                operation = parent.createOperation(self.getShortName(child_element))
                self.readClientServerOperation(child_element, operation)
            else:
                self.notImplemented("Unsupported Operation <%s>" % tag_name)

    def readPossibleErrors(self, element: ET.Element, parent: ClientServerInterface):
        for child_element in self.findall(element, "POSSIBLE-ERRORS/APPLICATION-ERROR"):
            short_name = self.getShortName(child_element)
            error = parent.createApplicationError(short_name)
            self.readIdentifiable(child_element, error)  # some errors has its uuid
            error.setErrorCode(self.getChildElementOptionalIntegerValue(child_element, "ERROR-CODE"))

    def readPortInterface(self, element: ET.Element, port_interface: PortInterface):
        self.readIdentifiable(element, port_interface)
        port_interface.setIsService(self.getChildElementOptionalBooleanValue(element, "IS-SERVICE"))
        port_interface.setServiceKind(self.getChildElementOptionalLiteral(element, "SERVICE-KIND"))

    def readParameterInterfaceParameters(self, element: ET.Element, param_interface: ParameterInterface):
        for child_element in self.findall(element, "PARAMETERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PARAMETER-DATA-PROTOTYPE":
                prototype = param_interface.createParameterDataPrototype(self.getShortName(child_element))
                self.readParameterDataPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported Parameter <%s>" % tag_name)

    def readDataInterface(self, element: ET.Element, interface: DataInterface):
        self.readPortInterface(element, interface)

    def readParameterInterface(self, element: ET.Element, interface: ParameterInterface):
        self.logger.debug("Read ParameterInterface <%s>" % interface.getShortName())
        self.readDataInterface(element, interface)
        self.readParameterInterfaceParameters(element, interface)

    def readNvDataInterfaceNvDatas(self, element: ET.Element, nv_interface: NvDataInterface):
        for child_element in self.findall(element, "NV-DATAS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-DATA-PROTOTYPE":
                prototype = nv_interface.createNvData(self.getShortName(child_element))
                self.readVariableDataPrototype(child_element, prototype)
            else:
                self.notImplemented("Unsupported NvData <%s>" % tag_name)

    def readNvDataInterface(self, element: ET.Element, nv_interface: NvDataInterface):
        self.logger.debug("Read NvDataInterface <%s>" % nv_interface.getShortName())
        self.readDataInterface(element, nv_interface)
        self.readNvDataInterfaceNvDatas(element, nv_interface)

    def readClientServerInterface(self, element: ET.Element, cs_interface: ClientServerInterface):
        self.logger.debug("Read ClientServerInterface <%s>" % cs_interface.getShortName())
        self.readPortInterface(element, cs_interface)
        self.readClientServerInterfaceOperations(element, cs_interface)
        self.readPossibleErrors(element, cs_interface)

    def getCompuConstContent(self, element: ET.Element) -> CompuConstContent:
        child_element = self.find(element, "*")
        content = None
        if child_element is not None:
            tag_name = self.getTagName(child_element)
            if tag_name == "VF":
                content = CompuConstFormulaContent()
                content.setVf(self.getChildElementOptionalNumericalValue(element, "VF"))
            elif tag_name == "V":
                content = CompuConstNumericContent()
                content.setV(self.getChildElementOptionalNumericalValue(element, "V"))
            elif tag_name == "VT":
                content = CompuConstTextContent()
                content.setVt(self.getChildElementOptionalVerbatimString(element, "VT"))
            else:
                self.notImplemented("Unsupported CompuConstContent <%s>" % tag_name)
        return content

    def getCompuConst(self, element: ET.Element, key: str) -> CompuConst:
        compu_const = None
        child_element = self.find(element, key)
        if child_element is not None:
            compu_const = CompuConst()
            self.readARObject(child_element, compu_const)
            compu_const.setCompuConstContentType(self.getCompuConstContent(child_element))
        return compu_const

    def readCompuConst(self, element: ET.Element, parent: CompuScale):
        child_element = self.find(element, "COMPU-CONST/VT")
        if child_element is not None:
            # self.logger.debug("Read CompuConst VT: %s" % child_element.text)
            contents = CompuScaleConstantContents()
            contents.compuConst = CompuConst()
            contents.compuConst.compuConstContentType = CompuConstTextContent()
            contents.compuConst.compuConstContentType.vt = ARLiteral()
            contents.compuConst.compuConstContentType.vt.setValue(child_element.text)
            parent.compuScaleContents = contents

    def readCompuNominatorDenominator(self, element: ET.Element, key: str, parent: CompuNominatorDenominator):
        for child_element in self.findall(element, "%s/V" % key):
            # self.logger.debug("Read CompuNominatorDenominator - %s: %s" % (key, child_element.text))
            parent.addV(Numerical().setValue(child_element.text))

    def readCompuRationCoeffs(self, element: ET.Element, parent: CompuScale):
        child_element = self.find(element, "COMPU-RATIONAL-COEFFS")
        if child_element is not None:
            # self.logger.debug("Read CompuRationCoeffs")
            contents = CompuScaleRationalFormula()
            contents.compuRationalCoeffs = CompuRationalCoeffs()
            contents.compuRationalCoeffs.compuDenominator = CompuNominatorDenominator()
            contents.compuRationalCoeffs.compuNumerator = CompuNominatorDenominator()
            self.readCompuNominatorDenominator(child_element, "COMPU-DENOMINATOR", contents.compuRationalCoeffs.compuDenominator)
            self.readCompuNominatorDenominator(child_element, "COMPU-NUMERATOR", contents.compuRationalCoeffs.compuNumerator)
            parent.compuScaleContents = contents

    def readCompuScaleContents(self, element: ET.Element, parent: CompuScale):
        self.readCompuConst(element, parent)
        self.readCompuRationCoeffs(element, parent)

    def readCompuScale(self, element: ET.Element, compu_scale: CompuScale):
        self.readARObject(element, compu_scale)
        compu_scale.setA2lDisplayText(self.getChildElementOptionalLiteral(element, "A2L-DISPLAY-TEXT"))
        compu_scale.setCompuInverseValue(self.getCompuConst(element, "COMPU-INVERSE-VALUE"))
        compu_scale.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        compu_scale.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))
        compu_scale.setDesc(self.getMultiLanguageOverviewParagraph(element, "DESC"))
        compu_scale.setMask(self.getChildElementOptionalPositiveInteger(element, "MASK"))
        compu_scale.setLowerLimit(self.getChildLimitElement(element, "LOWER-LIMIT"))
        compu_scale.setUpperLimit(self.getChildLimitElement(element, "UPPER-LIMIT"))
        self.readCompuScaleContents(element, compu_scale)

    def getCompuScales(self, element: ET.Element) -> CompuScales:
        compu_scales = None
        compu_scales_tag = self.find(element, "COMPU-SCALES")
        if compu_scales_tag is not None:
            compu_scales = CompuScales()
            for child_element in self.findall(compu_scales_tag, "COMPU-SCALE"):
                compu_scale = CompuScale()
                self.readCompuScale(child_element, compu_scale)
                compu_scales.addCompuScale(compu_scale)
        return compu_scales

    def getCompu(self, element: ET.Element, key: str) -> Compu:
        child_element = self.find(element, key)
        compu = None
        if child_element is not None:
            compu = Compu()
            self.readARObject(child_element, compu)
            compu.setCompuContent(self.getCompuScales(child_element))
            compu.setCompuDefaultValue(self.getCompuConst(child_element, "COMPU-DEFAULT-VALUE"))
        return compu

    def readCompuMethod(self, element: ET.Element, compu_method: CompuMethod):
        self.logger.debug("Read CompuMethod <%s>" % compu_method.getShortName())
        self.readIdentifiable(element, compu_method)
        compu_method.setDisplayFormat(self.getChildElementOptionalLiteral(element, "DISPLAY-FORMAT"))
        compu_method.setUnitRef(self.getChildElementOptionalRefType(element, "UNIT-REF"))
        compu_method.setCompuInternalToPhys(self.getCompu(element, "COMPU-INTERNAL-TO-PHYS"))
        compu_method.setCompuPhysToInternal(self.getCompu(element, "COMPU-PHYS-TO-INTERNAL"))

    def readSwcBswMappingSwcBswRunnableMappings(self, element: ET.Element, parent: SwcBswMapping):
        for child_element in self.findall(element, "RUNNABLE-MAPPINGS/SWC-BSW-RUNNABLE-MAPPING"):
            mapping = SwcBswRunnableMapping()
            mapping.setBswEntityRef(self.getChildElementOptionalRefType(child_element, "BSW-ENTITY-REF"))
            mapping.setSwcRunnableRef(self.getChildElementOptionalRefType(child_element, "SWC-RUNNABLE-REF"))
            variation_point_element = self.find(child_element, "VARIATION-POINT")
            if variation_point_element is not None:
                if isinstance(mapping, VariationPointCapable):
                    mapping.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
                else:
                    self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(child_element.tag))
            parent.addRunnableMapping(mapping)

    def readSwcBswSynchronizedModeGroupPrototype(self, element: ET.Element) -> SwcBswSynchronizedModeGroupPrototype:
        mode_group = SwcBswSynchronizedModeGroupPrototype()
        mode_group.setBswModeGroupRef(self.getChildElementOptionalRefType(element, "BSW-MODE-GROUP-REF"))
        child_element = self.find(element, "SWC-MODE-GROUP-IREF")
        if child_element is not None:
            instance_ref = PModeGroupInAtomicSwcInstanceRef()
            self.readPModeGroupInAtomicSWCInstanceRef(child_element, instance_ref)
            mode_group.setSwcModeGroupIRef(instance_ref)
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(mode_group, VariationPointCapable):
                mode_group.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))
        return mode_group

    def readSwcBswSynchronizedTrigger(self, element: ET.Element) -> SwcBswSynchronizedTrigger:
        trigger = SwcBswSynchronizedTrigger()
        trigger.setBswTriggerRef(self.getChildElementOptionalRefType(element, "BSW-TRIGGER-REF"))
        child_element = self.find(element, "SWC-TRIGGER-IREF")
        if child_element is not None:
            instance_ref = PTriggerInAtomicSwcTypeInstanceRef()
            self.readPTriggerInAtomicSwcTypeInstanceRef(child_element, instance_ref)
            trigger.setSwcTriggerIRef(instance_ref)
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(trigger, VariationPointCapable):
                trigger.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))
        return trigger

    def readSwcBswMappingSwcBswSynchronizedModeGroups(self, element: ET.Element, parent: SwcBswMapping):
        for child_element in self.findall(element, "SYNCHRONIZED-MODE-GROUPS/SWC-BSW-SYNCHRONIZED-MODE-GROUP-PROTOTYPE"):
            parent.addSynchronizedModeGroup(self.readSwcBswSynchronizedModeGroupPrototype(child_element))

    def readSwcBswMappingSwcBswSynchronizedTriggers(self, element: ET.Element, parent: SwcBswMapping):
        for child_element in self.findall(element, "SYNCHRONIZED-TRIGGERS/SWC-BSW-SYNCHRONIZED-TRIGGER"):
            parent.addSynchronizedTrigger(self.readSwcBswSynchronizedTrigger(child_element))

    def readSwcBswMapping(self, element: ET.Element, mapping: SwcBswMapping):
        self.logger.debug("Read SwcBswMapping <%s>" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        mapping.setBswBehaviorRef(self.getChildElementOptionalRefType(element, "BSW-BEHAVIOR-REF"))
        self.readSwcBswMappingSwcBswRunnableMappings(element, mapping)
        self.readSwcBswMappingSwcBswSynchronizedModeGroups(element, mapping)
        self.readSwcBswMappingSwcBswSynchronizedTriggers(element, mapping)
        mapping.setSwcBehaviorRef(self.getChildElementOptionalRefType(element, "SWC-BEHAVIOR-REF"))

    def readValueSpecification(self, element: ET.Element, value_spec: ValueSpecification):
        self.readARObject(element, value_spec)
        value_spec.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        self.readVariationPointCapable(element, value_spec)
        # self.logger.debug("read ValueSpecification")

    def getApplicationValueSpecification(self, element: ET.Element) -> ApplicationValueSpecification:
        value_spec = ApplicationValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        value_spec.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        value_spec.setSwValueCont(self.getSwValueCont(element))
        return value_spec

    def getNumericalOrText(self, element: ET.Element) -> NumericalOrText:
        not_text = NumericalOrText()
        self.readARObject(element, not_text)
        not_text.setVf(self.getChildElementOptionalNumericalValue(element, "VF"))
        not_text.setVt(self.getChildElementOptionalLiteral(element, "VT"))
        self.readVariationPointCapable(element, not_text)
        return not_text

    def getRuleArguments(self, element: ET.Element) -> RuleArguments:
        arguments = RuleArguments()
        self.readARObject(element, arguments)
        arguments.setV(self.getChildElementOptionalNumericalValue(element, "V"))
        arguments.setVf(self.getChildElementOptionalNumericalValue(element, "VF"))
        arguments.setVt(self.getChildElementOptionalVerbatimString(element, "VT"))
        vtf = self.find(element, "VTF")
        if vtf is not None:
            arguments.setVtf(self.getNumericalOrText(vtf))
        self.readVariationPointCapable(element, arguments)
        return arguments

    def getRuleBasedValueSpecification(self, element: ET.Element) -> RuleBasedValueSpecification:
        if element is None:
            return None
        value_spec = RuleBasedValueSpecification()
        self.readARObject(element, value_spec)
        value_spec.setRule(self.getChildElementOptionalIdentifier(element, "RULE"))
        for child_element in self.findall(element, "ARGUMENTSS/RULE-ARGUMENTS"):
            value_spec.addArgument(self.getRuleArguments(child_element))
        value_spec.setMaxSizeToFill(self.getChildElementOptionalPositiveInteger(element, "MAX-SIZE-TO-FILL"))
        return value_spec

    def getRuleBasedAxisCont(self, element: ET.Element) -> RuleBasedAxisCont:
        cont = RuleBasedAxisCont()
        self.readARObject(element, cont)
        cont.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        cont.setUnitRef(self.getChildElementOptionalRefType(element, "UNIT-REF"))
        cont.setSwArraysize(self.getValueList(element, "SW-ARRAYSIZE"))
        cont.setSwAxisIndex(self.getChildElementOptionalLiteral(element, "SW-AXIS-INDEX"))
        cont.setRuleBasedValues(self.getRuleBasedValueSpecification(self.find(element, "RULE-BASED-VALUES")))
        return cont

    def getRuleBasedValueCont(self, element: ET.Element) -> RuleBasedValueCont:
        cont = None
        child_element = self.find(element, "SW-VALUE-CONT")
        if child_element is not None:
            cont = RuleBasedValueCont()
            self.readARObject(child_element, cont)
            cont.setUnitRef(self.getChildElementOptionalRefType(child_element, "UNIT-REF"))
            cont.setSwArraysize(self.getValueList(child_element, "SW-ARRAYSIZE"))
            cont.setRuleBasedValues(self.getRuleBasedValueSpecification(self.find(child_element, "RULE-BASED-VALUES")))
        return cont

    def getApplicationRuleBasedValueSpecification(self, element: ET.Element) -> ApplicationRuleBasedValueSpecification:
        value_spec = ApplicationRuleBasedValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        for child_element in self.findall(element, "SW-AXIS-CONTS/RULE-BASED-AXIS-CONT"):
            value_spec.addSwAxisCont(self.getRuleBasedAxisCont(child_element))
        value_spec.setSwValueCont(self.getRuleBasedValueCont(element))
        return value_spec

    def getCompositeRuleBasedValueSpecification(self, element: ET.Element) -> CompositeRuleBasedValueSpecification:
        value_spec = CompositeRuleBasedValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setRule(self.getChildElementOptionalIdentifier(element, "RULE"))
        for child_element in self.findall(element, "ARGUMENTS/*"):
            value_spec.addArgument(self.getValueSpecification(child_element, self.getTagName(child_element)))
        for child_element in self.findall(element, "COMPOUND-PRIMITIVE-ARGUMENTS/*"):
            value_spec.addCompoundPrimitiveArgument(self.getValueSpecification(child_element, self.getTagName(child_element)))
        value_spec.setMaxSizeToFill(self.getChildElementOptionalPositiveInteger(element, "MAX-SIZE-TO-FILL"))
        return value_spec

    def getNumericalValueSpecification(self, element: ET.Element) -> NumericalValueSpecification:
        value_spec = NumericalValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        value_spec.setValue(self.getChildElementOptionalNumericalValue(element, "VALUE"))
        return value_spec

    def getTextValueSpecification(self, element: ET.Element) -> TextValueSpecification:
        # self.logger.debug("Get TextValueSpecification")
        value_spec = TextValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        value_spec.setValue(self.getChildElementOptionalVerbatimString(element, "VALUE"))
        return value_spec

    def getArrayValueSpecification(self, element: ET.Element) -> ArrayValueSpecification:
        # self.logger.debug("Get ArrayValueSpecification")
        value_spec = ArrayValueSpecification()
        self.readValueSpecification(element, value_spec)
        child_elements = element.findall("./xmlns:ELEMENTS/*", self.nsmap)
        for child_element in child_elements:
            value_spec.addElement(self.getValueSpecification(child_element, self.getTagName(child_element)))
        value_spec.setIntendedPartialInitializationCount(self.getChildElementOptionalPositiveInteger(element, "INTENDED-PARTIAL-INITIALIZATION-COUNT"))
        return value_spec

    def getConstantReference(self, element: ET.Element) -> ConstantReference:
        # self.logger.debug("getConstantReference")
        value_spec = ConstantReference()
        self.readValueSpecification(element, value_spec)
        value_spec.setConstantRef(self.getChildElementOptionalRefType(element, "CONSTANT-REF"))
        return value_spec

    def getReferenceValueSpecification(self, element: ET.Element) -> ReferenceValueSpecification:
        value_spec = ReferenceValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setReferenceValueRef(self.getChildElementOptionalRefType(element, "REFERENCE-VALUE-REF"))
        return value_spec

    def getNotAvailableValueSpecification(self, element: ET.Element) -> NotAvailableValueSpecification:
        value_spec = NotAvailableValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setDefaultPattern(self.getChildElementOptionalPositiveInteger(element, "DEFAULT-PATTERN"))
        return value_spec

    def getNumericalRuleBasedValueSpecification(self, element: ET.Element) -> NumericalRuleBasedValueSpecification:
        value_spec = NumericalRuleBasedValueSpecification()
        self.readValueSpecification(element, value_spec)
        value_spec.setRuleBasedValues(self.getRuleBasedValueSpecification(self.find(element, "RULE-BASED-VALUES")))
        return value_spec

    def getConstantSpecificationMapping(self, element: ET.Element) -> ConstantSpecificationMapping:
        mapping = ConstantSpecificationMapping()
        self.readARObject(element, mapping)
        mapping.setApplConstantRef(self.getChildElementOptionalRefType(element, "APPL-CONSTANT-REF"))
        mapping.setImplConstantRef(self.getChildElementOptionalRefType(element, "IMPL-CONSTANT-REF"))
        return mapping

    def getValueSpecification(self, element: ET.Element, tag_name: str) -> ValueSpecification:
        if tag_name == "APPLICATION-VALUE-SPECIFICATION":
            value_spec = self.getApplicationValueSpecification(element)
        elif tag_name == "APPLICATION-RULE-BASED-VALUE-SPECIFICATION":
            value_spec = self.getApplicationRuleBasedValueSpecification(element)
        elif tag_name == "COMPOSITE-RULE-BASED-VALUE-SPECIFICATION":
            value_spec = self.getCompositeRuleBasedValueSpecification(element)
        elif tag_name == "RECORD-VALUE-SPECIFICATION":
            value_spec = self.getRecordValueSpecification(element)
        elif tag_name == "NUMERICAL-VALUE-SPECIFICATION":
            value_spec = self.getNumericalValueSpecification(element)
        elif tag_name == "ARRAY-VALUE-SPECIFICATION":
            value_spec = self.getArrayValueSpecification(element)
        elif tag_name == "TEXT-VALUE-SPECIFICATION":
            value_spec = self.getTextValueSpecification(element)
        elif tag_name == "CONSTANT-REFERENCE":
            value_spec = self.getConstantReference(element)
        elif tag_name == "REFERENCE-VALUE-SPECIFICATION":
            value_spec = self.getReferenceValueSpecification(element)
        elif tag_name == "NOT-AVAILABLE-VALUE-SPECIFICATION":
            value_spec = self.getNotAvailableValueSpecification(element)
        elif tag_name == "NUMERICAL-RULE-BASED-VALUE-SPECIFICATION":
            value_spec = self.getNumericalRuleBasedValueSpecification(element)
        else:
            self.notImplemented("Unsupported RecordValueSpecificationField %s" % tag_name)
        return value_spec

    def readRecordValueSpecificationFields(self, element: ET.Element, spec: RecordValueSpecification):
        for child_element in element.findall("./xmlns:FIELDS/*", self.nsmap):
            spec.addField(self.getValueSpecification(child_element, self.getTagName(child_element)))

    def getRecordValueSpecification(self, element: ET.Element) -> RecordValueSpecification:
        value_spec = RecordValueSpecification()
        self.readValueSpecification(element, value_spec)
        self.readRecordValueSpecificationFields(element, value_spec)
        return value_spec

    def readConstantSpecification(self, element: ET.Element, spec: ConstantSpecification):
        self.logger.debug("Read ConstantSpecification <%s>" % spec.getShortName())
        self.readIdentifiable(element, spec)
        for child_element in self.findall(element, "VALUE-SPEC/*"):
            spec.setValueSpec(self.getValueSpecification(child_element, self.getTagName(child_element)))

    def readInternalConstrs(self, element: ET.Element, parent: DataConstrRule):
        child_element = self.find(element, "INTERNAL-CONSTRS")
        if child_element is not None:
            constrs = InternalConstrs()
            self.readARObject(child_element, constrs)
            constrs.setLowerLimit(self.getChildLimitElement(child_element, "LOWER-LIMIT"))
            constrs.setUpperLimit(self.getChildLimitElement(child_element, "UPPER-LIMIT"))
            for sc_element in self.findall(child_element, "SCALE-CONSTRS/SCALE-CONSTR"):
                constrs.addScaleConstr(self.readScaleConstr(sc_element))
            constrs.setMaxGradient(self.getChildElementOptionalNumericalValue(child_element, "MAX-GRADIENT"))
            constrs.setMaxDiff(self.getChildElementOptionalNumericalValue(child_element, "MAX-DIFF"))
            constrs.setMonotony(self.getChildElementOptionalLiteral(child_element, "MONOTONY"))
            parent.setInternalConstrs(constrs)

    def readScaleConstr(self, element: ET.Element) -> ScaleConstr:
        scale_constr = ScaleConstr()
        self.readARObject(element, scale_constr)
        scale_constr.setDesc(self.getMultiLanguageOverviewParagraph(element, "DESC"))
        scale_constr.setLowerLimit(self.getChildLimitElement(element, "LOWER-LIMIT"))
        scale_constr.setShortLabel(self.getChildElementOptionalIdentifier(element, "SHORT-LABEL"))
        scale_constr.setUpperLimit(self.getChildLimitElement(element, "UPPER-LIMIT"))
        validity_value = element.get("VALIDITY")
        if validity_value is not None:
            scale_constr.setValidity(ScaleConstrValidityEnum().setValue(validity_value))
        return scale_constr

    def readPhysConstrs(self, element: ET.Element, parent: DataConstrRule):
        child_element = self.find(element, "PHYS-CONSTRS")
        if child_element is not None:
            constrs = PhysConstrs()
            self.readARObject(child_element, constrs)
            constrs.setLowerLimit(self.getChildLimitElement(child_element, "LOWER-LIMIT"))
            constrs.setUpperLimit(self.getChildLimitElement(child_element, "UPPER-LIMIT"))
            constrs.setMaxDiff(self.getChildElementOptionalNumericalValue(child_element, "MAX-DIFF"))
            constrs.setMaxGradient(self.getChildElementOptionalNumericalValue(child_element, "MAX-GRADIENT"))
            constrs.setMonotony(self.getChildElementOptionalLiteral(child_element, "MONOTONY"))
            for sc_element in self.findall(child_element, "SCALE-CONSTRS/SCALE-CONSTR"):
                constrs.addScaleConstr(self.readScaleConstr(sc_element))
            constrs.setUnitRef(self.getChildElementOptionalRefType(child_element, "UNIT-REF"))
            parent.setPhysConstrs(constrs)

    def readDataConstrRule(self, element: ET.Element, parent: DataConstr):
        for child_element in self.findall(element, "DATA-CONSTR-RULES/DATA-CONSTR-RULE"):
            # self.logger.debug("Read DataConstrRule")
            rule = DataConstrRule()
            self.readARObject(child_element, rule)
            rule.setConstrLevel(self.getChildElementOptionalIntegerValue(child_element, "CONSTR-LEVEL"))
            self.readInternalConstrs(child_element, rule)
            self.readPhysConstrs(child_element, rule)
            parent.addDataConstrRule(rule)

    def readDataConstr(self, element: ET.Element, constr: DataConstr):
        # self.logger.debug("Read DataConstr <%s>" % constr.getShortName())
        self.readIdentifiable(element, constr)
        self.readDataConstrRule(element, constr)

    def readUnit(self, element: ET.Element, unit: Unit):
        self.logger.debug("Read Unit <%s>" % unit.getShortName())
        self.readIdentifiable(element, unit)
        unit.setDisplayName(self.getSingleLanguageUnitNames(element, "DISPLAY-NAME"))
        unit.setFactorSiToUnit(self.getChildElementOptionalFloatValue(element, "FACTOR-SI-TO-UNIT"))
        unit.setOffsetSiToUnit(self.getChildElementOptionalFloatValue(element, "OFFSET-SI-TO-UNIT"))
        unit.setPhysicalDimensionRef(self.getChildElementOptionalRefType(element, "PHYSICAL-DIMENSION-REF"))

    def readUnitGroup(self, element: ET.Element, unit_group: UnitGroup):
        self.logger.debug("Read UnitGroup <%s>" % unit_group.getShortName())
        self.readIdentifiable(element, unit_group)
        for ref in self.getChildElementRefTypeList(element, "UNIT-REFS/UNIT-REF"):
            unit_group.addUnitRef(ref)

    def readEndToEndDescriptionDataIds(self, element: ET.Element, parent: EndToEndDescription):
        child_element = self.find(element, "DATA-IDS")
        if child_element is not None:
            for value in self.getChildElementPositiveIntegerValueList(child_element, "DATA-ID"):
                parent.addDataId(value)

    def getEndToEndDescription(self, element: ET.Element, key: str) -> EndToEndDescription:
        child_element = self.find(element, key)
        desc = None
        if child_element is not None:
            desc = EndToEndDescription()
            self.readARObject(child_element, desc)
            desc.setCategory(self.getChildElementOptionalNameToken(child_element, "CATEGORY"))
            self.readEndToEndDescriptionDataIds(child_element, desc)
            desc.setDataIdMode(self.getChildElementOptionalPositiveInteger(child_element, "DATA-ID-MODE"))
            desc.setDataLength(self.getChildElementOptionalPositiveInteger(child_element, "DATA-LENGTH"))
            desc.setMaxDeltaCounterInit(self.getChildElementOptionalPositiveInteger(child_element, "MAX-DELTA-COUNTER-INIT"))
            desc.setCrcOffset(self.getChildElementOptionalPositiveInteger(child_element, "CRC-OFFSET"))
            desc.setCounterOffset(self.getChildElementOptionalPositiveInteger(child_element, "COUNTER-OFFSET"))
            desc.setMaxNoNewOrRepeatedData(self.getChildElementOptionalPositiveInteger(child_element, "MAX-NO-NEW-OR-REPEATED-DATA"))
            desc.setSyncCounterInit(self.getChildElementOptionalPositiveInteger(child_element, "SYNC-COUNTER-INIT"))
            desc.setDataIdNibbleOffset(self.getChildElementOptionalPositiveInteger(child_element, "DATA-ID-NIBBLE-OFFSET"))
        return desc

    def getVariableDataPrototypeInSystemInstanceRef(self, element: ET.Element) -> VariableDataPrototypeInSystemInstanceRef:
        instance_ref = None
        if element is not None:
            instance_ref = VariableDataPrototypeInSystemInstanceRef()
            self.readARObject(element, instance_ref)
            instance_ref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE-REF"))
            for ref in self.getChildElementRefTypeList(element, "CONTEXT-COMPONENT-REF"):
                instance_ref.addContextComponentRef(ref)
            instance_ref.setContextCompositionRef(self.getChildElementOptionalRefType(element, "CONTEXT-COMPOSITION-REF"))
            instance_ref.setContextPortRef(self.getChildElementOptionalRefType(element, "CONTEXT-PORT-REF"))
            instance_ref.setTargetDataPrototypeRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-REF"))
        return instance_ref

    def readEndToEndProtectionVariablePrototype(self, element: ET.Element, prototype: EndToEndProtectionVariablePrototype):
        self.readARObject(element, prototype)
        for child_element in self.findall(element, "RECEIVER-IREFS/RECEIVER-IREF"):
            prototype.addReceiverIref(self.getVariableDataPrototypeInSystemInstanceRef(child_element))
        prototype.setSenderIref(self.getVariableDataPrototypeInSystemInstanceRef(self.find(element, "SENDER-IREF")))
        prototype.setShortLabel(self.getChildElementOptionalIdentifier(element, "SHORT-LABEL"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(prototype, VariationPointCapable):
                prototype.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))
        return prototype

    def readEndToEndProtectionEndToEndProtectionVariablePrototypes(self, element: ET.Element, protection: EndToEndProtection):
        for child_element in self.findall(element, "END-TO-END-PROTECTION-VARIABLE-PROTOTYPES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-PROTECTION-VARIABLE-PROTOTYPE":
                prototype = EndToEndProtectionVariablePrototype()
                self.readEndToEndProtectionVariablePrototype(child_element, prototype)
                protection.addEndToEndProtectionVariablePrototype(prototype)
            else:
                self.raiseError("Unsupported End To End Protection Variable Prototype <%s>" % tag_name)

    def readEndToEndProtectionISignalIPdu(self, element: ET.Element, ipdu: EndToEndProtectionISignalIPdu):
        self.readARObject(element, ipdu)
        ipdu.setDataOffset(self.getChildElementOptionalIntegerValue(element, "DATA-OFFSET"))
        ipdu.setISignalGroupRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-GROUP-REF"))
        ipdu.setISignalIPduRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-I-PDU-REF"))
        self.readVariationPointCapable(element, ipdu)

    def readEndToEndProtectionEndToEndProtectionISignalIPdus(self, element: ET.Element, protection: EndToEndProtection):
        for child_element in self.findall(element, "END-TO-END-PROTECTION-I-SIGNAL-I-PDUS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-PROTECTION-I-SIGNAL-I-PDU":
                ipdu = EndToEndProtectionISignalIPdu()
                self.readEndToEndProtectionISignalIPdu(child_element, ipdu)
                protection.addEndToEndProtectionISignalIPdu(ipdu)
            else:
                self.notImplemented("Unsupported EndToEndProtectionISignalIPdu <%s>" % tag_name)

    def readEndToEndProtection(self, element: ET.Element, parent: EndToEndProtectionSet):
        short_name = self.getShortName(element)
        self.logger.debug("readEndToEndProtection %s" % short_name)
        protection = parent.createEndToEndProtection(short_name)
        self.readIdentifiable(element, protection)
        protection.setEndToEndProfile(self.getEndToEndDescription(element, "END-TO-END-PROFILE"))
        self.readEndToEndProtectionEndToEndProtectionISignalIPdus(element, protection)
        self.readEndToEndProtectionEndToEndProtectionVariablePrototypes(element, protection)

    def readEndToEndProtections(self, element: ET.Element, parent: EndToEndProtectionSet):
        for child_element in self.findall(element, "END-TO-END-PROTECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-PROTECTION":
                self.readEndToEndProtection(child_element, parent)
            else:
                self.notImplemented("Unsupported EndToEndProtectionSet <%s>" % tag_name)

    def readEndToEndProtectionSet(self, element: ET.Element, protection_set: EndToEndProtectionSet):
        self.logger.debug("Read EndToEndProtectionSet <%s>" % protection_set.getShortName())
        self.readIdentifiable(element, protection_set)
        self.readEndToEndProtections(element, protection_set)

    def readImplementationProps(self, element: ET.Element, props: ImplementationProps):
        self.readReferrable(element, props)
        props.setSymbol(self.getChildElementOptionalLiteral(element, "SYMBOL"))

    def readSymbolProps(self, element: ET.Element, props: SymbolProps):
        self.readImplementationProps(element, props)

    def readImplementationDataTypeSymbolProps(self, element: ET.Element, data_type: ImplementationDataType):
        child_element = self.find(element, "SYMBOL-PROPS")
        if child_element is not None:
            props = data_type.createSymbolProps(self.getShortName(child_element))
            self.readSymbolProps(child_element, props)

    def readApplicationDataType(self, element: ET.Element, data_type: ApplicationDataType):
        self.readAutosarDataType(element, data_type)

    def readApplicationCompositeDataType(self, element: ET.Element, data_type: ApplicationCompositeDataType):
        self.readApplicationDataType(element, data_type)

    def readDataPrototype(self, element: ET.Element, prototype: DataPrototype):
        self.readIdentifiable(element, prototype)
        prototype.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))

    def readApplicationCompositeElementDataPrototype(self, element: ET.Element, prototype: ApplicationCompositeElementDataPrototype):
        self.readDataPrototype(element, prototype)
        prototype.setTypeTRef(self.getChildElementOptionalRefType(element, "TYPE-TREF"))

    def readApplicationArrayElement(self, element: ET.Element, parent: ApplicationArrayDataType):
        child_element = self.find(element, "ELEMENT")
        if child_element is not None:
            short_name = self.getShortName(child_element)
            self.logger.debug("Read ApplicationArrayElement %s" % short_name)
            array_element = parent.createApplicationArrayElement(short_name)
            self.readApplicationCompositeElementDataPrototype(child_element, array_element)
            array_element.setArraySizeHandling(self.getChildElementOptionalLiteral(child_element, "ARRAY-SIZE-HANDLING"))
            array_element.setArraySizeSemantics(self.getChildElementOptionalLiteral(child_element, "ARRAY-SIZE-SEMANTICS"))
            array_element.setIndexDataTypeRef(self.getChildElementOptionalRefType(child_element, "INDEX-DATA-TYPE-REF"))
            array_element.setMaxNumberOfElements(self.getChildElementOptionalNumericalValue(child_element, "MAX-NUMBER-OF-ELEMENTS"))

    def readApplicationArrayDataType(self, element: ET.Element, data_type: ApplicationArrayDataType):
        self.logger.debug("Read ApplicationArrayDataType <%s>" % data_type.getShortName())
        self.readApplicationCompositeDataType(element, data_type)
        data_type.setDynamicArraySizeProfile(self.getChildElementOptionalLiteral(element, "DYNAMIC-ARRAY-SIZE-PROFILE"))
        self.readApplicationArrayElement(element, data_type)

    def getSwRecordLayoutV(self, element: ET.Element, key: str) -> SwRecordLayoutV:
        child_element = self.find(element, key)
        layout_v = None
        if child_element is not None:
            layout_v = SwRecordLayoutV()
            layout_v.setShortLabel(self.getChildElementOptionalLiteral(child_element, "SHORT-LABEL"))
            layout_v.setBaseTypeRef(self.getChildElementOptionalRefType(child_element, "BASE-TYPE-REF"))
            layout_v.setDesc(self.getMultiLanguageOverviewParagraph(child_element, "DESC"))
            layout_v.setSwGenericAxisParamTypeRef(self.getChildElementOptionalRefType(child_element, "SW-GENERIC-AXIS-PARAM-TYPE-REF"))
            layout_v.setSwRecordLayoutVAxis(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-V-AXIS"))
            layout_v.setSwRecordLayoutVProp(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-V-PROP"))
            layout_v.setSwRecordLayoutVIndex(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-V-INDEX"))
            layout_v.setSwRecordLayoutVFixValue(self.getChildElementOptionalNumericalValue(child_element, "SW-RECORD-LAYOUT-V-FIX-VALUE"))
        return layout_v

    def readSwRecordLayoutGroupSwRecordLayoutGroupContentType(self, element: ET.Element, group: SwRecordLayoutGroup):
        content = SwRecordLayoutGroupContent()
        content.setSwRecordLayoutRef(self.getChildElementOptionalRefType(element, "SW-RECORD-LAYOUT-REF"))
        content.setSwRecordLayoutGroup(self.getSwRecordLayoutGroup(element, "SW-RECORD-LAYOUT-GROUP"))
        content.setSwRecordLayoutV(self.getSwRecordLayoutV(element, "SW-RECORD-LAYOUT-V"))
        group.setSwRecordLayoutGroupContentType(content)

    def getSwRecordLayoutGroup(self, element: ET.Element, key: str) -> SwRecordLayoutGroup:
        child_element = self.find(element, key)
        group = None
        if child_element is not None:
            group = SwRecordLayoutGroup()
            group.setShortLabel(self.getChildElementOptionalLiteral(child_element, "SHORT-LABEL"))
            group.setCategory(self.getChildElementOptionalLiteral(child_element, "CATEGORY"))
            group.setDesc(self.getMultiLanguageOverviewParagraph(child_element, "DESC"))
            group.setSwRecordLayoutGroupAxis(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-GROUP-AXIS"))
            group.setSwRecordLayoutGroupIndex(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-GROUP-INDEX"))
            group.setSwGenericAxisParamTypeRef(self.getChildElementOptionalRefType(child_element, "SW-GENERIC-AXIS-PARAM-TYPE-REF"))
            group.setSwRecordLayoutGroupFrom(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-GROUP-FROM"))
            group.setSwRecordLayoutGroupStep(self.getChildElementOptionalIntegerValue(child_element, "SW-RECORD-LAYOUT-GROUP-STEP"))
            group.setSwRecordLayoutGroupTo(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-GROUP-TO"))
            group.setSwRecordLayoutComponent(self.getChildElementOptionalLiteral(child_element, "SW-RECORD-LAYOUT-COMPONENT"))
            self.readSwRecordLayoutGroupSwRecordLayoutGroupContentType(child_element, group)

        return group

    def readSwRecordLayout(self, element: ET.Element, layout: SwRecordLayout):
        self.logger.debug("Read SwRecordLayout <%s>" % layout.getShortName())
        self.readIdentifiable(element, layout)
        layout.setSwRecordLayoutGroup(self.getSwRecordLayoutGroup(element, "SW-RECORD-LAYOUT-GROUP"))

    def readSwAddrMethod(self, element: ET.Element, method: SwAddrMethod):
        self.logger.debug("Read SwAddrMethod <%s>" % method.getShortName())
        self.readIdentifiable(element, method)
        memory_allocation_keyword_policy = self.getChildElementOptionalLiteral(element, "MEMORY-ALLOCATION-KEYWORD-POLICY")
        if memory_allocation_keyword_policy is not None:
            method.setMemoryAllocationKeywordPolicy(MemoryAllocationKeywordPolicyType().setValue(memory_allocation_keyword_policy.getValue()))
        for option in self.getChildElementLiteralValueList(element, "OPTIONS/OPTION"):
            method.addOption(option)
        section_initialization_policy = self.getChildElementOptionalLiteral(element, "SECTION-INITIALIZATION-POLICY")
        if section_initialization_policy is not None:
            method.setSectionInitializationPolicy(SectionInitializationPolicyType().setValue(section_initialization_policy.getValue()))
        section_type = self.getChildElementOptionalLiteral(element, "SECTION-TYPE")
        if section_type is not None:
            method.setSectionType(MemorySectionType().setValue(section_type.getValue()))

    def readTriggerInterfaceTriggers(self, element: ET.Element, trigger_if: TriggerInterface):
        for child_element in self.findall(element, "TRIGGERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TRIGGER":
                trigger = trigger_if.createTrigger(self.getShortName(child_element))
                self.readTrigger(child_element, trigger)
            else:
                self.notImplemented("Unsupported Trigger Interface Trigger <%s>" % tag_name)

    def readTriggerInterface(self, element: ET.Element, trigger_if: TriggerInterface):
        self.logger.debug("Read TriggerInterface <%s>" % trigger_if.getShortName())
        self.readIdentifiable(element, trigger_if)
        self.readTriggerInterfaceTriggers(element, trigger_if)

    def readModeDeclarationGroupModeDeclaration(self, element: ET.Element, parent: ModeDeclarationGroup):
        for child_element in self.findall(element, "MODE-DECLARATIONS/MODE-DECLARATION"):
            short_name = self.getShortName(child_element)
            declaration = parent.createModeDeclaration(short_name)
            self.readARObject(child_element, declaration)
            declaration.setValue(self.getChildElementOptionalPositiveInteger(child_element, "VALUE"))

    def readModeErrorBehavior(self, element: ET.Element) -> ModeErrorBehavior:
        behavior = ModeErrorBehavior()
        self.readARObject(element, behavior)
        behavior.setDefaultModeRef(self.getChildElementOptionalRefType(element, "DEFAULT-MODE-REF"))
        error_reaction_policy = self.getChildElementOptionalLiteral(element, "ERROR-REACTION-POLICY")
        if error_reaction_policy is not None:
            behavior.setErrorReactionPolicy(ModeErrorReactionPolicyEnum().setValue(error_reaction_policy.getValue()))
        return behavior

    def readModeDeclarationGroupModeTransition(self, element: ET.Element, parent: ModeDeclarationGroup):
        for child_element in self.findall(element, "MODE-TRANSITIONS/MODE-TRANSITION"):
            short_name = self.getShortName(child_element)
            transition = parent.createModeTransition(short_name)
            self.readARObject(child_element, transition)
            transition.setEnteredModeRef(self.getChildElementOptionalRefType(child_element, "ENTERED-MODE-REF"))
            transition.setExitedModeRef(self.getChildElementOptionalRefType(child_element, "EXITED-MODE-REF"))

    def readModeDeclarationGroup(self, element: ET.Element, group: ModeDeclarationGroup):
        self.logger.debug("Read ModeDeclarationGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        self.readModeDeclarationGroupModeDeclaration(element, group)
        group.setInitialModeRef(self.getChildElementOptionalRefType(element, "INITIAL-MODE-REF"))
        mode_manager_error_behavior = self.find(element, "MODE-MANAGER-ERROR-BEHAVIOR")
        if mode_manager_error_behavior is not None:
            group.setModeManagerErrorBehavior(self.readModeErrorBehavior(mode_manager_error_behavior))
        self.readModeDeclarationGroupModeTransition(element, group)
        mode_user_error_behavior = self.find(element, "MODE-USER-ERROR-BEHAVIOR")
        if mode_user_error_behavior is not None:
            group.setModeUserErrorBehavior(self.readModeErrorBehavior(mode_user_error_behavior))
        group.setOnTransitionValue(self.getChildElementOptionalPositiveInteger(element, "ON-TRANSITION-VALUE"))

    def readModeSwitchInterfaceModeGroup(self, element: ET.Element, parent: ModeSwitchInterface):
        child_element = self.find(element, "MODE-GROUP")
        if child_element is not None:
            short_name = self.getShortName(child_element)
            mode_group = parent.createModeGroup(short_name)
            self.readModeDeclarationGroupPrototype(child_element, mode_group)

    def readModeSwitchInterface(self, element: ET.Element, mode_interface: ModeSwitchInterface):
        self.logger.debug("Read ModeSwitchInterface <%s>" % mode_interface.getShortName())
        self.readPortInterface(element, mode_interface)
        self.readModeSwitchInterfaceModeGroup(element, mode_interface)

    def readExecutionOrderConstraintOrderedElement(self, element: ET.Element, constrain: ExecutionOrderConstraint):
        for child_element in self.findall(element, "ORDERED-ELEMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "EOC-EXECUTABLE-ENTITY-REF":
                entity_ref = constrain.createEOCExecutableEntityRef(self.getShortName(child_element))
                self.readEOCExecutableEntityRef(child_element, entity_ref)
            elif tag_name == "EOC-EVENT-REF":
                event_ref = constrain.createEOCEventRef(self.getShortName(child_element))
                self.readEOCEventRef(child_element, event_ref)
            elif tag_name == "EOC-EXECUTABLE-ENTITY-REF-GROUP":
                entity_ref_group = constrain.createEOCExecutableEntityRefGroup(self.getShortName(child_element))
                self.readEOCExecutableEntityRefGroup(child_element, entity_ref_group)
            else:
                self.raiseError("Unsupported order element <%s>." % tag_name)

    def readExecutionOrderConstraint(self, element: ET.Element, constraint: ExecutionOrderConstraint):
        self.logger.debug("readExecutionOrderConstraint %s" % self.getShortName(element))
        self.readTimingConstraint(element, constraint)
        constraint.setBaseCompositionRef(self.getChildElementOptionalRefType(element, "BASE-COMPOSITION-REF"))
        literal = self.getChildElementOptionalLiteral(element, "EXECUTION-ORDER-CONSTRAINT-TYPE")
        if literal is not None:
            constraint.setExecutionOrderConstraintType(ExecutionOrderConstraintTypeEnum().setValue(literal.getText()))
        constraint.setIgnoreOrderAllowed(self.getChildElementOptionalBooleanValue(element, "IGNORE-ORDER-ALLOWED"))
        constraint.setIsEvent(self.getChildElementOptionalBooleanValue(element, "IS-EVENT"))
        self.readExecutionOrderConstraintOrderedElement(element, constraint)
        constraint.setPermitMultipleReferencesToEE(self.getChildElementOptionalBooleanValue(element, "PERMIT-MULTIPLE-REFERENCES-TO-EE"))

    def readTimingExtensionConstraint(self, element: ET.Element, extension: TimingExtension, key: str):
        tag_name = self.getTagName(element)
        if tag_name not in (
            "AGE-CONSTRAINT",
            "ARBITRARY-EVENT-TRIGGERING",
            "BURST-PATTERN-EVENT-TRIGGERING",
            "CONCRETE-PATTERN-EVENT-TRIGGERING",
            "EXECUTION-ORDER-CONSTRAINT",
            "EXECUTION-TIME-CONSTRAINT",
            "LATENCY-TIMING-CONSTRAINT",
            "OFFSET-TIMING-CONSTRAINT",
            "PERIODIC-EVENT-TRIGGERING",
            "SPORADIC-EVENT-TRIGGERING",
            "SYNCHRONIZATION-POINT-CONSTRAINT",
            "SYNCHRONIZATION-TIMING-CONSTRAINT",
        ):
            self.raiseError("Unsupported timing requirement <%s>" % tag_name)
            return
        short_name = self.getShortName(element)
        constraint = None
        if tag_name == "AGE-CONSTRAINT":
            constraint = AgeConstraint(extension, short_name)
            self.readAgeConstraint(element, constraint)
        elif tag_name == "ARBITRARY-EVENT-TRIGGERING":
            constraint = ArbitraryEventTriggering(extension, short_name)
            self.readArbitraryEventTriggering(element, constraint)
        elif tag_name == "BURST-PATTERN-EVENT-TRIGGERING":
            constraint = BurstPatternEventTriggering(extension, short_name)
            self.readBurstPatternEventTriggering(element, constraint)
        elif tag_name == "CONCRETE-PATTERN-EVENT-TRIGGERING":
            constraint = ConcretePatternEventTriggering(extension, short_name)
            self.readConcretePatternEventTriggering(element, constraint)
        elif tag_name == "EXECUTION-ORDER-CONSTRAINT":
            constraint = ExecutionOrderConstraint(extension, short_name)
            self.readExecutionOrderConstraint(element, constraint)
        elif tag_name == "EXECUTION-TIME-CONSTRAINT":
            constraint = ExecutionTimeConstraint(extension, short_name)
            self.readExecutionTimeConstraint(element, constraint)
        elif tag_name == "LATENCY-TIMING-CONSTRAINT":
            constraint = LatencyTimingConstraint(extension, short_name)
            self.readLatencyTimingConstraint(element, constraint)
        elif tag_name == "OFFSET-TIMING-CONSTRAINT":
            constraint = OffsetTimingConstraint(extension, short_name)
            self.readOffsetTimingConstraint(element, constraint)
        elif tag_name == "PERIODIC-EVENT-TRIGGERING":
            constraint = PeriodicEventTriggering(extension, short_name)
            self.readPeriodicEventTriggering(element, constraint)
        elif tag_name == "SPORADIC-EVENT-TRIGGERING":
            constraint = SporadicEventTriggering(extension, short_name)
            self.readSporadicEventTriggering(element, constraint)
        elif tag_name == "SYNCHRONIZATION-POINT-CONSTRAINT":
            constraint = SynchronizationPointConstraint(extension, short_name)
            self.readSynchronizationPointConstraint(element, constraint)
        elif tag_name == "SYNCHRONIZATION-TIMING-CONSTRAINT":
            constraint = SynchronizationTimingConstraint(extension, short_name)
            self.readSynchronizationTimingConstraint(element, constraint)
        else:
            self.raiseError("Unsupported timing requirement <%s>" % tag_name)
            return
        extension.addElement(constraint)
        if key == "TIMING-GUARANTEES":
            extension.addTimingGuarantee(constraint)
        else:
            extension.addTimingRequirement(constraint)

    def readTimingExtension(self, element: ET.Element, extension: TimingExtension):
        for child_element in self.findall(element, "TIMING-CLOCKS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TDLET-ZONE-CLOCK":
                clock = TDLETZoneClock(extension, self.getShortName(child_element))
                self.readTDLETZoneClock(child_element, clock)
                extension.addElement(clock)
                extension.addTimingClock(clock)
            else:
                self.notImplemented("Unsupported TIMING-CLOCKS item <%s>" % tag_name)
        for child_element in self.findall(element, "TIMING-CLOCK-SYNC-ACCURACYS/TIMING-CLOCK-SYNC-ACCURACY"):
            sync_accuracy = extension.createTimingClockSyncAccuracy(self.getShortName(child_element))
            self.readTimingClockSyncAccuracy(child_element, sync_accuracy)
        for child_element in self.findall(element, "TIMING-CONDITIONS/TIMING-CONDITION"):
            condition = extension.createTimingCondition(self.getShortName(child_element))
            self.readTimingCondition(child_element, condition)
        self.readTimingDescriptions(element, extension)
        for child_element in self.findall(element, "TIMING-GUARANTEES/*"):
            self.readTimingExtensionConstraint(child_element, extension, "TIMING-GUARANTEES")
        for child_element in self.findall(element, "TIMING-REQUIREMENTS/*"):
            self.readTimingExtensionConstraint(child_element, extension, "TIMING-REQUIREMENTS")
        resource_element = self.find(element, "TIMING-RESOURCE")
        if resource_element is not None:
            resource = extension.createTimingResource(self.getShortName(resource_element))
            self.readTimingExtensionResource(resource_element, resource)

    def readSwcTiming(self, element: ET.Element, timing: SwcTiming):
        self.logger.debug("Read SwcTiming <%s>" % timing.getShortName())
        self.readIdentifiable(element, timing)
        self.readTimingExtension(element, timing)
        timing.setBehaviorRef(self.getChildElementOptionalRefType(element, "BEHAVIOR-REF"))

    def readFrameTriggering(self, element: ET.Element, triggering: FrameTriggering):
        self.readIdentifiable(element, triggering)
        for ref in self.getChildElementRefTypeList(element, "FRAME-PORT-REFS/FRAME-PORT-REF"):
            triggering.addFramePortRef(ref)
        triggering.setFrameRef(self.getChildElementOptionalRefType(element, "FRAME-REF"))
        for child_element in self.findall(element, "PDU-TRIGGERINGS/PDU-TRIGGERING-REF-CONDITIONAL"):
            triggering.addPduTriggeringRef(self.getChildElementOptionalRefType(child_element, "PDU-TRIGGERING-REF"))

    def readCanFrameTriggering(self, element: ET.Element, triggering: CanFrameTriggering):
        self.logger.debug("Read CanFrameTriggering %s" % triggering.getShortName())
        self.readFrameTriggering(element, triggering)
        self.readCanFrameTriggeringAbsolutelyScheduledTimings(element, triggering)
        addressing_mode_literal = self.getChildElementOptionalLiteral(element, "CAN-ADDRESSING-MODE")
        if addressing_mode_literal is not None:
            addressing_mode = CanAddressingModeType()
            addressing_mode.setValue(addressing_mode_literal.getValue())
            triggering.setCanAddressingMode(addressing_mode)
        rx_behavior_literal = self.getChildElementOptionalLiteral(element, "CAN-FRAME-RX-BEHAVIOR")
        if rx_behavior_literal is not None:
            rx_behavior = CanFrameRxBehaviorEnum()
            rx_behavior.setValue(rx_behavior_literal.getValue())
            triggering.setCanFrameRxBehavior(rx_behavior)
        tx_behavior_literal = self.getChildElementOptionalLiteral(element, "CAN-FRAME-TX-BEHAVIOR")
        if tx_behavior_literal is not None:
            tx_behavior = CanFrameTxBehaviorEnum()
            tx_behavior.setValue(tx_behavior_literal.getValue())
            triggering.setCanFrameTxBehavior(tx_behavior)
        triggering.setCanXlFrameTriggeringProps(self.getCanXlFrameTriggeringProps(element, "CAN-XL-FRAME-TRIGGERING-PROPS"))
        triggering.setIdentifier(self.getChildElementOptionalNumericalValue(element, "IDENTIFIER"))
        triggering.setJ1939requestable(self.getChildElementOptionalBooleanValue(element, "J-1939-REQUESTABLE"))
        triggering.setRxIdentifierRange(self.getRxIdentifierRange(element, "RX-IDENTIFIER-RANGE"))
        triggering.setRxMask(self.getChildElementOptionalPositiveInteger(element, "RX-MASK"))
        triggering.setTxMask(self.getChildElementOptionalPositiveInteger(element, "TX-MASK"))

    def readCanFrameTriggeringAbsolutelyScheduledTimings(self, element: ET.Element, triggering: CanFrameTriggering):
        for child_element in self.findall(element, "ABSOLUTELY-SCHEDULED-TIMINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TTCAN-ABSOLUTELY-SCHEDULED-TIMING":
                timing = TtcanAbsolutelyScheduledTiming()
                self.readTtcanAbsolutelyScheduledTiming(child_element, timing)
                triggering.addAbsolutelyScheduledTiming(timing)
            else:
                self.notImplemented("Unsupported AbsolutelyScheduledTiming <%s>" % tag_name)

    def getCanXlFrameTriggeringProps(self, element: ET.Element, key: str) -> CanXlFrameTriggeringProps:
        props = None
        child_element = self.find(element, key)
        if child_element is not None:
            props = CanXlFrameTriggeringProps()
            props.setAcceptanceField(self.getChildElementOptionalPositiveInteger(child_element, "ACCEPTANCE-FIELD"))
            props.setPriorityId(self.getChildElementOptionalPositiveInteger(child_element, "PRIORITY-ID"))
            props.setSduType(self.getChildElementOptionalPositiveInteger(child_element, "SDU-TYPE"))
            props.setVcid(self.getChildElementOptionalPositiveInteger(child_element, "VCID"))
        return props

    def readLinFrameTriggering(self, element: ET.Element, triggering: LinFrameTriggering):
        self.logger.debug("Read LinFrameTriggering %s" % triggering.getShortName())
        self.readFrameTriggering(element, triggering)
        triggering.setIdentifier(self.getChildElementOptionalNumericalValue(element, "IDENTIFIER"))
        triggering.setLinChecksum(self.getChildElementOptionalLiteral(element, "LIN-CHECKSUM"))

    def readCommunicationCycle(self, element: ET.Element, cycle: CommunicationCycle):
        self.readARObject(element, cycle)

    def readCycleCounter(self, element: ET.Element, cycle: CycleCounter):
        self.readCommunicationCycle(element, cycle)
        cycle.setCycleCounter(self.getChildElementOptionalIntegerValue(element, "CYCLE-COUNTER"))

    def readCycleRepetition(self, element: ET.Element, cycle: CycleRepetition):
        self.readCommunicationCycle(element, cycle)
        cycle.setBaseCycle(self.getChildElementOptionalIntegerValue(element, "BASE-CYCLE"))
        cycle.setCycleRepetition(self.getChildElementOptionalLiteral(element, "CYCLE-REPETITION"))

    def readFlexrayAbsolutelyScheduledTimingCommunicationCycle(self, element: ET.Element, timing: FlexrayAbsolutelyScheduledTiming):
        for child_element in self.findall(element, "COMMUNICATION-CYCLE/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CYCLE-COUNTER":
                counter = CycleCounter()
                self.readCycleCounter(child_element, counter)
                timing.setCommunicationCycle(counter)
            elif tag_name == "CYCLE-REPETITION":
                repetition = CycleRepetition()
                self.readCycleRepetition(child_element, repetition)
                timing.setCommunicationCycle(repetition)
            else:
                self.notImplemented("Unsupported CommunicationCycle <%s>" % tag_name)

    def readFlexrayAbsolutelyScheduledTiming(self, element: ET.Element, timing: FlexrayAbsolutelyScheduledTiming):
        self.readARObject(element, timing)
        self.readFlexrayAbsolutelyScheduledTimingCommunicationCycle(element, timing)
        timing.setSlotID(self.getChildElementOptionalPositiveInteger(element, "SLOT-ID"))

    def readFlexrayFrameTriggeringAbsolutelyScheduledTimings(self, element: ET.Element, triggering: FlexrayFrameTriggering):
        for child_element in self.findall(element, "ABSOLUTELY-SCHEDULED-TIMINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "FLEXRAY-ABSOLUTELY-SCHEDULED-TIMING":
                timing = FlexrayAbsolutelyScheduledTiming()
                self.readFlexrayAbsolutelyScheduledTiming(child_element, timing)
                triggering.addAbsolutelyScheduledTiming(timing)
            else:
                self.notImplemented("Unsupported AbsolutelyScheduledTiming <%s>" % tag_name)

    def readTtcanAbsolutelyScheduledTimingCommunicationCycle(self, element: ET.Element, timing: TtcanAbsolutelyScheduledTiming):
        for child_element in self.findall(element, "COMMUNICATION-CYCLE/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CYCLE-COUNTER":
                counter = CycleCounter()
                self.readCycleCounter(child_element, counter)
                timing.setCommunicationCycle(counter)
            elif tag_name == "CYCLE-REPETITION":
                repetition = CycleRepetition()
                self.readCycleRepetition(child_element, repetition)
                timing.setCommunicationCycle(repetition)
            else:
                self.notImplemented("Unsupported CommunicationCycle <%s>" % tag_name)

    def readTtcanAbsolutelyScheduledTiming(self, element: ET.Element, timing: TtcanAbsolutelyScheduledTiming):
        self.readARObject(element, timing)
        self.readTtcanAbsolutelyScheduledTimingCommunicationCycle(element, timing)
        timing.setTimeMark(self.getChildElementOptionalIntegerValue(element, "TIME-MARK"))
        timing.setTrigger(self.getChildElementOptionalLiteral(element, "TRIGGER"))

    def readFlexrayFrameTriggering(self, element: ET.Element, triggering: FlexrayFrameTriggering):
        self.logger.debug("Read FlexrayFrameTriggering %s" % triggering.getShortName())
        self.readFrameTriggering(element, triggering)
        self.readFlexrayFrameTriggeringAbsolutelyScheduledTimings(element, triggering)
        triggering.setAllowDynamicLSduLength(self.getChildElementOptionalBooleanValue(element, "ALLOW-DYNAMIC-L-SDU-LENGTH"))
        triggering.setMessageId(self.getChildElementOptionalPositiveInteger(element, "MESSAGE-ID"))
        triggering.setPayloadPreambleIndicator(self.getChildElementOptionalBooleanValue(element, "PAYLOAD-PREAMBLE-INDICATOR"))

    def readISignalTriggering(self, element: ET.Element, triggering: ISignalTriggering):
        self.logger.debug("Read ISignalTriggering %s" % triggering.getShortName())
        self.readIdentifiable(element, triggering)
        triggering.setISignalGroupRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-GROUP-REF"))
        for ref in self.getChildElementRefTypeList(element, "I-SIGNAL-PORT-REFS/I-SIGNAL-PORT-REF"):
            triggering.addISignalPortRef(ref)
        triggering.setISignalRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-REF"))

    def readPduTriggering(self, element: ET.Element, triggering: PduTriggering):
        self.logger.debug("Read PduTriggering %s" % triggering.getShortName())
        self.readIdentifiable(element, triggering)
        for ref in self.getChildElementRefTypeList(element, "I-PDU-PORT-REFS/I-PDU-PORT-REF"):
            triggering.addIPduPortRef(ref)
        triggering.setIPduRef(self.getChildElementOptionalRefType(element, "I-PDU-REF"))
        for child_element in self.findall(element, "I-SIGNAL-TRIGGERINGS/I-SIGNAL-TRIGGERING-REF-CONDITIONAL"):
            triggering.addISignalTriggeringRef(self.getChildElementOptionalRefType(child_element, "I-SIGNAL-TRIGGERING-REF"))
        triggering.setSecOcCryptoMappingRef(self.getChildElementOptionalRefType(element, "SEC-OC-CRYPTO-MAPPING-REF"))
        for child_element in self.findall(element, "TRIGGER-I-PDU-SEND-CONDITIONS/TRIGGER-I-PDU-SEND-CONDITION"):
            condition = TriggerIPduSendCondition()
            self.readTriggerIPduSendCondition(child_element, condition)
            triggering.addTriggerIPduSendCondition(condition)

    def readTriggerIPduSendCondition(self, element: ET.Element, condition: TriggerIPduSendCondition):
        for ref in self.getChildElementRefTypeList(element, "MODE-DECLARATION-REFS/MODE-DECLARATION-REF"):
            condition.addModeDeclarationRef(ref)

    def readModeDrivenTransmissionModeCondition(self, element: ET.Element, condition: ModeDrivenTransmissionModeCondition):
        for ref in self.getChildElementRefTypeList(element, "MODE-DECLARATION-REFS/MODE-DECLARATION-REF"):
            condition.addModeDeclarationRef(ref)

    def readPhysicalChannelCommConnectorRefs(self, element: ET.Element, channel: PhysicalChannel):
        for child_element in self.findall(element, "COMM-CONNECTORS/COMMUNICATION-CONNECTOR-REF-CONDITIONAL"):
            channel.addCommConnectorRef(self.getChildElementOptionalRefType(child_element, "COMMUNICATION-CONNECTOR-REF"))

    def readPhysicalChannelFrameTriggerings(self, element: ET.Element, channel: PhysicalChannel):
        for child_element in self.findall(element, "FRAME-TRIGGERINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-FRAME-TRIGGERING":
                triggering = channel.createCanFrameTriggering(self.getShortName(child_element))
                self.readCanFrameTriggering(child_element, triggering)
            elif tag_name == "LIN-FRAME-TRIGGERING":
                triggering = channel.createLinFrameTriggering(self.getShortName(child_element))
                self.readLinFrameTriggering(child_element, triggering)
            elif tag_name == "FLEXRAY-FRAME-TRIGGERING":
                triggering = channel.createFlexrayFrameTriggering(self.getShortName(child_element))
                self.readFlexrayFrameTriggering(child_element, triggering)
            else:
                self.notImplemented("Unsupported Frame Triggering <%s>" % tag_name)

    def readPhysicalChannelISignalTriggerings(self, element: ET.Element, channel: PhysicalChannel):
        for child_element in self.findall(element, "I-SIGNAL-TRIGGERINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "I-SIGNAL-TRIGGERING":
                triggering = channel.createISignalTriggering(self.getShortName(child_element))
                self.readISignalTriggering(child_element, triggering)
            else:
                self.notImplemented("Unsupported Frame Triggering <%s>" % tag_name)

    def readPhysicalChannelPduTriggerings(self, element, channel):
        for child_element in self.findall(element, "PDU-TRIGGERINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PDU-TRIGGERING":
                triggering = channel.createPduTriggering(self.getShortName(child_element))
                self.readPduTriggering(child_element, triggering)
            else:
                self.notImplemented("Unsupported Frame Triggering <%s>" % tag_name)

    def readPhysicalChannelManagedPhysicalChannelRefs(self, element: ET.Element, channel: PhysicalChannel):
        for child_element in self.findall(element, "MANAGED-PHYSICAL-CHANNEL-REFS/MANAGED-PHYSICAL-CHANNEL-REF"):
            channel.addManagedPhysicalChannelRef(self._getChildElementRefTypeDestAndValue(child_element))

    def readPhysicalChannel(self, element: ET.Element, channel: PhysicalChannel):
        self.readIdentifiable(element, channel)

        self.readPhysicalChannelCommConnectorRefs(element, channel)
        self.readPhysicalChannelFrameTriggerings(element, channel)
        self.readPhysicalChannelISignalTriggerings(element, channel)
        self.readPhysicalChannelPduTriggerings(element, channel)
        self.readPhysicalChannelManagedPhysicalChannelRefs(element, channel)

    def readCanPhysicalChannel(self, element: ET.Element, channel: CanPhysicalChannel):
        self.readPhysicalChannel(element, channel)

    def readScheduleTableEntry(self, element: ET.Element, entry: ScheduleTableEntry):
        entry.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))
        entry.setDelay(self.getChildElementOptionalTimeValue(element, "DELAY"))
        entry.setPositionInTable(self.getChildElementOptionalIntegerValue(element, "POSITION-IN-TABLE"))

    def getApplicationEntry(self, element: ET.Element, key: str) -> ApplicationEntry:
        entry = None
        if element is not None:
            entry = ApplicationEntry()
            self.readScheduleTableEntry(element, entry)
            entry.setFrameTriggeringRef(self.getChildElementOptionalRefType(element, "FRAME-TRIGGERING-REF"))
        return entry

    def readLinConfigurationEntry(self, element: ET.Element, entry: LinConfigurationEntry):
        entry.setAssignedControllerRef(self.getChildElementOptionalRefType(element, "ASSIGNED-CONTROLLER-REF"))
        entry.setAssignedLinSlaveConfigRef(self.getChildElementOptionalRefType(element, "ASSIGNED-LIN-SLAVE-CONFIG-REF"))

    def readByteValues(self, element: ET.Element, entry):
        for child_element in self.findall(element, "BYTE-VALUES/BYTE-VALUE"):
            entry.addByteValue(self.getChildElementOptionalIntegerValue(child_element, "."))

    def getFreeFormat(self, element: ET.Element) -> FreeFormat:
        entry = None
        if element is not None:
            entry = FreeFormat()
            self.readScheduleTableEntry(element, entry)
            self.readByteValues(element, entry)
        return entry

    def getAssignFrameId(self, element: ET.Element) -> AssignFrameId:
        entry = None
        if element is not None:
            entry = AssignFrameId()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
            entry.setAssignedFrameTriggeringRef(self.getChildElementOptionalRefType(element, "ASSIGNED-FRAME-TRIGGERING-REF"))
        return entry

    def getUnassignFrameId(self, element: ET.Element) -> UnassignFrameId:
        entry = None
        if element is not None:
            entry = UnassignFrameId()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
            entry.setUnassignedFrameTriggeringRef(self.getChildElementOptionalRefType(element, "UNASSIGNED-FRAME-TRIGGERING-REF"))
        return entry

    def getAssignFrameIdRange(self, element: ET.Element) -> AssignFrameIdRange:
        entry = None
        if element is not None:
            entry = AssignFrameIdRange()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
            for child_element in self.findall(element, "FRAME-PIDS/FRAME-PID"):
                frame_pid = FramePid()
                frame_pid.setIndex(self.getChildElementOptionalIntegerValue(child_element, "INDEX"))
                frame_pid.setPid(self.getChildElementOptionalPositiveInteger(child_element, "PID"))
                entry.addFramePid(frame_pid)
            entry.setStartIndex(self.getChildElementOptionalIntegerValue(element, "START-INDEX"))
        return entry

    def getAssignNad(self, element: ET.Element) -> AssignNad:
        entry = None
        if element is not None:
            entry = AssignNad()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
            entry.setNewNad(self.getChildElementOptionalIntegerValue(element, "NEW-NAD"))
        return entry

    def getConditionalChangeNad(self, element: ET.Element) -> ConditionalChangeNad:
        entry = None
        if element is not None:
            entry = ConditionalChangeNad()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
            entry.setByte(self.getChildElementOptionalIntegerValue(element, "BYTE"))
            entry.setId(self.getChildElementOptionalPositiveInteger(element, "ID"))
            entry.setInvert(self.getChildElementOptionalIntegerValue(element, "INVERT"))
            entry.setMask(self.getChildElementOptionalIntegerValue(element, "MASK"))
            entry.setNewNad(self.getChildElementOptionalIntegerValue(element, "NEW-NAD"))
        return entry

    def getSaveConfigurationEntry(self, element: ET.Element) -> SaveConfigurationEntry:
        entry = None
        if element is not None:
            entry = SaveConfigurationEntry()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
        return entry

    def getDataDumpEntry(self, element: ET.Element) -> DataDumpEntry:
        entry = None
        if element is not None:
            entry = DataDumpEntry()
            self.readScheduleTableEntry(element, entry)
            self.readLinConfigurationEntry(element, entry)
            self.readByteValues(element, entry)
        return entry

    def readLinScheduleTableTableEntries(self, element: ET.Element, table: LinScheduleTable):
        for child_element in self.findall(element, "TABLE-ENTRYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "APPLICATION-ENTRY":
                table = table.addTableEntry(self.getApplicationEntry(child_element, "APPLICATION-ENTRY"))
            elif tag_name == "FREE-FORMAT":
                table = table.addTableEntry(self.getFreeFormat(child_element))
            elif tag_name == "ASSIGN-FRAME-ID":
                table = table.addTableEntry(self.getAssignFrameId(child_element))
            elif tag_name == "ASSIGN-FRAME-ID-RANGE":
                table = table.addTableEntry(self.getAssignFrameIdRange(child_element))
            elif tag_name == "UNASSIGN-FRAME-ID":
                table = table.addTableEntry(self.getUnassignFrameId(child_element))
            elif tag_name == "ASSIGN-NAD":
                table = table.addTableEntry(self.getAssignNad(child_element))
            elif tag_name == "CONDITIONAL-CHANGE-NAD":
                table = table.addTableEntry(self.getConditionalChangeNad(child_element))
            elif tag_name == "SAVE-CONFIGURATION-ENTRY":
                table = table.addTableEntry(self.getSaveConfigurationEntry(child_element))
            elif tag_name == "DATA-DUMP-ENTRY":
                table = table.addTableEntry(self.getDataDumpEntry(child_element))
            else:
                self.notImplemented("Unsupported Schedule Table <%s>" % tag_name)

    def readLinScheduleTable(self, element: ET.Element, table: LinScheduleTable):
        self.readIdentifiable(element, table)
        resume_position_literal = self.getChildElementOptionalLiteral(element, "RESUME-POSITION")
        if resume_position_literal is not None:
            resume_position = ResumePosition()
            resume_position.setValue(resume_position_literal.getValue())
            table.setResumePosition(resume_position)
        run_mode_literal = self.getChildElementOptionalLiteral(element, "RUN-MODE")
        if run_mode_literal is not None:
            run_mode = RunMode()
            run_mode.setValue(run_mode_literal.getValue())
            table.setRunMode(run_mode)
        self.readLinScheduleTableTableEntries(element, table)

    def readLinPhysicalChannelScheduleTables(self, element: ET.Element, channel: LinPhysicalChannel):
        for child_element in self.findall(element, "SCHEDULE-TABLES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "LIN-SCHEDULE-TABLE":
                table = channel.createLinScheduleTable(self.getShortName(child_element))
                self.readLinScheduleTable(child_element, table)
            else:
                self.notImplemented("Unsupported Schedule Table <%s>" % tag_name)

    def readLinPhysicalChannel(self, element: ET.Element, channel: LinPhysicalChannel):
        self.readPhysicalChannel(element, channel)
        self.readLinPhysicalChannelScheduleTables(element, channel)

    def getIpv4Configuration(self, element: ET.Element) -> Ipv4Configuration:
        configuration = None
        if element is not None:
            configuration = Ipv4Configuration()
            configuration.setAssignmentPriority(self.getChildElementOptionalPositiveInteger(element, "ASSIGNMENT-PRIORITY"))
            configuration.setDefaultGateway(self.getChildElementOptionalLiteral(element, "DEFAULT-GATEWAY"))
            for address in self.findall(element, "DNS-SERVER-ADDRESSES/DNS-SERVER-ADDRESS"):
                literal = ARLiteral()
                self.readARType(address, literal)
                literal.setValue(address.text)
                configuration.addDnsServerAddress(literal)
            keep_literal = self.getChildElementOptionalLiteral(element, "IP-ADDRESS-KEEP-BEHAVIOR")
            if keep_literal is not None:
                keep = IpAddressKeepEnum()
                keep.setValue(keep_literal.getValue())
                configuration.setIpAddressKeepBehavior(keep)
            configuration.setIpv4Address(self.getChildElementOptionalLiteral(element, "IPV-4-ADDRESS"))
            configuration.setIpv4AddressSource(self.getChildElementOptionalLiteral(element, "IPV-4-ADDRESS-SOURCE"))
            configuration.setNetworkMask(self.getChildElementOptionalLiteral(element, "NETWORK-MASK"))
            configuration.setTtl(self.getChildElementOptionalPositiveInteger(element, "TTL"))
        return configuration

    def getIpv6Configuration(self, element: ET.Element) -> Ipv6Configuration:
        configuration = None
        if element is not None:
            configuration = Ipv6Configuration()
            configuration.setAssignmentPriority(self.getChildElementOptionalPositiveInteger(element, "ASSIGNMENT-PRIORITY"))
            configuration.setDefaultRouter(self.getChildElementOptionalLiteral(element, "DEFAULT-ROUTER"))
            for address in self.findall(element, "DNS-SERVER-ADDRESSES/DNS-SERVER-ADDRESS"):
                literal = ARLiteral()
                self.readARType(address, literal)
                literal.setValue(address.text)
                configuration.addDnsServerAddress(literal)
            configuration.setEnableAnycast(self.getChildElementOptionalBooleanValue(element, "ENABLE-ANYCAST"))
            configuration.setHopCount(self.getChildElementOptionalPositiveInteger(element, "HOP-COUNT"))
            keep_literal = self.getChildElementOptionalLiteral(element, "IP-ADDRESS-KEEP-BEHAVIOR")
            if keep_literal is not None:
                keep = IpAddressKeepEnum()
                keep.setValue(keep_literal.getValue())
                configuration.setIpAddressKeepBehavior(keep)
            configuration.setIpAddressPrefixLength(self.getChildElementOptionalPositiveInteger(element, "IP-ADDRESS-PREFIX-LENGTH"))
            configuration.setIpv6Address(self.getChildElementOptionalLiteral(element, "IPV-6-ADDRESS"))
            source_literal = self.getChildElementOptionalLiteral(element, "IPV-6-ADDRESS-SOURCE")
            if source_literal is not None:
                source = Ipv6AddressSourceEnum()
                source.setValue(source_literal.getValue())
                configuration.setIpv6AddressSource(source)
        return configuration

    def readNetworkEndPointNetworkEndPointAddress(self, element: ET.Element, end_point: NetworkEndpoint):
        for child_element in self.findall(element, "NETWORK-ENDPOINT-ADDRESSES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "IPV-4-CONFIGURATION":
                end_point.addNetworkEndpointAddress(self.getIpv4Configuration(child_element))
            elif tag_name == "IPV-6-CONFIGURATION":
                end_point.addNetworkEndpointAddress(self.getIpv6Configuration(child_element))
            else:
                self.notImplemented("Unsupported Network EndPoint Address <%s>" % tag_name)

    def getDoIpEntity(self, element: ET.Element, key: str) -> DoIpEntity:
        entity = None
        child_element = self.find(element, key)
        if child_element is not None:
            entity = DoIpEntity()
            do_ip_entity_role = self.getChildElementOptionalLiteral(child_element, "DO-IP-ENTITY-ROLE")
            if do_ip_entity_role is not None:
                e = DoIpEntityRoleEnum()
                e.setValue(do_ip_entity_role.getValue())
                entity.setDoIpEntityRole(e)
        return entity

    def getTimeSynchronization(self, element: ET.Element, key: str) -> TimeSynchronization:
        sync = None
        child_element = self.find(element, key)
        if child_element is not None:
            sync = TimeSynchronization()
            client_element = self.find(child_element, "TIME-SYNC-CLIENT")
            if client_element is not None:
                client = TimeSyncClientConfiguration()
                time_sync_technology = self.getChildElementOptionalLiteral(client_element, "TIME-SYNC-TECHNOLOGY")
                if time_sync_technology is not None:
                    e = TimeSyncTechnologyEnum()
                    e.setValue(time_sync_technology.getValue())
                    client.setTimeSyncTechnology(e)
                for master_element in self.findall(client_element, "ORDERED-MASTER-LIST/ORDERED-MASTER"):
                    master = OrderedMaster()
                    self.readOrderedMaster(master_element, master)
                    client.addOrderedMaster(master)
                sync.setTimeSyncClient(client)
            server_element = self.find(child_element, "TIME-SYNC-SERVER")
            if server_element is not None:
                server = TimeSyncServerConfiguration(None, self.getShortName(server_element))
                self.readReferrable(server_element, server)
                time_sync_technology = self.getChildElementOptionalLiteral(server_element, "TIME-SYNC-TECHNOLOGY")
                if time_sync_technology is not None:
                    e = TimeSyncTechnologyEnum()
                    e.setValue(time_sync_technology.getValue())
                    server.setTimeSyncTechnology(e)
                sync.setTimeSyncServer(server)
        return sync

    def readOrderedMaster(self, element: ET.Element, master: OrderedMaster):
        self.readARObject(element, master)
        master.setIndex(self.getChildElementOptionalPositiveInteger(element, "INDEX"))
        ref = self.getChildElementOptionalRefType(element, "TIME-SYNC-SERVER-REF")
        if ref is not None:
            master.setTimeSyncServerRef(ref)

    def getInfrastructureServices(self, element: ET.Element, key: str) -> InfrastructureServices:
        services = None
        child_element = self.find(element, key)
        if child_element is not None:
            services = InfrastructureServices()
            services.setDoIpEntity(self.getDoIpEntity(child_element, "DO-IP-ENTITY"))
            services.setTimeSynchronization(self.getTimeSynchronization(child_element, "TIME-SYNCHRONIZATION"))
        return services

    def readNetworkEndPoint(self, element: ET.Element, end_point: NetworkEndpoint):
        self.readIdentifiable(element, end_point)
        end_point.setInfrastructureServices(self.getInfrastructureServices(element, "INFRASTRUCTURE-SERVICES"))
        ip_sec_config_element = self.find(element, "IP-SEC-CONFIG")
        if ip_sec_config_element is not None:
            config = IPSecConfig()
            end_point.setIpSecConfig(config)
            self.readIPSecConfig(ip_sec_config_element, config)
        self.readNetworkEndPointNetworkEndPointAddress(element, end_point)
        end_point.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))

    def readEthernetPhysicalChannelNetworkEndPoints(self, element: ET.Element, channel: EthernetPhysicalChannel):
        for child_element in self.findall(element, "NETWORK-ENDPOINTS/NETWORK-ENDPOINT"):
            end_point = channel.createNetworkEndpoint(self.getShortName(child_element))
            self.readNetworkEndPoint(child_element, end_point)

    def getSocketConnectionIpduIdentifier(self, element: ET.Element) -> SocketConnectionIpduIdentifier:
        identifier = None
        if element is not None:
            identifier = SocketConnectionIpduIdentifier()
            identifier.setHeaderId(self.getChildElementOptionalPositiveInteger(element, "HEADER-ID"))
            identifier.setPduCollectionPduTimeout(self.getChildElementOptionalTimeValue(element, "PDU-COLLECTION-PDU-TIMEOUT"))
            semantics_literal = self.getChildElementOptionalLiteral(element, "PDU-COLLECTION-SEMANTICS")
            if semantics_literal is not None:
                from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.ServiceInstances import PduCollectionSemanticsEnum

                identifier.setPduCollectionSemantics(PduCollectionSemanticsEnum().setValue(semantics_literal.getValue()))
            trigger_literal = self.getChildElementOptionalLiteral(element, "PDU-COLLECTION-TRIGGER")
            if trigger_literal is not None:
                from armodel.models.M2.AUTOSARTemplates.SystemTemplate.Fibex.Fibex4Ethernet.ServiceInstances import PduCollectionTriggerEnum

                identifier.setPduCollectionTrigger(PduCollectionTriggerEnum().setValue(trigger_literal.getValue()))
            identifier.setPduTriggeringRef(self.getChildElementOptionalRefType(element, "PDU-TRIGGERING-REF"))
            routing_group_refs = []
            for ref in self.getChildElementRefTypeList(element, "ROUTING-GROUP-REFS/ROUTING-GROUP-REF"):
                routing_group_refs.append(ref)
            identifier.setRoutingGroupRefs(routing_group_refs)
        return identifier

    def getSocketConnectionPdus(self, element: ET.Element) -> List[SocketConnectionIpduIdentifier]:
        pdus = []
        for child_element in self.findall(element, "PDUS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SOCKET-CONNECTION-IPDU-IDENTIFIER":
                pdus.append(self.getSocketConnectionIpduIdentifier(child_element))
            else:
                self.notImplemented("Unsupported Pdu <%s>" % tag_name)
        return pdus

    def getSocketConnection(self, element: ET.Element) -> SocketConnection:
        connection = None
        if element is not None:
            connection = SocketConnection()
            runtime_port_configuration = self.getChildElementOptionalLiteral(element, "RUNTIME-PORT-CONFIGURATION")
            if runtime_port_configuration is not None:
                enum_value = RuntimeAddressConfigurationEnum()
                enum_value.setValue(runtime_port_configuration.getValue())
                connection.setRuntimePortConfiguration(enum_value)
            connection.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
            connection.setAllowedIPv6ExtHeadersRef(self.getChildElementOptionalRefType(element, "ALLOWED-I-PV-6-EXT-HEADERS-REF"))
            connection.setAllowedTcpOptionsRef(self.getChildElementOptionalRefType(element, "ALLOWED-TCP-OPTIONS-REF"))
            connection.setClientIpAddrFromConnectionRequest(self.getChildElementOptionalBooleanValue(element, "CLIENT-IP-ADDR-FROM-CONNECTION-REQUEST"))
            connection.setClientPortRef(self.getChildElementOptionalRefType(element, "CLIENT-PORT-REF"))
            connection.setClientPortFromConnectionRequest(self.getChildElementOptionalBooleanValue(element, "CLIENT-PORT-FROM-CONNECTION-REQUEST"))
            for pdu in self.getSocketConnectionPdus(element):
                connection.addPdu(pdu)
            connection.setPduCollectionMaxBufferSize(self.getChildElementOptionalPositiveInteger(element, "PDU-COLLECTION-MAX-BUFFER-SIZE"))
            connection.setPduCollectionTimeout(self.getChildElementOptionalTimeValue(element, "PDU-COLLECTION-TIMEOUT"))
            runtime_ip_address_configuration = self.getChildElementOptionalLiteral(element, "RUNTIME-IP-ADDRESS-CONFIGURATION")
            if runtime_ip_address_configuration is not None:
                ip_enum = RuntimeAddressConfigurationEnum()
                ip_enum.setValue(runtime_ip_address_configuration.getValue())
                connection.setRuntimeIpAddressConfiguration(ip_enum)
        return connection

    def readSocketConnectionBundleConnections(self, element: ET.Element, bundle: SocketConnectionBundle):
        for child_element in self.findall(element, "BUNDLED-CONNECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SOCKET-CONNECTION":
                bundle.addBundledConnection(self.getSocketConnection(child_element))
            else:
                self.notImplemented("Unsupported Bundled Connection <%s>" % tag_name)

    def readSocketConnectionBundle(self, element: ET.Element, bundle: SocketConnectionBundle):
        self.readSocketConnectionBundleConnections(element, bundle)
        bundle.setDifferentiatedServiceField(self.getChildElementOptionalPositiveInteger(element, "DIFFERENTIATED-SERVICE-FIELD"))
        bundle.setFlowLabel(self.getChildElementOptionalPositiveInteger(element, "FLOW-LABEL"))
        bundle.setPathMtuDiscoveryEnabled(self.getChildElementOptionalBooleanValue(element, "PATH-MTU-DISCOVERY-ENABLED"))
        for pdu in self.getSocketConnectionPdus(element):
            bundle.addPdu(pdu)
        bundle.setServerPortRef(self.getChildElementOptionalRefType(element, "SERVER-PORT-REF"))
        bundle.setUdpChecksumHandling(self.getChildElementOptionalLiteral(element, "UDP-CHECKSUM-HANDLING"))

    def readTcpOptionFilterSet(self, element: ET.Element, tcp_option_filter_set: TcpOptionFilterSet):
        self.logger.debug("Read TcpOptionFilterSet <%s>" % tcp_option_filter_set.getShortName())
        self.readIdentifiable(element, tcp_option_filter_set)
        self.getTcpOptionFilterLists(element, tcp_option_filter_set)

    def getTcpOptionFilterLists(self, element: ET.Element, tcp_option_filter_set: TcpOptionFilterSet):
        for child_element in self.findall(element, "TCP-OPTION-FILTER-LISTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TCP-OPTION-FILTER-LIST":
                tcp_filter_list = tcp_option_filter_set.createTcpOptionFilterList(self.getShortName(child_element))
                self.readTcpOptionFilterList(child_element, tcp_filter_list)
            else:
                self.notImplemented("Unsupported TcpOptionFilterList <%s>" % tag_name)

    def readTcpOptionFilterList(self, element: ET.Element, tcp_filter_list: TcpOptionFilterList):
        self.readIdentifiable(element, tcp_filter_list)
        options_element = self.find(element, "ALLOWED-TCP-OPTIONS")
        if options_element is not None:
            for value in self.getChildElementNumericalValueList(options_element, "ALLOWED-TCP-OPTION"):
                option = PositiveInteger()
                option.setValue(str(int(value.getValue())))
                tcp_filter_list.addAllowedTcpOption(option)

    def readSoAdConfigConnectionBundles(self, element: ET.Element, config: SoAdConfig):
        for child_element in self.findall(element, "CONNECTION-BUNDLES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SOCKET-CONNECTION-BUNDLE":
                bundle = config.createSocketConnectionBundle(self.getShortName(child_element))
                self.readSocketConnectionBundle(child_element, bundle)
            else:
                self.notImplemented("Unsupported Connection Bundle <%s>" % tag_name)

    def getTpPort(self, element: ET.Element, key: str) -> TpPort:
        port = None
        child_element = self.find(element, key)
        if child_element is not None:
            port = TpPort()
            port.setDynamicallyAssigned(self.getChildElementOptionalBooleanValue(child_element, "DYNAMICALLY-ASSIGNED"))
            port.setPortNumber(self.getChildElementOptionalPositiveInteger(child_element, "PORT-NUMBER"))
        return port

    def readUdpTp(self, element: ET.Element, tp: UdpTp):
        tp.setUdpTpPort(self.getTpPort(element, "UDP-TP-PORT"))

    def readTcpTp(self, element: ET.Element, tp: TcpTp):
        tp.setKeepAliveInterval(self.getChildElementOptionalTimeValue(element, "KEEP-ALIVE-INTERVAL"))
        tp.setKeepAliveProbesMax(self.getChildElementOptionalPositiveInteger(element, "KEEP-ALIVE-PROBES-MAX"))
        tp.setKeepAliveTime(self.getChildElementOptionalTimeValue(element, "KEEP-ALIVE-TIME"))
        tp.setKeepAlives(self.getChildElementOptionalBooleanValue(element, "KEEP-ALIVES"))
        tp.setNaglesAlgorithm(self.getChildElementOptionalLiteral(element, "NAGLES-ALGORITHM"))
        tp.setReceiveWindowMin(self.getChildElementOptionalPositiveInteger(element, "RECEIVE-WINDOW-MIN"))
        tp.setTcpRetransmissionTimeout(self.getChildElementOptionalTimeValue(element, "TCP-RETRANSMISSION-TIMEOUT"))
        tp.setTcpTpPort(self.getTpPort(element, "TCP-TP-PORT"))

    def readGenericTp(self, element: ET.Element, tp: GenericTp):
        tp.setTpAddress(self.getChildElementOptionalLiteral(element, "TP-ADDRESS"))
        tp.setTpTechnology(self.getChildElementOptionalLiteral(element, "TP-TECHNOLOGY"))

    def getTransportProtocolConfiguration(self, element: ET.Element, key: str) -> TransportProtocolConfiguration:
        configuration = None
        child_element = self.find(element, "%s/*" % key)
        if child_element is not None:
            tag_name = self.getTagName(child_element)
            if tag_name == "UDP-TP":
                configuration = UdpTp()
                self.readUdpTp(child_element, configuration)
            elif tag_name == "TCP-TP":
                configuration = TcpTp()
                self.readTcpTp(child_element, configuration)
            elif tag_name == "GENERIC-TP":
                configuration = GenericTp()
                self.readGenericTp(child_element, configuration)
            else:
                self.notImplemented("Unsupported TransportProtocolConfiguration <%s>" % tag_name)
        return configuration

    def readConsumedEventGroupRoutingGroupRefs(self, element: ET.Element, group: ConsumedEventGroup):
        for ref in self.getChildElementRefTypeList(element, "ROUTING-GROUP-REFS/ROUTING-GROUP-REF"):
            group.addRoutingGroupRef(ref)

    def getRequestResponseDelay(self, element: ET.Element, key: str) -> RequestResponseDelay:
        delay = None
        child_element = self.find(element, key)
        if child_element is not None:
            delay = RequestResponseDelay()
            delay.setMaxValue(self.getChildElementOptionalTimeValue(child_element, "MAX-VALUE"))
            delay.setMinValue(self.getChildElementOptionalTimeValue(child_element, "MIN-VALUE"))
        return delay

    def getSdClientConfig(self, element: ET.Element, key: str) -> SdClientConfig:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = SdClientConfig()
            for tag in self.getTagWithOptionalValues(child_element, "CAPABILITY-RECORDS"):
                config.addCapabilityRecord(tag)
            config.setClientServiceMajorVersion(self.getChildElementOptionalPositiveInteger(child_element, "CLIENT-SERVICE-MAJOR-VERSION"))
            config.setClientServiceMinorVersion(self.getChildElementOptionalPositiveInteger(child_element, "CLIENT-SERVICE-MINOR-VERSION"))
            config.setInitialFindBehavior(self.getInitialSdDelayConfig(child_element, "INITIAL-FIND-BEHAVIOR"))
            config.setRequestResponseDelay(self.getRequestResponseDelay(child_element, "REQUEST-RESPONSE-DELAY"))
            config.setTtl(self.getChildElementOptionalPositiveInteger(child_element, "TTL"))
        return config

    def readAbstractServiceInstanceMethodActivationRoutingGroups(self, element: ET.Element, instance: AbstractServiceInstance):
        for child_element in self.findall(element, "METHOD-ACTIVATION-ROUTING-GROUPS/PDU-ACTIVATION-ROUTING-GROUP"):
            instance.setMethodActivationRoutingGroup(self.getPduActivationRoutingGroup(child_element))

    def readConsumedEventGroup(self, element: ET.Element, group: ConsumedEventGroup):
        self.readIdentifiable(element, group)
        group.setApplicationEndpointRef(self.getChildElementOptionalRefType(element, "APPLICATION-ENDPOINT-REF"))
        group.setAutoRequire(self.getChildElementOptionalBooleanValue(element, "AUTO-REQUIRE"))
        group.setEventGroupIdentifier(self.getChildElementOptionalPositiveInteger(element, "EVENT-GROUP-IDENTIFIER"))
        for ref in self.getChildElementRefTypeList(element, "EVENT-MULTICAST-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            group.addEventMulticastAddressRef(ref)
        for child_element in self.findall(element, "PDU-ACTIVATION-ROUTING-GROUPS/PDU-ACTIVATION-ROUTING-GROUP"):
            group.addPduActivationRoutingGroup(self.getPduActivationRoutingGroup(child_element))
        group.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))
        self.readConsumedEventGroupRoutingGroupRefs(element, group)
        group.setSdClientConfig(self.getSdClientConfig(element, "SD-CLIENT-CONFIG"))
        group.setSdClientTimerConfigRef(
            self.getChildElementOptionalRefType(element, "SD-CLIENT-TIMER-CONFIGS/SOMEIP-SD-CLIENT-EVENT-GROUP-TIMING-CONFIG-REF-CONDITIONAL/SOMEIP-SD-CLIENT-EVENT-GROUP-TIMING-CONFIG-REF")
        )

    def readConsumedServiceInstanceConsumedEventGroups(self, element: ET.Element, instance: ConsumedServiceInstance):
        for child_element in self.findall(element, "CONSUMED-EVENT-GROUPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CONSUMED-EVENT-GROUP":
                group = instance.createConsumedEventGroup(self.getShortName(child_element))
                self.readConsumedEventGroup(child_element, group)
            else:
                self.notImplemented("Unsupported ConsumedEventGroups <%s>" % tag_name)

    def getSomeipServiceVersions(self, element: ET.Element, key: str) -> List[SomeipServiceVersion]:
        versions = []
        wrapper = self.find(element, key)
        if wrapper is not None:
            for child_element in self.findall(wrapper, "SOMEIP-SERVICE-VERSION"):
                version = SomeipServiceVersion()
                version.setMajorVersion(self.getChildElementOptionalPositiveInteger(child_element, "MAJOR-VERSION"))
                version.setMinorVersion(self.getChildElementOptionalPositiveInteger(child_element, "MINOR-VERSION"))
                versions.append(version)
        return versions

    def readConsumedProvidedServiceInstanceGroup(self, element: ET.Element, instance: ConsumedProvidedServiceInstanceGroup):
        self.readIdentifiable(element, instance)
        for ref in self.getChildElementRefTypeList(element, "CONSUMED-SERVICE-INSTANCES/CONSUMED-SERVICE-INSTANCE-REF-CONDITIONAL/CONSUMED-SERVICE-INSTANCE-REF"):
            instance.addConsumedServiceInstanceRef(ref)
        for ref in self.getChildElementRefTypeList(element, "PROVIDED-SERVICE-INSTANCES/PROVIDED-SERVICE-INSTANCE-REF-CONDITIONAL/PROVIDED-SERVICE-INSTANCE-REF"):
            instance.addProvidedServiceInstanceRef(ref)

    def readConsumedServiceInstance(self, element: ET.Element, instance: ConsumedServiceInstance):
        self.readIdentifiable(element, instance)
        for ref in self.getChildElementRefTypeList(element, "ALLOWED-SERVICE-PROVIDERS/NETWORK-ENDPOINT-REF-CONDITIONAL/NETWORK-ENDPOINT-REF"):
            instance.addAllowedServiceProviderRef(ref)
        instance.setAutoRequire(self.getChildElementOptionalBooleanValue(element, "AUTO-REQUIRE"))
        for version in self.getSomeipServiceVersions(element, "BLOCKLISTED-VERSIONS"):
            instance.addBlocklistedVersion(version)
        for tag in self.getTagWithOptionalValues(element, "CAPABILITY-RECORDS"):
            instance.addCapabilityRecord(tag)
        self.readAbstractServiceInstanceMethodActivationRoutingGroups(element, instance)
        self.readConsumedServiceInstanceConsumedEventGroups(element, instance)
        instance.setEventMulticastSubscriptionAddressRef(
            self.getChildElementOptionalRefType(element, "EVENT-MULTICAST-SUBSCRIPTION-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF")
        )
        instance_id_literal = self.getChildElementOptionalLiteral(element, "INSTANCE-IDENTIFIER")
        if instance_id_literal is not None:
            instance_id = AnyServiceInstanceId()
            instance_id.setValue(instance_id_literal.getValue())
            instance.setInstanceIdentifier(instance_id)
        for ref in self.getChildElementRefTypeList(element, "LOCAL-UNICAST-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            instance.addLocalUnicastAddressRef(ref)
        instance.setMajorVersion(self.getChildElementOptionalPositiveInteger(element, "MAJOR-VERSION"))
        minor_version_literal = self.getChildElementOptionalLiteral(element, "MINOR-VERSION")
        if minor_version_literal is not None:
            minor_version = AnyVersionString()
            minor_version.setValue(minor_version_literal.getValue())
            instance.setMinorVersion(minor_version)
        instance.setProvidedServiceInstanceRef(self.getChildElementOptionalRefType(element, "PROVIDED-SERVICE-INSTANCE-REF"))
        for ref in self.getChildElementRefTypeList(element, "REMOTE-UNICAST-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            instance.addRemoteUnicastAddressRef(ref)
        for ref in self.getChildElementRefTypeList(element, "ROUTING-GROUP-REFS/ROUTING-GROUP-REF"):
            instance.addRoutingGroupRef(ref)
        instance.setSdClientConfig(self.getSdClientConfig(element, "SD-CLIENT-CONFIG"))
        instance.setSdClientTimerConfigRef(
            self.getChildElementOptionalRefType(element, "SD-CLIENT-TIMER-CONFIGS/SOMEIP-SD-CLIENT-SERVICE-INSTANCE-CONFIG-REF-CONDITIONAL/SOMEIP-SD-CLIENT-SERVICE-INSTANCE-CONFIG-REF")
        )
        instance.setServiceIdentifier(self.getChildElementOptionalPositiveInteger(element, "SERVICE-IDENTIFIER"))
        behavior_literal = self.getChildElementOptionalLiteral(element, "VERSION-DRIVEN-FIND-BEHAVIOR")
        if behavior_literal is not None:
            behavior = ServiceVersionAcceptanceKindEnum()
            behavior.setValue(behavior_literal.getValue())
            instance.setVersionDrivenFindBehavior(behavior)

    def readSocketAddressApplicationEndpointConsumedServiceInstances(self, element: ET.Element, end_point: ApplicationEndpoint):
        for child_element in self.findall(element, "CONSUMED-SERVICE-INSTANCES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CONSUMED-SERVICE-INSTANCE":
                instance = end_point.createConsumedServiceInstance(self.getShortName(child_element))
                self.readConsumedServiceInstance(child_element, instance)
            else:
                self.notImplemented("Unsupported ConsumedServiceInstances <%s>" % tag_name)

    def getInitialSdDelayConfig(self, element: ET.Element, key: str) -> InitialSdDelayConfig:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = InitialSdDelayConfig()
            config.setInitialDelayMaxValue(self.getChildElementOptionalTimeValue(child_element, "INITIAL-DELAY-MAX-VALUE"))
            config.setInitialDelayMinValue(self.getChildElementOptionalTimeValue(child_element, "INITIAL-DELAY-MIN-VALUE"))
            config.setInitialRepetitionsBaseDelay(self.getChildElementOptionalTimeValue(child_element, "INITIAL-REPETITIONS-BASE-DELAY"))
            config.setInitialRepetitionsMax(self.getChildElementOptionalPositiveInteger(child_element, "INITIAL-REPETITIONS-MAX"))
        return config

    def getTagWithOptionalValue(self, element: ET.Element, key: str) -> Optional[TagWithOptionalValue]:
        tag = None
        child_element = self.find(element, key)
        if child_element is not None:
            tag = TagWithOptionalValue()
            self.readARObject(child_element, tag)
            tag.setKey(self.getChildElementOptionalString(child_element, "KEY"))
            tag.setSequenceOffset(self.getChildElementOptionalIntegerValue(child_element, "SEQUENCE-OFFSET"))
            tag.setValue(self.getChildElementOptionalString(child_element, "VALUE"))
        return tag

    def getTagWithOptionalValues(self, element: ET.Element, key: str) -> List[TagWithOptionalValue]:
        tags = []
        wrapper = self.find(element, key)
        if wrapper is not None:
            for child_element in self.findall(wrapper, "TAG-WITH-OPTIONAL-VALUE"):
                tag = TagWithOptionalValue()
                self.readARObject(child_element, tag)
                tag.setKey(self.getChildElementOptionalString(child_element, "KEY"))
                tag.setSequenceOffset(self.getChildElementOptionalIntegerValue(child_element, "SEQUENCE-OFFSET"))
                tag.setValue(self.getChildElementOptionalString(child_element, "VALUE"))
                tags.append(tag)
        return tags

    def readSomeipSdClientServiceInstanceConfig(self, element: ET.Element, config: SomeipSdClientServiceInstanceConfig):
        self.logger.debug("Read SomeipSdClientServiceInstanceConfig <%s>" % config.getShortName())
        self.readIdentifiable(element, config)
        config.setInitialFindBehavior(self.getInitialSdDelayConfig(element, "INITIAL-FIND-BEHAVIOR"))
        config.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))
        config.setServiceFindTimeToLive(self.getChildElementOptionalPositiveInteger(element, "SERVICE-FIND-TIME-TO-LIVE"))

    def readSomeipSdClientEventGroupTimingConfig(self, element: ET.Element, config: SomeipSdClientEventGroupTimingConfig):
        self.logger.debug("Read SomeipSdClientEventGroupTimingConfig <%s>" % config.getShortName())
        self.readIdentifiable(element, config)
        config.setRequestResponseDelay(self.getRequestResponseDelay(element, "REQUEST-RESPONSE-DELAY"))
        config.setSubscribeEventgroupRetryDelay(self.getChildElementOptionalTimeValue(element, "SUBSCRIBE-EVENTGROUP-RETRY-DELAY"))
        config.setSubscribeEventgroupRetryMax(self.getChildElementOptionalPositiveInteger(element, "SUBSCRIBE-EVENTGROUP-RETRY-MAX"))
        config.setTimeToLive(self.getChildElementOptionalPositiveInteger(element, "TIME-TO-LIVE"))

    def readSomeipSdServerEventGroupTimingConfig(self, element: ET.Element, config: SomeipSdServerEventGroupTimingConfig):
        self.logger.debug("Read SomeipSdServerEventGroupTimingConfig <%s>" % config.getShortName())
        self.readIdentifiable(element, config)
        config.setRequestResponseDelay(self.getRequestResponseDelay(element, "REQUEST-RESPONSE-DELAY"))

    def getSdServerConfig(self, element: ET.Element, key: str) -> SdServerConfig:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = SdServerConfig()
            config.setInitialOfferBehavior(self.getInitialSdDelayConfig(child_element, "INITIAL-OFFER-BEHAVIOR"))
            config.setOfferCyclicDelay(self.getChildElementOptionalTimeValue(child_element, "OFFER-CYCLIC-DELAY"))
            config.setRequestResponseDelay(self.getRequestResponseDelay(child_element, "REQUEST-RESPONSE-DELAY"))
            config.setServerServiceMajorVersion(self.getChildElementOptionalPositiveInteger(child_element, "SERVER-SERVICE-MAJOR-VERSION"))
            config.setServerServiceMinorVersion(self.getChildElementOptionalPositiveInteger(child_element, "SERVER-SERVICE-MINOR-VERSION"))
            config.setTtl(self.getChildElementOptionalPositiveInteger(child_element, "TTL"))
        return config

    def readEventHandler(self, element: ET.Element, handler: EventHandler):
        self.readIdentifiable(element, handler)
        for ref in self.getChildElementRefTypeList(element, "CONSUMED-EVENT-GROUP-REFS/CONSUMED-EVENT-GROUP-REF"):
            handler.addConsumedEventGroupRef(ref)
        handler.setEventGroupIdentifier(self.getChildElementOptionalPositiveInteger(element, "EVENT-GROUP-IDENTIFIER"))
        for ref in self.getChildElementRefTypeList(element, "EVENT-MULTICAST-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            handler.setEventMulticastAddressRef(ref)
        handler.setMulticastThreshold(self.getChildElementOptionalPositiveInteger(element, "MULTICAST-THRESHOLD"))
        for child_element in self.findall(element, "PDU-ACTIVATION-ROUTING-GROUPS/PDU-ACTIVATION-ROUTING-GROUP"):
            handler.addPduActivationRoutingGroup(self.getPduActivationRoutingGroup(child_element))
        for ref in self.getChildElementRefTypeList(element, "ROUTING-GROUP-REFS/ROUTING-GROUP-REF"):
            handler.addRoutingGroupRef(ref)
        handler.setSdServerConfig(self.getSdServerConfig(element, "SD-SERVER-CONFIG"))
        for ref in self.getChildElementRefTypeList(element, "SD-SERVER-EG-TIMING-CONFIGS/SOMEIP-SD-SERVER-EVENT-GROUP-TIMING-CONFIG-REF-CONDITIONAL/SOMEIP-SD-SERVER-EVENT-GROUP-TIMING-CONFIG-REF"):
            handler.setSdServerEgTimingConfigRef(ref)

    def readProvidedServiceInstanceEventHandlers(self, element: ET.Element, instance: ProvidedServiceInstance):
        for child_element in self.findall(element, "EVENT-HANDLERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "EVENT-HANDLER":
                handler = instance.createEventHandler(self.getShortName(child_element))
                self.readEventHandler(child_element, handler)
            else:
                self.notImplemented("Unsupported Event Handler <%s>" % tag_name)

    def readProvidedServiceInstance(self, element: ET.Element, instance: ProvidedServiceInstance):
        self.readIdentifiable(element, instance)
        for tag in self.getTagWithOptionalValues(element, "CAPABILITY-RECORDS"):
            instance.addCapabilityRecord(tag)
        self.readAbstractServiceInstanceMethodActivationRoutingGroups(element, instance)
        self.readProvidedServiceInstanceEventHandlers(element, instance)
        instance.setInstanceIdentifier(self.getChildElementOptionalPositiveInteger(element, "INSTANCE-IDENTIFIER"))
        instance.setLoadBalancingPriority(self.getChildElementOptionalPositiveInteger(element, "LOAD-BALANCING-PRIORITY"))
        instance.setLoadBalancingWeight(self.getChildElementOptionalPositiveInteger(element, "LOAD-BALANCING-WEIGHT"))
        for ref in self.getChildElementRefTypeList(element, "LOCAL-UNICAST-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            instance.addLocalUnicastAddressRef(ref)
        instance.setMajorVersion(self.getChildElementOptionalPositiveInteger(element, "MAJOR-VERSION"))
        instance.setMinorVersion(self.getChildElementOptionalPositiveInteger(element, "MINOR-VERSION"))
        instance.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))
        for ref in self.getChildElementRefTypeList(element, "REMOTE-MULTICAST-SUBSCRIPTION-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            instance.addRemoteMulticastSubscriptionAddressRef(ref)
        for ref in self.getChildElementRefTypeList(element, "REMOTE-UNICAST-ADDRESSS/APPLICATION-ENDPOINT-REF-CONDITIONAL/APPLICATION-ENDPOINT-REF"):
            instance.addRemoteUnicastAddressRef(ref)
        for ref in self.getChildElementRefTypeList(element, "ROUTING-GROUP-REFS/ROUTING-GROUP-REF"):
            instance.addRoutingGroupRef(ref)
        instance.setSdServerConfig(self.getSdServerConfig(element, "SD-SERVER-CONFIG"))
        instance.setSdServerTimerConfigRef(
            self.getChildElementOptionalRefType(element, "SD-SERVER-TIMER-CONFIGS/SOMEIP-SD-SERVER-SERVICE-INSTANCE-CONFIG-REF-CONDITIONAL/SOMEIP-SD-SERVER-SERVICE-INSTANCE-CONFIG-REF")
        )
        for ref in self.getChildElementRefTypeList(element, "ALLOWED-SERVICE-CONSUMERS/NETWORK-ENDPOINT-REF-CONDITIONAL/NETWORK-ENDPOINT-REF"):
            instance.addAllowedServiceConsumerRef(ref)
        instance.setAutoAvailable(self.getChildElementOptionalBooleanValue(element, "AUTO-AVAILABLE"))
        instance.setServiceIdentifier(self.getChildElementOptionalPositiveInteger(element, "SERVICE-IDENTIFIER"))

    def readSocketAddressApplicationEndpointProvidedServiceInstance(self, element: ET.Element, end_point: ApplicationEndpoint):
        for child_element in self.findall(element, "PROVIDED-SERVICE-INSTANCES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PROVIDED-SERVICE-INSTANCE":
                instance = end_point.createProvidedServiceInstance(self.getShortName(child_element))
                self.readProvidedServiceInstance(child_element, instance)
            else:
                self.notImplemented("Unsupported ConsumedServiceInstances <%s>" % tag_name)

    def readSocketAddressApplicationEndpoint(self, element: ET.Element, address: SocketAddress):
        child_element = self.find(element, "APPLICATION-ENDPOINT")
        if child_element is not None:
            end_point = address.createApplicationEndpoint(self.getShortName(child_element))
            self.readIdentifiable(child_element, end_point)
            self.readSocketAddressApplicationEndpointConsumedServiceInstances(child_element, end_point)
            end_point.setMaxNumberOfConnections(self.getChildElementOptionalPositiveInteger(child_element, "MAX-NUMBER-OF-CONNECTIONS"))
            end_point.setNetworkEndpointRef(self.getChildElementOptionalRefType(child_element, "NETWORK-ENDPOINT-REF"))
            end_point.setPriority(self.getChildElementOptionalPositiveInteger(child_element, "PRIORITY"))
            self.readSocketAddressApplicationEndpointProvidedServiceInstance(child_element, end_point)
            end_point.setTlsCryptoMappingRef(self.getChildElementOptionalRefType(child_element, "TLS-CRYPTO-MAPPING-REF"))
            end_point.setTpConfiguration(self.getTransportProtocolConfiguration(child_element, "TP-CONFIGURATION"))

    def readSocketAddressMulticastConnectorRefs(self, element: ET.Element, address: SocketAddress):
        for ref in self.getChildElementRefTypeList(element, "MULTICAST-CONNECTOR-REFS/MULTICAST-CONNECTOR-REF"):
            address.addMulticastConnectorRef(ref)

    def readSocketAddress(self, element: ET.Element, address: SocketAddress):
        self.readIdentifiable(element, address)
        address.setAllowedIPv6ExtHeadersRef(self.getChildElementOptionalRefType(element, "ALLOWED-I-PV-6-EXT-HEADERS-REF"))
        address.setAllowedTcpOptionsRef(self.getChildElementOptionalRefType(element, "ALLOWED-TCP-OPTIONS-REF"))
        self.readSocketAddressApplicationEndpoint(element, address)
        address.setConnectorRef(self.getChildElementOptionalRefType(element, "CONNECTOR-REF"))
        address.setDifferentiatedServiceField(self.getChildElementOptionalPositiveInteger(element, "DIFFERENTIATED-SERVICE-FIELD"))
        address.setFlowLabel(self.getChildElementOptionalPositiveInteger(element, "FLOW-LABEL"))
        self.readSocketAddressMulticastConnectorRefs(element, address)
        address.setPathMtuDiscoveryEnabled(self.getChildElementOptionalBooleanValue(element, "PATH-MTU-DISCOVERY-ENABLED"))
        address.setPduCollectionMaxBufferSize(self.getChildElementOptionalPositiveInteger(element, "PDU-COLLECTION-MAX-BUFFER-SIZE"))
        address.setPduCollectionTimeout(self.getChildElementOptionalTimeValue(element, "PDU-COLLECTION-TIMEOUT"))
        for child_element in self.findall(element, "STATIC-SOCKET-CONNECTIONS/STATIC-SOCKET-CONNECTION"):
            address.addStaticSocketConnection(self.getStaticSocketConnection(child_element))
        behavior_literal = self.getChildElementOptionalLiteral(element, "UDP-CHECKSUM-HANDLING")
        if behavior_literal is not None:
            behavior = UdpChecksumCalculationEnum()
            behavior.setValue(behavior_literal.getValue())
            address.setUdpChecksumHandling(behavior)

    def readSoAdConfigSocketAddresses(self, element: ET.Element, config: SoAdConfig):
        for child_element in self.findall(element, "SOCKET-ADDRESSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SOCKET-ADDRESS":
                address = config.createSocketAddress(self.getShortName(child_element))
                self.readSocketAddress(child_element, address)
            else:
                self.notImplemented("Unsupported Socket Address <%s>" % tag_name)

    def readSoAdConfigConnections(self, element: ET.Element, config: SoAdConfig):
        for child_element in self.findall(element, "CONNECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SOCKET-CONNECTION":
                config.addConnection(self.getSocketConnection(child_element))
            else:
                self.notImplemented("Unsupported Connection <%s>" % tag_name)

    def getSoAdConfig(self, element: ET.Element, key: str) -> SoAdConfig:
        child_element = self.find(element, key)
        config = None
        if child_element is not None:
            config = SoAdConfig()
            self.readSoAdConfigConnections(child_element, config)
            self.readSoAdConfigConnectionBundles(child_element, config)
            self.readSoAdConfigSocketAddresses(child_element, config)
        return config

    def readEthernetPhysicalChannelVlan(self, element: ET.Element, channel: EthernetPhysicalChannel):
        child_element = self.find(element, "VLAN")
        if child_element is not None:
            vlan = channel.createVlanConfig(self.getShortName(child_element))
            vlan.setVlanIdentifier(self.getChildElementOptionalPositiveInteger(child_element, "VLAN-IDENTIFIER"))

    def readEthernetPhysicalChannel(self, element: ET.Element, channel: EthernetPhysicalChannel):
        self.readPhysicalChannel(element, channel)
        self.readEthernetPhysicalChannelNetworkEndPoints(element, channel)
        channel.setSoAdConfig(self.getSoAdConfig(element, "SO-AD-CONFIG"))
        self.readEthernetPhysicalChannelVlan(element, channel)

    def readFlexrayPhysicalChannel(self, element: ET.Element, channel: FlexrayPhysicalChannel):
        self.readPhysicalChannel(element, channel)
        channel.setChannelName(self.getChildElementOptionalLiteral(element, "CHANNEL-NAME"))

    def readCommunicationClusterPhysicalChannels(self, element: ET.Element, cluster: CommunicationCluster):
        for child_element in self.findall(element, "PHYSICAL-CHANNELS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-PHYSICAL-CHANNEL":
                channel = cluster.createCanPhysicalChannel(self.getShortName(child_element))
                self.readCanPhysicalChannel(child_element, channel)
            elif tag_name == "LIN-PHYSICAL-CHANNEL":
                channel = cluster.createLinPhysicalChannel(self.getShortName(child_element))
                self.readLinPhysicalChannel(child_element, channel)
            elif tag_name == "ETHERNET-PHYSICAL-CHANNEL":
                channel = cluster.createEthernetPhysicalChannel(self.getShortName(child_element))
                self.readEthernetPhysicalChannel(child_element, channel)
            elif tag_name == "FLEXRAY-PHYSICAL-CHANNEL":
                channel = cluster.createFlexrayPhysicalChannel(self.getShortName(child_element))
                self.readFlexrayPhysicalChannel(child_element, channel)
            else:
                self.notImplemented("Unsupported Physical Channel <%s>" % tag_name)

    def readCommunicationCluster(self, element: ET.Element, cluster: CommunicationCluster):
        cluster.setBaudrate(self.getChildElementOptionalNumericalValue(element, "BAUDRATE"))
        self.readCommunicationClusterPhysicalChannels(element, cluster)
        cluster.setProtocolName(self.getChildElementOptionalLiteral(element, "PROTOCOL-NAME"))
        cluster.setProtocolVersion(self.getChildElementOptionalLiteral(element, "PROTOCOL-VERSION"))

    def getCanClusterBusOffRecovery(self, element: ET.Element, key: str) -> CanClusterBusOffRecovery:
        recovery = None
        child_element = self.find(element, key)
        if child_element is not None:
            recovery = CanClusterBusOffRecovery()
            recovery.setBorCounterL1ToL2(self.getChildElementOptionalPositiveInteger(child_element, "BOR-COUNTER-L-1-TO-L-2"))
            recovery.setBorTimeL1(self.getChildElementOptionalTimeValue(child_element, "BOR-TIME-L-1"))
            recovery.setBorTimeL2(self.getChildElementOptionalTimeValue(child_element, "BOR-TIME-L-2"))
            recovery.setBorTimeTxEnsured(self.getChildElementOptionalTimeValue(child_element, "BOR-TIME-TX-ENSURED"))
            recovery.setMainFunctionPeriod(self.getChildElementOptionalTimeValue(child_element, "MAIN-FUNCTION-PERIOD"))
        return recovery

    def readAbstractCanCluster(self, element: ET.Element, cluster: AbstractCanCluster):
        self.readCommunicationCluster(element, cluster)
        cluster.setBusOffRecovery(self.getCanClusterBusOffRecovery(element, "BUS-OFF-RECOVERY"))
        cluster.setCanFdBaudrate(self.getChildElementOptionalNumericalValue(element, "CAN-FD-BAUDRATE"))
        cluster.setCanXlBaudrate(self.getChildElementOptionalNumericalValue(element, "CAN-XL-BAUDRATE"))

    def readLinCluster(self, element: ET.Element, cluster: LinCluster):
        self.logger.debug("Read LinCluster <%s>" % cluster.getShortName())
        self.readIdentifiable(element, cluster)
        child_element = self.find(element, "LIN-CLUSTER-VARIANTS/LIN-CLUSTER-CONDITIONAL")
        if child_element is not None:
            self.readCommunicationCluster(child_element, cluster)

    def readCanCluster(self, element: ET.Element, cluster: CanCluster):
        self.logger.debug("Read CanCluster <%s>" % cluster.getShortName())
        self.readIdentifiable(element, cluster)
        child_element = self.find(element, "CAN-CLUSTER-VARIANTS/CAN-CLUSTER-CONDITIONAL")
        if child_element is not None:
            self.readAbstractCanCluster(child_element, cluster)

    def readJ1939Cluster(self, element: ET.Element, cluster: J1939Cluster):
        self.logger.debug("Read J1939Cluster <%s>" % cluster.getShortName())
        self.readIdentifiable(element, cluster)
        child_element = self.find(element, "J-1939-CLUSTER-VARIANTS/J-1939-CLUSTER-CONDITIONAL")
        if child_element is not None:
            self.readAbstractCanCluster(child_element, cluster)
            cluster.setNetworkId(self.getChildElementOptionalPositiveInteger(child_element, "NETWORK-ID"))
            cluster.setRequest2Support(self.getChildElementOptionalBooleanValue(child_element, "REQUEST-2-SUPPORT"))
            cluster.setUsesAddressArbitration(self.getChildElementOptionalBooleanValue(child_element, "USES-ADDRESS-ARBITRATION"))

    def readUdpProps(self, element: ET.Element, props: UdpProps):
        """Read an R23-11 <UDP-PROPS> element (Table 3.110, p.154): single optional UDP-TTL."""
        props.setUdpTtl(self.getChildElementOptionalPositiveInteger(element, "UDP-TTL"))

    def readEthTcpIpProps(self, element: ET.Element, props: EthTcpIpProps):
        """Read an R23-11 <ETH-TCP-IP-PROPS> element (Table 3.109, p.153): SHORT-NAME, TCP-PROPS, UDP-PROPS."""
        self.readIdentifiable(element, props)
        child_element = self.find(element, "TCP-PROPS")
        if child_element is not None:
            tcp_props = TcpProps()
            self.readTcpProps(child_element, tcp_props)
            props.setTcpProps(tcp_props)
        child_element = self.find(element, "UDP-PROPS")
        if child_element is not None:
            udp_props = UdpProps()
            self.readUdpProps(child_element, udp_props)
            props.setUdpProps(udp_props)

    def readTcpProps(self, element: ET.Element, props: TcpProps):
        """Read an R23-11 <TCP-PROPS> element (Table 3.111, p.155): 18 optional attributes in XSD order."""
        props.setTcpCongestionAvoidanceEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-CONGESTION-AVOIDANCE-ENABLED"))
        props.setTcpDelayedAckTimeout(self.getChildElementOptionalTimeValue(element, "TCP-DELAYED-ACK-TIMEOUT"))
        props.setTcpFastRecoveryEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-FAST-RECOVERY-ENABLED"))
        props.setTcpFastRetransmitEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-FAST-RETRANSMIT-ENABLED"))
        props.setTcpFinWait2Timeout(self.getChildElementOptionalTimeValue(element, "TCP-FIN-WAIT2TIMEOUT"))
        props.setTcpKeepAliveEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-KEEP-ALIVE-ENABLED"))
        props.setTcpKeepAliveInterval(self.getChildElementOptionalTimeValue(element, "TCP-KEEP-ALIVE-INTERVAL"))
        props.setTcpKeepAliveProbesMax(self.getChildElementOptionalPositiveInteger(element, "TCP-KEEP-ALIVE-PROBES-MAX"))
        props.setTcpKeepAliveTime(self.getChildElementOptionalTimeValue(element, "TCP-KEEP-ALIVE-TIME"))
        props.setTcpMaxRtx(self.getChildElementOptionalPositiveInteger(element, "TCP-MAX-RTX"))
        props.setTcpMsl(self.getChildElementOptionalTimeValue(element, "TCP-MSL"))
        props.setTcpNagleEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-NAGLE-ENABLED"))
        props.setTcpReceiveWindowMax(self.getChildElementOptionalPositiveInteger(element, "TCP-RECEIVE-WINDOW-MAX"))
        props.setTcpRetransmissionTimeout(self.getChildElementOptionalTimeValue(element, "TCP-RETRANSMISSION-TIMEOUT"))
        props.setTcpSlowStartEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-SLOW-START-ENABLED"))
        props.setTcpSynMaxRtx(self.getChildElementOptionalPositiveInteger(element, "TCP-SYN-MAX-RTX"))
        props.setTcpSynReceivedTimeout(self.getChildElementOptionalTimeValue(element, "TCP-SYN-RECEIVED-TIMEOUT"))
        props.setTcpTtl(self.getChildElementOptionalPositiveInteger(element, "TCP-TTL"))

    def readTcpIpIcmpv4Props(self, element: ET.Element, props: TcpIpIcmpv4Props):
        """Read an R23-11 <TCP-IP-ICMPV-4-PROPS> element (Table 3.113, p.156): 2 optional attributes in XSD order."""
        props.setTcpIpIcmpV4EchoReplyEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-IP-ICMP-V-4-ECHO-REPLY-ENABLED"))
        props.setTcpIpIcmpV4Ttl(self.getChildElementOptionalPositiveInteger(element, "TCP-IP-ICMP-V-4-TTL"))

    def readTcpIpIcmpv6Props(self, element: ET.Element, props: TcpIpIcmpv6Props):
        """Read an R23-11 <ICMP-V-6-PROPS> element (Table 3.114, p.157): 5 optional attributes in XSD order."""
        props.setTcpIpIcmpV6EchoReplyAvoidFragmentation(self.getChildElementOptionalBooleanValue(element, "TCP-IP-ICMP-V-6-ECHO-REPLY-AVOID-FRAGMENTATION"))
        props.setTcpIpIcmpV6EchoReplyEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-IP-ICMP-V-6-ECHO-REPLY-ENABLED"))
        props.setTcpIpIcmpV6HopLimit(self.getChildElementOptionalPositiveInteger(element, "TCP-IP-ICMP-V-6-HOP-LIMIT"))
        props.setTcpIpIcmpV6MsgDestinationUnreachableEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-IP-ICMP-V-6-MSG-DESTINATION-UNREACHABLE-ENABLED"))
        props.setTcpIpIcmpV6MsgParameterProblemEnabled(self.getChildElementOptionalBooleanValue(element, "TCP-IP-ICMP-V-6-MSG-PARAMETER-PROBLEM-ENABLED"))

    def readEthTcpIpIcmpProps(self, element: ET.Element, props: EthTcpIpIcmpProps):
        """Read an R23-11 <ETH-TCP-IP-ICMP-PROPS> element (Table 3.112, p.156): SHORT-NAME, ICMP-V-4-PROPS, ICMP-V-6-PROPS."""
        self.readIdentifiable(element, props)
        child_element = self.find(element, "ICMP-V-4-PROPS")
        if child_element is not None:
            v4_props = TcpIpIcmpv4Props()
            self.readTcpIpIcmpv4Props(child_element, v4_props)
            props.setIcmpV4Props(v4_props)
        child_element = self.find(element, "ICMP-V-6-PROPS")
        if child_element is not None:
            v6_props = TcpIpIcmpv6Props()
            self.readTcpIpIcmpv6Props(child_element, v6_props)
            props.setIcmpV6Props(v6_props)

    def readOsTaskProxy(self, element: ET.Element, proxy: OsTaskProxy):
        """Read an R23-11 <OS-TASK-PROXY> element (Table 5.15, p.208): SHORT-NAME, PERIOD, PREEMPTABILITY, PRIORITY."""
        self.readIdentifiable(element, proxy)
        proxy.setPeriod(self.getChildElementOptionalTimeValue(element, "PERIOD"))
        child_element = self.find(element, "PREEMPTABILITY")
        if child_element is not None:
            proxy.setPreemptability(OsTaskPreemptabilityEnum().setValue(child_element.text))
        proxy.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))

    def readFlexrayCluster(self, element: ET.Element, cluster: FlexrayCluster):
        self.logger.debug("Read FlexrayCluster <%s>" % cluster.getShortName())
        self.readIdentifiable(element, cluster)
        child_element = self.find(element, "FLEXRAY-CLUSTER-VARIANTS/FLEXRAY-CLUSTER-CONDITIONAL")
        if child_element is not None:
            self.readCommunicationCluster(child_element, cluster)
            cluster.setActionPointOffset(self.getChildElementOptionalIntegerValue(child_element, "ACTION-POINT-OFFSET"))
            cluster.setBit(self.getChildElementOptionalTimeValue(child_element, "BIT"))
            cluster.setCasRxLowMax(self.getChildElementOptionalIntegerValue(child_element, "CAS-RX-LOW-MAX"))
            cluster.setColdStartAttempts(self.getChildElementOptionalIntegerValue(child_element, "COLD-START-ATTEMPTS"))
            cluster.setCycle(self.getChildElementOptionalTimeValue(child_element, "CYCLE"))
            cluster.setCycleCountMax(self.getChildElementOptionalIntegerValue(child_element, "CYCLE-COUNT-MAX"))
            cluster.setDetectNitError(self.getChildElementOptionalBooleanValue(child_element, "DETECT-NIT-ERROR"))
            cluster.setDynamicSlotIdlePhase(self.getChildElementOptionalIntegerValue(child_element, "DYNAMIC-SLOT-IDLE-PHASE"))
            cluster.setIgnoreAfterTx(self.getChildElementOptionalIntegerValue(child_element, "IGNORE-AFTER-TX"))
            cluster.setListenNoise(self.getChildElementOptionalIntegerValue(child_element, "LISTEN-NOISE"))
            cluster.setMacroPerCycle(self.getChildElementOptionalIntegerValue(child_element, "MACRO-PER-CYCLE"))
            cluster.setMacrotickDuration(self.getChildElementOptionalTimeValue(child_element, "MACROTICK-DURATION"))
            cluster.setMaxWithoutClockCorrectionFatal(self.getChildElementOptionalIntegerValue(child_element, "MAX-WITHOUT-CLOCK-CORRECTION-FATAL"))
            cluster.setMaxWithoutClockCorrectionPassive(self.getChildElementOptionalIntegerValue(child_element, "MAX-WITHOUT-CLOCK-CORRECTION-PASSIVE"))
            cluster.setMinislotActionPointOffset(self.getChildElementOptionalIntegerValue(child_element, "MINISLOT-ACTION-POINT-OFFSET"))
            cluster.setMinislotDuration(self.getChildElementOptionalIntegerValue(child_element, "MINISLOT-DURATION"))
            cluster.setNetworkIdleTime(self.getChildElementOptionalIntegerValue(child_element, "NETWORK-IDLE-TIME"))
            cluster.setNetworkManagementVectorLength(self.getChildElementOptionalIntegerValue(child_element, "NETWORK-MANAGEMENT-VECTOR-LENGTH"))
            cluster.setNumberOfMinislots(self.getChildElementOptionalIntegerValue(child_element, "NUMBER-OF-MINISLOTS"))
            cluster.setNumberOfStaticSlots(self.getChildElementOptionalIntegerValue(child_element, "NUMBER-OF-STATIC-SLOTS"))
            cluster.setOffsetCorrectionStart(self.getChildElementOptionalIntegerValue(child_element, "OFFSET-CORRECTION-START"))
            cluster.setPayloadLengthStatic(self.getChildElementOptionalIntegerValue(child_element, "PAYLOAD-LENGTH-STATIC"))
            cluster.setSafetyMargin(self.getChildElementOptionalIntegerValue(child_element, "SAFETY-MARGIN"))
            cluster.setSampleClockPeriod(self.getChildElementOptionalTimeValue(child_element, "SAMPLE-CLOCK-PERIOD"))
            cluster.setStaticSlotDuration(self.getChildElementOptionalIntegerValue(child_element, "STATIC-SLOT-DURATION"))
            cluster.setSymbolWindow(self.getChildElementOptionalIntegerValue(child_element, "SYMBOL-WINDOW"))
            cluster.setSymbolWindowActionPointOffset(self.getChildElementOptionalIntegerValue(child_element, "SYMBOL-WINDOW-ACTION-POINT-OFFSET"))
            cluster.setSyncFrameIdCountMax(self.getChildElementOptionalIntegerValue(child_element, "SYNC-FRAME-ID-COUNT-MAX"))
            cluster.setTranceiverStandbyDelay(self.getChildElementOptionalFloatValue(child_element, "TRANCEIVER-STANDBY-DELAY"))
            cluster.setTransmissionStartSequenceDuration(self.getChildElementOptionalIntegerValue(child_element, "TRANSMISSION-START-SEQUENCE-DURATION"))
            cluster.setWakeupRxIdle(self.getChildElementOptionalIntegerValue(child_element, "WAKEUP-RX-IDLE"))
            cluster.setWakeupRxLow(self.getChildElementOptionalIntegerValue(child_element, "WAKEUP-RX-LOW"))
            cluster.setWakeupRxWindow(self.getChildElementOptionalIntegerValue(child_element, "WAKEUP-RX-WINDOW"))
            cluster.setWakeupTxActive(self.getChildElementOptionalIntegerValue(child_element, "WAKEUP-TX-ACTIVE"))
            cluster.setWakeupTxIdle(self.getChildElementOptionalIntegerValue(child_element, "WAKEUP-TX-IDLE"))  # noqa E501

    def readMacMulticastGroup(self, element: ET.Element, group: MacMulticastGroup):
        self.readIdentifiable(element, group)
        group.setMacMulticastAddress(
            self.getChildElementOptionalLiteral(
                element,
                "MAC-MULTICAST-ADDRESS",
            )
        )

    def readEthernetClusterMacMulticastGroups(self, element: ET.Element, cluster: EthernetCluster):
        for child_element in self.findall(element, "MAC-MULTICAST-GROUPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MAC-MULTICAST-GROUP":
                group = cluster.createMacMulticastGroup(self.getShortName(child_element))
                self.readMacMulticastGroup(child_element, group)
            else:
                self.notImplemented("Unsupported assigned data type <%s>" % tag_name)

    def readCouplingPortConnection(self, element: ET.Element, connection: CouplingPortConnection):
        connection.setFirstPortRef(self.getChildElementOptionalRefType(element, "FIRST-PORT-REF"))
        for ref in self.getChildElementRefTypeList(element, "NODE-PORTS/COUPLING-PORT-REF-CONDITIONAL/COUPLING-PORT-REF"):
            connection.addNodePortRef(ref)
        connection.setPlcaLocalNodeCount(self.getChildElementOptionalPositiveInteger(element, "PLCA-LOCAL-NODE-COUNT"))
        connection.setPlcaTransmitOpportunityTimer(self.getChildElementOptionalPositiveInteger(element, "PLCA-TRANSMIT-OPPORTUNITY-TIMER"))
        connection.setSecondPortRef(self.getChildElementOptionalRefType(element, "SECOND-PORT-REF"))

    def readEthernetClusterCouplingPortConnections(self, element: ET.Element, cluster: EthernetCluster):
        for child_element in self.findall(element, "COUPLING-PORT-CONNECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "COUPLING-PORT-CONNECTION":
                connection = CouplingPortConnection()
                self.readCouplingPortConnection(child_element, connection)
                cluster.addCouplingPortConnection(connection)
            else:
                self.notImplemented("Unsupported CouplingPortConnection <%s>" % tag_name)

    def readEthernetCluster(self, element: ET.Element, cluster: EthernetCluster):
        self.logger.debug("Read EthernetCluster <%s>" % cluster.getShortName())
        self.readIdentifiable(element, cluster)
        child_element = self.find(element, "ETHERNET-CLUSTER-VARIANTS/ETHERNET-CLUSTER-CONDITIONAL")
        if child_element is not None:
            self.readCommunicationCluster(child_element, cluster)
            cluster.setCouplingPortStartupActiveTime(self.getChildElementOptionalTimeValue(child_element, "COUPLING-PORT-STARTUP-ACTIVE-TIME"))
            cluster.setCouplingPortSwitchoffDelay(self.getChildElementOptionalTimeValue(child_element, "COUPLING-PORT-SWITCHOFF-DELAY"))
            self.readEthernetClusterMacMulticastGroups(child_element, cluster)
            self.readEthernetClusterCouplingPortConnections(child_element, cluster)

    def readDiagnosticConnectionFunctionalRequestRefs(self, element: ET.Element, connection: DiagnosticConnection):
        for ref in self.getChildElementRefTypeList(element, "FUNCTIONAL-REQUEST-REFS/FUNCTIONAL-REQUEST-REF"):
            connection.addFunctionalRequestRef(ref)

    def readDiagnosticConnectionPeriodicResponseUudtRefs(self, element: ET.Element, connection: DiagnosticConnection):
        for ref in self.getChildElementRefTypeList(element, "PERIODIC-RESPONSE-UUDT-REFS/PERIODIC-RESPONSE-UUDT-REF"):
            connection.addPeriodicResponseUudtRef(ref)

    def readDiagnosticConnection(self, element: ET.Element, connection: DiagnosticConnection):
        self.logger.debug("Read DiagnosticConnection <%s>" % connection.getShortName())
        self.readIdentifiable(element, connection)
        self.readDiagnosticConnectionFunctionalRequestRefs(element, connection)
        self.readDiagnosticConnectionPeriodicResponseUudtRefs(element, connection)
        connection.setPhysicalRequestRef(self.getChildElementOptionalRefType(element, "PHYSICAL-REQUEST-REF"))
        connection.setResponseRef(self.getChildElementOptionalRefType(element, "RESPONSE-REF"))
        connection.setResponseOnEventRef(self.getChildElementOptionalRefType(element, "RESPONSE-ON-EVENT-REF"))

    def readDiagnosticServiceInstance(self, element: ET.Element, instance: DiagnosticServiceInstance):
        instance.setAccessPermissionRef(self.getChildElementOptionalRefType(element, "ACCESS-PERMISSION-REF"))
        instance.setServiceClassRef(self.getChildElementOptionalRefType(element, "SERVICE-CLASS-REF"))

    def readDiagnosticAuthRoleProxy(self, element: ET.Element, proxy: DiagnosticAuthRoleProxy):
        self.readARObject(element, proxy)
        for ref in self.getChildElementRefTypeList(element, "AUTHENTICATION-ROLE-REFS/AUTHENTICATION-ROLE-REF"):
            proxy.addAuthenticationRoleRef(ref)

    def readDiagnosticSession(self, element: ET.Element, session: DiagnosticSession):
        self.logger.debug("Read DiagnosticSession <%s>" % session.getShortName())
        self.readIdentifiable(element, session)
        session.setId(self.getChildElementOptionalPositiveInteger(element, "ID"))
        jump_to_boot_loader = self.getChildElementOptionalLiteral(element, "JUMP-TO-BOOT-LOADER")
        if jump_to_boot_loader is not None:
            e = DiagnosticJumpToBootLoaderEnum()
            e.setValue(jump_to_boot_loader.getValue())
            session.setJumpToBootLoader(e)
        session.setP2ServerMax(self.getChildElementOptionalTimeValue(element, "P-2-SERVER-MAX"))
        session.setP2StarServerMax(self.getChildElementOptionalTimeValue(element, "P-2-STAR-SERVER-MAX"))

    def readDiagnosticSecurityLevel(self, element: ET.Element, security_level: DiagnosticSecurityLevel):
        self.logger.debug("Read DiagnosticSecurityLevel <%s>" % security_level.getShortName())
        self.readIdentifiable(element, security_level)
        security_level.setAccessDataRecordSize(self.getChildElementOptionalPositiveInteger(element, "ACCESS-DATA-RECORD-SIZE"))
        security_level.setKeySize(self.getChildElementOptionalPositiveInteger(element, "KEY-SIZE"))
        security_level.setNumFailedSecurityAccess(self.getChildElementOptionalPositiveInteger(element, "NUM-FAILED-SECURITY-ACCESS"))
        security_level.setSecurityDelayTime(self.getChildElementOptionalTimeValue(element, "SECURITY-DELAY-TIME"))
        security_level.setSeedSize(self.getChildElementOptionalPositiveInteger(element, "SEED-SIZE"))

    def readDiagnosticEnvCompareCondition(self, element: ET.Element, condition: DiagnosticEnvCompareCondition):
        self.readARObject(element, condition)
        condition.setCompareType(self._readEnumToken(element, "COMPARE-TYPE", DiagnosticCompareTypeEnum, DIAGNOSTIC_COMPARE_TYPE_XML_MAP))

    def readDiagnosticEnvConditionFormula(self, element: ET.Element, formula: DiagnosticEnvConditionFormula):
        self.readARObject(element, formula)
        formula.setNrcValue(self.getChildElementOptionalPositiveInteger(element, "NRC-VALUE"))
        op = self.getChildElementOptionalLiteral(element, "OP")
        if op is not None:
            e = DiagnosticLogicalOperatorEnum()
            e.setValue(op.getValue())
            formula.setOp(e)
        # NOTE: DiagnosticLogicalOperatorEnum stores the XSD wire tokens (LOGICAL-AND/LOGICAL-OR)
        # as literal values (pre-existing sync decision), so OP needs no token map.
        parts_element = self.find(element, "PARTS")
        if parts_element is not None:
            for child_element in parts_element:
                tag_name = self.getTagName(child_element)
                if tag_name == "DIAGNOSTIC-ENV-CONDITION-FORMULA":
                    part = DiagnosticEnvConditionFormula()
                    self.readDiagnosticEnvConditionFormula(child_element, part)
                    formula.addPart(part)
                else:
                    self.notImplemented("Unsupported DiagnosticEnvConditionFormulaPart <%s>" % tag_name)

    def getDiagnosticEnvConditionFormula(self, element: ET.Element, key: str) -> Optional[DiagnosticEnvConditionFormula]:
        formula = None
        child_element = self.find(element, key)
        if child_element is not None:
            formula = DiagnosticEnvConditionFormula()
            self.readDiagnosticEnvConditionFormula(child_element, formula)
        return formula

    def readDiagnosticEnvironmentalCondition(self, element: ET.Element, condition: DiagnosticEnvironmentalCondition):
        self.logger.debug("Read DiagnosticEnvironmentalCondition <%s>" % condition.getShortName())
        self.readIdentifiable(element, condition)
        condition.setFormula(self.getDiagnosticEnvConditionFormula(element, "FORMULA"))

    def readDiagnosticAccessPermission(self, element: ET.Element, permission: DiagnosticAccessPermission):
        self.logger.debug("Read DiagnosticAccessPermission <%s>" % permission.getShortName())
        self.readIdentifiable(element, permission)
        authentication_enabled = self.find(element, "AUTHENTICATION-ENABLED")
        if authentication_enabled is not None:
            proxy = DiagnosticAuthRoleProxy()
            self.readDiagnosticAuthRoleProxy(authentication_enabled, proxy)
            permission.setAuthenticationEnabled(proxy)
        for ref in self.getChildElementRefTypeList(element, "DIAGNOSTIC-SESSION-REFS/DIAGNOSTIC-SESSION-REF"):
            permission.addDiagnosticSessionRef(ref)
        permission.setEnvironmentalConditionRef(self.getChildElementOptionalRefType(element, "ENVIRONMENTAL-CONDITION-REF"))
        for ref in self.getChildElementRefTypeList(element, "SECURITY-LEVEL-REFS/SECURITY-LEVEL-REF"):
            permission.addSecurityLevelRef(ref)

    def readDiagnosticServiceTableDiagnosticConnectionRefs(self, element: ET.Element, table: DiagnosticServiceTable):
        for ref in self.getChildElementRefTypeList(element, "DIAGNOSTIC-CONNECTIONS/DIAGNOSTIC-CONNECTION-REF-CONDITIONAL/DIAGNOSTIC-CONNECTION-REF"):
            table.addDiagnosticConnectionRef(ref)

    def readDiagnosticServiceTable(self, element: ET.Element, table: DiagnosticServiceTable):
        self.logger.debug("Read DiagnosticServiceTable <%s>" % table.getShortName())
        self.readIdentifiable(element, table)
        self.readDiagnosticServiceTableDiagnosticConnectionRefs(element, table)
        table.setEcuInstanceRef(self.getChildElementOptionalRefType(element, "ECU-INSTANCE-REF"))
        table.setProtocolKind(self.getChildElementOptionalLiteral(element, "PROTOCOL-KIND"))
        for ref in self.getChildElementRefTypeList(element, "SERVICE-INSTANCE-REFS/SERVICE-INSTANCE-REF"):
            table.addServiceInstanceRef(ref)

    def readSegmentPosition(self, element: ET.Element, position: SegmentPosition):
        position.setSegmentByteOrder(self.getChildElementOptionalLiteral(element, "SEGMENT-BYTE-ORDER"))
        position.setSegmentLength(self.getChildElementOptionalIntegerValue(element, "SEGMENT-LENGTH"))
        position.setSegmentPosition(self.getChildElementOptionalIntegerValue(element, "SEGMENT-POSITION"))

    def readMultiplexedPartSegmentPositions(self, element: ET.Element, part: MultiplexedPart):
        for child_element in self.findall(element, "SEGMENT-POSITIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SEGMENT-POSITION":
                position = SegmentPosition()
                self.readSegmentPosition(child_element, position)
                part.addSegmentPosition(position)
            else:
                self.notImplemented("Unsupported DynamicPart <%s>" % tag_name)

    def readMultiplexedPart(self, element: ET.Element, part: MultiplexedPart):
        self.readMultiplexedPartSegmentPositions(element, part)

    def readDynamicPartAlternative(self, element: ET.Element, alternative: DynamicPartAlternative):
        alternative.setIPduRef(self.getChildElementOptionalRefType(element, "I-PDU-REF"))
        alternative.setInitialDynamicPart(self.getChildElementOptionalBooleanValue(element, "INITIAL-DYNAMIC-PART"))
        alternative.setSelectorFieldCode(self.getChildElementOptionalIntegerValue(element, "SELECTOR-FIELD-CODE"))

    def readDynamicPartDynamicPartAlternatives(self, element: ET.Element, part: DynamicPart):
        for child_element in self.findall(element, "DYNAMIC-PART-ALTERNATIVES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DYNAMIC-PART-ALTERNATIVE":
                alternative = DynamicPartAlternative()
                self.readDynamicPartAlternative(child_element, alternative)
                part.addDynamicPartAlternative(alternative)
            else:
                self.notImplemented("Unsupported DynamicPartAlternative <%s>" % tag_name)

    def readDynamicPart(self, element: ET.Element, part: DynamicPart):
        self.readMultiplexedPart(element, part)
        self.readDynamicPartDynamicPartAlternatives(element, part)

    def readMultiplexedIPduDynamicParts(self, element: ET.Element, ipdu: MultiplexedIPdu):
        for child_element in self.findall(element, "DYNAMIC-PARTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DYNAMIC-PART":
                part = DynamicPart()
                self.readDynamicPart(child_element, part)
                ipdu.setDynamicPart(part)
            else:
                self.notImplemented("Unsupported DynamicPart <%s>" % tag_name)

    def readStaticPart(self, element: ET.Element, part: StaticPart):
        self.readMultiplexedPart(element, part)
        part.setIPduRef(self.getChildElementOptionalRefType(element, "I-PDU-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(part, VariationPointCapable):
                part.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readMultiplexedIPduStaticParts(self, element: ET.Element, ipdu: MultiplexedIPdu):
        for child_element in self.findall(element, "STATIC-PARTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "STATIC-PART":
                part = StaticPart()
                self.readStaticPart(child_element, part)
                ipdu.setStaticPart(part)
            else:
                self.notImplemented("Unsupported StaticPart <%s>" % tag_name)

    def readMultiplexedIPdu(self, element: ET.Element, ipdu: MultiplexedIPdu):
        self.logger.debug("Read MultiplexedIPdu <%s>" % ipdu.getShortName())
        self.readIPdu(element, ipdu)
        self.readMultiplexedIPduDynamicParts(element, ipdu)
        ipdu.setSelectorFieldByteOrder(self.getChildElementOptionalLiteral(element, "SELECTOR-FIELD-BYTE-ORDER"))
        ipdu.setSelectorFieldLength(self.getChildElementOptionalIntegerValue(element, "SELECTOR-FIELD-LENGTH"))
        ipdu.setSelectorFieldStartPosition(self.getChildElementOptionalIntegerValue(element, "SELECTOR-FIELD-START-POSITION"))
        self.readMultiplexedIPduStaticParts(element, ipdu)
        ipdu.setTriggerMode(self.getChildElementOptionalLiteral(element, "TRIGGER-MODE"))
        ipdu.setUnusedBitPattern(self.getChildElementOptionalIntegerValue(element, "UNUSED-BIT-PATTERN"))

    def readUserDefinedIPdu(self, element: ET.Element, ipdu: UserDefinedIPdu):
        self.logger.debug("Read UserDefinedIPdu <%s>" % ipdu.getShortName())
        self.readIPdu(element, ipdu)
        ipdu.setCddType(self.getChildElementOptionalLiteral(element, "CDD-TYPE"))

    def readUserDefinedPdu(self, element: ET.Element, pdu: UserDefinedPdu):
        self.logger.debug("Read UserDefinedPdu <%s>" % pdu.getShortName())
        self.readPdu(element, pdu)
        pdu.setCddType(self.getChildElementOptionalLiteral(element, "CDD-TYPE"))

    def readGeneralPurposePdu(self, element: ET.Element, pdu: GeneralPurposePdu):
        self.logger.debug("Read GeneralPurposePdu <%s>" % pdu.getShortName())
        self.readPdu(element, pdu)

    def readGeneralPurposeIPdu(self, element: ET.Element, i_pdu: GeneralPurposeIPdu):
        self.logger.debug("Read GeneralPurposeIPdu <%s>" % i_pdu.getShortName())
        self.readIPdu(element, i_pdu)

    def readSecureCommunicationAuthenticationProps(self, element: ET.Element, props: SecureCommunicationAuthenticationProps):
        self.readIdentifiable(element, props)
        props.setAuthInfoTxLength(self.getChildElementOptionalPositiveInteger(element, "AUTH-INFO-TX-LENGTH"))

    def readSecureCommunicationPropsSetAuthenticationProps(self, element: ET.Element, props_set: SecureCommunicationPropsSet):
        for child_element in self.findall(element, "AUTHENTICATION-PROPSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SECURE-COMMUNICATION-AUTHENTICATION-PROPS":
                props = props_set.createSecureCommunicationAuthenticationProps(self.getShortName(child_element))
                self.readSecureCommunicationAuthenticationProps(child_element, props)
            else:
                self.notImplemented("Unsupported AuthenticationProps <%s>" % tag_name)

    def readSecureCommunicationFreshnessProps(self, element: ET.Element, props: SecureCommunicationFreshnessProps):
        self.readIdentifiable(element, props)
        props.setFreshnessCounterSyncAttempts(self.getChildElementOptionalPositiveInteger(element, "FRESHNESS-COUNTER-SYNC-ATTEMPTS"))
        props.setFreshnessTimestampTimePeriodFactor(self.getChildElementOptionalPositiveInteger(element, "FRESHNESS-TIMESTAMP-TIME-PERIOD-FACTOR"))
        props.setFreshnessValueLength(self.getChildElementOptionalPositiveInteger(element, "FRESHNESS-VALUE-LENGTH"))
        props.setFreshnessValueTxLength(self.getChildElementOptionalPositiveInteger(element, "FRESHNESS-VALUE-TX-LENGTH"))
        props.setUseFreshnessTimestamp(self.getChildElementOptionalBooleanValue(element, "USE-FRESHNESS-TIMESTAMP"))

    def readSecureCommunicationPropsSetFreshnessProps(self, element: ET.Element, props_set: SecureCommunicationPropsSet):
        for child_element in self.findall(element, "FRESHNESS-PROPSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SECURE-COMMUNICATION-FRESHNESS-PROPS":
                props = props_set.createSecureCommunicationFreshnessProps(self.getShortName(child_element))
                self.readSecureCommunicationFreshnessProps(child_element, props)
            else:
                self.notImplemented("Unsupported FreshnessProps <%s>" % tag_name)

    def readSecureCommunicationPropsSet(self, element: ET.Element, props_set: SecureCommunicationPropsSet):
        self.logger.debug("Read SecureCommunicationPropsSet <%s>" % props_set.getShortName())
        self.readIdentifiable(element, props_set)
        self.readSecureCommunicationPropsSetAuthenticationProps(element, props_set)
        self.readSecureCommunicationPropsSetFreshnessProps(element, props_set)

    def readSoAdRoutingGroup(self, element: ET.Element, group: SoAdRoutingGroup):
        self.logger.debug("Read SoAdRoutingGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        control_type_literal = self.getChildElementOptionalLiteral(element, "EVENT-GROUP-CONTROL-TYPE")
        if control_type_literal is not None:
            control_type = EventGroupControlTypeEnum()
            control_type.setValue(control_type_literal.getValue())
            group.setEventGroupControlType(control_type)

    def readDoIpLogicAddress(self, element: ET.Element, address: DoIpLogicAddress):
        self.readIdentifiable(element, address)
        address.setAddress(self.getChildElementOptionalIntegerValue(element, "ADDRESS"))
        self.readDoIpLogicAddressProps(element, address)

    def readDoIpLogicAddressProps(self, element: ET.Element, address: DoIpLogicAddress):
        for child_element in self.findall(element, "DO-IP-LOGIC-ADDRESS-PROPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DO-IP-LOGIC-TARGET-ADDRESS-PROPS":
                props = address.createDoIpLogicTargetAddressProps(self.getShortName(child_element))
                self.readIdentifiable(child_element, props)
            elif tag_name == "DO-IP-LOGIC-TESTER-ADDRESS-PROPS":
                props = address.createDoIpLogicTesterAddressProps(self.getShortName(child_element))
                self.readIdentifiable(child_element, props)
                for ref in self.getChildElementRefTypeList(child_element, "DO-IP-TESTER-ROUTING-ACTIVATION-REFS/DO-IP-TESTER-ROUTING-ACTIVATION-REF"):
                    props.addDoIpTesterRoutingActivationRef(ref)
            else:
                self.notImplemented("Unsupported DoIpLogicAddressProps <%s>" % tag_name)

    def readDoIpTpConfigDoIpLogicAddresses(self, element: ET.Element, config: DoIpTpConfig):
        for child_element in self.findall(element, "DO-IP-LOGIC-ADDRESSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DO-IP-LOGIC-ADDRESS":
                address = config.createDoIpLogicAddress(self.getShortName(child_element))
                self.readDoIpLogicAddress(child_element, address)
            else:
                self.notImplemented("Unsupported DoIpLogicAddress <%s>" % tag_name)

    def readDoIpTpConnection(self, element: ET.Element, connection: DoIpTpConnection):
        self.readTpConnection(element, connection)
        connection.setDoIpSourceAddressRef(self.getChildElementOptionalRefType(element, "DO-IP-SOURCE-ADDRESS-REF"))
        connection.setDoIpTargetAddressRef(self.getChildElementOptionalRefType(element, "DO-IP-TARGET-ADDRESS-REF"))
        connection.setTpSduRef(self.getChildElementOptionalRefType(element, "TP-SDU-REF"))

    def readDoIpTpConfigTpConnections(self, element: ET.Element, config: DoIpTpConfig):
        for child_element in self.findall(element, "TP-CONNECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DO-IP-TP-CONNECTION":
                connection = DoIpTpConnection()
                self.readDoIpTpConnection(child_element, connection)
                config.addTpConnection(connection)
            else:
                self.notImplemented("Unsupported TpConnection <%s>" % tag_name)

    def readDoIpTpConfig(self, element: ET.Element, config: DoIpTpConfig):
        self.logger.debug("Read DoIpTpConfig <%s>" % config.getShortName())
        self.readTpConfig(element, config)
        self.readDoIpTpConfigDoIpLogicAddresses(element, config)
        self.readDoIpTpConfigTpConnections(element, config)

    def readHwDescriptionEntityHwCategoryRefs(self, element: ET.Element, entity: HwDescriptionEntity):
        for ref in self.getChildElementRefTypeList(element, "HW-CATEGORY-REFS/HW-CATEGORY-REF"):
            entity.addHwCategoryRef(ref)

    def readHwAttributeValue(self, element: ET.Element, attribute_value: HwAttributeValue):
        # XSD group HW-ATTRIBUTE-VALUE (AUTOSAR_00052.xsd l.65663):
        # ANNOTATION, HW-ATTRIBUTE-DEF-REF, V, VT, VARIATION-POINT.
        self.readARObject(element, attribute_value)
        annotation_element = self.find(element, "ANNOTATION")
        if annotation_element is not None:
            annotation = Annotation()
            self.readGeneralAnnotation(annotation_element, annotation)
            attribute_value.setAnnotation(annotation)
        attribute_value.setHwAttributeDefRef(self.getChildElementOptionalRefType(element, "HW-ATTRIBUTE-DEF-REF"))
        attribute_value.setV(self.getChildElementOptionalNumerical(element, "V"))
        attribute_value.setVt(self.getChildElementOptionalVerbatimString(element, "VT"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            attribute_value.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))

    def readHwDescriptionEntityHwAttributeValues(self, element: ET.Element, entity: HwDescriptionEntity):
        for child_element in self.findall(element, "HW-ATTRIBUTE-VALUES/HW-ATTRIBUTE-VALUE"):
            attribute_value = HwAttributeValue()
            self.readHwAttributeValue(child_element, attribute_value)
            entity.addHwAttributeValue(attribute_value)

    def readHwDescriptionEntity(self, element: ET.Element, entity: HwDescriptionEntity):
        # HwDescriptionEntity itself is Referrable-only (ECUResourceTemplate Table 2.1), but it is
        # abstract and every concrete subclass (HwElement, HwType, HwPin, HwPinGroup) is an
        # Identifiable per its own spec Base — so the shared reader walks the Identifiable chain
        # and picks up UUID/DESC/CATEGORY/ADMIN-DATA/INTRODUCTION (Rule 0013.1).
        self.readIdentifiable(element, entity)
        entity.setHwTypeRef(self.getChildElementOptionalRefType(element, "HW-TYPE-REF"))
        self.readHwDescriptionEntityHwCategoryRefs(element, entity)
        self.readHwDescriptionEntityHwAttributeValues(element, entity)

    def readHwPinGroup(self, element: ET.Element, pin_group: HwPinGroup):
        self.readHwDescriptionEntity(element, pin_group)
        content_element = self.find(element, "HW-PIN-GROUP-CONTENT")
        if content_element is not None:
            content = HwPinGroupContent()
            self.readHwPinGroupContent(content_element, content)
            pin_group.setHwPinGroupContent(content)

    def readHwPinGroupContent(self, element: ET.Element, content: HwPinGroupContent):
        for child_element in self.findall(element, "*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "HW-PIN":
                pin = content.createHwPin(self.getShortName(child_element))
                self.readHwPin(child_element, pin)
            elif tag_name == "HW-PIN-GROUP":
                child_group = HwPinGroup(content, self.getShortName(child_element))
                self.readHwPinGroup(child_element, child_group)
                content.setHwPinGroup(child_group)

    def readHwPin(self, element: ET.Element, hw_pin: HwPin):
        self.readHwDescriptionEntity(element, hw_pin)
        for function_name_element in self.findall(element, "FUNCTION-NAMES/FUNCTION-NAME"):
            if function_name_element.text is not None:
                hw_pin.addFunctionName(function_name_element.text)
        packaging_pin_name_element = self.find(element, "PACKAGING-PIN-NAME")
        if packaging_pin_name_element is not None and packaging_pin_name_element.text is not None:
            hw_pin.setPackagingPinName(packaging_pin_name_element.text)
        hw_pin.setPinNumber(self.getChildElementOptionalIntegerValue(element, "PIN-NUMBER"))

    def readHwElementHwPinGroups(self, element: ET.Element, hw_element: HwElement):
        for child_element in self.findall(element, "HW-PIN-GROUPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "HW-PIN-GROUP":
                pin_group = hw_element.createHwPinGroup(self.getShortName(child_element))
                self.readHwPinGroup(child_element, pin_group)
            else:
                self.notImplemented("Unsupported Hw Pin Group <%s>" % tag_name)

    def readHwPinConnector(self, element: ET.Element) -> HwPinConnector:
        pin = HwPinConnector()
        self.readDescribable(element, pin)
        for ref in self.getChildElementRefTypeList(element, "HW-PIN-REF"):
            pin.addHwPinRef(ref)
        return pin

    def readHwPinGroupConnector(self, element: ET.Element) -> HwPinGroupConnector:
        group = HwPinGroupConnector()
        self.readDescribable(element, group)
        for child_element in self.findall(element, "HW-PIN-CONNECTION"):
            group.addHwPinConnection(self.readHwPinConnector(child_element))
        for ref in self.getChildElementRefTypeList(element, "HW-PIN-GROUP-REF"):
            group.addHwPinGroupRef(ref)
        return group

    def readHwElementConnector(self, element: ET.Element, connector: HwElementConnector):
        self.readDescribable(element, connector)
        for ref in self.getChildElementRefTypeList(element, "HW-ELEMENT-REF"):
            connector.addHwElementRef(ref)
        for child_element in self.findall(element, "HW-PIN-CONNECTION"):
            connector.addHwPinConnection(self.readHwPinConnector(child_element))
        for child_element in self.findall(element, "HW-PIN-GROUP-CONNECTION"):
            connector.addHwPinGroupConnection(self.readHwPinGroupConnector(child_element))

    def readHwElementHwElementConnections(self, element: ET.Element, hw_element: HwElement):
        for child_element in self.findall(element, "HW-ELEMENT-CONNECTIONS/HW-ELEMENT-CONNECTOR"):
            connector = HwElementConnector()
            self.readHwElementConnector(child_element, connector)
            hw_element.addHwElementConnection(connector)

    def readHwElementHwNestedElementRefs(self, element: ET.Element, hw_element: HwElement):
        refs = self.getChildElementRefTypeList(element, "NESTED-ELEMENTS/HW-ELEMENT-REF-CONDITIONAL/HW-ELEMENT-REF")
        if len(refs) == 0:
            refs = self.getChildElementRefTypeList(element, "NESTED-ELEMENTS/HW-ELEMENT-REF")
        for ref in refs:
            hw_element.addNestedElementRef(ref)

    def readHwElement(self, element: ET.Element, hw_element: HwElement):
        self.logger.debug("Read HwElement <%s>" % hw_element.getShortName())
        self.readHwDescriptionEntity(element, hw_element)
        self.readHwElementHwPinGroups(element, hw_element)
        self.readHwElementHwElementConnections(element, hw_element)
        self.readHwElementHwNestedElementRefs(element, hw_element)

    def readHwAttributeDef(self, element: ET.Element, attribute_def: HwAttributeDef):
        self.readIdentifiable(element, attribute_def)
        for child_element in self.findall(element, "HW-ATTRIBUTE-LITERALS/HW-ATTRIBUTE-LITERAL-DEF"):
            literal_def = attribute_def.createHwAttributeLiteral(self.getShortName(child_element))
            self.readHwAttributeLiteralDef(child_element, literal_def)
        attribute_def.setIsRequired(self.getChildElementOptionalBooleanValue(element, "IS-REQUIRED"))
        attribute_def.setUnitRef(self.getChildElementOptionalRefType(element, "UNIT-REF"))

    def readHwAttributeLiteralDef(self, element: ET.Element, literal_def):
        self.readIdentifiable(element, literal_def)

    def readHwCategoryHwAttributeDef(self, element: ET.Element, hw_category: HwCategory):
        for child_element in self.findall(element, "HW-ATTRIBUTE-DEFS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "HW-ATTRIBUTE-DEF":
                pin_group = hw_category.createHwAttributeDef(self.getShortName(child_element))
                self.readHwAttributeDef(child_element, pin_group)
            else:
                self.notImplemented("Unsupported Hw Attribute Defs <%s>" % tag_name)

    def readHwCategory(self, element: ET.Element, hw_category: HwCategory):
        self.logger.debug("Read HwCategory <%s>" % hw_category.getShortName())
        self.readARElement(element, hw_category)
        self.readHwCategoryHwAttributeDef(element, hw_category)

    def readHwType(self, element: ET.Element, type: HwType):
        self.logger.debug("Read HwType <%s>" % type.getShortName())
        # HW-TYPE references the AR:HW-DESCRIPTION-ENTITY group (AUTOSAR_00052.xsd l.66369), so
        # the HwDescriptionEntity aggregations are read here too (previously bypassed).
        self.readHwDescriptionEntity(element, type)

    def readPduToFrameMappings(self, element: ET.Element, parent: Frame):
        for child_element in self.findall(element, "PDU-TO-FRAME-MAPPINGS/PDU-TO-FRAME-MAPPING"):
            short_name = self.getShortName(child_element)
            self.logger.debug("readPduToFrameMapping %s" % short_name)
            mapping = parent.createPduToFrameMapping(short_name)
            self.readIdentifiable(child_element, mapping)
            mapping.setPackingByteOrder(self.getChildElementOptionalLiteral(child_element, "PACKING-BYTE-ORDER"))
            mapping.setPduRef(self.getChildElementOptionalRefType(child_element, "PDU-REF"))
            mapping.setStartPosition(self.getChildElementOptionalIntegerValue(child_element, "START-POSITION"))
            mapping.setUpdateIndicationBitPosition(self.getChildElementOptionalIntegerValue(child_element, "UPDATE-INDICATION-BIT-POSITION"))

    def readFrame(self, element: ET.Element, frame: Frame):
        self.readIdentifiable(element, frame)
        frame.frameLength = self.getChildElementOptionalIntegerValue(element, "FRAME-LENGTH")
        self.readPduToFrameMappings(element, frame)

    def readLinUnconditionalFrame(self, element: ET.Element, frame: LinUnconditionalFrame):
        self.logger.debug("Read LinUnconditionalFrame <%s>" % frame.getShortName())
        self.readFrame(element, frame)

    def readPdu(self, element: ET.Element, pdu: Pdu):
        self.readIdentifiable(element, pdu)
        pdu.setHasDynamicLength(self.getChildElementOptionalBooleanValue(element, "HAS-DYNAMIC-LENGTH"))
        pdu.setLength(self.getChildElementOptionalNumericalValue(element, "LENGTH"))

    def readISignalToIPduMapping(self, element: ET.Element, mapping: ISignalToIPduMapping):
        self.readIdentifiable(element, mapping)
        mapping.setISignalRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-REF"))
        mapping.setISignalGroupRef(self.getChildElementOptionalRefType(element, "I-SIGNAL-GROUP-REF"))
        mapping.setPackingByteOrder(self.getChildElementOptionalLiteral(element, "PACKING-BYTE-ORDER"))
        mapping.setStartPosition(self.getChildElementOptionalIntegerValue(element, "START-POSITION"))
        mapping.setTransferProperty(self.getChildElementOptionalLiteral(element, "TRANSFER-PROPERTY"))
        mapping.setUpdateIndicationBitPosition(self.getChildElementOptionalNumericalValue(element, "UPDATE-INDICATION-BIT-POSITION"))

    def readNmPduISignalToIPduMappings(self, element: ET.Element, pdu: NmPdu):
        for child_element in self.findall(element, "I-SIGNAL-TO-I-PDU-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "I-SIGNAL-TO-I-PDU-MAPPING":
                mapping = pdu.createISignalToIPduMapping(self.getShortName(child_element))
                self.readISignalToIPduMapping(child_element, mapping)
            else:
                self.notImplemented("Unsupported ISignalToIPduMapping <%s>" % tag_name)

    def readNmPdu(self, element: ET.Element, pdu: NmPdu):
        self.logger.debug("Read NmPdu <%s>" % pdu.getShortName())
        self.readPdu(element, pdu)
        self.readNmPduISignalToIPduMappings(element, pdu)
        pdu.setNmDataInformation(self.getChildElementOptionalBooleanValue(element, "NM-DATA-INFORMATION"))
        pdu.setNmVoteInformation(self.getChildElementOptionalBooleanValue(element, "NM-VOTE-INFORMATION"))
        pdu.setUnusedBitPattern(self.getChildElementOptionalIntegerValue(element, "UNUSED-BIT-PATTERN"))

    def readContainedIPduProps(self, element: ET.Element) -> ContainedIPduProps:
        props = None
        child_element = self.find(element, "CONTAINED-I-PDU-PROPS")
        if child_element is not None:
            props = ContainedIPduProps()
            props.setCollectionSemantics(self.getChildElementOptionalLiteral(child_element, "COLLECTION-SEMANTICS"))
            props.setContainedPduTriggeringRef(self.getChildElementOptionalRefType(child_element, "CONTAINED-PDU-TRIGGERING-REF"))
            props.setHeaderIdLongHeader(self.getChildElementOptionalPositiveInteger(child_element, "HEADER-ID-LONG-HEADER"))
            props.setHeaderIdShortHeader(self.getChildElementOptionalPositiveInteger(child_element, "HEADER-ID-SHORT-HEADER"))
            props.setOffset(self.getChildElementOptionalPositiveInteger(child_element, "OFFSET"))
            props.setPriority(self.getChildElementOptionalPositiveInteger(child_element, "PRIORITY"))
            props.setTimeout(self.getChildElementOptionalTimeValue(child_element, "TIMEOUT"))
            props.setTrigger(self.getChildElementOptionalLiteral(child_element, "TRIGGER"))
            props.setUpdateIndicationBitPosition(self.getChildElementOptionalPositiveInteger(child_element, "UPDATE-INDICATION-BIT-POSITION"))
        return props

    def readIPdu(self, element: ET.Element, pdu: IPdu):
        self.readPdu(element, pdu)
        pdu.setContainedIPduProps(self.readContainedIPduProps(element))

    def readNPdu(self, element: ET.Element, pdu: NPdu):
        self.logger.debug("Read NPdu <%s>" % pdu.getShortName())
        self.readIPdu(element, pdu)

    def readDcmIPdu(self, element: ET.Element, i_pdu: DcmIPdu):
        self.logger.debug("Read DcmIPdu <%s>" % i_pdu.getShortName())
        self.readIPdu(element, i_pdu)
        i_pdu.setDiagPduType(self.getChildElementOptionalLiteral(element, "DIAG-PDU-TYPE"))

    def getSecureCommunicationProps(self, element: ET.Element, key: str) -> SecureCommunicationProps:
        props = None
        child_element = self.find(element, key)
        if child_element is not None:
            props = SecureCommunicationProps()
            props.setAuthDataFreshnessLength(self.getChildElementOptionalPositiveInteger(child_element, "AUTH-DATA-FRESHNESS-LENGTH"))
            props.setAuthDataFreshnessStartPosition(self.getChildElementOptionalPositiveInteger(child_element, "AUTH-DATA-FRESHNESS-START-POSITION"))
            props.setAuthenticationBuildAttempts(self.getChildElementOptionalPositiveInteger(child_element, "AUTHENTICATION-BUILD-ATTEMPTS"))
            props.setAuthenticationRetries(self.getChildElementOptionalPositiveInteger(child_element, "AUTHENTICATION-RETRIES"))
            props.setDataId(self.getChildElementOptionalPositiveInteger(child_element, "DATA-ID"))
            props.setFreshnessValueId(self.getChildElementOptionalPositiveInteger(child_element, "FRESHNESS-VALUE-ID"))
            props.setMessageLinkLength(self.getChildElementOptionalPositiveInteger(child_element, "MESSAGE-LINK-LENGTH"))
            props.setMessageLinkPosition(self.getChildElementOptionalPositiveInteger(child_element, "MESSAGE-LINK-POSITION"))
            props.setSecondaryFreshnessValueId(self.getChildElementOptionalPositiveInteger(child_element, "SECONDARY-FRESHNESS-VALUE-ID"))
            props.setSecuredAreaLength(self.getChildElementOptionalPositiveInteger(child_element, "SECURED-AREA-LENGTH"))
            props.setSecuredAreaOffset(self.getChildElementOptionalPositiveInteger(child_element, "SECURED-AREA-OFFSET"))
        return props

    def readSecuredIPdu(self, element: ET.Element, i_pdu: SecuredIPdu):
        self.logger.debug("Read SecuredIPdu <%s>" % i_pdu.getShortName())
        self.readIPdu(element, i_pdu)
        i_pdu.setAuthenticationPropsRef(self.getChildElementOptionalRefType(element, "AUTHENTICATION-PROPS-REF"))
        i_pdu.setDynamicRuntimeLengthHandling(self.getChildElementOptionalBooleanValue(element, "DYNAMIC-RUNTIME-LENGTH-HANDLING"))
        i_pdu.setFreshnessPropsRef(self.getChildElementOptionalRefType(element, "FRESHNESS-PROPS-REF"))
        i_pdu.setPayloadRef(self.getChildElementOptionalRefType(element, "PAYLOAD-REF"))
        i_pdu.setSecureCommunicationProps(self.getSecureCommunicationProps(element, "SECURE-COMMUNICATION-PROPS"))
        i_pdu.setUseAsCryptographicIPdu(self.getChildElementOptionalBooleanValue(element, "USE-AS-CRYPTOGRAPHIC-I-PDU"))
        i_pdu.setUseSecuredPduHeader(self.getChildElementOptionalLiteral(element, "USE-SECURED-PDU-HEADER"))

    def readNmNode(self, element: ET.Element, nm_node: NmNode):
        self.readIdentifiable(element, nm_node)

        nm_node.setControllerRef(self.getChildElementOptionalRefType(element, "CONTROLLER-REF"))
        nm_node.setNmCoordCluster(self.getChildElementOptionalPositiveInteger(element, "NM-COORD-CLUSTER"))
        nm_node.setNmCoordinatorRole(self.getChildElementOptionalLiteral(element, "NM-COORDINATOR-ROLE"))
        nm_node.setNmIfEcuRef(self.getChildElementOptionalRefType(element, "NM-IF-ECU-REF"))
        nm_node.setNmNodeId(self.getChildElementOptionalIntegerValue(element, "NM-NODE-ID"))
        nm_node.setNmPassiveModeEnabled(self.getChildElementOptionalBooleanValue(element, "NM-PASSIVE-MODE-ENABLED"))
        for ref in self.getChildElementRefTypeList(element, "RX-NM-PDU-REFS/RX-NM-PDU-REF"):
            nm_node.addRxNmPduRef(ref)
        for ref in self.getChildElementRefTypeList(element, "TX-NM-PDU-REFS/TX-NM-PDU-REF"):
            nm_node.addTxNmPduRef(ref)

    def readCanNmNode(self, element: ET.Element, nm_node: CanNmNode):
        self.logger.debug("Read CanNmNode <%s>" % nm_node.getShortName())
        self.readNmNode(element, nm_node)
        nm_node.setAllNmMessagesKeepAwake(self.getChildElementOptionalBooleanValue(element, "ALL-NM-MESSAGES-KEEP-AWAKE"))
        nm_node.setNmCarWakeUpFilterEnabled(self.getChildElementOptionalBooleanValue(element, "NM-CAR-WAKE-UP-FILTER-ENABLED"))
        nm_node.setNmCarWakeUpRxEnabled(self.getChildElementOptionalBooleanValue(element, "NM-CAR-WAKE-UP-RX-ENABLED"))
        nm_node.setNmMsgCycleOffset(self.getChildElementOptionalTimeValue(element, "NM-MSG-CYCLE-OFFSET"))
        nm_node.setNmMsgReducedTime(self.getChildElementOptionalTimeValue(element, "NM-MSG-REDUCED-TIME"))

    def readUdpNmNode(self, element: ET.Element, nm_node: UdpNmNode):
        self.logger.debug("Read UdpNmNode <%s>" % nm_node.getShortName())
        self.readNmNode(element, nm_node)
        nm_node.setAllNmMessagesKeepAwake(self.getChildElementOptionalBooleanValue(element, "ALL-NM-MESSAGES-KEEP-AWAKE"))
        nm_node.setNmMsgCycleOffset(self.getChildElementOptionalTimeValue(element, "NM-MSG-CYCLE-OFFSET"))

    def readJ1939NmNode(self, element: ET.Element, nm_node: J1939NmNode):
        self.logger.debug("Read J1939NmNode <%s>" % nm_node.getShortName())
        self.readNmNode(element, nm_node)
        nm_node.setAddressConfigurationCapability(self.getChildElementOptionalLiteral(element, "ADDRESS-CONFIGURATION-CAPABILITY"))
        nm_node.setNodeName(self.getJ1939NodeName(element, "NODE-NAME"))

    def readNmClusterNmNodes(self, element: ET.Element, cluster: NmCluster):
        self.logger.debug("readNmConfigNmNodes %s" % cluster.getShortName())
        for child_element in self.findall(element, "NM-NODES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-NM-NODE":
                nm_node = cluster.createCanNmNode(self.getShortName(child_element))
                self.readCanNmNode(child_element, nm_node)
            elif tag_name == "UDP-NM-NODE":
                nm_node = cluster.createUdpNmNode(self.getShortName(child_element))
                self.readUdpNmNode(child_element, nm_node)
            elif tag_name == "FLEXRAY-NM-NODE":
                nm_node = cluster.createFlexrayNmNode(self.getShortName(child_element))
                self.readNmNode(child_element, nm_node)
            elif tag_name == "J-1939-NM-NODE":
                nm_node = cluster.createJ1939NmNode(self.getShortName(child_element))
                self.readJ1939NmNode(child_element, nm_node)
            else:
                self.notImplemented("Unsupported Nm Node <%s>" % tag_name)

    def getCanNmClusterCoupling(self, element: ET.Element) -> CanNmClusterCoupling:
        coupling = CanNmClusterCoupling()
        for ref in self.getChildElementRefTypeList(element, "COUPLED-CLUSTER-REFS/COUPLED-CLUSTER-REF"):
            coupling.addCoupledClusterRef(ref)
        coupling.setNmBusloadReductionEnabled(self.getChildElementOptionalBooleanValue(element, "NM-BUSLOAD-REDUCTION-ENABLED"))
        coupling.setNmImmediateRestartEnabled(self.getChildElementOptionalBooleanValue(element, "NM-IMMEDIATE-RESTART-ENABLED"))
        return coupling

    def getUdpNmClusterCoupling(self, element: ET.Element) -> UdpNmClusterCoupling:
        coupling = UdpNmClusterCoupling()
        for ref in self.getChildElementRefTypeList(element, "COUPLED-CLUSTER-REFS/COUPLED-CLUSTER-REF"):
            coupling.addCoupledClusterRef(ref)
        coupling.setNmImmediateRestartEnabled(self.getChildElementOptionalBooleanValue(element, "NM-IMMEDIATE-RESTART-ENABLED"))
        return coupling

    def getFlexrayNmClusterCoupling(self, element: ET.Element) -> FlexrayNmClusterCoupling:
        coupling = FlexrayNmClusterCoupling()
        for ref in self.getChildElementRefTypeList(element, "COUPLED-CLUSTER-REFS/COUPLED-CLUSTER-REF"):
            coupling.addCoupledClusterRef(ref)
        coupling.setNmScheduleVariant(self.getChildElementOptionalLiteral(element, "NM-SCHEDULE-VARIANT"))
        return coupling

    def readNmConfigNmClusterCouplings(self, element: ET.Element, nm_config: NmConfig):
        for child_element in self.findall(element, "NM-CLUSTER-COUPLINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-NM-CLUSTER-COUPLING":
                nm_config.addNmClusterCouplings(self.getCanNmClusterCoupling(child_element))
            elif tag_name == "UDP-NM-CLUSTER-COUPLING":
                nm_config.addNmClusterCouplings(self.getUdpNmClusterCoupling(child_element))
            elif tag_name == "FLEXRAY-NM-CLUSTER-COUPLING":
                nm_config.addNmClusterCouplings(self.getFlexrayNmClusterCoupling(child_element))
            else:
                self.notImplemented("Unsupported Nm Node <%s>" % tag_name)

    def readNmCluster(self, element: ET.Element, cluster: NmCluster):
        self.logger.debug("read NmCluster %s" % cluster.getShortName())
        self.readIdentifiable(element, cluster)
        cluster.setCommunicationClusterRef(self.getChildElementOptionalRefType(element, "COMMUNICATION-CLUSTER-REF"))
        cluster.setNmChannelId(self.getChildElementOptionalNumericalValue(element, "NM-CHANNEL-ID"))
        cluster.setNmChannelSleepMaster(self.getChildElementOptionalBooleanValue(element, "NM-CHANNEL-SLEEP-MASTER"))
        self.readNmClusterNmNodes(element, cluster)
        cluster.setNmNodeDetectionEnabled(self.getChildElementOptionalBooleanValue(element, "NM-NODE-DETECTION-ENABLED"))
        cluster.setNmNodeIdEnabled(self.getChildElementOptionalBooleanValue(element, "NM-NODE-ID-ENABLED"))
        cluster.setNmPncParticipation(self.getChildElementOptionalBooleanValue(element, "NM-PNC-PARTICIPATION"))
        cluster.setNmRepeatMsgIndEnabled(self.getChildElementOptionalBooleanValue(element, "NM-REPEAT-MSG-IND-ENABLED"))
        cluster.setNmSynchronizingNetwork(self.getChildElementOptionalBooleanValue(element, "NM-SYNCHRONIZING-NETWORK"))
        cluster.setPncClusterVectorLength(self.getChildElementOptionalPositiveInteger(element, "PNC-CLUSTER-VECTOR-LENGTH"))

    def readCanNmCluster(self, element: ET.Element, cluster: CanNmCluster):
        self.logger.debug("Read CanNmCluster <%s>" % cluster.getShortName())
        self.readNmCluster(element, cluster)
        cluster.setNmBusloadReductionActive(self.getChildElementOptionalBooleanValue(element, "NM-BUSLOAD-REDUCTION-ACTIVE"))
        cluster.setNmCarWakeUpBitPosition(self.getChildElementOptionalPositiveInteger(element, "NM-CAR-WAKE-UP-BIT-POSITION"))
        cluster.setNmCarWakeUpFilterNodeId(self.getChildElementOptionalPositiveInteger(element, "NM-CAR-WAKE-UP-FILTER-NODE-ID"))
        cluster.setNmCbvPosition(self.getChildElementOptionalIntegerValue(element, "NM-CBV-POSITION"))
        cluster.setNmImmediateNmCycleTime(self.getChildElementOptionalTimeValue(element, "NM-IMMEDIATE-NM-CYCLE-TIME"))
        cluster.setNmImmediateNmTransmissions(self.getChildElementOptionalPositiveInteger(element, "NM-IMMEDIATE-NM-TRANSMISSIONS"))
        cluster.setNmMessageTimeoutTime(self.getChildElementOptionalTimeValue(element, "NM-MESSAGE-TIMEOUT-TIME"))
        cluster.setNmMsgCycleTime(self.getChildElementOptionalTimeValue(element, "NM-MSG-CYCLE-TIME"))
        cluster.setNmNetworkTimeout(self.getChildElementOptionalTimeValue(element, "NM-NETWORK-TIMEOUT"))
        cluster.setNmNidPosition(self.getChildElementOptionalIntegerValue(element, "NM-NID-POSITION"))
        cluster.setNmRemoteSleepIndicationTime(self.getChildElementOptionalTimeValue(element, "NM-REMOTE-SLEEP-INDICATION-TIME"))
        cluster.setNmRepeatMessageTime(self.getChildElementOptionalTimeValue(element, "NM-REPEAT-MESSAGE-TIME"))
        cluster.setNmWaitBusSleepTime(self.getChildElementOptionalTimeValue(element, "NM-WAIT-BUS-SLEEP-TIME"))

    def readUdpNmCluster(self, element: ET.Element, cluster: UdpNmCluster):
        self.logger.debug("Read UdpNmCluster %s" % cluster.getShortName())
        self.readNmCluster(element, cluster)
        cluster.setNmCbvPosition(self.getChildElementOptionalIntegerValue(element, "NM-CBV-POSITION"))
        cluster.setNmImmediateNmCycleTime(self.getChildElementOptionalTimeValue(element, "NM-IMMEDIATE-NM-CYCLE-TIME"))
        cluster.setNmImmediateNmTransmissions(self.getChildElementOptionalPositiveInteger(element, "NM-IMMEDIATE-NM-TRANSMISSIONS"))
        cluster.setNmMessageTimeoutTime(self.getChildElementOptionalTimeValue(element, "NM-MESSAGE-TIMEOUT-TIME"))
        cluster.setNmMsgCycleTime(self.getChildElementOptionalTimeValue(element, "NM-MSG-CYCLE-TIME"))
        cluster.setNmNetworkTimeout(self.getChildElementOptionalTimeValue(element, "NM-NETWORK-TIMEOUT"))
        cluster.setNmNidPosition(self.getChildElementOptionalIntegerValue(element, "NM-NID-POSITION"))
        cluster.setNmRemoteSleepIndicationTime(self.getChildElementOptionalTimeValue(element, "NM-REMOTE-SLEEP-INDICATION-TIME"))
        cluster.setNmRepeatMessageTime(self.getChildElementOptionalTimeValue(element, "NM-REPEAT-MESSAGE-TIME"))
        cluster.setNmWaitBusSleepTime(self.getChildElementOptionalTimeValue(element, "NM-WAIT-BUS-SLEEP-TIME"))
        cluster.setVlanRef(self.getChildElementOptionalRefType(element, "VLAN-REF"))

    def readFlexrayNmCluster(self, element: ET.Element, cluster: FlexrayNmCluster):
        self.logger.debug("Read FlexrayNmCluster <%s>" % cluster.getShortName())
        self.readNmCluster(element, cluster)
        cluster.setNmCarWakeUpBitPosition(self.getChildElementOptionalPositiveInteger(element, "NM-CAR-WAKE-UP-BIT-POSITION"))
        cluster.setNmCarWakeUpFilterEnabled(self.getChildElementOptionalBooleanValue(element, "NM-CAR-WAKE-UP-FILTER-ENABLED"))
        cluster.setNmCarWakeUpFilterNodeId(self.getChildElementOptionalPositiveInteger(element, "NM-CAR-WAKE-UP-FILTER-NODE-ID"))
        cluster.setNmCarWakeUpRxEnabled(self.getChildElementOptionalBooleanValue(element, "NM-CAR-WAKE-UP-RX-ENABLED"))
        cluster.setNmDataCycle(self.getChildElementOptionalIntegerValue(element, "NM-DATA-CYCLE"))
        cluster.setNmMainFunctionPeriod(self.getChildElementOptionalTimeValue(element, "NM-MAIN-FUNCTION-PERIOD"))
        cluster.setNmRemoteSleepIndicationTime(self.getChildElementOptionalTimeValue(element, "NM-REMOTE-SLEEP-INDICATION-TIME"))
        cluster.setNmRepeatMessageTime(self.getChildElementOptionalTimeValue(element, "NM-REPEAT-MESSAGE-TIME"))
        cluster.setNmRepetitionCycle(self.getChildElementOptionalIntegerValue(element, "NM-REPETITION-CYCLE"))
        cluster.setNmVotingCycle(self.getChildElementOptionalIntegerValue(element, "NM-VOTING-CYCLE"))

    def readJ1939NmCluster(self, element: ET.Element, cluster: J1939NmCluster):
        self.logger.debug("Read J1939NmCluster <%s>" % cluster.getShortName())
        self.readNmCluster(element, cluster)
        cluster.setAddressClaimEnabled(self.getChildElementOptionalBooleanValue(element, "ADDRESS-CLAIM-ENABLED"))
        cluster.setUsesDynamicAddressing(self.getChildElementOptionalBooleanValue(element, "USES-DYNAMIC-ADDRESSING"))

    def readNmConfigNmClusters(self, element: ET.Element, nm_config: NmConfig):
        for child_element in self.findall(element, "NM-CLUSTERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-NM-CLUSTER":
                cluster = nm_config.createCanNmCluster(self.getShortName(child_element))
                self.readCanNmCluster(child_element, cluster)
            elif tag_name == "UDP-NM-CLUSTER":
                cluster = nm_config.createUdpNmCluster(self.getShortName(child_element))
                self.readUdpNmCluster(child_element, cluster)
            elif tag_name == "FLEXRAY-NM-CLUSTER":
                cluster = nm_config.createFlexrayNmCluster(self.getShortName(child_element))
                self.readFlexrayNmCluster(child_element, cluster)
            elif tag_name == "J-1939-NM-CLUSTER":
                cluster = nm_config.createJ1939NmCluster(self.getShortName(child_element))
                self.readJ1939NmCluster(child_element, cluster)
            else:
                self.raiseError("Unsupported Nm Cluster <%s>" % tag_name)

    def readUdpNmEcu(self, element: ET.Element, ecu: UdpNmEcu):
        ecu.setNmSynchronizationPointEnabled(self.getChildElementOptionalBooleanValue(element, "NM-SYNCHRONIZATION-POINT-ENABLED"))

    def readFlexrayNmEcu(self, element: ET.Element, ecu: FlexrayNmEcu):
        ecu.setNmHwVoteEnabled(self.getChildElementOptionalBooleanValue(element, "NM-HW-VOTE-ENABLED"))
        ecu.setNmMainFunctionAcrossFrCycle(self.getChildElementOptionalBooleanValue(element, "NM-MAIN-FUNCTION-ACROSS-FR-CYCLE"))

    def readCanNmEcu(self, element: ET.Element, ecu: CanNmEcu):
        pass

    def readJ1939NmEcu(self, element: ET.Element, ecu: J1939NmEcu):
        pass

    def readBusDependentNmEcus(self, element: ET.Element, nm_ecu: NmEcu):
        for child_element in self.findall(element, "BUS-DEPENDENT-NM-ECUS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "UDP-NM-ECU":
                udp_nm_ecu = UdpNmEcu()
                self.readUdpNmEcu(child_element, udp_nm_ecu)
                nm_ecu.addBusDependentNmEcu(udp_nm_ecu)
            elif tag_name == "CAN-NM-ECU":
                can_nm_ecu = CanNmEcu()
                self.readCanNmEcu(child_element, can_nm_ecu)
                nm_ecu.addBusDependentNmEcu(can_nm_ecu)
            elif tag_name == "FLEXRAY-NM-ECU":
                flexray_nm_ecu = FlexrayNmEcu()
                self.readFlexrayNmEcu(child_element, flexray_nm_ecu)
                nm_ecu.addBusDependentNmEcu(flexray_nm_ecu)
            elif tag_name == "J-1939-NM-ECU":
                j1939_nm_ecu = J1939NmEcu()
                self.readJ1939NmEcu(child_element, j1939_nm_ecu)
                nm_ecu.addBusDependentNmEcu(j1939_nm_ecu)
            else:
                self.notImplemented("Unsupported BusDependentNmEcu <%s>" % tag_name)

    def readNmEcu(self, element: ET.Element, nm_ecu: NmEcu):
        self.readIdentifiable(element, nm_ecu)
        self.readBusDependentNmEcus(element, nm_ecu)
        nm_ecu.setEcuInstanceRef(self.getChildElementOptionalRefType(element, "ECU-INSTANCE-REF"))
        nm_ecu.setNmBusSynchronizationEnabled(self.getChildElementOptionalBooleanValue(element, "NM-BUS-SYNCHRONIZATION-ENABLED"))
        nm_ecu.setNmComControlEnabled(self.getChildElementOptionalBooleanValue(element, "NM-COM-CONTROL-ENABLED"))
        nm_ecu.setNmCycletimeMainFunction(self.getChildElementOptionalTimeValue(element, "NM-CYCLETIME-MAIN-FUNCTION"))
        nm_ecu.setNmPduRxIndicationEnabled(self.getChildElementOptionalBooleanValue(element, "NM-PDU-RX-INDICATION-ENABLED"))
        nm_ecu.setNmRemoteSleepIndEnabled(self.getChildElementOptionalBooleanValue(element, "NM-REMOTE-SLEEP-IND-ENABLED"))
        nm_ecu.setNmStateChangeIndEnabled(self.getChildElementOptionalBooleanValue(element, "NM-STATE-CHANGE-IND-ENABLED"))
        nm_ecu.setNmUserDataEnabled(self.getChildElementOptionalBooleanValue(element, "NM-USER-DATA-ENABLED"))

    def readNmConfigNmIfEcus(self, element: ET.Element, nm_config: NmConfig):
        for child_element in self.findall(element, "NM-IF-ECUS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "NM-ECU":
                ecu = nm_config.createNmEcu(self.getShortName(child_element))
                self.readNmEcu(child_element, ecu)
            else:
                self.notImplemented("Unsupported NmIfEcus <%s>" % tag_name)

    def readNmConfig(self, element: ET.Element, config: NmConfig):
        self.logger.debug("Read NmConfig <%s>" % config.getShortName())
        self.readIdentifiable(element, config)
        self.readNmConfigNmClusters(element, config)
        self.readNmConfigNmClusterCouplings(element, config)
        self.readNmConfigNmIfEcus(element, config)

    def readTpConfig(self, element: ET.Element, config: TpConfig):
        self.readIdentifiable(element, config)
        config.setCommunicationClusterRef(self.getChildElementOptionalRefType(element, "COMMUNICATION-CLUSTER-REF"))

    def readCanTpAddress(self, element: ET.Element, address: CanTpAddress):
        self.readIdentifiable(element, address)
        address.setTpAddress(self.getChildElementOptionalIntegerValue(element, "TP-ADDRESS"))
        address.setTpAddressExtensionValue(self.getChildElementOptionalIntegerValue(element, "TP-ADDRESS-EXTENSION-VALUE"))

    def readCanTpConfigTpAddresses(self, element: ET.Element, config: CanTpConfig):
        for child_element in self.findall(element, "TP-ADDRESSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-TP-ADDRESS":
                address = config.createCanTpAddress(self.getShortName(child_element))
                self.readCanTpAddress(child_element, address)
            else:
                self.notImplemented("Unsupported TpAddress <%s>" % tag_name)

    def readCanTpChannel(self, element: ET.Element, channel: CanTpChannel):
        self.readIdentifiable(element, channel)
        channel.setChannelId(self.getChildElementOptionalPositiveInteger(element, "CHANNEL-ID"))

    def readCanTpConfigTpChannels(self, element: ET.Element, config: CanTpConfig):
        for child_element in self.findall(element, "TP-CHANNELS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-TP-CHANNEL":
                channel = config.createCanTpChannel(self.getShortName(child_element))
                self.readCanTpChannel(child_element, channel)
            else:
                self.notImplemented("Unsupported TpChannel <%s>" % tag_name)

    def readTpConnection(self, element: ET.Element, connection: TpConnection):
        self.readARObject(element, connection)
        child_element = self.find(element, "IDENT")
        if child_element is not None:
            ident = connection.createTpConnectionIdent(self.getShortName(child_element))
            self.readReferrable(child_element, ident)

    def readTpConnectionReceiverRefs(self, element: ET.Element, connection: CanTpConnection):
        for ref in self.getChildElementRefTypeList(element, "RECEIVER-REFS/RECEIVER-REF"):
            connection.addReceiverRef(ref)

    def readCanTpConnection(self, element: ET.Element, connection: CanTpConnection):
        self.readTpConnection(element, connection)
        addressing_format_literal = self.getChildElementOptionalLiteral(element, "ADDRESSING-FORMAT")
        if addressing_format_literal is not None:
            addressing_format = CanTpAddressingFormatType()
            addressing_format.setValue(addressing_format_literal.getValue())
            connection.setAddressingFormat(addressing_format)
        connection.setCanTpChannelRef(self.getChildElementOptionalRefType(element, "CAN-TP-CHANNEL-REF"))
        connection.setCancellation(self.getChildElementOptionalBooleanValue(element, "CANCELLATION"))
        connection.setDataPduRef(self.getChildElementOptionalRefType(element, "DATA-PDU-REF"))
        connection.setFlowControlPduRef(self.getChildElementOptionalRefType(element, "FLOW-CONTROL-PDU-REF"))
        connection.setMaxBlockSize(self.getChildElementOptionalIntegerValue(element, "MAX-BLOCK-SIZE"))
        connection.setMulticastRef(self.getChildElementOptionalRefType(element, "MULTICAST-REF"))
        connection.setPaddingActivation(self.getChildElementOptionalBooleanValue(element, "PADDING-ACTIVATION"))
        self.readTpConnectionReceiverRefs(element, connection)
        connection.setTaType(self.getChildElementOptionalLiteral(element, "TA-TYPE"))
        connection.setTimeoutBr(self.getChildElementOptionalTimeValue(element, "TIMEOUT-BR"))
        connection.setTimeoutBs(self.getChildElementOptionalTimeValue(element, "TIMEOUT-BS"))
        connection.setTimeoutCr(self.getChildElementOptionalTimeValue(element, "TIMEOUT-CR"))
        connection.setTimeoutCs(self.getChildElementOptionalTimeValue(element, "TIMEOUT-CS"))
        connection.setTpSduRef(self.getChildElementOptionalRefType(element, "TP-SDU-REF"))
        connection.setTransmitterRef(self.getChildElementOptionalRefType(element, "TRANSMITTER-REF"))

    def readCanTpConfigTpConnections(self, element: ET.Element, config: CanTpConfig):
        for child_element in self.findall(element, "TP-CONNECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-TP-CONNECTION":
                connection = CanTpConnection()
                self.readCanTpConnection(child_element, connection)
                config.addTpConnection(connection)
            else:
                self.notImplemented("Unsupported TpConnection <%s>" % tag_name)

    def readCanTpEcu(self, element: ET.Element, tp_ecu: CanTpEcu):
        self.readARObject(element, tp_ecu)
        tp_ecu.setCycleTimeMainFunction(self.getChildElementOptionalTimeValue(element, "CYCLE-TIME-MAIN-FUNCTION"))
        tp_ecu.setEcuInstanceRef(self.getChildElementOptionalRefType(element, "ECU-INSTANCE-REF"))
        self.readVariationPointCapable(element, tp_ecu)

    def readCanTpConfigTpEcus(self, element: ET.Element, config: CanTpConfig):
        for child_element in self.findall(element, "TP-ECUS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-TP-ECU":
                tp_ecu = CanTpEcu()
                self.readCanTpEcu(child_element, tp_ecu)
                config.addTpEcu(tp_ecu)
            else:
                self.notImplemented("Unsupported TpEcu <%s>" % tag_name)

    def readCanTpNode(self, element: ET.Element, tp_node: CanTpNode):
        self.readIdentifiable(element, tp_node)
        tp_node.setConnectorRef(self.getChildElementOptionalRefType(element, "CONNECTOR-REF"))
        tp_node.setMaxFcWait(self.getChildElementOptionalIntegerValue(element, "MAX-FC-WAIT"))
        tp_node.setStMin(self.getChildElementOptionalTimeValue(element, "ST-MIN"))
        tp_node.setTimeoutAr(self.getChildElementOptionalTimeValue(element, "TIMEOUT-AR"))
        tp_node.setTimeoutAs(self.getChildElementOptionalTimeValue(element, "TIMEOUT-AS"))
        tp_node.setTpAddressRef(self.getChildElementOptionalRefType(element, "TP-ADDRESS-REF"))

    def readCanTpConfigTpNodes(self, element: ET.Element, config: CanTpConfig):
        for child_element in self.findall(element, "TP-NODES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-TP-NODE":
                tp_node = config.createCanTpNode(self.getShortName(child_element))
                self.readCanTpNode(child_element, tp_node)
            else:
                self.notImplemented("Unsupported TpNode <%s>" % tag_name)

    def readCanTpConfig(self, element: ET.Element, config: CanTpConfig):
        self.logger.debug("Read CanTpConfig <%s>" % config.getShortName())
        self.readTpConfig(element, config)
        self.readCanTpConfigTpAddresses(element, config)
        self.readCanTpConfigTpChannels(element, config)
        self.readCanTpConfigTpConnections(element, config)
        self.readCanTpConfigTpEcus(element, config)
        self.readCanTpConfigTpNodes(element, config)

    def readTpAddress(self, element: ET.Element, address: TpAddress):
        self.readIdentifiable(element, address)
        address.setTpAddress(self.getChildElementOptionalIntegerValue(element, "TP-ADDRESS"))

    def readLinTpConfigTpAddresses(self, element: ET.Element, config: LinTpConfig):
        for child_element in self.findall(element, "TP-ADDRESSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TP-ADDRESS":
                address = config.createTpAddress(self.getShortName(child_element))
                self.readTpAddress(child_element, address)
            else:
                self.notImplemented("Unsupported TpAddress <%s>" % tag_name)

    def readLinTpConnection(self, element: ET.Element, connection: LinTpConnection):
        self.readTpConnection(element, connection)
        connection.setDataPduRef(self.getChildElementOptionalRefType(element, "DATA-PDU-REF"))
        connection.setFlowControlRef(self.getChildElementOptionalRefType(element, "FLOW-CONTROL-REF"))
        connection.setLinTpNSduRef(self.getChildElementOptionalRefType(element, "LIN-TP-N-SDU-REF"))
        connection.setMulticastRef(self.getChildElementOptionalRefType(element, "MULTICAST-REF"))
        self.readTpConnectionReceiverRefs(element, connection)
        connection.setTimeoutAs(self.getChildElementOptionalTimeValue(element, "TIMEOUT-AS"))
        connection.setTimeoutCr(self.getChildElementOptionalTimeValue(element, "TIMEOUT-CR"))
        connection.setTimeoutCs(self.getChildElementOptionalTimeValue(element, "TIMEOUT-CS"))
        connection.setTransmitterRef(self.getChildElementOptionalRefType(element, "TRANSMITTER-REF"))
        self.readVariationPointCapable(element, connection)

    def readLinTpConfigTpConnections(self, element: ET.Element, config: LinTpConfig):
        for child_element in self.findall(element, "TP-CONNECTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "LIN-TP-CONNECTION":
                connection = LinTpConnection()
                self.readLinTpConnection(child_element, connection)
                config.addTpConnection(connection)
            else:
                self.notImplemented("Unsupported TpConnection <%s>" % tag_name)

    def readLinTpNode(self, element: ET.Element, tp_node: LinTpNode):
        self.readIdentifiable(element, tp_node)
        tp_node.setConnectorRef(self.getChildElementOptionalRefType(element, "CONNECTOR-REF"))
        tp_node.setDropNotRequestedNad(self.getChildElementOptionalBooleanValue(element, "DROP-NOT-REQUESTED-NAD"))
        tp_node.setMaxNumberOfRespPendingFrames(self.getChildElementOptionalIntegerValue(element, "MAX-NUMBER-OF-RESP-PENDING-FRAMES"))
        tp_node.setP2Max(self.getChildElementOptionalTimeValue(element, "P-2-MAX"))
        tp_node.setP2Timing(self.getChildElementOptionalTimeValue(element, "P-2-TIMING"))
        tp_node.setTpAddressRef(self.getChildElementOptionalRefType(element, "TP-ADDRESS-REF"))

    def readLinTpConfigTpNodes(self, element: ET.Element, config: LinTpConfig):
        for child_element in self.findall(element, "TP-NODES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "LIN-TP-NODE":
                tp_node = config.createLinTpNode(self.getShortName(child_element))
                self.readLinTpNode(child_element, tp_node)
            else:
                self.notImplemented("Unsupported TpNode <%s>" % tag_name)

    def readLinTpConfig(self, element: ET.Element, config: LinTpConfig):
        self.logger.debug("Read LinTpConfig <%s>" % config.getShortName())
        self.readTpConfig(element, config)
        self.readLinTpConfigTpAddresses(element, config)
        self.readLinTpConfigTpConnections(element, config)
        self.readLinTpConfigTpNodes(element, config)

    def readCanFrame(self, element: ET.Element, frame: CanFrame):
        self.logger.debug("Read CanFrame <%s>" % frame.getShortName())
        self.readFrame(element, frame)

    def readFlexrayFrame(self, element: ET.Element, frame: FlexrayFrame):
        self.logger.debug("Read FlexrayFrame <%s>" % frame.getShortName())
        self.readFrame(element, frame)

    def readCryptoKeySlot(self, element: ET.Element, key_slot: CryptoKeySlot):
        self.logger.debug("Read CryptoKeySlot <%s>" % key_slot.getShortName())
        self.readIdentifiable(element, key_slot)
        key_slot.setAllocateShadowCopy(self.getChildElementOptionalBooleanValue(element, "ALLOCATE-SHADOW-COPY"))
        key_slot.setCryptoAlgId(self.getChildElementOptionalString(element, "CRYPTO-ALG-ID"))
        literal = self.getChildElementOptionalLiteral(element, "CRYPTO-OBJECT-TYPE")
        if literal is not None:
            object_type = CryptoObjectTypeEnum()
            object_type.setValue(literal.getValue())
            key_slot.setCryptoObjectType(object_type)
        modification_element = self.find(element, "KEY-SLOT-ALLOWED-MODIFICATION")
        if modification_element is not None:
            modification = CryptoKeySlotAllowedModification()
            self.readCryptoKeySlotAllowedModification(modification_element, modification)
            key_slot.setKeySlotAllowedModification(modification)
        for usage_element in self.findall(element, "KEY-SLOT-CONTENT-ALLOWED-USAGES/CRYPTO-KEY-SLOT-CONTENT-ALLOWED-USAGE"):
            usage = CryptoKeySlotContentAllowedUsage()
            self.readCryptoKeySlotContentAllowedUsage(usage_element, usage)
            key_slot.addKeySlotContentAllowedUsage(usage)
        key_slot.setSlotCapacity(self.getChildElementOptionalPositiveInteger(element, "SLOT-CAPACITY"))
        literal = self.getChildElementOptionalLiteral(element, "SLOT-TYPE")
        if literal is not None:
            slot_type = CryptoKeySlotTypeEnum()
            slot_type.setValue(literal.getValue())
            key_slot.setSlotType(slot_type)

    def readCryptoKeySlotAllowedModification(self, element: ET.Element, modification: CryptoKeySlotAllowedModification):
        self.readARObject(element, modification)
        modification.setAllowContentTypeChange(self.getChildElementOptionalBooleanValue(element, "ALLOW-CONTENT-TYPE-CHANGE"))
        modification.setExportability(self.getChildElementOptionalBooleanValue(element, "EXPORTABILITY"))
        modification.setMaxNumberOfAllowedUpdates(self.getChildElementOptionalPositiveInteger(element, "MAX-NUMBER-OF-ALLOWED-UPDATES"))
        modification.setRestrictUpdate(self.getChildElementOptionalBooleanValue(element, "RESTRICT-UPDATE"))

    def readCryptoKeySlotContentAllowedUsage(self, element: ET.Element, usage: CryptoKeySlotContentAllowedUsage):
        self.readARObject(element, usage)
        usage.setAllowedKeyslotUsage(self.getChildElementOptionalString(element, "ALLOWED-KEYSLOT-USAGE"))

    def readFlexrayCommunicationController(self, element: ET.Element, controller: FlexrayCommunicationController):
        self.logger.debug("Read CommunicationController <%s>" % controller.getShortName())
        self.readIdentifiable(element, controller)
        self.readCommunicationController(element, controller)
        child_element = self.find(element, "FLEXRAY-COMMUNICATION-CONTROLLER-VARIANTS/FLEXRAY-COMMUNICATION-CONTROLLER-CONDITIONAL")
        if child_element is not None:
            controller.setAcceptedStartupRange(self.getChildElementOptionalIntegerValue(child_element, "ACCEPTED-STARTUP-RANGE"))
            controller.setAllowHaltDueToClock(self.getChildElementOptionalBooleanValue(child_element, "ALLOW-HALT-DUE-TO-CLOCK"))
            controller.setAllowPassiveToActive(self.getChildElementOptionalIntegerValue(child_element, "ALLOW-PASSIVE-TO-ACTIVE"))
            controller.setClusterDriftDamping(self.getChildElementOptionalIntegerValue(child_element, "CLUSTER-DRIFT-DAMPING"))
            controller.setDecodingCorrection(self.getChildElementOptionalIntegerValue(child_element, "DECODING-CORRECTION"))
            controller.setDelayCompensationA(self.getChildElementOptionalIntegerValue(child_element, "DELAY-COMPENSATION-A"))
            controller.setDelayCompensationB(self.getChildElementOptionalIntegerValue(child_element, "DELAY-COMPENSATION-B"))
            controller.setExternOffsetCorrection(self.getChildElementOptionalIntegerValue(child_element, "EXTERN-OFFSET-CORRECTION"))
            controller.setExternRateCorrection(self.getChildElementOptionalIntegerValue(child_element, "EXTERN-RATE-CORRECTION"))
            controller.setExternalSync(self.getChildElementOptionalBooleanValue(child_element, "EXTERNAL-SYNC"))
            controller.setFallBackInternal(self.getChildElementOptionalBooleanValue(child_element, "FALL-BACK-INTERNAL"))
            for fifo_element in self.findall(child_element, "FLEXRAY-FIFOS/FLEXRAY-FIFO-CONFIGURATION"):
                controller.addFlexrayFifo(self.getFlexrayFifoConfiguration(fifo_element, "."))
            controller.setKeySlotID(self.getChildElementOptionalPositiveInteger(child_element, "KEY-SLOT-ID"))
            controller.setKeySlotOnlyEnabled(self.getChildElementOptionalBooleanValue(child_element, "KEY-SLOT-ONLY-ENABLED"))
            controller.setKeySlotUsedForStartUp(self.getChildElementOptionalBooleanValue(child_element, "KEY-SLOT-USED-FOR-START-UP"))
            controller.setKeySlotUsedForSync(self.getChildElementOptionalBooleanValue(child_element, "KEY-SLOT-USED-FOR-SYNC"))
            controller.setLatestTX(self.getChildElementOptionalIntegerValue(child_element, "LATEST-TX"))
            controller.setListenTimeout(self.getChildElementOptionalIntegerValue(child_element, "LISTEN-TIMEOUT"))
            controller.setMacroInitialOffsetA(self.getChildElementOptionalIntegerValue(child_element, "MACRO-INITIAL-OFFSET-A"))
            controller.setMacroInitialOffsetB(self.getChildElementOptionalIntegerValue(child_element, "MACRO-INITIAL-OFFSET-B"))
            controller.setMaximumDynamicPayloadLength(self.getChildElementOptionalIntegerValue(child_element, "MAXIMUM-DYNAMIC-PAYLOAD-LENGTH"))
            controller.setMicroInitialOffsetA(self.getChildElementOptionalIntegerValue(child_element, "MICRO-INITIAL-OFFSET-A"))
            controller.setMicroInitialOffsetB(self.getChildElementOptionalIntegerValue(child_element, "MICRO-INITIAL-OFFSET-B"))
            controller.setMicroPerCycle(self.getChildElementOptionalIntegerValue(child_element, "MICRO-PER-CYCLE"))
            controller.setMicrotickDuration(self.getChildElementOptionalTimeValue(child_element, "MICROTICK-DURATION"))
            controller.setNmVectorEarlyUpdate(self.getChildElementOptionalBooleanValue(child_element, "NM-VECTOR-EARLY-UPDATE"))
            controller.setOffsetCorrectionOut(self.getChildElementOptionalIntegerValue(child_element, "OFFSET-CORRECTION-OUT"))
            controller.setRateCorrectionOut(self.getChildElementOptionalIntegerValue(child_element, "RATE-CORRECTION-OUT"))
            controller.setSamplesPerMicrotick(self.getChildElementOptionalIntegerValue(child_element, "SAMPLES-PER-MICROTICK"))
            controller.setSecondKeySlotId(self.getChildElementOptionalPositiveInteger(child_element, "SECOND-KEY-SLOT-ID"))
            controller.setTwoKeySlotMode(self.getChildElementOptionalBooleanValue(child_element, "TWO-KEY-SLOT-MODE"))
            controller.setWakeUpPattern(self.getChildElementOptionalIntegerValue(child_element, "WAKE-UP-PATTERN"))

    def readDataTransformationTransformerChainRefs(self, element: ET.Element, dtf: DataTransformation):
        for ref in self.getChildElementRefTypeList(element, "TRANSFORMER-CHAIN-REFS/TRANSFORMER-CHAIN-REF"):
            dtf.addTransformerChainRef(ref)

    def readDataTransformation(self, element: ET.Element, dtf: DataTransformation):
        self.readIdentifiable(element, dtf)
        dtf.setDataTransformationKind(self.getChildElementOptionalLiteral(element, "DATA-TRANSFORMATION-KIND"))
        dtf.setExecuteDespiteDataUnavailability(self.getChildElementOptionalBooleanValue(element, "EXECUTE-DESPITE-DATA-UNAVAILABILITY"))
        self.readDataTransformationTransformerChainRefs(element, dtf)

    def readDataTransformationSetDataTransformations(self, element: ET.Element, dtf_set: DataTransformationSet):
        for child_element in self.findall(element, "DATA-TRANSFORMATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DATA-TRANSFORMATION":
                dtf = dtf_set.createDataTransformation(self.getShortName(child_element))
                self.readDataTransformation(child_element, dtf)
            else:
                self.notImplemented("Unsupported DataTransformation <%s>" % tag_name)

    def getBufferProperties(self, element: ET.Element, key: str) -> BufferProperties:
        properties = None
        child_element = self.find(element, key)
        if child_element is not None:
            properties = BufferProperties()
            properties.setHeaderLength(self.getChildElementOptionalIntegerValue(child_element, "HEADER-LENGTH"))
            properties.setInPlace(self.getChildElementOptionalBooleanValue(child_element, "IN-PLACE"))
        return properties

    def readDescribable(self, element: ET.Element, desc: Describable):
        self.readARObject(element, desc)

        desc.setDesc(self.getMultiLanguageOverviewParagraph(element, "DESC"))
        desc.setCategory(self.getChildElementOptionalLiteral(element, "CATEGORY"))
        desc.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))
        desc.setAdminData(self.getAdminData(element, "ADMIN-DATA"))

    def readTransformationDescription(self, element: ET.Element, desc: TransformationDescription):
        self.readDescribable(element, desc)

    def readEndToEndTransformationDescription(self, element: ET.Element, desc: EndToEndTransformationDescription):
        self.readTransformationDescription(element, desc)
        desc.setClearFromValidToInvalid(self.getChildElementOptionalBooleanValue(element, "CLEAR-FROM-VALID-TO-INVALID"))
        desc.setCounterOffset(self.getChildElementOptionalPositiveInteger(element, "COUNTER-OFFSET"))
        desc.setCrcOffset(self.getChildElementOptionalPositiveInteger(element, "CRC-OFFSET"))
        desc.setDataIdMode(self.getChildElementOptionalLiteral(element, "DATA-ID-MODE"))
        desc.setDataIdNibbleOffset(self.getChildElementOptionalPositiveInteger(element, "DATA-ID-NIBBLE-OFFSET"))
        desc.setE2eProfileCompatibilityPropsRef(self.getChildElementOptionalRefType(element, "E-2-E-PROFILE-COMPATIBILITY-PROPS-REF"))
        desc.setMaxDeltaCounter(self.getChildElementOptionalPositiveInteger(element, "MAX-DELTA-COUNTER"))
        desc.setMaxErrorStateInit(self.getChildElementOptionalPositiveInteger(element, "MAX-ERROR-STATE-INIT"))
        desc.setMaxErrorStateInvalid(self.getChildElementOptionalPositiveInteger(element, "MAX-ERROR-STATE-INVALID"))
        desc.setMaxErrorStateValid(self.getChildElementOptionalPositiveInteger(element, "MAX-ERROR-STATE-VALID"))
        desc.setMaxNoNewOrRepeatedData(self.getChildElementOptionalPositiveInteger(element, "MAX-NO-NEW-OR-REPEATED-DATA"))
        desc.setMinOkStateInit(self.getChildElementOptionalPositiveInteger(element, "MIN-OK-STATE-INIT"))
        desc.setMinOkStateInvalid(self.getChildElementOptionalPositiveInteger(element, "MIN-OK-STATE-INVALID"))
        desc.setMinOkStateValid(self.getChildElementOptionalPositiveInteger(element, "MIN-OK-STATE-VALID"))
        desc.setOffset(self.getChildElementOptionalPositiveInteger(element, "OFFSET"))
        desc.setProfileBehavior(self.getChildElementOptionalLiteral(element, "PROFILE-BEHAVIOR"))
        desc.setProfileName(self.getChildElementOptionalLiteral(element, "PROFILE-NAME"))
        desc.setSyncCounterInit(self.getChildElementOptionalPositiveInteger(element, "SYNC-COUNTER-INIT"))
        desc.setUpperHeaderBitsToShift(self.getChildElementOptionalPositiveInteger(element, "UPPER-HEADER-BITS-TO-SHIFT"))
        desc.setWindowSizeInit(self.getChildElementOptionalPositiveInteger(element, "WINDOW-SIZE-INIT"))
        desc.setWindowSizeInvalid(self.getChildElementOptionalPositiveInteger(element, "WINDOW-SIZE-INVALID"))
        desc.setWindowSizeValid(self.getChildElementOptionalPositiveInteger(element, "WINDOW-SIZE-VALID"))

    def readTransformationTechnologyTransformationDescriptions(self, element: ET.Element, tech: TransformationTechnology):
        for child_element in self.findall(element, "TRANSFORMATION-DESCRIPTIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-TRANSFORMATION-DESCRIPTION":
                desc = EndToEndTransformationDescription()
                self.readEndToEndTransformationDescription(child_element, desc)
                tech.setTransformationDescription(desc)
            else:
                self.notImplemented("Unsupported TransformationDescription <%s>" % tag_name)

    def readTransformationTechnology(self, element: ET.Element, tech: TransformationTechnology):
        self.readIdentifiable(element, tech)
        tech.setBufferProperties(self.getBufferProperties(element, "BUFFER-PROPERTIES"))
        tech.setHasInternalState(self.getChildElementOptionalBooleanValue(element, "HAS-INTERNAL-STATE"))
        tech.setNeedsOriginalData(self.getChildElementOptionalBooleanValue(element, "NEEDS-ORIGINAL-DATA"))
        tech.setProtocol(self.getChildElementOptionalLiteral(element, "PROTOCOL"))
        self.readTransformationTechnologyTransformationDescriptions(element, tech)
        tech.setTransformerClass(self.getChildElementOptionalLiteral(element, "TRANSFORMER-CLASS"))
        tech.setVersion(self.getChildElementOptionalLiteral(element, "VERSION"))

    def readDataTransformationSetTransformationTechnologies(self, element: ET.Element, dtf_set: DataTransformationSet):
        for child_element in self.findall(element, "TRANSFORMATION-TECHNOLOGYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TRANSFORMATION-TECHNOLOGY":
                tech = dtf_set.createTransformationTechnology(self.getShortName(child_element))
                self.readTransformationTechnology(child_element, tech)
            else:
                self.notImplemented("Unsupported TransformationTechnology <%s>" % tag_name)

    def readDataTransformationSet(self, element: ET.Element, dtf_set: DataTransformationSet):
        self.logger.debug("Read DataTransformationSet <%s>" % dtf_set.getShortName())
        self.readARElement(element, dtf_set)
        self.readDataTransformationSetDataTransformations(element, dtf_set)
        self.readDataTransformationSetTransformationTechnologies(element, dtf_set)

    def readE2EProfileCompatibilityProps(self, element: ET.Element, props: E2EProfileCompatibilityProps):
        self.logger.debug("Read E2EProfileCompatibilityProps <%s>" % props.getShortName())
        self.readARElement(element, props)
        props.setTransitToInvalidExtended(self.getChildElementOptionalBooleanValue(element, "TRANSIT-TO-INVALID-EXTENDED"))

    def readKeywordClassifications(self, element: ET.Element, keyword: Keyword):
        for literal in self.getChildElementLiteralValueList(element, "CLASSIFICATIONS/CLASSIFICATION"):
            keyword.addClassification(literal)

    def readKeyword(self, element: ET.Element, keyword: Keyword):
        # self.logger.debug("Read Keyword <%s>" % keyword.getShortName())
        self.readIdentifiable(element, keyword)
        keyword.setAbbrName(self.getChildElementOptionalLiteral(element, "ABBR-NAME"))
        self.readKeywordClassifications(element, keyword)

    def readKeywordSetKeywords(self, element: ET.Element, keyword_set: KeywordSet):
        for child_element in self.findall(element, "KEYWORDS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "KEYWORD":
                tech = keyword_set.createKeyword(self.getShortName(child_element))
                self.readKeyword(child_element, tech)
            else:
                self.notImplemented("Unsupported Keyword <%s>" % tag_name)

    def readKeywordSet(self, element: ET.Element, keyword_set: KeywordSet):
        self.logger.debug("Read KeywordSet <%s>" % keyword_set.getShortName())
        self.readARElement(element, keyword_set)
        self.readKeywordSetKeywords(element, keyword_set)

    def readPortPrototypeBlueprint(self, element: ET.Element, blueprint: PortPrototypeBlueprint):
        self.logger.debug("Read PortPrototypeBlueprint <%s>" % blueprint.getShortName())
        self.readARElement(element, blueprint)
        self.readPortPrototypeBlueprintInitValues(element, blueprint)
        blueprint.setInterfaceRef(self.getChildElementOptionalRefType(element, "INTERFACE-REF"))
        self.readProvidedComSpec(element, blueprint)
        self.readRequiredComSpec(element, blueprint)

    def readPortPrototypeBlueprintInitValues(self, element: ET.Element, blueprint: PortPrototypeBlueprint):
        for child_element in self.findall(element, "INIT-VALUES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "PORT-PROTOTYPE-BLUEPRINT-INIT-VALUE":
                init_value = PortPrototypeBlueprintInitValue()
                self.readPortPrototypeBlueprintInitValue(child_element, init_value)
                blueprint.addInitValue(init_value)
            else:
                self.notImplemented("Unsupported PortPrototypeBlueprintInitValue <%s>" % tag_name)

    def readPortPrototypeBlueprintInitValue(self, element: ET.Element, init_value: PortPrototypeBlueprintInitValue):
        self.readARObject(element, init_value)
        init_value.setDataPrototypeRef(self.getChildElementOptionalRefType(element, "DATA-PROTOTYPE-REF"))
        init_value.setValue(self.getChildValueSpecification(element, "VALUE"))

    def readModeDeclarationMappingFirstModeRefs(self, element: ET.Element, mapping: ModeDeclarationMapping):
        for ref_link in self.getChildElementRefTypeList(element, "FIRST-MODE-REFS/FIRST-MODE-REF"):
            mapping.addFirstModeRef(ref_link)

    def readModeDeclarationMapping(self, element: ET.Element, mapping: ModeDeclarationMapping):
        # self.logger.debug("Read ModeDeclarationMapping <%s>" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        self.readModeDeclarationMappingFirstModeRefs(element, mapping)
        mapping.setSecondModeRef(self.getChildElementOptionalRefType(element, "SECOND-MODE-REF"))

    def readModeDeclarationMappingSetModeDeclarationMappings(self, element: ET.Element, mapping_set: ModeDeclarationMappingSet):
        for child_element in self.findall(element, "MODE-DECLARATION-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "MODE-DECLARATION-MAPPING":
                mapping = mapping_set.createModeDeclarationMapping(self.getShortName(child_element))
                self.readModeDeclarationMapping(child_element, mapping)
            else:
                self.notImplemented("Unsupported ModeDeclarationMapping <%s>" % tag_name)

    def readModeDeclarationMappingSet(self, element: ET.Element, mapping_set: ModeDeclarationMappingSet):
        self.logger.debug("Read ModeDeclarationMappingSet <%s>" % mapping_set.getShortName())
        self.readARElement(element, mapping_set)
        self.readModeDeclarationMappingSetModeDeclarationMappings(element, mapping_set)

    def readEcucDefinitionElement(self, element: ET.Element, def_element: EcucDefinitionElement):
        self.readIdentifiable(element, def_element)
        def_element.setEcucCond(self.readEcucConditionSpecification(element))
        self.readEcucValidationConditions(element, def_element)
        def_element.setLowerMultiplicity(self.getChildElementOptionalPositiveInteger(element, "LOWER-MULTIPLICITY"))
        def_element.setUpperMultiplicity(self.getChildElementOptionalPositiveInteger(element, "UPPER-MULTIPLICITY"))
        def_element.setScope(self.getChildElementOptionalLiteral(element, "SCOPE"))

    def readEcucModuleDefSupportedConfigVariants(self, element: ET.Element, module_def: EcucModuleDef):
        for variant in self.getChildElementLiteralValueList(element, "SUPPORTED-CONFIG-VARIANTS/SUPPORTED-CONFIG-VARIANT"):
            module_def.addSupportedConfigVariant(variant)

    def readEcucAbstractConfigurationClass(self, element: ET.Element, cfg_class: EcucAbstractConfigurationClass):
        self.readARObject(element, cfg_class)
        cfg_class.setConfigClass(self.getChildElementOptionalLiteral(element, "CONFIG-CLASS"))
        cfg_class.setConfigVariant(self.getChildElementOptionalLiteral(element, "CONFIG-VARIANT"))

    def readEcucMultiplicityConfigurationClass(self, element: ET.Element, cfg_class: EcucMultiplicityConfigurationClass):
        self.readEcucAbstractConfigurationClass(element, cfg_class)

    def getEcucMultiplicityConfigurationClasses(self, element: ET.Element) -> List[EcucMultiplicityConfigurationClass]:
        cfg_classes = []
        for child_element in self.findall(element, "MULTIPLICITY-CONFIG-CLASSES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-MULTIPLICITY-CONFIGURATION-CLASS":
                cfg_class = EcucMultiplicityConfigurationClass()
                self.readEcucMultiplicityConfigurationClass(child_element, cfg_class)
                cfg_classes.append(cfg_class)
            else:
                self.notImplemented("Unsupported MultiplicityConfigClass <%s>" % tag_name)
        return cfg_classes

    def readEcucContainerDef(self, element: ET.Element, container_def: EcucContainerDef):
        self.readEcucDefinitionElement(element, container_def)
        for uri_ref in self.getEcucDestinationUriRefs(element):
            container_def.addDestinationUriRef(uri_ref)
        for cfg_class in self.getEcucMultiplicityConfigurationClasses(element):
            container_def.addMultiplicityConfigClass(cfg_class)
        container_def.setPostBuildVariantMultiplicity(self.getChildElementOptionalBooleanValue(element, "POST-BUILD-VARIANT-MULTIPLICITY"))
        container_def.setRequiresIndex(self.getChildElementOptionalBooleanValue(element, "REQUIRES-INDEX"))
        origin_lit = self.getChildElementOptionalLiteral(element, "ORIGIN")
        if origin_lit is not None:
            origin = String()
            origin.setValue(origin_lit.getValue())
            container_def.setOrigin(origin)

    def getEcucDestinationUriRefs(self, element: ET.Element) -> List[EcucDestinationUriDefRefType]:
        uri_refs = []
        for child_element in self.findall(element, "DESTINATION-URI-REFS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DESTINATION-URI-REF":
                uri_ref = EcucDestinationUriDefRefType()
                if "BASE" in child_element.attrib:
                    uri_ref.setBase(child_element.attrib["BASE"])
                if "DEST" in child_element.attrib:
                    uri_ref.setDest(child_element.attrib["DEST"])
                uri_ref.setValue(child_element.text)
                uri_refs.append(uri_ref)
            else:
                self.notImplemented("Unsupported DestinationUriRef <%s>" % tag_name)
        return uri_refs

    def readEcucDestinationUriDefSet(self, element: ET.Element, uri_def_set: EcucDestinationUriDefSet):
        self.logger.debug("Read EcucDestinationUriDefSet <%s>" % uri_def_set.getShortName())
        for child_element in self.findall(element, "DESTINATION-URI-DEFS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-DESTINATION-URI-DEF":
                uri_def = uri_def_set.createEcucDestinationUriDef(self.getShortName(child_element))
                self.readEcucDestinationUriDef(child_element, uri_def)
            else:
                self.notImplemented("Unsupported DestinationUriDef <%s>" % tag_name)

    def readEcucDestinationUriDef(self, element: ET.Element, uri_def: EcucDestinationUriDef):
        self.logger.debug("Read EcucDestinationUriDef <%s>" % uri_def.getShortName())
        self.readIdentifiable(element, uri_def)
        policy_element = self.find(element, "DESTINATION-URI-POLICY")
        if policy_element is not None:
            policy = EcucDestinationUriPolicy()
            self.readEcucDestinationUriPolicy(policy_element, policy)
            uri_def.setDestinationUriPolicy(policy)

    def readEcucDestinationUriPolicy(self, element: ET.Element, policy: EcucDestinationUriPolicy):
        self.readARObject(element, policy)
        self.readEcucDestinationUriPolicyContainers(element, policy)
        nesting_contract = self.getChildElementOptionalLiteral(element, "DESTINATION-URI-NESTING-CONTRACT")
        if nesting_contract is not None:
            contract_enum = EcucDestinationUriNestingContractEnum()
            contract_enum.setValue(nesting_contract)
            policy.setDestinationUriNestingContract(contract_enum)
        self.readEcucDestinationUriPolicyParameters(element, policy)
        self.readEcucDestinationUriPolicyReferences(element, policy)

    def readEcucDestinationUriPolicyContainers(self, element: ET.Element, policy: EcucDestinationUriPolicy):
        for child_element in self.findall(element, "CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-PARAM-CONF-CONTAINER-DEF":
                container_def = EcucParamConfContainerDef(policy, self.getShortName(child_element))
                self.readEcucParamConfContainerDef(child_element, container_def)
                policy.addContainer(container_def)
            elif tag_name == "ECUC-CHOICE-CONTAINER-DEF":
                container_def = EcucChoiceContainerDef(policy, self.getShortName(child_element))
                self.readEcucChoiceContainerDef(child_element, container_def)
                policy.addContainer(container_def)
            else:
                self.notImplemented("Unsupported DestinationUriPolicy Container <%s>" % tag_name)

    def readEcucDestinationUriPolicyParameters(self, element: ET.Element, policy: EcucDestinationUriPolicy):
        for child_element in self.findall(element, "PARAMETERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-BOOLEAN-PARAM-DEF":
                param_def = EcucBooleanParamDef(policy, self.getShortName(child_element))
                self.readEcucBooleanParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-ADD-INFO-PARAM-DEF":
                param_def = EcucAddInfoParamDef(policy, self.getShortName(child_element))
                self.readEcucAddInfoParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-STRING-PARAM-DEF":
                param_def = EcucStringParamDef(policy, self.getShortName(child_element))
                self.readEcucStringParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-INTEGER-PARAM-DEF":
                param_def = EcucIntegerParamDef(policy, self.getShortName(child_element))
                self.readEcucIntegerParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-FLOAT-PARAM-DEF":
                param_def = EcucFloatParamDef(policy, self.getShortName(child_element))
                self.readEcucFloatParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-ENUMERATION-PARAM-DEF":
                param_def = EcucEnumerationParamDef(policy, self.getShortName(child_element))
                self.readEcucEnumerationParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-FUNCTION-NAME-DEF":
                param_def = EcucFunctionNameDef(policy, self.getShortName(child_element))
                self.readEcucFunctionNameDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-MULTILINE-STRING-PARAM-DEF":
                param_def = EcucMultilineStringParamDef(policy, self.getShortName(child_element))
                self.readEcucMultilineStringParamDef(child_element, param_def)
                policy.addParameter(param_def)
            elif tag_name == "ECUC-LINKER-SYMBOL-DEF":
                param_def = EcucLinkerSymbolDef(policy, self.getShortName(child_element))
                self.readEcucLinkerSymbolDef(child_element, param_def)
                policy.addParameter(param_def)
            else:
                self.notImplemented("Unsupported DestinationUriPolicy Parameter <%s>" % tag_name)

    def readEcucDestinationUriPolicyReferences(self, element: ET.Element, policy: EcucDestinationUriPolicy):
        for child_element in self.findall(element, "REFERENCES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-SYMBOLIC-NAME-REFERENCE-DEF":
                ref_def = EcucSymbolicNameReferenceDef(policy, self.getShortName(child_element))
                self.readEcucSymbolicNameReferenceDef(child_element, ref_def)
                policy.addReference(ref_def)
            elif tag_name == "ECUC-REFERENCE-DEF":
                ref_def = EcucReferenceDef(policy, self.getShortName(child_element))
                self.readEcucReferenceDef(child_element, ref_def)
                policy.addReference(ref_def)
            elif tag_name == "ECUC-CHOICE-REFERENCE-DEF":
                ref_def = EcucChoiceReferenceDef(policy, self.getShortName(child_element))
                self.readEcucChoiceReferenceDef(child_element, ref_def)
                policy.addReference(ref_def)
            elif tag_name == "ECUC-INSTANCE-REFERENCE-DEF":
                ref_def = EcucInstanceReferenceDef(policy, self.getShortName(child_element))
                self.readEcucInstanceReferenceDef(child_element, ref_def)
                policy.addReference(ref_def)
            elif tag_name == "ECUC-FOREIGN-REFERENCE-DEF":
                ref_def = EcucForeignReferenceDef(policy, self.getShortName(child_element))
                self.readEcucForeignReferenceDef(child_element, ref_def)
                policy.addReference(ref_def)
            else:
                self.notImplemented("Unsupported DestinationUriPolicy Reference <%s>" % tag_name)

    def readEcucValueConfigurationClass(self, element: ET.Element, cfg_class: EcucValueConfigurationClass):
        self.readEcucAbstractConfigurationClass(element, cfg_class)

    def getEcucValueConfigurationClasses(self, element: ET.Element) -> List[EcucValueConfigurationClass]:
        cfg_classes = []
        for child_element in self.findall(element, "VALUE-CONFIG-CLASSES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-VALUE-CONFIGURATION-CLASS":
                cfg_class = EcucValueConfigurationClass()
                self.readEcucValueConfigurationClass(child_element, cfg_class)
                cfg_classes.append(cfg_class)
            else:
                self.notImplemented("Unsupported ValueConfigClass <%s>" % tag_name)
        return cfg_classes

    def readEcucCommonAttributes(self, element: ET.Element, common_attrs: EcucCommonAttributes):
        self.readEcucDefinitionElement(element, common_attrs)
        for cfg_class in self.getEcucMultiplicityConfigurationClasses(element):
            common_attrs.addMultiplicityConfigClass(cfg_class)
        common_attrs.setOrigin(self.getChildElementOptionalLiteral(element, "ORIGIN"))
        common_attrs.setPostBuildVariantMultiplicity(self.getChildElementOptionalBooleanValue(element, "POST-BUILD-VARIANT-MULTIPLICITY"))
        common_attrs.setPostBuildVariantValue(self.getChildElementOptionalBooleanValue(element, "POST-BUILD-VARIANT-VALUE"))
        common_attrs.setRequiresIndex(self.getChildElementOptionalBooleanValue(element, "REQUIRES-INDEX"))
        for cfg_class in self.getEcucValueConfigurationClasses(element):
            common_attrs.addValueConfigClass(cfg_class)

    def readEcucParameterDef(self, element: ET.Element, param_def: EcucParameterDef):
        self.readEcucCommonAttributes(element, param_def)
        param_def.setDerivation(self.readEcucDerivationSpecification(element))
        param_def.setSymbolicNameValue(self.getChildElementOptionalBooleanValue(element, "SYMBOLIC-NAME-VALUE"))
        param_def.setWithAuto(self.getChildElementOptionalBooleanValue(element, "WITH-AUTO"))

    def readEcucDerivationSpecification(self, element: ET.Element) -> Optional[EcucDerivationSpecification]:
        child_element = self.find(element, "DERIVATION")
        if child_element is None:
            return None
        derivation = EcucDerivationSpecification()
        calc_formula = self.find(child_element, "CALCULATION-FORMULA")
        if calc_formula is not None:
            derivation.setCalculationFormula(self.readEcucParameterDerivationFormula(calc_formula))
        for query_element in self.findall(child_element, "ECUC-QUERYS/ECUC-QUERY"):
            query = derivation.createEcucQuery(self.getShortName(query_element))
            self.readEcucQuery(query_element, query)
        derivation.setInformalFormula(self.getMlFormula(child_element, "INFORMAL-FORMULA"))
        return derivation

    def readEcucParameterDerivationFormula(self, element: ET.Element) -> EcucParameterDerivationFormula:
        formula = EcucParameterDerivationFormula()
        formula.setEcucQueryRef(self.getChildElementOptionalRefType(element, "ECUC-QUERY-REF"))
        formula.setEcucQueryStringRef(self.getChildElementOptionalRefType(element, "ECUC-QUERY-STRING-REF"))
        return formula

    def readEcucConditionFormula(self, element: ET.Element) -> EcucConditionFormula:
        formula = EcucConditionFormula()
        formula.setEcucQueryRef(self.getChildElementOptionalRefType(element, "ECUC-QUERY-REF"))
        formula.setEcucQueryStringRef(self.getChildElementOptionalRefType(element, "ECUC-QUERY-STRING-REF"))
        return formula

    def readEcucConditionSpecification(self, element: ET.Element) -> Optional[EcucConditionSpecification]:
        child_element = self.find(element, "ECUC-COND")
        if child_element is None:
            return None
        cond = EcucConditionSpecification()
        formula_element = self.find(child_element, "CONDITION-FORMULA")
        if formula_element is not None:
            cond.setConditionFormula(self.readEcucConditionFormula(formula_element))
        for query_element in self.findall(child_element, "ECUC-QUERYS/ECUC-QUERY"):
            query = cond.createEcucQuery(self.getShortName(query_element))
            self.readEcucQuery(query_element, query)
        cond.setInformalFormula(self.getMlFormula(child_element, "INFORMAL-FORMULA"))
        return cond

    def readEcucValidationCondition(self, element: ET.Element) -> EcucValidationCondition:
        vc = EcucValidationCondition(None, self.getShortName(element))
        self.readIdentifiable(element, vc)
        for query_element in self.findall(element, "ECUC-QUERYS/ECUC-QUERY"):
            query = vc.createEcucQuery(self.getShortName(query_element))
            self.readEcucQuery(query_element, query)
        formula_element = self.find(element, "VALIDATION-FORMULA")
        if formula_element is not None:
            vc.setValidationFormula(self.readEcucConditionFormula(formula_element))
        return vc

    def readEcucValidationConditions(self, element: ET.Element, def_element: EcucDefinitionElement):
        for vc_element in self.findall(element, "ECUC-VALIDATION-CONDS/ECUC-VALIDATION-CONDITION"):
            vc = self.readEcucValidationCondition(vc_element)
            def_element.addEcucValidationCond(vc)

    def readEcucQuery(self, element: ET.Element, query: EcucQuery):
        self.readIdentifiable(element, query)
        expr_element = self.find(element, "ECUC-QUERY-EXPRESSION")
        if expr_element is not None:
            expr = EcucQueryExpression()
            expr.setConfigElementDefGlobalRef(self.getChildElementOptionalRefType(expr_element, "CONFIG-ELEMENT-DEF-GLOBAL-REF"))
            expr.setConfigElementDefLocalRef(self.getChildElementOptionalRefType(expr_element, "CONFIG-ELEMENT-DEF-LOCAL-REF"))
            query.setEcucQueryExpression(expr)

    def readEcucAddInfoParamDef(self, element: ET.Element, param_def: EcucAddInfoParamDef):
        self.readEcucParameterDef(element, param_def)

    def readEcucBooleanParamDef(self, element: ET.Element, param_def: EcucBooleanParamDef):
        self.readEcucParameterDef(element, param_def)
        param_def.setDefaultValue(self.getChildElementOptionalBooleanValue(element, "DEFAULT-VALUE"))

    def readEcucAbstractStringParamDef(self, element: ET.Element, param_def: EcucAbstractStringParamDef):
        self.readEcucParameterDef(element, param_def)
        param_def.setDefaultValue(self.getChildElementOptionalLiteral(element, "DEFAULT-VALUE"))
        param_def.setMaxLength(self.getChildElementOptionalIntegerValue(element, "MAX-LENGTH"))
        param_def.setMinLength(self.getChildElementOptionalIntegerValue(element, "MIN-LENGTH"))
        param_def.setRegularExpression(self.getChildElementOptionalLiteral(element, "REGULAR-EXPRESSION"))

    def readEcucStringParamDef(self, element: ET.Element, param_def: EcucStringParamDef):
        self.readEcucParameterDef(element, param_def)
        child_element = self.find(element, "ECUC-STRING-PARAM-DEF-VARIANTS/ECUC-STRING-PARAM-DEF-CONDITIONAL")
        if child_element is not None:
            param_def.setDefaultValue(self.getChildElementOptionalLiteral(child_element, "DEFAULT-VALUE"))
            param_def.setMinLength(self.getChildElementOptionalIntegerValue(child_element, "MIN-LENGTH"))
            param_def.setMaxLength(self.getChildElementOptionalIntegerValue(child_element, "MAX-LENGTH"))
            param_def.setRegularExpression(self.getChildElementOptionalLiteral(child_element, "REGULAR-EXPRESSION"))

    def readEcucMultilineStringParamDef(self, element: ET.Element, param_def: EcucMultilineStringParamDef):
        self.readEcucParameterDef(element, param_def)
        child_element = self.find(element, "ECUC-MULTILINE-STRING-PARAM-DEF-VARIANTS/ECUC-MULTILINE-STRING-PARAM-DEF-CONDITIONAL")
        if child_element is not None:
            param_def.setDefaultValue(self.getChildElementOptionalLiteral(child_element, "DEFAULT-VALUE"))
            param_def.setMinLength(self.getChildElementOptionalIntegerValue(child_element, "MIN-LENGTH"))
            param_def.setMaxLength(self.getChildElementOptionalIntegerValue(child_element, "MAX-LENGTH"))
            param_def.setRegularExpression(self.getChildElementOptionalLiteral(child_element, "REGULAR-EXPRESSION"))

    def readEcucLinkerSymbolDef(self, element: ET.Element, param_def: EcucLinkerSymbolDef):
        self.readEcucParameterDef(element, param_def)
        child_element = self.find(element, "ECUC-LINKER-SYMBOL-DEF-VARIANTS/ECUC-LINKER-SYMBOL-DEF-CONDITIONAL")
        if child_element is not None:
            param_def.setDefaultValue(self.getChildElementOptionalLiteral(child_element, "DEFAULT-VALUE"))
            param_def.setMinLength(self.getChildElementOptionalIntegerValue(child_element, "MIN-LENGTH"))
            param_def.setMaxLength(self.getChildElementOptionalIntegerValue(child_element, "MAX-LENGTH"))
            param_def.setRegularExpression(self.getChildElementOptionalLiteral(child_element, "REGULAR-EXPRESSION"))

    def readEcucIntegerParamDef(self, element: ET.Element, param_def: EcucIntegerParamDef):
        self.readEcucParameterDef(element, param_def)
        param_def.setDefaultValue(self.getChildElementOptionalIntegerValue(element, "DEFAULT-VALUE"))
        param_def.setMax(self.getChildElementOptionalIntegerValue(element, "MAX"))
        param_def.setMin(self.getChildElementOptionalIntegerValue(element, "MIN"))

    def readEcucFloatParamDef(self, element: ET.Element, param_def: EcucFloatParamDef):
        self.readEcucParameterDef(element, param_def)
        param_def.setDefaultValue(self.getChildElementOptionalFloatValue(element, "DEFAULT-VALUE"))
        param_def.setMax(self.getChildLimitElement(element, "MAX"))
        param_def.setMin(self.getChildLimitElement(element, "MIN"))

    def readEcucEnumerationLiteral(self, element: ET.Element, literal: EcucEnumerationLiteralDef):
        self.readIdentifiable(element, literal)
        literal.setEcucCond(self.readEcucConditionSpecification(element))
        literal.setOrigin(self.getChildElementOptionalLiteral(element, "ORIGIN"))

    def readEcucEnumerationParamDefLiterals(self, element: ET.Element, literal_def: EcucEnumerationParamDef):
        for child_element in self.findall(element, "LITERALS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-ENUMERATION-LITERAL-DEF":
                literal = literal_def.createLiteral(self.getShortName(child_element))
                self.readEcucEnumerationLiteral(child_element, literal)
            else:
                self.notImplemented("Unsupported EnumerationLiteral <%s>" % tag_name)

    def readEcucEnumerationParamDef(self, element: ET.Element, param_def: EcucEnumerationParamDef):
        self.readEcucParameterDef(element, param_def)
        param_def.setDefaultValue(self.getChildElementOptionalLiteral(element, "DEFAULT-VALUE"))
        self.readEcucEnumerationParamDefLiterals(element, param_def)

    def readEcucFunctionNameDef(self, element: ET.Element, ref_def: EcucFunctionNameDef):
        self.readEcucParameterDef(element, ref_def)
        child_element = self.find(element, "ECUC-FUNCTION-NAME-DEF-VARIANTS/ECUC-FUNCTION-NAME-DEF-CONDITIONAL")
        if child_element is not None:
            ref_def.setDefaultValue(self.getChildElementOptionalLiteral(child_element, "DEFAULT-VALUE"))
            ref_def.setMinLength(self.getChildElementOptionalIntegerValue(child_element, "MIN-LENGTH"))
            ref_def.setMaxLength(self.getChildElementOptionalIntegerValue(child_element, "MAX-LENGTH"))
            ref_def.setRegularExpression(self.getChildElementOptionalLiteral(child_element, "REGULAR-EXPRESSION"))

    def readEcucContainerDefParameters(self, element: ET.Element, container_def: EcucParamConfContainerDef):
        for child_element in self.findall(element, "PARAMETERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-BOOLEAN-PARAM-DEF":
                param_def = container_def.createEcucBooleanParamDef(self.getShortName(child_element))
                self.readEcucBooleanParamDef(child_element, param_def)
            elif tag_name == "ECUC-ADD-INFO-PARAM-DEF":
                param_def = container_def.createEcucAddInfoParamDef(self.getShortName(child_element))
                self.readEcucAddInfoParamDef(child_element, param_def)
            elif tag_name == "ECUC-STRING-PARAM-DEF":
                param_def = container_def.createEcucStringParamDef(self.getShortName(child_element))
                self.readEcucStringParamDef(child_element, param_def)
            elif tag_name == "ECUC-INTEGER-PARAM-DEF":
                param_def = container_def.createEcucIntegerParamDef(self.getShortName(child_element))
                self.readEcucIntegerParamDef(child_element, param_def)
            elif tag_name == "ECUC-FLOAT-PARAM-DEF":
                param_def = container_def.createEcucFloatParamDef(self.getShortName(child_element))
                self.readEcucFloatParamDef(child_element, param_def)
            elif tag_name == "ECUC-ENUMERATION-PARAM-DEF":
                param_def = container_def.createEcucEnumerationParamDef(self.getShortName(child_element))
                self.readEcucEnumerationParamDef(child_element, param_def)
            elif tag_name == "ECUC-FUNCTION-NAME-DEF":
                param_def = container_def.createEcucFunctionNameDef(self.getShortName(child_element))
                self.readEcucFunctionNameDef(child_element, param_def)
            elif tag_name == "ECUC-MULTILINE-STRING-PARAM-DEF":
                param_def = container_def.createEcucMultilineStringParamDef(self.getShortName(child_element))
                self.readEcucMultilineStringParamDef(child_element, param_def)
            elif tag_name == "ECUC-LINKER-SYMBOL-DEF":
                param_def = container_def.createEcucLinkerSymbolDef(self.getShortName(child_element))
                self.readEcucLinkerSymbolDef(child_element, param_def)
            else:
                self.notImplemented("Unsupported Parameter <%s>" % tag_name)

    def readEcucAbstractReferenceDef(self, element: ET.Element, ref_def: EcucAbstractReferenceDef):
        self.readEcucCommonAttributes(element, ref_def)
        ref_def.setWithAuto(self.getChildElementOptionalBooleanValue(element, "WITH-AUTO"))

    def readEcucAbstractInternalReferenceDef(self, element: ET.Element, ref_def: EcucAbstractInternalReferenceDef):
        self.readEcucAbstractReferenceDef(element, ref_def)
        ref_def.setRequiresSymbolicNameValue(self.getChildElementOptionalBooleanValue(element, "REQUIRES-SYMBOLIC-NAME-VALUE"))

    def readEcucAbstractExternalReferenceDef(self, element: ET.Element, ref_def: EcucAbstractExternalReferenceDef):
        self.readEcucAbstractReferenceDef(element, ref_def)

    def readEcucSymbolicNameReferenceDef(self, element: ET.Element, ref_def: EcucSymbolicNameReferenceDef):
        self.readEcucAbstractInternalReferenceDef(element, ref_def)
        ref_def.setDestinationRef(self.getChildElementOptionalRefType(element, "DESTINATION-REF"))

    def readEcucReferenceDef(self, element: ET.Element, ref_def: EcucReferenceDef):
        self.readEcucAbstractInternalReferenceDef(element, ref_def)
        ref_def.setDestinationRef(self.getChildElementOptionalRefType(element, "DESTINATION-REF"))

    def readEcucChoiceReferenceDef(self, element: ET.Element, ref_def: EcucChoiceReferenceDef):
        self.readEcucAbstractInternalReferenceDef(element, ref_def)
        for ref in self.getChildElementRefTypeList(element, "DESTINATION-REFS/DESTINATION-REF"):
            ref_def.addDestinationRef(ref)

    def readEcucInstanceReferenceDef(self, element: ET.Element, ref_def: EcucInstanceReferenceDef):
        self.readEcucAbstractExternalReferenceDef(element, ref_def)
        ref_def.setDestinationContext(self.getChildElementOptionalLiteral(element, "DESTINATION-CONTEXT"))
        ref_def.setDestinationType(self.getChildElementOptionalLiteral(element, "DESTINATION-TYPE"))

    def readEcucForeignReferenceDef(self, element: ET.Element, ref_def: EcucForeignReferenceDef):
        self.readEcucAbstractExternalReferenceDef(element, ref_def)
        ref_def.setDestinationType(self.getChildElementOptionalLiteral(element, "DESTINATION-TYPE"))

    def readEcucContainerDefReferences(self, element: ET.Element, container_def: EcucParamConfContainerDef):
        for child_element in self.findall(element, "REFERENCES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-SYMBOLIC-NAME-REFERENCE-DEF":
                ref_def = container_def.createEcucSymbolicNameReferenceDef(self.getShortName(child_element))
                self.readEcucSymbolicNameReferenceDef(child_element, ref_def)
            elif tag_name == "ECUC-REFERENCE-DEF":
                ref_def = container_def.createEcucReferenceDef(self.getShortName(child_element))
                self.readEcucReferenceDef(child_element, ref_def)
            elif tag_name == "ECUC-CHOICE-REFERENCE-DEF":
                ref_def = container_def.createEcucChoiceReferenceDef(self.getShortName(child_element))
                self.readEcucChoiceReferenceDef(child_element, ref_def)
            elif tag_name == "ECUC-INSTANCE-REFERENCE-DEF":
                ref_def = container_def.createEcucInstanceReferenceDef(self.getShortName(child_element))
                self.readEcucInstanceReferenceDef(child_element, ref_def)
            elif tag_name == "ECUC-FOREIGN-REFERENCE-DEF":
                ref_def = container_def.createEcucForeignReferenceDef(self.getShortName(child_element))
                self.readEcucForeignReferenceDef(child_element, ref_def)
            else:
                self.notImplemented("Unsupported EcucReferenceDef <%s>" % tag_name)

    def readEcucContainerDefSubContainers(self, element: ET.Element, container_def: EcucParamConfContainerDef):
        for child_element in self.findall(element, "SUB-CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-PARAM-CONF-CONTAINER-DEF":
                sub_container_def = container_def.createEcucParamConfContainerDef(self.getShortName(child_element))
                self.readEcucParamConfContainerDef(child_element, sub_container_def)
            elif tag_name == "ECUC-CHOICE-CONTAINER-DEF":
                sub_container_def = container_def.createEcucChoiceContainerDef(self.getShortName(child_element))
                self.readEcucChoiceContainerDef(child_element, sub_container_def)
            else:
                self.notImplemented("Unsupported SubContainer <%s>" % tag_name)

    def readEcucParamConfContainerDef(self, element: ET.Element, container_def: EcucParamConfContainerDef):
        self.readEcucContainerDef(element, container_def)
        self.readEcucContainerDefParameters(element, container_def)
        self.readEcucContainerDefReferences(element, container_def)
        self.readEcucContainerDefSubContainers(element, container_def)

    def readEcucChoiceContainerDefChoices(self, element: ET.Element, container_def: EcucChoiceContainerDef):
        for child_element in self.findall(element, "CHOICES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-PARAM-CONF-CONTAINER-DEF":
                ref_def = container_def.createEcucParamConfContainerDef(self.getShortName(child_element))
                self.readEcucParamConfContainerDef(child_element, ref_def)
            else:
                self.notImplemented("Unsupported Choice <%s>" % tag_name)

    def readEcucChoiceContainerDef(self, element: ET.Element, container_def: EcucChoiceContainerDef):
        self.readEcucContainerDef(element, container_def)
        self.readEcucChoiceContainerDefChoices(element, container_def)

    def readEcucModuleDefContainers(self, element: ET.Element, module_def: EcucModuleDef):
        for child_element in self.findall(element, "CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-PARAM-CONF-CONTAINER-DEF":
                container_def = module_def.createEcucParamConfContainerDef(self.getShortName(child_element))
                self.readEcucParamConfContainerDef(child_element, container_def)
            elif tag_name == "ECUC-CHOICE-CONTAINER-DEF":
                container_def = module_def.createEcucChoiceContainerDef(self.getShortName(child_element))
                self.readEcucChoiceContainerDef(child_element, container_def)
            else:
                self.notImplemented("Unsupported Container <%s>" % tag_name)

    def readEcucModuleDef(self, element: ET.Element, module_def: EcucModuleDef):
        self.logger.debug("Read EcucModuleDef <%s>" % module_def.getShortName())
        self.readEcucDefinitionElement(element, module_def)
        module_def.setApiServicePrefix(self.getChildElementOptionalLiteral(element, "API-SERVICE-PREFIX"))
        module_def.setPostBuildVariantSupport(self.getChildElementOptionalBooleanValue(element, "POST-BUILD-VARIANT-SUPPORT"))
        module_def.setRefinedModuleDefRef(self.getChildElementOptionalRefType(element, "REFINED-MODULE-DEF-REF"))
        self.readEcucModuleDefSupportedConfigVariants(element, module_def)
        self.readEcucModuleDefContainers(element, module_def)

    def readEcucDefinitionCollection(self, element: ET.Element, collection: EcucDefinitionCollection):
        self.logger.debug("Read EcucDefinitionCollection <%s>" % collection.getShortName())
        self.readARElement(element, collection)
        module_refs = self.getChildElementRefTypeList(element, "MODULE-REFS/MODULE-REF")
        for module_ref in module_refs:
            collection.addModuleRef(module_ref)

    def readSwSystemconst(self, element: ET.Element, system_const: SwSystemconst):
        self.logger.debug("Read SwSystemconst <%s>" % system_const.getShortName())
        self.readIdentifiable(element, system_const)
        system_const.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))

    def readSwSystemconstValue(self, element: ET.Element, value: SwSystemconstValue):
        value.setSwSystemconstRef(self.getChildElementOptionalRefType(element, "SW-SYSTEMCONST-REF"))
        value.setValue(self.getChildElementOptionalNumerical(element, "VALUE"))
        for annotation in self.getAnnotations(element):
            value.addAnnotation(annotation)

    def readSwSystemconstantValueSetSwSystemconstantValues(self, element: ET.Element, value_set: SwSystemconstantValueSet):
        for child_element in self.findall(element, "SW-SYSTEMCONSTANT-VALUES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SW-SYSTEMCONST-VALUE":
                value = SwSystemconstValue()
                self.readSwSystemconstValue(child_element, value)
                value_set.addSwSystemconstantValue(value)
            else:
                self.notImplemented("Unsupported SwSystemconstValue <%s>" % tag_name)

    def readSwSystemconstantValueSet(self, element: ET.Element, value_set: SwSystemconstantValueSet):
        self.logger.debug("Read SwSystemconstantValueSet <%s>" % value_set.getShortName())
        self.readIdentifiable(element, value_set)
        self.readSwSystemconstantValueSetSwSystemconstantValues(element, value_set)

    def readPredefinedVariantIncludedVariantRefs(self, element: ET.Element, variant: PredefinedVariant):
        for ref in self.getChildElementRefTypeList(
            element,
            "INCLUDED-VARIANT-REFS/INCLUDED-VARIANT-REF",
        ):
            variant.addIncludedVariantRef(ref)

    def readPredefinedVariantPostBuildVariantCriterionValueSetRefs(self, element: ET.Element, variant: PredefinedVariant):
        for ref in self.getChildElementRefTypeList(
            element,
            "POST-BUILD-VARIANT-CRITERION-VALUE-SET-REFS/" "POST-BUILD-VARIANT-CRITERION-VALUE-SET-REF",
        ):
            variant.addPostBuildVariantCriterionValueSetRef(ref)

    def readPredefinedVariantSwSystemconstantValueSetRefs(self, element: ET.Element, variant: PredefinedVariant):
        for ref in self.getChildElementRefTypeList(
            element,
            "SW-SYSTEMCONSTANT-VALUE-SET-REFS/" "SW-SYSTEMCONSTANT-VALUE-SET-REF",
        ):
            variant.addSwSystemconstantValueSetRef(ref)

    def readPredefinedVariant(self, element: ET.Element, variant: PredefinedVariant):
        self.logger.debug("Read PredefinedVariant <%s>" % variant.getShortName())
        self.readIdentifiable(element, variant)
        self.readPredefinedVariantIncludedVariantRefs(element, variant)
        self.readPredefinedVariantPostBuildVariantCriterionValueSetRefs(element, variant)
        self.readPredefinedVariantSwSystemconstantValueSetRefs(element, variant)

    def readAbstractVariationRestriction(self, element: ET.Element, restriction: AbstractVariationRestriction):
        restriction.setVariation(self.getChildElementOptionalBooleanValue(element, "VARIATION"))
        times_element = self.find(element, "VALID-BINDING-TIMES")
        if times_element is not None:
            for child_element in self.findall(times_element, "VALID-BINDING-TIME"):
                time = FullBindingTimeEnum()
                time.setValue(child_element.text)
                restriction.addValidBindingTime(time)

    def readAbstractValueRestriction(self, element: ET.Element, restriction: AbstractValueRestriction):
        restriction.setMax(self.getChildLimitElement(element, "MAX"))
        restriction.setMaxLength(self.getChildElementOptionalPositiveInteger(element, "MAX-LENGTH"))
        restriction.setMin(self.getChildLimitElement(element, "MIN"))
        restriction.setMinLength(self.getChildElementOptionalPositiveInteger(element, "MIN-LENGTH"))
        restriction.setPattern(self.getChildElementOptionalRegularExpression(element, "PATTERN"))

    def readSdgDef(self, element: ET.Element, sdg_def: SdgDef):
        self.logger.debug("Read SdgDef <%s>" % sdg_def.getShortName())
        self.readIdentifiable(element, sdg_def)
        self.readSdgDefSdgClasses(element, sdg_def)

    def readSdgDefSdgClasses(self, element: ET.Element, sdg_def: SdgDef):
        classes_element = self.find(element, "SDG-CLASSES")
        if classes_element is not None:
            for child_element in classes_element:
                tag_name = self.getTagName(child_element)
                if tag_name == "SDG-CLASS":
                    sdg_class = SdgClass(sdg_def, self.getShortName(child_element))
                    self.readSdgClass(child_element, sdg_class)
                    sdg_def.addSdgClass(sdg_class)

    def readSdgClass(self, element: ET.Element, sdg_class: SdgClass):
        self.logger.debug("Read SdgClass <%s>" % sdg_class.getShortName())
        self.readIdentifiable(element, sdg_class)
        sdg_class.setGid(self.getChildElementOptionalNameToken(element, "GID"))
        sdg_class.setExtendsMetaClass(self.getChildElementOptionalStringValue(element, "EXTENDS-META-CLASS"))
        sdg_class.setCaption(self.getChildElementOptionalBooleanValue(element, "CAPTION"))
        self.readSdgClassAttributes(element, sdg_class)
        self.readSdgClassSdgConstraintRefs(element, sdg_class)

    def readSdgClassAttributes(self, element: ET.Element, sdg_class: SdgClass):
        attributes_element = self.find(element, "ATTRIBUTES")
        if attributes_element is not None:
            for child_element in attributes_element:
                tag_name = self.getTagName(child_element)
                short_name = self.getShortName(child_element)
                if tag_name == "SDG-AGGREGATION-WITH-VARIATION":
                    attribute = SdgAggregationWithVariation(sdg_class, short_name)
                    self.readSdgAggregationWithVariation(child_element, attribute)
                elif tag_name == "SDG-FOREIGN-REFERENCE-WITH-VARIATION":
                    attribute = SdgForeignReferenceWithVariation(sdg_class, short_name)
                    self.readSdgForeignReferenceWithVariation(child_element, attribute)
                elif tag_name == "SDG-FOREIGN-REFERENCE":
                    attribute = SdgForeignReference(sdg_class, short_name)
                    self.readSdgForeignReference(child_element, attribute)
                elif tag_name == "SDG-PRIMITIVE-ATTRIBUTE-WITH-VARIATION":
                    attribute = SdgPrimitiveAttributeWithVariation(sdg_class, short_name)
                    self.readSdgPrimitiveAttributeWithVariation(child_element, attribute)
                elif tag_name == "SDG-PRIMITIVE-ATTRIBUTE":
                    attribute = SdgPrimitiveAttribute(sdg_class, short_name)
                    self.readSdgPrimitiveAttribute(child_element, attribute)
                elif tag_name == "SDG-REFERENCE":
                    attribute = SdgReference(sdg_class, short_name)
                    self.readSdgReference(child_element, attribute)
                else:
                    continue
                sdg_class.addAttribute(attribute)

    def readSdgClassSdgConstraintRefs(self, element: ET.Element, sdg_class: SdgClass):
        for ref in self.getChildElementRefTypeList(
            element,
            "SDG-CONSTRAINT-REFS/" "SDG-CONSTRAINT-REF",
        ):
            sdg_class.addSdgConstraintRef(ref)

    def readSdgPrimitiveAttribute(self, element: ET.Element, attribute: SdgPrimitiveAttribute):
        self.readIdentifiable(element, attribute)
        attribute.setGid(self.getChildElementOptionalNameToken(element, "GID"))
        self.readAbstractValueRestriction(element, attribute)

    def readSdgPrimitiveAttributeWithVariation(self, element: ET.Element, attribute: SdgPrimitiveAttributeWithVariation):
        self.readIdentifiable(element, attribute)
        attribute.setGid(self.getChildElementOptionalNameToken(element, "GID"))
        self.readAbstractValueRestriction(element, attribute)
        self.readAbstractVariationRestriction(element, attribute)

    def readSdgAggregationWithVariation(self, element: ET.Element, attribute: SdgAggregationWithVariation):
        self.readIdentifiable(element, attribute)
        attribute.setGid(self.getChildElementOptionalNameToken(element, "GID"))
        self.readAbstractVariationRestriction(element, attribute)
        attribute.setSubSdgRef(self.getChildElementOptionalRefType(element, "SUB-SDG-REF"))

    def readSdgReference(self, element: ET.Element, attribute: SdgReference):
        self.readIdentifiable(element, attribute)
        attribute.setDestSdgRef(self.getChildElementOptionalRefType(element, "DEST-SDG-REF"))

    def readSdgForeignReference(self, element: ET.Element, attribute: SdgForeignReference):
        self.readIdentifiable(element, attribute)
        attribute.setGid(self.getChildElementOptionalNameToken(element, "GID"))
        attribute.setDestMetaClass(self.getChildElementOptionalStringValue(element, "DEST-META-CLASS"))

    def readSdgForeignReferenceWithVariation(self, element: ET.Element, attribute: SdgForeignReferenceWithVariation):
        self.readIdentifiable(element, attribute)
        attribute.setGid(self.getChildElementOptionalNameToken(element, "GID"))
        attribute.setDestMetaClass(self.getChildElementOptionalStringValue(element, "DEST-META-CLASS"))
        self.readAbstractVariationRestriction(element, attribute)

    def readEvaluatedVariantSetApprovalStatus(self, element: ET.Element, variant_set: EvaluatedVariantSet):
        variant_set.setApprovalStatus(self.getChildElementOptionalNameToken(element, "APPROVAL-STATUS"))

    def readEvaluatedVariantSetEvaluatedElementRefs(self, element: ET.Element, variant_set: EvaluatedVariantSet):
        for ref in self.getChildElementRefTypeList(
            element,
            "EVALUATED-ELEMENT-REFS/" "EVALUATED-ELEMENT-REF",
        ):
            variant_set.addEvaluatedElementRef(ref)

    def readEvaluatedVariantSetEvaluatedVariantRefs(self, element: ET.Element, variant_set: EvaluatedVariantSet):
        for ref in self.getChildElementRefTypeList(
            element,
            "EVALUATED-VARIANT-REFS/" "EVALUATED-VARIANT-REF",
        ):
            variant_set.addEvaluatedVariantRef(ref)

    def readEvaluatedVariantSet(self, element: ET.Element, variant_set: EvaluatedVariantSet):
        self.logger.debug("Read EvaluatedVariantSet <%s>" % variant_set.getShortName())
        self.readIdentifiable(element, variant_set)
        self.readEvaluatedVariantSetApprovalStatus(element, variant_set)
        self.readEvaluatedVariantSetEvaluatedElementRefs(element, variant_set)
        self.readEvaluatedVariantSetEvaluatedVariantRefs(element, variant_set)

    def readPostBuildVariantCriterion(self, element: ET.Element, criterion: PostBuildVariantCriterion):
        self.logger.debug("Read PostBuildVariantCriterion <%s>" % criterion.getShortName())
        self.readIdentifiable(element, criterion)
        criterion.setCompuMethodRef(self.getChildElementOptionalRefType(element, "COMPU-METHOD-REF"))

    def readCommunicationController(self, element: ET.Element, controller: CommunicationController):
        controller.setWakeUpByControllerSupported(self.getChildElementOptionalBooleanValue(element, "WAKE-UP-BY-CONTROLLER-SUPPORTED"))

    def getCanControllerFdConfiguration(self, element: ET.Element, key: str) -> CanControllerFdConfiguration:
        configuration = None
        child_element = self.find(element, key)
        if child_element is not None:
            configuration = CanControllerFdConfiguration()
            configuration.setPaddingValue(self.getChildElementOptionalIntegerValue(child_element, "PADDING-VALUE"))
            configuration.setPropSeg(self.getChildElementOptionalIntegerValue(child_element, "PROP-SEG"))
            configuration.setSspOffset(self.getChildElementOptionalIntegerValue(child_element, "SSP-OFFSET"))
            configuration.setSyncJumpWidth(self.getChildElementOptionalIntegerValue(child_element, "SYNC-JUMP-WIDTH"))
            configuration.setTimeSeg1(self.getChildElementOptionalIntegerValue(child_element, "TIME-SEG1"))
            configuration.setTimeSeg2(self.getChildElementOptionalIntegerValue(child_element, "TIME-SEG2"))
            configuration.setTxBitRateSwitch(self.getChildElementOptionalBooleanValue(child_element, "TX-BIT-RATE-SWITCH"))
        return configuration

    def getFlexrayFifoRange(self, element: ET.Element, key: str) -> FlexrayFifoRange:
        fifo_range = None
        child_element = self.find(element, key)
        if child_element is not None:
            fifo_range = FlexrayFifoRange()
            fifo_range.setRangeMax(self.getChildElementOptionalIntegerValue(child_element, "RANGE-MAX"))
            fifo_range.setRangeMin(self.getChildElementOptionalIntegerValue(child_element, "RANGE-MIN"))
        return fifo_range

    def getFlexrayFifoConfiguration(self, element: ET.Element, key: str) -> FlexrayFifoConfiguration:
        configuration = None
        child_element = self.find(element, key)
        if child_element is not None:
            configuration = FlexrayFifoConfiguration()
            configuration.setAdmitWithoutMessageId(self.getChildElementOptionalBooleanValue(child_element, "ADMIT-WITHOUT-MESSAGE-ID"))
            configuration.setBaseCycle(self.getChildElementOptionalIntegerValue(child_element, "BASE-CYCLE"))
            configuration.setChannelRef(self.getChildElementOptionalRefType(child_element, "CHANNEL-REF"))
            configuration.setCycleRepetition(self.getChildElementOptionalIntegerValue(child_element, "CYCLE-REPETITION"))
            configuration.setFifoDepth(self.getChildElementOptionalIntegerValue(child_element, "FIFO-DEPTH"))
            for range_child in self.findall(child_element, "FLEXRAY-FIFO-RANGE"):
                fifo_range = configuration.createFlexrayFifoRange()
                fifo_range.setRangeMax(self.getChildElementOptionalIntegerValue(range_child, "RANGE-MAX"))
                fifo_range.setRangeMin(self.getChildElementOptionalIntegerValue(range_child, "RANGE-MIN"))
            configuration.setMsgIdMask(self.getChildElementOptionalIntegerValue(child_element, "MSG-ID-MASK"))
            configuration.setMsgIdMatch(self.getChildElementOptionalIntegerValue(child_element, "MSG-ID-MATCH"))
        return configuration

    def getCanControllerFdConfigurationRequirements(self, element: ET.Element, key: str) -> CanControllerFdConfigurationRequirements:
        requirements = None
        child_element = self.find(element, key)
        if child_element is not None:
            requirements = CanControllerFdConfigurationRequirements()
            requirements.setMaxNumberOfTimeQuantaPerBit(self.getChildElementOptionalIntegerValue(child_element, "MAX-NUMBER-OF-TIME-QUANTA-PER-BIT"))
            requirements.setMaxSamplePoint(self.getChildElementOptionalFloatValue(child_element, "MAX-SAMPLE-POINT"))
            requirements.setMaxSyncJumpWidth(self.getChildElementOptionalFloatValue(child_element, "MAX-SYNC-JUMP-WIDTH"))
            requirements.setMaxTrcvDelayCompensationOffset(self.getChildElementOptionalTimeValue(child_element, "MAX-TRCV-DELAY-COMPENSATION-OFFSET"))
            requirements.setMinNumberOfTimeQuantaPerBit(self.getChildElementOptionalIntegerValue(child_element, "MIN-NUMBER-OF-TIME-QUANTA-PER-BIT"))
            requirements.setMinSamplePoint(self.getChildElementOptionalFloatValue(child_element, "MIN-SAMPLE-POINT"))
            requirements.setMinSyncJumpWidth(self.getChildElementOptionalFloatValue(child_element, "MIN-SYNC-JUMP-WIDTH"))
            requirements.setMinTrcvDelayCompensationOffset(self.getChildElementOptionalTimeValue(child_element, "MIN-TRCV-DELAY-COMPENSATION-OFFSET"))
            requirements.setPaddingValue(self.getChildElementOptionalPositiveInteger(child_element, "PADDING-VALUE"))
            requirements.setTxBitRateSwitch(self.getChildElementOptionalBooleanValue(child_element, "TX-BIT-RATE-SWITCH"))  # NOQA E501
        return requirements

    def getCanControllerXlConfiguration(self, element: ET.Element, key: str) -> CanControllerXlConfiguration:
        configuration = None
        child_element = self.find(element, key)
        if child_element is not None:
            configuration = CanControllerXlConfiguration()
            configuration.setErrorSignalingEnabled(self.getChildElementOptionalBooleanValue(child_element, "ERROR-SIGNALING-ENABLED"))
            configuration.setPropSeg(self.getChildElementOptionalIntegerValue(child_element, "PROP-SEG"))
            configuration.setPwmL(self.getChildElementOptionalIntegerValue(child_element, "PWM-L"))
            configuration.setPwmO(self.getChildElementOptionalIntegerValue(child_element, "PWM-O"))
            configuration.setPwmS(self.getChildElementOptionalIntegerValue(child_element, "PWM-S"))
            configuration.setSspOffset(self.getChildElementOptionalIntegerValue(child_element, "SSP-OFFSET"))
            configuration.setSyncJumpWidth(self.getChildElementOptionalIntegerValue(child_element, "SYNC-JUMP-WIDTH"))
            configuration.setTimeSeg1(self.getChildElementOptionalIntegerValue(child_element, "TIME-SEG1"))
            configuration.setTimeSeg2(self.getChildElementOptionalIntegerValue(child_element, "TIME-SEG2"))
            configuration.setTrcvPwmModeEnabled(self.getChildElementOptionalBooleanValue(child_element, "TRCV-PWM-MODE-ENABLED"))
        return configuration

    def getCanControllerConfiguration(self, element: ET.Element, key: str) -> CanControllerConfiguration:
        configuration = None
        child_element = self.find(element, key)
        if child_element is not None:
            configuration = CanControllerConfiguration()
            self.readCanControllerConfiguration(child_element, configuration)
        return configuration

    def readCanControllerConfiguration(self, element: ET.Element, configuration: CanControllerConfiguration):
        self.readAbstractCanCommunicationControllerAttributes(element, configuration)
        configuration.setPropSeg(self.getChildElementOptionalIntegerValue(element, "PROP-SEG"))
        configuration.setSyncJumpWidth(self.getChildElementOptionalIntegerValue(element, "SYNC-JUMP-WIDTH"))
        configuration.setTimeSeg1(self.getChildElementOptionalIntegerValue(element, "TIME-SEG-1"))
        configuration.setTimeSeg2(self.getChildElementOptionalIntegerValue(element, "TIME-SEG-2"))

    def getCanControllerXlConfigurationRequirements(self, element: ET.Element, key: str) -> CanControllerXlConfigurationRequirements:
        requirements = None
        child_element = self.find(element, key)
        if child_element is not None:
            requirements = CanControllerXlConfigurationRequirements()
            requirements.setErrorSignalingEnabled(self.getChildElementOptionalBooleanValue(child_element, "ERROR-SIGNALING-ENABLED"))
            requirements.setMaxNumberOfTimeQuantaPerBit(self.getChildElementOptionalIntegerValue(child_element, "MAX-NUMBER-OF-TIME-QUANTA-PER-BIT"))
            requirements.setMaxPwmL(self.getChildElementOptionalIntegerValue(child_element, "MAX-PWM-L"))
            requirements.setMaxPwmO(self.getChildElementOptionalIntegerValue(child_element, "MAX-PWM-O"))
            requirements.setMaxPwmS(self.getChildElementOptionalIntegerValue(child_element, "MAX-PWM-S"))
            requirements.setMaxSamplePoint(self.getChildElementOptionalFloatValue(child_element, "MAX-SAMPLE-POINT"))
            requirements.setMaxSyncJumpWidth(self.getChildElementOptionalFloatValue(child_element, "MAX-SYNC-JUMP-WIDTH"))
            requirements.setMaxTrcvDelayCompensationOffset(self.getChildElementOptionalTimeValue(child_element, "MAX-TRCV-DELAY-COMPENSATION-OFFSET"))
            requirements.setMinNumberOfTimeQuantaPerBit(self.getChildElementOptionalIntegerValue(child_element, "MIN-NUMBER-OF-TIME-QUANTA-PER-BIT"))
            requirements.setMinPwmL(self.getChildElementOptionalIntegerValue(child_element, "MIN-PWM-L"))
            requirements.setMinPwmO(self.getChildElementOptionalIntegerValue(child_element, "MIN-PWM-O"))
            requirements.setMinPwmS(self.getChildElementOptionalIntegerValue(child_element, "MIN-PWM-S"))
            requirements.setMinSamplePoint(self.getChildElementOptionalFloatValue(child_element, "MIN-SAMPLE-POINT"))
            requirements.setMinSyncJumpWidth(self.getChildElementOptionalFloatValue(child_element, "MIN-SYNC-JUMP-WIDTH"))
            requirements.setMinTrcvDelayCompensationOffset(self.getChildElementOptionalTimeValue(child_element, "MIN-TRCV-DELAY-COMPENSATION-OFFSET"))
            requirements.setTrcvPwmModeEnabled(self.getChildElementOptionalBooleanValue(child_element, "TRCV-PWM-MODE-ENABLED"))
        return requirements

    def readCanXlProps(self, element: ET.Element, can_xl_props: CanXlProps):
        self.readIdentifiable(element, can_xl_props)
        can_xl_props.setCanBaudrate(self.getChildElementOptionalPositiveInteger(element, "CAN-BAUDRATE"))
        can_xl_props.setCanConfig(self.getCanControllerConfiguration(element, "CAN-CONFIG"))
        can_xl_props.setCanFdBaudrate(self.getChildElementOptionalPositiveInteger(element, "CAN-FD-BAUDRATE"))
        can_xl_props.setCanFdConfig(self.getCanControllerFdConfiguration(element, "CAN-FD-CONFIG"))
        can_xl_props.setCanXlBaudrate(self.getChildElementOptionalPositiveInteger(element, "CAN-XL-BAUDRATE"))
        can_xl_props.setCanXlConfig(self.getCanControllerXlConfiguration(element, "CAN-XL-CONFIG"))
        can_xl_props.setCanXlConfigReqs(self.getCanControllerXlConfigurationRequirements(element, "CAN-XL-CONFIG-REQS"))

    def readAbstractCanCommunicationControllerAttributes(self, element: ET.Element, attributes: AbstractCanCommunicationControllerAttributes):
        attributes.setCanControllerFdAttributes(self.getCanControllerFdConfiguration(element, "CAN-CONTROLLER-FD-CONFIGURATION"))
        attributes.setCanControllerFdRequirements(self.getCanControllerFdConfigurationRequirements(element, "CAN-CONTROLLER-FD-REQUIREMENTS"))
        attributes.setCanControllerXlAttributes(self.getCanControllerXlConfiguration(element, "CAN-CONTROLLER-XL-CONFIGURATION"))
        attributes.setCanControllerXlRequirements(self.getCanControllerXlConfigurationRequirements(element, "CAN-CONTROLLER-XL-REQUIREMENTS"))

    def readCanControllerConfigurationRequirements(self, element: ET.Element, requirements: CanControllerConfigurationRequirements):
        self.readAbstractCanCommunicationControllerAttributes(element, requirements)
        requirements.setMaxNumberOfTimeQuantaPerBit(self.getChildElementOptionalIntegerValue(element, "MAX-NUMBER-OF-TIME-QUANTA-PER-BIT"))
        requirements.setMaxSamplePoint(self.getChildElementOptionalFloatValue(element, "MAX-SAMPLE-POINT"))
        requirements.setMaxSyncJumpWidth(self.getChildElementOptionalFloatValue(element, "MAX-SYNC-JUMP-WIDTH"))
        requirements.setMinNumberOfTimeQuantaPerBit(self.getChildElementOptionalIntegerValue(element, "MIN-NUMBER-OF-TIME-QUANTA-PER-BIT"))
        requirements.setMinSamplePoint(self.getChildElementOptionalFloatValue(element, "MIN-SAMPLE-POINT"))
        requirements.setMinSyncJumpWidth(self.getChildElementOptionalFloatValue(element, "MIN-SYNC-JUMP-WIDTH"))

    def readAbstractCanCommunicationControllerCanControllerAttributes(self, element: ET.Element, controller: AbstractCanCommunicationController):
        for child_element in self.findall(element, "CAN-CONTROLLER-ATTRIBUTES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-CONTROLLER-CONFIGURATION-REQUIREMENTS":
                requirements = CanControllerConfigurationRequirements()
                self.readCanControllerConfigurationRequirements(child_element, requirements)
                controller.setCanControllerAttributes(requirements)
            elif tag_name == "CAN-CONTROLLER-CONFIGURATION":
                configuration = CanControllerConfiguration()
                self.readCanControllerConfiguration(child_element, configuration)
                controller.setCanControllerAttributes(configuration)
            else:
                self.notImplemented("Unsupported CanControllerAttributes <%s>" % tag_name)

    def readAbstractCanCommunicationController(self, element: ET.Element, controller: AbstractCanCommunicationController):
        self.readCommunicationController(element, controller)
        self.readAbstractCanCommunicationControllerCanControllerAttributes(element, controller)

    def readCanCommunicationController(self, element: ET.Element, controller: CanCommunicationController):
        self.logger.debug("Read CanCommunicationController %s" % controller.getShortName())
        self.readIdentifiable(element, controller)
        child_element = self.find(element, "CAN-COMMUNICATION-CONTROLLER-VARIANTS/CAN-COMMUNICATION-CONTROLLER-CONDITIONAL")
        if child_element is not None:
            self.readAbstractCanCommunicationController(child_element, controller)

    def readCouplingPortSchedulerCouplingPortStructuralElement(self, element: ET.Element, item: CouplingPortStructuralElement):
        self.readIdentifiable(element, item)

    def readCouplingPortFifo(self, element: ET.Element, fifo: CouplingPortFifo):
        self.readCouplingPortSchedulerCouplingPortStructuralElement(element, fifo)
        for item in self.findall(element, "ASSIGNED-TRAFFIC-CLASSS/ASSIGNED-TRAFFIC-CLASS"):
            value = PositiveInteger()
            value.setValue(item.text)
            fifo.addAssignedTrafficClass(value)
        fifo.setMinimumFifoLength(self.getChildElementOptionalPositiveInteger(element, "MINIMUM-FIFO-LENGTH"))
        self.readCouplingPortFifoShaper(element, fifo)

    def readCouplingPortFifoShaper(self, element: ET.Element, fifo: CouplingPortFifo):
        shaper_element = self.find(element, "SHAPER")
        if shaper_element is not None:
            for child in shaper_element:
                tag = self.getTagName(child)
                shaper_cls = CouplingPortAbstractShaper.getShaperClass(tag)
                if shaper_cls is not None:
                    shaper = shaper_cls(fifo, self.getShortName(child))
                    self.readIdentifiable(child, shaper)
                    fifo.setShaper(shaper)
                else:
                    self.notImplemented("Unsupported CouplingPort shaper <%s>" % tag)

    def readCouplingPortScheduler(self, element: ET.Element, scheduler: CouplingPortScheduler):
        self.readCouplingPortSchedulerCouplingPortStructuralElement(element, scheduler)
        scheduler.setPortScheduler(self.getChildElementOptionalLiteral(element, "PORT-SCHEDULER"))
        for ref in self.getChildElementRefTypeList(element, "PREDECESSOR-REFS/PREDECESSOR-REF"):
            scheduler.addPredecessorRef(ref)

    def readCouplingPortDetailsCouplingPortStructuralElements(self, item: ET.Element, details: CouplingPortDetails):
        for child_element in self.findall(item, "COUPLING-PORT-STRUCTURAL-ELEMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "COUPLING-PORT-FIFO":
                item = details.createCouplingPortFifo(self.getShortName(child_element))
                self.readCouplingPortFifo(child_element, item)
            elif tag_name == "COUPLING-PORT-SCHEDULER":
                item = details.createCouplingPortScheduler(self.getShortName(child_element))
                self.readCouplingPortScheduler(child_element, item)
            else:
                self.notImplemented("Unsupported CouplingPortStructuralElement <%s>" % tag_name)

    def readEthernetPriorityRegeneration(self, element: ET.Element, regeneration: EthernetPriorityRegeneration):
        regeneration.setIngressPriority(self.getChildElementOptionalPositiveInteger(element, "INGRESS-PRIORITY"))
        regeneration.setRegeneratedPriority(self.getChildElementOptionalPositiveInteger(element, "REGENERATED-PRIORITY"))

    def readCouplingPortDetailsEthernetPriorityRegenerations(self, element: ET.Element, details: CouplingPortDetails):
        for child_element in self.findall(element, "ETHERNET-PRIORITY-REGENERATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ETHERNET-PRIORITY-REGENERATION":
                item = details.createEthernetPriorityRegeneration(self.getShortName(child_element))
                self.readEthernetPriorityRegeneration(child_element, item)
            else:
                self.notImplemented("Unsupported EthernetPriorityRegeneration <%s>" % tag_name)

    def readCouplingPortTrafficClassAssignment(self, element: ET.Element, assignment: CouplingPortTrafficClassAssignment):
        self.readReferrable(element, assignment)
        for child_element in self.findall(element, "PRIORITY"):
            priority = PositiveInteger()
            self.readARType(child_element, priority)
            priority.setValue(child_element.text)
            assignment.addPriority(priority)
        assignment.setTrafficClass(self.getChildElementOptionalPositiveInteger(element, "TRAFFIC-CLASS"))

    def readCouplingPortDetailsEthernetTrafficClassAssignments(self, element: ET.Element, details: CouplingPortDetails):
        for child_element in self.findall(element, "ETHERNET-TRAFFIC-CLASS-ASSIGNMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "COUPLING-PORT-TRAFFIC-CLASS-ASSIGNMENT":
                assignment = CouplingPortTrafficClassAssignment(details, self.getShortName(child_element))
                self.readCouplingPortTrafficClassAssignment(child_element, assignment)
                details.addEthernetTrafficClassAssignment(assignment)
            else:
                self.notImplemented("Unsupported CouplingPortTrafficClassAssignment <%s>" % tag_name)

    def readCouplingPortDetailsRatePolicys(self, element: ET.Element, details: CouplingPortDetails):
        for child_element in self.findall(element, "RATE-POLICYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "COUPLING-PORT-RATE-POLICY":
                rate_policy = CouplingPortRatePolicy()
                self.readCouplingPortRatePolicy(child_element, rate_policy)
                details.addRatePolicy(rate_policy)
            else:
                self.notImplemented("Unsupported CouplingPortRatePolicy <%s>" % tag_name)

    def readCouplingPortRatePolicy(self, element: ET.Element, policy: CouplingPortRatePolicy):
        policy.setDataLength(self.getChildElementOptionalPositiveInteger(element, "DATA-LENGTH"))
        literal = self.getChildElementOptionalLiteral(element, "POLICY-ACTION")
        if literal is not None:
            e = CouplingPortRatePolicyActionEnum()
            e.setValue(literal.getValue())
            policy.setPolicyAction(e)
        policy.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))
        policy.setTimeInterval(self.getChildElementOptionalTimeValue(element, "TIME-INTERVAL"))
        for ref in self.getChildElementRefTypeList(element, "V-LAN-REFS/V-LAN-REF"):
            policy.addVlanRef(ref)

    def getPlcaProps(self, element: ET.Element, key: str) -> PlcaProps:
        props = None
        child_element = self.find(element, key)
        if child_element is not None:
            props = PlcaProps()
            props.setPlcaLocalNodeId(self.getChildElementOptionalPositiveInteger(child_element, "PLCA-LOCAL-NODE-ID"))
            props.setPlcaMaxBurstCount(self.getChildElementOptionalPositiveInteger(child_element, "PLCA-MAX-BURST-COUNT"))
            props.setPlcaMaxBurstTimer(self.getChildElementOptionalPositiveInteger(child_element, "PLCA-MAX-BURST-TIMER"))
        return props

    def getGlobalTimeProps(self, element: ET.Element, key: str) -> GlobalTimeCouplingPortProps:
        props = None
        child_element = self.find(element, key)
        if child_element is not None:
            props = GlobalTimeCouplingPortProps()
            props.setPropagationDelay(self.getChildElementOptionalTimeValue(child_element, "PROPAGATION-DELAY"))
        return props

    def readMacSecGlobalKayProps(self, element: ET.Element, props: MacSecGlobalKayProps):
        self.logger.debug("Read MacSecGlobalKayProps <%s>" % props.getShortName())
        self.readIdentifiable(element, props)
        wrapper = self.find(element, "BYPASS-ETHER-TYPES")
        if wrapper is not None:
            for child_element in self.findall(wrapper, "BYPASS-ETHER-TYPE"):
                if child_element.text is not None:
                    value = PositiveInteger()
                    value.setValue(child_element.text)
                    props.addBypassEtherType(value)
        wrapper = self.find(element, "BYPASS-VLANS")
        if wrapper is not None:
            for child_element in self.findall(wrapper, "BYPASS-VLAN"):
                if child_element.text is not None:
                    value = PositiveInteger()
                    value.setValue(child_element.text)
                    props.addBypassVlan(value)

    def readMacSecCipherSuiteConfig(self, element: ET.Element, config: MacSecCipherSuiteConfig):
        self.logger.debug("Read MacSecCipherSuiteConfig")
        config.setCipherSuite(self.getChildElementOptionalString(element, "CIPHER-SUITE"))
        config.setCipherSuitePriority(self.getChildElementOptionalPositiveInteger(element, "CIPHER-SUITE-PRIORITY"))

    def readMacSecCryptoAlgoConfig(self, element: ET.Element, config: MacSecCryptoAlgoConfig):
        self.logger.debug("Read MacSecCryptoAlgoConfig")
        capability = self.getChildElementOptionalLiteral(element, "CAPABILITY")
        if capability is not None:
            e = MacSecCapabilityEnum()
            e.setValue(capability.getValue())
            config.setCapability(e)
        wrapper = self.find(element, "CIPHER-SUITE-CONFIGS")
        if wrapper is not None:
            for child_element in self.findall(wrapper, "MAC-SEC-CIPHER-SUITE-CONFIG"):
                cipher_config = config.createCipherSuiteConfig()
                self.readMacSecCipherSuiteConfig(child_element, cipher_config)
        confidentiality_offset = self.getChildElementOptionalLiteral(element, "CONFIDENTIALITY-OFFSET")
        if confidentiality_offset is not None:
            e = MacSecConfidentialityOffsetEnum()
            e.setValue(confidentiality_offset.getValue())
            config.setConfidentialityOffset(e)
        config.setReplayProtection(self.getChildElementOptionalBooleanValue(element, "REPLAY-PROTECTION"))
        config.setReplayProtectionWindow(self.getChildElementOptionalPositiveInteger(element, "REPLAY-PROTECTION-WINDOW"))

    def readMacSecKayParticipant(self, element: ET.Element, participant: MacSecKayParticipant):
        self.logger.debug("Read MacSecKayParticipant <%s>" % participant.getShortName())
        self.readIdentifiable(element, participant)
        participant.setCknRef(self.getChildElementOptionalRefType(element, "CKN-REF"))
        algo_element = self.find(element, "CRYPTO-ALGO-CONFIG")
        if algo_element is not None:
            config = MacSecCryptoAlgoConfig()
            self.readMacSecCryptoAlgoConfig(algo_element, config)
            participant.setCryptoAlgoConfig(config)
        participant.setSakRef(self.getChildElementOptionalRefType(element, "SAK-REF"))

    def getMacSecLocalKayProps(self, element: ET.Element) -> Optional[MacSecLocalKayProps]:
        props = None
        if element is not None:
            props = MacSecLocalKayProps()
            destination_mac = self.getChildElementOptionalLiteral(element, "DESTINATION-MAC-ADDRESS")
            if destination_mac is not None:
                mac_address = MacAddressString()
                mac_address.setValue(destination_mac.getValue())
                props.setDestinationMacAddress(mac_address)
            props.setGlobalKayPropsRef(self.getChildElementOptionalRefType(element, "GLOBAL-KAY-PROPS-REF"))
            props.setKeyServerPriority(self.getChildElementOptionalPositiveInteger(element, "KEY-SERVER-PRIORITY"))
            for ref in self.getChildElementRefTypeList(element, "MKA-PARTICIPANT-REFS/MKA-PARTICIPANT-REF"):
                props.addMkaParticipantRef(ref)
            role = self.getChildElementOptionalLiteral(element, "ROLE")
            if role is not None:
                e = MacSecRoleEnum()
                e.setValue(role.getValue())
                props.setRole(e)
            source_mac = self.getChildElementOptionalLiteral(element, "SOURCE-MAC-ADDRESS")
            if source_mac is not None:
                mac_address = MacAddressString()
                mac_address.setValue(source_mac.getValue())
                props.setSourceMacAddress(mac_address)
        return props

    def getMacSecProps(self, element: ET.Element) -> Optional[MacSecProps]:
        props = None
        if element is not None:
            props = MacSecProps()
            props.setAutoStart(self.getChildElementOptionalBooleanValue(element, "AUTO-START"))
            props.setMacSecKayConfig(self.getMacSecLocalKayProps(self.find(element, "MAC-SEC-KAY-CONFIG")))
            on_fail_permissive_mode = self.getChildElementOptionalLiteral(element, "ON-FAIL-PERMISSIVE-MODE")
            if on_fail_permissive_mode is not None:
                e = MacSecFailPermissiveModeEnum()
                e.setValue(on_fail_permissive_mode.getValue())
                props.setOnFailPermissiveMode(e)
            props.setOnFailPermissiveModeTimeout(self.getChildElementOptionalTimeValue(element, "ON-FAIL-PERMISSIVE-MODE-TIMEOUT"))
            props.setSakRekeyTimeSpan(self.getChildElementOptionalTimeValue(element, "SAK-REKEY-TIME-SPAN"))
        return props

    def getCouplingPortDetails(self, element: ET.Element, key: str) -> CouplingPortDetails:
        details = None
        child_element = self.find(element, key)
        if child_element is not None:
            details = CouplingPortDetails()
            self.readCouplingPortDetailsCouplingPortStructuralElements(child_element, details)
            self.readCouplingPortDetailsEthernetPriorityRegenerations(child_element, details)
            self.readCouplingPortDetailsEthernetTrafficClassAssignments(child_element, details)
            details.setGlobalTimeProps(self.getGlobalTimeProps(child_element, "GLOBAL-TIME-PROPS"))
            details.setLastEgressSchedulerRef(self.getChildElementOptionalRefType(child_element, "LAST-EGRESS-SCHEDULER-REF"))
            self.readCouplingPortDetailsRatePolicys(child_element, details)
        return details

    def getDhcpServerConfiguration(self, element: ET.Element, key: str) -> DhcpServerConfiguration:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = DhcpServerConfiguration()
            config.setIpv4DhcpServerConfiguration(self.getIpv4DhcpServerConfiguration(child_element, "IPV-4-DHCP-SERVER-CONFIGURATION"))
            config.setIpv6DhcpServerConfiguration(self.getIpv6DhcpServerConfiguration(child_element, "IPV-6-DHCP-SERVER-CONFIGURATION"))
        return config

    def getIpv4DhcpServerConfiguration(self, element: ET.Element, key: str) -> Optional[Ipv4DhcpServerConfiguration]:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = Ipv4DhcpServerConfiguration()
            config.setAddressRangeLowerBound(self.getChildElementOptionalLiteral(child_element, "ADDRESS-RANGE-LOWER-BOUND"))
            config.setAddressRangeUpperBound(self.getChildElementOptionalLiteral(child_element, "ADDRESS-RANGE-UPPER-BOUND"))
            config.setDefaultGateway(self.getChildElementOptionalLiteral(child_element, "DEFAULT-GATEWAY"))
            config.setDefaultLeaseTime(self.getChildElementOptionalTimeValue(child_element, "DEFAULT-LEASE-TIME"))
            for address in self.findall(child_element, "DNS-SERVER-ADDRESSES/DNS-SERVER-ADDRESS"):
                literal = ARLiteral()
                self.readARType(address, literal)
                literal.setValue(address.text)
                config.addDnsServerAddress(literal)
            config.setNetworkMask(self.getChildElementOptionalLiteral(child_element, "NETWORK-MASK"))
        return config

    def getPduActivationRoutingGroup(self, element: ET.Element) -> Optional[PduActivationRoutingGroup]:
        group = None
        if element is not None:
            group = PduActivationRoutingGroup(None, self.getShortName(element))
            self.readIdentifiable(element, group)
            control_type_literal = self.getChildElementOptionalLiteral(element, "EVENT-GROUP-CONTROL-TYPE")
            if control_type_literal is not None:
                control_type = EventGroupControlTypeEnum()
                control_type.setValue(control_type_literal.getValue())
                group.setEventGroupControlType(control_type)
            for ref in self.getChildElementRefTypeList(element, "I-PDU-IDENTIFIER-TCP-REFS/I-PDU-IDENTIFIER-TCP-REF"):
                group.addIPduIdentifierTcpRef(ref)
            for ref in self.getChildElementRefTypeList(element, "I-PDU-IDENTIFIER-UDP-REFS/I-PDU-IDENTIFIER-UDP-REF"):
                group.addIPduIdentifierUdpRef(ref)
        return group

    def getStaticSocketConnection(self, element: ET.Element) -> Optional[StaticSocketConnection]:
        connection = None
        if element is not None:
            connection = StaticSocketConnection(None, self.getShortName(element))
            self.readIdentifiable(element, connection)
            for ref in self.getChildElementRefTypeList(element, "I-PDU-IDENTIFIERS/SO-CON-I-PDU-IDENTIFIER-REF-CONDITIONAL/SO-CON-I-PDU-IDENTIFIER-REF"):
                connection.addIPduIdentifierRef(ref)
            for ref in self.getChildElementRefTypeList(element, "REMOTE-ADDRESSS/SOCKET-ADDRESS-REF-CONDITIONAL/SOCKET-ADDRESS-REF"):
                connection.setRemoteAddressRef(ref)
            connection.setTcpConnectTimeout(self.getChildElementOptionalTimeValue(element, "TCP-CONNECT-TIMEOUT"))
            tcp_role_literal = self.getChildElementOptionalLiteral(element, "TCP-ROLE")
            if tcp_role_literal is not None:
                tcp_role = TcpRoleEnum()
                tcp_role.setValue(tcp_role_literal.getValue())
                connection.setTcpRole(tcp_role)
        return connection

    def getIpv6DhcpServerConfiguration(self, element: ET.Element, key: str) -> Optional[Ipv6DhcpServerConfiguration]:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = Ipv6DhcpServerConfiguration()
            config.setAddressRangeLowerBound(self.getChildElementOptionalLiteral(child_element, "ADDRESS-RANGE-LOWER-BOUND"))
            config.setAddressRangeUpperBound(self.getChildElementOptionalLiteral(child_element, "ADDRESS-RANGE-UPPER-BOUND"))
            config.setDefaultGateway(self.getChildElementOptionalLiteral(child_element, "DEFAULT-GATEWAY"))
            config.setDefaultLeaseTime(self.getChildElementOptionalTimeValue(child_element, "DEFAULT-LEASE-TIME"))
            for address in self.findall(child_element, "DNS-SERVER-ADDRESSES/DNS-SERVER-ADDRESS"):
                literal = ARLiteral()
                self.readARType(address, literal)
                literal.setValue(address.text)
                config.addDnsServerAddress(literal)
            config.setNetworkMask(self.getChildElementOptionalLiteral(child_element, "NETWORK-MASK"))
        return config

    def readVlanMembership(self, element: ET.Element, membership: VlanMembership):
        membership.setDefaultPriority(self.getChildElementOptionalPositiveInteger(element, "DEFAULT-PRIORITY"))
        membership.setDhcpAddressAssignment(self.getDhcpServerConfiguration(element, "DHCP-ADDRESS-ASSIGNMENT"))
        membership.setSendActivity(self.getChildElementOptionalLiteral(element, "SEND-ACTIVITY"))
        membership.setVlanRef(self.getChildElementOptionalRefType(element, "VLAN-REF"))

    def readCouplingPortVlanMemberships(self, element: ET.Element, port: CouplingPort):
        for child_element in self.findall(element, "VLAN-MEMBERSHIPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VLAN-MEMBERSHIP":
                membership = VlanMembership()
                self.readVlanMembership(child_element, membership)
                port.addVlanMembership(membership)
            else:
                self.notImplemented("Unsupported VlanMembership <%s>" % tag_name)

    def readCouplingPort(self, element: ET.Element, port: CouplingPort):
        self.readIdentifiable(element, port)
        connection_negotiation_behavior = self.getChildElementOptionalLiteral(element, "CONNECTION-NEGOTIATION-BEHAVIOR")
        if connection_negotiation_behavior is not None:
            e = EthernetConnectionNegotiationEnum()
            e.setValue(connection_negotiation_behavior.getValue())
            port.setConnectionNegotiationBehavior(e)
        port.setCouplingPortDetails(self.getCouplingPortDetails(element, "COUPLING-PORT-DETAILS"))
        port.setPlcaProps(self.getPlcaProps(element, "PLCA-PROPS"))
        for child_element in self.findall(element, "MAC-SEC-PROPS"):
            props = self.getMacSecProps(child_element)
            if props is not None:
                port.addMacSecProps(props)
        coupling_port_role = self.getChildElementOptionalLiteral(element, "COUPLING-PORT-ROLE")
        if coupling_port_role is not None:
            e = CouplingPortRoleEnum()
            e.setValue(coupling_port_role.getValue())
            port.setCouplingPortRole(e)
        port.setDefaultVlanRef(self.getChildElementOptionalRefType(element, "DEFAULT-VLAN-REF"))
        mac_layer_type = self.getChildElementOptionalLiteral(element, "MAC-LAYER-TYPE")
        if mac_layer_type is not None:
            e = EthernetMacLayerTypeEnum()
            e.setValue(mac_layer_type.getValue())
            port.setMacLayerType(e)
        for ref in self.getChildElementRefTypeList(element, "MAC-MULTICAST-ADDRESS-REFS/MAC-MULTICAST-ADDRESS-REF"):
            port.addMacMulticastAddressRef(ref)
        for ref in self.getChildElementRefTypeList(element, "PNC-MAPPING-REFS/PNC-MAPPING-REF"):
            port.addPncMappingRef(ref)
        receive_activity = self.getChildElementOptionalLiteral(element, "RECEIVE-ACTIVITY")
        if receive_activity is not None:
            e = EthernetSwitchVlanIngressTagEnum()
            e.setValue(receive_activity.getValue())
            port.setReceiveActivity(e)
        physical_layer_type = self.getChildElementOptionalLiteral(element, "PHYSICAL-LAYER-TYPE")
        if physical_layer_type is not None:
            e = EthernetPhysicalLayerTypeEnum()
            e.setValue(physical_layer_type.getValue())
            port.setPhysicalLayerType(e)
        self.readCouplingPortVlanMemberships(element, port)
        port.setVlanModifierRef(self.getChildElementOptionalRefType(element, "VLAN-MODIFIER-REF"))
        port.setWakeupSleepOnDatalineConfigRef(self.getChildElementOptionalRefType(element, "WAKEUP-SLEEP-ON-DATALINE-CONFIG-REF"))

    def readEthernetCommunicationControllerCouplingPorts(self, element: ET.Element, controller: EthernetCommunicationController):
        for child_element in self.findall(element, "COUPLING-PORTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "COUPLING-PORT":
                port = controller.createCouplingPort(self.getShortName(child_element))
                self.readCouplingPort(child_element, port)
            else:
                self.notImplemented("Unsupported Coupling Port <%s>" % tag_name)

    def readEthernetCommunicationController(self, element: ET.Element, controller: EthernetCommunicationController):
        self.logger.debug("Read EthernetCommunicationController %s" % controller.getShortName())
        self.readIdentifiable(element, controller)
        child_element = self.find(element, "ETHERNET-COMMUNICATION-CONTROLLER-VARIANTS/ETHERNET-COMMUNICATION-CONTROLLER-CONDITIONAL")
        if child_element is not None:
            self.readCommunicationController(child_element, controller)
            controller.setCanXlConfigRef(self.getChildElementOptionalRefType(child_element, "CAN-XL-CONFIG-REF"))
            self.readEthernetCommunicationControllerCouplingPorts(child_element, controller)
            mac_layer_type = self.getChildElementOptionalLiteral(child_element, "MAC-LAYER-TYPE")
            if mac_layer_type is not None:
                e = EthernetMacLayerTypeEnum()
                e.setValue(mac_layer_type.getValue())
                controller.setMacLayerType(e)
            mac_unicast_literal = self.getChildElementOptionalLiteral(child_element, "MAC-UNICAST-ADDRESS")
            if mac_unicast_literal is not None:
                mac_unicast = MacAddressString()
                mac_unicast.setValue(mac_unicast_literal.getValue())
                controller.setMacUnicastAddress(mac_unicast)
            controller.setMaximumReceiveBufferLength(self.getChildElementOptionalIntegerValue(child_element, "MAXIMUM-RECEIVE-BUFFER-LENGTH"))
            controller.setMaximumTransmitBufferLength(self.getChildElementOptionalIntegerValue(child_element, "MAXIMUM-TRANSMIT-BUFFER-LENGTH"))
            controller.setSlaveActAsPassiveCommunicationSlave(self.getChildElementOptionalBooleanValue(child_element, "SLAVE-ACT-AS-PASSIVE-COMMUNICATION-SLAVE"))

    def readLinCommunicationController(self, element: ET.Element, controller: LinCommunicationController):
        self.readCommunicationController(element, controller)
        controller.setProtocolVersion(self.getChildElementOptionalLiteral(element, "PROTOCOL-VERSION"))

    def readLinMaster(self, element: ET.Element, controller: LinMaster):
        self.logger.debug("Read LinMaster %s" % controller.getShortName())
        self.readIdentifiable(element, controller)
        child_element = self.find(element, "LIN-MASTER-VARIANTS/LIN-MASTER-CONDITIONAL")
        if child_element is not None:
            self.readLinCommunicationController(child_element, controller)
            slaves_wrapper = self.find(child_element, "LIN-SLAVES")
            if slaves_wrapper is not None:
                for slave_element in self.findall(slaves_wrapper, "LIN-SLAVE-CONFIG"):
                    controller.addLinSlave(self.readLinSlaveConfig(slave_element))
            controller.setTimeBase(self.getChildElementOptionalTimeValue(child_element, "TIME-BASE"))
            controller.setTimeBaseJitter(self.getChildElementOptionalTimeValue(child_element, "TIME-BASE-JITTER"))

    def getLinErrorResponse(self, element: ET.Element, key: str) -> LinErrorResponse:
        response = None
        child_element = self.find(element, key)
        if child_element is not None:
            response = LinErrorResponse()
            response.setResponseErrorRef(self.getChildElementOptionalRefType(child_element, "RESPONSE-ERROR-REF"))
        return response

    def getLinConfigurableFrame(self, element: ET.Element, key: str) -> LinConfigurableFrame:
        frame = None
        child_element = self.find(element, key)
        if child_element is not None:
            frame = LinConfigurableFrame()
            frame.setFrameRef(self.getChildElementOptionalRefType(child_element, "FRAME-REF"))
            frame.setMessageId(self.getChildElementOptionalPositiveInteger(child_element, "MESSAGE-ID"))
        return frame

    def getLinOrderedConfigurableFrame(self, element: ET.Element, key: str) -> LinOrderedConfigurableFrame:
        frame = None
        child_element = self.find(element, key)
        if child_element is not None:
            frame = LinOrderedConfigurableFrame()
            frame.setFrameRef(self.getChildElementOptionalRefType(child_element, "FRAME-REF"))
            frame.setIndex(self.getChildElementOptionalIntegerValue(child_element, "INDEX"))
        return frame

    def getLinSlaveConfig(self, element: ET.Element, key: str) -> LinSlaveConfig:
        config = None
        child_element = self.find(element, key)
        if child_element is not None:
            config = self.readLinSlaveConfig(child_element)
        return config

    def readLinSlaveConfig(self, child_element: ET.Element) -> LinSlaveConfig:
        config = LinSlaveConfig()
        config.setConfiguredNad(self.getChildElementOptionalIntegerValue(child_element, "CONFIGURED-NAD"))
        config.setFunctionId(self.getChildElementOptionalPositiveInteger(child_element, "FUNCTION-ID"))
        ident_element = self.find(child_element, "IDENT")
        if ident_element is not None:
            ident = LinSlaveConfigIdent(config, self.getShortName(ident_element))
            self.readReferrable(ident_element, ident)
            config.setIdent(ident)
        config.setInitialNad(self.getChildElementOptionalIntegerValue(child_element, "INITIAL-NAD"))
        frames_wrapper = self.find(child_element, "LIN-CONFIGURABLE-FRAMES")
        if frames_wrapper is not None:
            for frame_element in self.findall(frames_wrapper, "LIN-CONFIGURABLE-FRAME"):
                frame = LinConfigurableFrame()
                frame.setFrameRef(self.getChildElementOptionalRefType(frame_element, "FRAME-REF"))
                frame.setMessageId(self.getChildElementOptionalPositiveInteger(frame_element, "MESSAGE-ID"))
                config.addLinConfigurableFrame(frame)
        config.setLinErrorResponse(self.getLinErrorResponse(child_element, "LIN-ERROR-RESPONSE"))
        ordered_wrapper = self.find(child_element, "LIN-ORDERED-CONFIGURABLE-FRAMES")
        if ordered_wrapper is not None:
            for frame_element in self.findall(ordered_wrapper, "LIN-ORDERED-CONFIGURABLE-FRAME"):
                frame = LinOrderedConfigurableFrame()
                frame.setFrameRef(self.getChildElementOptionalRefType(frame_element, "FRAME-REF"))
                frame.setIndex(self.getChildElementOptionalIntegerValue(frame_element, "INDEX"))
                config.addLinOrderedConfigurableFrame(frame)
        config.setProtocolVersion(self.getChildElementOptionalLiteral(child_element, "PROTOCOL-VERSION"))
        config.setSupplierId(self.getChildElementOptionalPositiveInteger(child_element, "SUPPLIER-ID"))
        config.setVariantId(self.getChildElementOptionalPositiveInteger(child_element, "VARIANT-ID"))
        return config

    def readEcuInstanceCommControllers(self, element: ET.Element, instance: EcuInstance):
        self.logger.debug("readEcuInstanceCommControllers %s" % instance.getShortName())
        for child_element in self.findall(element, "COMM-CONTROLLERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-COMMUNICATION-CONTROLLER":
                controller = instance.createCanCommunicationController(self.getShortName(child_element))
                self.readCanCommunicationController(child_element, controller)
            elif tag_name == "ETHERNET-COMMUNICATION-CONTROLLER":
                controller = instance.createEthernetCommunicationController(self.getShortName(child_element))
                self.readEthernetCommunicationController(child_element, controller)
            elif tag_name == "LIN-MASTER":
                controller = instance.createLinMaster(self.getShortName(child_element))
                self.readLinMaster(child_element, controller)
            elif tag_name == "FLEXRAY-COMMUNICATION-CONTROLLER":
                controller = instance.createFlexrayCommunicationController(self.getShortName(child_element))
                self.readFlexrayCommunicationController(child_element, controller)
            else:
                self.raiseError("Unsupported Communication Controller <%s>" % tag_name)

    def readCommConnectorPort(self, element: ET.Element, port: CommConnectorPort):
        self.readIdentifiable(element, port)
        port.setCommunicationDirection(self.getChildElementOptionalLiteral(element, "COMMUNICATION-DIRECTION"))

    def readFramePort(self, element: ET.Element, port: FramePort):
        self.readCommConnectorPort(element, port)

    def readIPduPort(self, element: ET.Element, port: IPduPort):
        self.readCommConnectorPort(element, port)
        port.setIPduSignalProcessing(self.getChildElementOptionalLiteral(element, "I-PDU-SIGNAL-PROCESSING"))
        port.setRxSecurityVerification(self.getChildElementOptionalBooleanValue(element, "RX-SECURITY-VERIFICATION"))
        port.setTimestampRxAcceptanceWindow(self.getChildElementOptionalTimeValue(element, "TIMESTAMP-RX-ACCEPTANCE-WINDOW"))
        port.setUseAuthDataFreshness(self.getChildElementOptionalBooleanValue(element, "USE-AUTH-DATA-FRESHNESS"))

    def readISignalPort(self, element: ET.Element, port: ISignalPort):
        self.readCommConnectorPort(element, port)
        port.setDataFilter(self.getDataFilter(element, "DATA-FILTER"))
        port.setDdsQosProfileRef(self.getChildElementOptionalRefType(element, "DDS-QOS-PROFILE-REF"))
        port.setFirstTimeout(self.getChildElementOptionalTimeValue(element, "FIRST-TIMEOUT"))
        port.setHandleInvalid(self.getChildElementOptionalLiteral(element, "HANDLE-INVALID"))
        port.setTimeout(self.getChildElementOptionalTimeValue(element, "TIMEOUT"))

    def readCommunicationConnectorEcuCommPortInstances(self, element: ET.Element, connector: CommunicationConnector):
        self.logger.debug("read EcuCommPortInstances of CommunicationConnector %s" % connector.getShortName())
        for child_element in self.findall(element, "ECU-COMM-PORT-INSTANCES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "FRAME-PORT":
                port = connector.createFramePort(self.getShortName(child_element))
                self.readFramePort(child_element, port)
            elif tag_name == "I-PDU-PORT":
                port = connector.createIPduPort(self.getShortName(child_element))
                self.readIPduPort(child_element, port)
            elif tag_name == "I-SIGNAL-PORT":
                port = connector.createISignalPort(self.getShortName(child_element))
                self.readISignalPort(child_element, port)
            else:
                self.raiseError("Unsupported EcuCommPortInstances <%s>" % tag_name)

    def readCommunicationConnector(self, element: ET.Element, connector: CommunicationConnector):
        self.readIdentifiable(element, connector)
        connector.setCommControllerRef(self.getChildElementOptionalRefType(element, "COMM-CONTROLLER-REF"))
        connector.setCreateEcuWakeupSource(self.getChildElementOptionalBooleanValue(element, "CREATE-ECU-WAKEUP-SOURCE"))
        connector.setDynamicPncToChannelMappingEnabled(self.getChildElementOptionalBooleanValue(element, "DYNAMIC-PNC-TO-CHANNEL-MAPPING-ENABLED"))
        self.readCommunicationConnectorEcuCommPortInstances(element, connector)
        for mask in self.findall(element, "PNC-FILTER-ARRAY-MASKS/PNC-FILTER-ARRAY-MASK"):
            if mask.text is not None:
                connector.addPncFilterArrayMask(int(mask.text.strip()))
        connector.setPncGatewayType(self.getChildElementOptionalLiteral(element, "PNC-GATEWAY-TYPE"))

    def readCanCommunicationConnector(self, element: ET.Element, connector: CanCommunicationConnector):
        self.readCommunicationConnector(element, connector)
        connector.setPncWakeupCanId(self.getChildElementOptionalPositiveInteger(element, "PNC-WAKEUP-CAN-ID"))
        connector.setPncWakeupCanIdExtended(self.getChildElementOptionalBooleanValue(element, "PNC-WAKEUP-CAN-ID-EXTENDED"))
        connector.setPncWakeupCanIdMask(self.getChildElementOptionalPositiveInteger(element, "PNC-WAKEUP-CAN-ID-MASK"))
        connector.setPncWakeupDataMask(self.getChildElementOptionalPositiveUnlimitedInteger(element, "PNC-WAKEUP-DATA-MASK"))
        connector.setPncWakeupDlc(self.getChildElementOptionalPositiveInteger(element, "PNC-WAKEUP-DLC"))

    def readEthernetCommunicationConnector(self, element: ET.Element, connector: EthernetCommunicationConnector):
        self.readCommunicationConnector(element, connector)
        connector.setEthIpPropsRef(self.getChildElementOptionalRefType(element, "ETH-IP-PROPS-REF"))
        connector.setMaximumTransmissionUnit(self.getChildElementOptionalPositiveInteger(element, "MAXIMUM-TRANSMISSION-UNIT"))
        connector.setNeighborCacheSize(self.getChildElementOptionalPositiveInteger(element, "NEIGHBOR-CACHE-SIZE"))
        connector.setPathMtuEnabled(self.getChildElementOptionalBooleanValue(element, "PATH-MTU-ENABLED"))
        connector.setPathMtuTimeout(self.getChildElementOptionalTimeValue(element, "PATH-MTU-TIMEOUT"))

    def readLinCommunicationConnector(self, element: ET.Element, connector: LinCommunicationConnector):
        self.readCommunicationConnector(element, connector)
        connector.setInitialNad(self.getChildElementOptionalIntegerValue(element, "INITIAL-NAD"))
        frames_wrapper = self.find(element, "LIN-CONFIGURABLE-FRAMES")
        if frames_wrapper is not None:
            for frame_element in self.findall(frames_wrapper, "LIN-CONFIGURABLE-FRAME"):
                frame = LinConfigurableFrame()
                frame.setFrameRef(self.getChildElementOptionalRefType(frame_element, "FRAME-REF"))
                frame.setMessageId(self.getChildElementOptionalPositiveInteger(frame_element, "MESSAGE-ID"))
                connector.addLinConfigurableFrame(frame)
        ordered_wrapper = self.find(element, "LIN-ORDERED-CONFIGURABLE-FRAMES")
        if ordered_wrapper is not None:
            for frame_element in self.findall(ordered_wrapper, "LIN-ORDERED-CONFIGURABLE-FRAME"):
                frame = LinOrderedConfigurableFrame()
                frame.setFrameRef(self.getChildElementOptionalRefType(frame_element, "FRAME-REF"))
                frame.setIndex(self.getChildElementOptionalIntegerValue(frame_element, "INDEX"))
                connector.addLinOrderedConfigurableFrame(frame)
        connector.setScheduleChangeNextTimeBase(self.getChildElementOptionalBooleanValue(element, "SCHEDULE-CHANGE-NEXT-TIME-BASE"))

    def readFlexrayCommunicationConnector(self, element: ET.Element, connector: FlexrayCommunicationConnector):
        self.readCommunicationConnector(element, connector)
        connector.setNmReadySleepTime(self.getChildElementOptionalFloatValue(element, "NM-READY-SLEEP-TIME"))
        connector.setWakeUpChannel(self.getChildElementOptionalBooleanValue(element, "WAKE-UP-CHANNEL"))

    def readEcuInstanceConnectors(self, element: ET.Element, instance: EcuInstance):
        self.logger.debug("readEcuInstanceCommControllers %s" % instance.getShortName())
        for child_element in self.findall(element, "CONNECTORS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CAN-COMMUNICATION-CONNECTOR":
                connector = instance.createCanCommunicationConnector(self.getShortName(child_element))
                self.readCanCommunicationConnector(child_element, connector)
            elif tag_name == "ETHERNET-COMMUNICATION-CONNECTOR":
                connector = instance.createEthernetCommunicationConnector(self.getShortName(child_element))
                self.readEthernetCommunicationConnector(child_element, connector)
            elif tag_name == "LIN-COMMUNICATION-CONNECTOR":
                connector = instance.createLinCommunicationConnector(self.getShortName(child_element))
                self.readLinCommunicationConnector(child_element, connector)
            elif tag_name == "FLEXRAY-COMMUNICATION-CONNECTOR":
                connector = instance.createFlexrayCommunicationConnector(self.getShortName(child_element))
                self.readFlexrayCommunicationConnector(child_element, connector)
            else:
                self.notImplemented("Unsupported Communication Connector <%s>" % tag_name)

    def readEcuInstanceAssociatedComIPduGroupRefs(self, element: ET.Element, instance: EcuInstance):
        for ref in self.getChildElementRefTypeList(element, "ASSOCIATED-COM-I-PDU-GROUP-REFS/ASSOCIATED-COM-I-PDU-GROUP-REF"):
            instance.addAssociatedComIPduGroupRef(ref)

    def readEcuInstanceAssociatedConsumedProvidedServiceInstanceGroupRefs(self, element: ET.Element, instance: EcuInstance):
        for ref in self.getChildElementRefTypeList(element, "ASSOCIATED-CONSUMED-PROVIDED-SERVICE-INSTANCE-GROUPS/CONSUMED-PROVIDED-SERVICE-INSTANCE-GROUP-REF-CONDITIONAL"):
            instance.addAssociatedConsumedProvidedServiceInstanceGroupRef(ref)

    def readEcuInstanceAssociatedPdurIPduGroupRefs(self, element: ET.Element, instance: EcuInstance):
        for ref in self.getChildElementRefTypeList(element, "ASSOCIATED-PDUR-I-PDU-GROUP-REFS/ASSOCIATED-PDUR-I-PDU-GROUP-REF"):
            instance.addAssociatedPdurIPduGroupRef(ref)

    def readEcuInstanceEcuTaskProxyRefs(self, element: ET.Element, instance: EcuInstance):
        for ref in self.getChildElementRefTypeList(element, "ECU-TASK-PROXY-REFS/ECU-TASK-PROXY-REF"):
            instance.addEcuTaskProxyRef(ref)

    def readEcuInstanceFirewallRuleRefs(self, element: ET.Element, instance: EcuInstance):
        for ref in self.getChildElementRefTypeList(element, "FIREWALL-RULE-REFS/FIREWALL-RULE-REF"):
            instance.addFirewallRuleRef(ref)

    def readEcuInstancePartitions(self, element: ET.Element, instance: EcuInstance):
        for child_element in self.findall(element, "PARTITIONS/ECU-PARTITION"):
            partition = instance.createEcuPartition(self.getShortName(child_element))
            self.readEcuPartition(child_element, partition)

    def readEcuPartition(self, element: ET.Element, partition: EcuPartition):
        self.readIdentifiable(element, partition)
        partition.setExecInUserMode(self.getChildElementOptionalBooleanValue(element, "EXEC-IN-USER-MODE"))

    def readPrivacyLevel(self, element: ET.Element, privacy_level: PrivacyLevel):
        privacy_level.setCompuMethodRef(self.getChildElementOptionalRefType(element, "COMPU-METHOD-REF"))
        privacy_level.setPrivacyLevel(self.getChildElementOptionalPositiveInteger(element, "PRIVACY-LEVEL"))

    def readDltArgument(self, element: ET.Element, argument: DltArgument):
        self.readIdentifiable(element, argument)
        for child_element in self.findall(element, "DLT-ARGUMENT-ENTRYS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DLT-ARGUMENT":
                entry = argument.createDltArgumentEntry(self.getShortName(child_element))
                self.readDltArgument(child_element, entry)
            else:
                self.notImplemented("Unsupported DltArgument Entry <%s>" % tag_name)
        argument.setLength(self.getChildElementOptionalPositiveInteger(element, "LENGTH"))
        argument.setNetworkRepresentation(self.getSwDataDefProps(element, "NETWORK-REPRESENTATION"))
        argument.setOptional(self.getChildElementOptionalBooleanValue(element, "OPTIONAL"))
        argument.setPredefinedText(self.getChildElementOptionalBooleanValue(element, "PREDEFINED-TEXT"))
        argument.setVariableLength(self.getChildElementOptionalBooleanValue(element, "VARIABLE-LENGTH"))

    def readDltMessage(self, element: ET.Element, message: DltMessage):
        self.readIdentifiable(element, message)
        for child_element in self.findall(element, "DLT-ARGUMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DLT-ARGUMENT":
                argument = message.createDltArgument(self.getShortName(child_element))
                self.readDltArgument(child_element, argument)
            else:
                self.notImplemented("Unsupported DltMessage Argument <%s>" % tag_name)
        message.setMessageId(self.getChildElementOptionalPositiveInteger(element, "MESSAGE-ID"))
        message.setMessageLineNumber(self.getChildElementOptionalPositiveInteger(element, "MESSAGE-LINE-NUMBER"))
        message.setMessageSourceFile(self.getChildElementOptionalString(element, "MESSAGE-SOURCE-FILE"))
        message.setMessageTypeInfo(self.getChildElementOptionalString(element, "MESSAGE-TYPE-INFO"))
        privacy_level_element = self.find(element, "PRIVACY-LEVEL")
        if privacy_level_element is not None:
            privacy_level = PrivacyLevel()
            self.readPrivacyLevel(privacy_level_element, privacy_level)
            message.setPrivacyLevel(privacy_level)

    def readDltContext(self, element: ET.Element, context: DltContext):
        self.readIdentifiable(element, context)
        context.setContextDescription(self.getChildElementOptionalString(element, "CONTEXT-DESCRIPTION"))
        context.setContextId(self.getChildElementOptionalString(element, "CONTEXT-ID"))
        for ref in self.getChildElementRefTypeList(element, "DLT-MESSAGES/DLT-MESSAGE-REF-CONDITIONAL/DLT-MESSAGE-REF"):
            context.addDltMessageRef(ref)

    def readDltApplication(self, element: ET.Element, application: DltApplication):
        self.readIdentifiable(element, application)
        application.setApplicationDescription(self.getChildElementOptionalString(element, "APPLICATION-DESCRIPTION"))
        application.setApplicationId(self.getChildElementOptionalString(element, "APPLICATION-ID"))
        for ref in self.getChildElementRefTypeList(element, "CONTEXTS/DLT-CONTEXT-REF-CONDITIONAL/DLT-CONTEXT-REF"):
            application.addContextRef(ref)

    def readDltEcu(self, element: ET.Element, ecu: DltEcu):
        self.readIdentifiable(element, ecu)
        for child_element in self.findall(element, "APPLICATIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DLT-APPLICATION":
                application = ecu.createApplication(self.getShortName(child_element))
                self.readDltApplication(child_element, application)
            else:
                self.notImplemented("Unsupported DltEcu Application <%s>" % tag_name)
        ecu.setEcuId(self.getChildElementOptionalString(element, "ECU-ID"))

    def readDltLogChannel(self, element: ET.Element, channel: DltLogChannel):
        self.readIdentifiable(element, channel)
        for ref in self.getChildElementRefTypeList(element, "APPLICATION-CONTEXT-REFS/APPLICATION-CONTEXT-REF"):
            channel.addApplicationContextRef(ref)
        default_trace_state_element = self.find(element, "DEFAULT-TRACE-STATE")
        if default_trace_state_element is not None:
            channel.setDefaultTraceState(DltDefaultTraceStateEnum().setValue(default_trace_state_element.text))
        for ref in self.getChildElementRefTypeList(element, "DLT-MESSAGE-REFS/DLT-MESSAGE-REF"):
            channel.addDltMessageRef(ref)
        channel.setLogChannelId(self.getChildElementOptionalString(element, "LOG-CHANNEL-ID"))
        log_trace_default_log_threshold_element = self.find(element, "LOG-TRACE-DEFAULT-LOG-THRESHOLD")
        if log_trace_default_log_threshold_element is not None:
            channel.setLogTraceDefaultLogThreshold(LogTraceDefaultLogLevelEnum().setValue(log_trace_default_log_threshold_element.text))
        channel.setNonVerboseMode(self.getChildElementOptionalBooleanValue(element, "NON-VERBOSE-MODE"))
        channel.setRxPduTriggeringRef(self.getChildElementOptionalRefType(element, "RX-PDU-TRIGGERING-REF"))
        channel.setSegmentationSupported(self.getChildElementOptionalBooleanValue(element, "SEGMENTATION-SUPPORTED"))
        channel.setTxPduTriggeringRef(self.getChildElementOptionalRefType(element, "TX-PDU-TRIGGERING-REF"))

    def readDltConfig(self, element: ET.Element, config: DltConfig):
        config.setDltEcuRef(self.getChildElementOptionalRefType(element, "DLT-ECU-REF"))
        for child_element in self.findall(element, "DLT-LOG-CHANNELS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "DLT-LOG-CHANNEL":
                channel = config.createDltLogChannel(self.getShortName(child_element))
                self.readDltLogChannel(child_element, channel)
            else:
                self.notImplemented("Unsupported DltConfig DltLogChannel <%s>" % tag_name)
        config.setSessionIdSupport(self.getChildElementOptionalBooleanValue(element, "SESSION-ID-SUPPORT"))
        config.setTimestampSupport(self.getChildElementOptionalBooleanValue(element, "TIMESTAMP-SUPPORT"))

    def readClientIdRange(self, element: ET.Element, id_range: ClientIdRange):
        id_range.setLowerLimit(self.getChildLimitElement(element, "LOWER-LIMIT"))
        id_range.setUpperLimit(self.getChildLimitElement(element, "UPPER-LIMIT"))

    def readEcuInstanceClientIdRange(self, element: ET.Element, instance: EcuInstance):
        client_id_range_element = self.find(element, "CLIENT-ID-RANGE")
        if client_id_range_element is not None:
            id_range = ClientIdRange()
            instance.setClientIdRange(id_range)
            self.readClientIdRange(client_id_range_element, id_range)

    def readEcuInstanceDltConfig(self, element: ET.Element, instance: EcuInstance):
        dlt_config_element = self.find(element, "DLT-CONFIG")
        if dlt_config_element is not None:
            config = DltConfig()
            instance.setDltConfig(config)
            self.readDltConfig(dlt_config_element, config)

    def readEcuInstanceDoIpConfig(self, element: ET.Element, instance: EcuInstance):
        do_ip_config_element = self.find(element, "DO-IP-CONFIG")
        if do_ip_config_element is not None:
            config = DoIpConfig()
            instance.setDoIpConfig(config)
            self.readDoIpConfig(do_ip_config_element, config)

    def readEcuInstance(self, element: ET.Element, instance: EcuInstance):
        self.logger.debug("Read EcuInstance <%s>" % instance.getShortName())
        self.readIdentifiable(element, instance)
        self.readEcuInstanceAssociatedComIPduGroupRefs(element, instance)
        self.readEcuInstanceAssociatedConsumedProvidedServiceInstanceGroupRefs(element, instance)
        self.readEcuInstanceAssociatedPdurIPduGroupRefs(element, instance)
        instance.setChannelSynchronousWakeup(self.getChildElementOptionalBooleanValue(element, "CHANNEL-SYNCHRONOUS-WAKEUP"))
        self.readEcuInstanceClientIdRange(element, instance)
        instance.setComConfigurationGwTimeBase(self.getChildElementOptionalTimeValue(element, "COM-CONFIGURATION-GW-TIME-BASE"))
        instance.setComConfigurationRxTimeBase(self.getChildElementOptionalTimeValue(element, "COM-CONFIGURATION-RX-TIME-BASE"))
        instance.setComConfigurationTxTimeBase(self.getChildElementOptionalTimeValue(element, "COM-CONFIGURATION-TX-TIME-BASE"))
        instance.setComEnableMDTForCyclicTransmission(self.getChildElementOptionalBooleanValue(element, "COM-ENABLE-MDT-FOR-CYCLIC-TRANSMISSION"))
        self.readEcuInstanceCommControllers(element, instance)
        self.readEcuInstanceConnectors(element, instance)
        self.readEcuInstanceDltConfig(element, instance)
        self.readEcuInstanceDoIpConfig(element, instance)
        self.readEcuInstanceEcuTaskProxyRefs(element, instance)
        instance.setEthSwitchPortGroupDerivation(self.getChildElementOptionalBooleanValue(element, "ETH-SWITCH-PORT-GROUP-DERIVATION"))
        self.readEcuInstanceFirewallRuleRefs(element, instance)
        self.readEcuInstancePartitions(element, instance)
        instance.setPnResetTime(self.getChildElementOptionalTimeValue(element, "PN-RESET-TIME"))
        instance.setPncNmRequest(self.getChildElementOptionalBooleanValue(element, "PNC-NM-REQUEST"))
        instance.setPncPrepareSleepTimer(self.getChildElementOptionalTimeValue(element, "PNC-PREPARE-SLEEP-TIMER"))
        instance.setPncSynchronousWakeup(self.getChildElementOptionalBooleanValue(element, "PNC-SYNCHRONOUS-WAKEUP"))
        instance.setSleepModeSupported(self.getChildElementOptionalBooleanValue(element, "SLEEP-MODE-SUPPORTED"))
        instance.setTcpIpIcmpPropsRef(self.getChildElementOptionalRefType(element, "TCP-IP-ICMP-PROPS-REF"))
        instance.setTcpIpPropsRef(self.getChildElementOptionalRefType(element, "TCP-IP-PROPS-REF"))
        instance.setV2xSupported(self.getChildElementOptionalLiteral(element, "V-2-X-SUPPORTED"))
        instance.setWakeUpOverBusSupported(self.getChildElementOptionalBooleanValue(element, "WAKE-UP-OVER-BUS-SUPPORTED"))

    def getFrameMappings(self, element: ET.Element) -> List[FrameMapping]:
        mappings = []
        for child_element in self.findall(element, "FRAME-MAPPINGS/FRAME-MAPPING"):
            mapping = FrameMapping()
            self.readFrameMapping(child_element, mapping)
            mappings.append(mapping)
        return mappings

    def readFrameMapping(self, element: ET.Element, mapping: FrameMapping):
        self.readARObject(element, mapping)
        mapping.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))
        mapping.setSourceFrameRef(self.getChildElementOptionalRefType(element, "SOURCE-FRAME-REF"))
        mapping.setTargetFrameRef(self.getChildElementOptionalRefType(element, "TARGET-FRAME-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(mapping, VariationPointCapable):
                mapping.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def getISignalMappings(self, element: ET.Element) -> List[ISignalMapping]:
        mappings = []
        for child_element in self.findall(element, "SIGNAL-MAPPINGS/I-SIGNAL-MAPPING"):
            mapping = ISignalMapping()
            self.readISignalMapping(child_element, mapping)
            mappings.append(mapping)
        return mappings

    def readISignalMapping(self, element: ET.Element, mapping: ISignalMapping):
        self.readARObject(element, mapping)
        mapping.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))
        mapping.setSourceSignalRef(self.getChildElementOptionalRefType(element, "SOURCE-SIGNAL-REF"))
        mapping.setTargetSignalRef(self.getChildElementOptionalRefType(element, "TARGET-SIGNAL-REF"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(mapping, VariationPointCapable):
                mapping.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def getTargetIPduRef(self, element, key: str) -> TargetIPduRef:
        i_pdu_ref = None
        child_element = self.find(element, key)
        if child_element is not None:
            i_pdu_ref = TargetIPduRef()
            default_value_element = self.find(child_element, "DEFAULT-VALUE")
            if default_value_element is not None:
                default_value = PduMappingDefaultValue()
                for element_element in self.findall(default_value_element, "DEFAULT-VALUE-ELEMENTS/DEFAULT-VALUE-ELEMENT"):
                    value = DefaultValueElement()
                    self.readDefaultValueElement(element_element, value)
                    default_value.addDefaultValueElement(value)
                i_pdu_ref.setDefaultValue(default_value)
            i_pdu_ref.setTargetIPduRef(self.getChildElementOptionalRefType(child_element, "TARGET-I-PDU-REF"))
        return i_pdu_ref

    def readDefaultValueElement(self, element: ET.Element, default_value: DefaultValueElement):
        self.readARObject(element, default_value)
        default_value.setElementByteValue(self.getChildElementOptionalIntegerValue(element, "ELEMENT-BYTE-VALUE"))
        default_value.setElementPosition(self.getChildElementOptionalIntegerValue(element, "ELEMENT-POSITION"))

    def getIPduMappings(self, element: ET.Element) -> List[IPduMapping]:
        mappings = []
        for child_element in self.findall(element, "I-PDU-MAPPINGS/I-PDU-MAPPING"):
            mapping = IPduMapping()
            mapping.setIntroduction(self.getDocumentationBlock(child_element, "INTRODUCTION"))
            mapping.setPduMaxLength(self.getChildElementOptionalPositiveInteger(child_element, "PDU-MAX-LENGTH"))
            mapping.setPdurTpChunkSize(self.getChildElementOptionalPositiveInteger(child_element, "PDUR-TP-CHUNK-SIZE"))
            mapping.setSourceIPduRef(self.getChildElementOptionalRefType(child_element, "SOURCE-I-PDU-REF"))
            mapping.setTargetIPdu(self.getTargetIPduRef(child_element, "TARGET-I-PDU"))
            mappings.append(mapping)
        return mappings

    def readGateway(self, element: ET.Element, gateway: Gateway):
        self.logger.debug("Read Gateway <%s>" % gateway.getShortName())
        self.readIdentifiable(element, gateway)
        gateway.setEcuRef(self.getChildElementOptionalRefType(element, "ECU-REF"))
        for mapping in self.getFrameMappings(element):
            gateway.addFrameMapping(mapping)
        for mapping in self.getIPduMappings(element):
            gateway.addIPduMapping(mapping)
        for mapping in self.getISignalMappings(element):
            gateway.addSignalMapping(mapping)

    def readISignal(self, element: ET.Element, signal: ISignal):
        self.logger.debug("Read ISignal <%s>" % signal.getShortName())
        self.readIdentifiable(element, signal)
        signal.setDataTransformationRef(self.getChildElementOptionalRefType(element, "DATA-TRANSFORMATIONS/DATA-TRANSFORMATION-REF-CONDITIONAL/DATA-TRANSFORMATION-REF"))
        signal.setDataTypePolicy(self.getChildElementOptionalLiteral(element, "DATA-TYPE-POLICY"))
        signal.setISignalType(self.getChildElementOptionalLiteral(element, "I-SIGNAL-TYPE"))
        signal.setInitValue(self.getInitValue(element))
        signal.setLength(self.getChildElementOptionalNumericalValue(element, "LENGTH"))
        signal.setNetworkRepresentationProps(self.getSwDataDefProps(element, "NETWORK-REPRESENTATION-PROPS"))
        signal.setSystemSignalRef(self.getChildElementOptionalRefType(element, "SYSTEM-SIGNAL-REF"))
        signal.setTimeoutSubstitutionValue(self.getChildValueSpecification(element, "TIMEOUT-SUBSTITUTION-VALUE"))
        self.readISignalProps(element, signal)
        self.readISignalTransformationISignalProps(element, signal)

    def readISignalProps(self, element: ET.Element, signal: ISignal):
        props_element = self.find(element, "I-SIGNAL-PROPS")
        if props_element is not None:
            props = ISignalProps()
            props.setHandleOutOfRange(self.getChildElementOptionalLiteral(props_element, "HANDLE-OUT-OF-RANGE"))
            signal.setISignalProps(props)

    def readISignalTransformationISignalProps(self, element: ET.Element, signal: ISignal):
        for child_element in self.findall(element, "TRANSFORMATION-I-SIGNAL-PROPSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-TRANSFORMATION-I-SIGNAL-PROPS":
                props = EndToEndTransformationISignalProps()
                self.readEndToEndTransformationISignalProps(child_element, props)
                signal.addTransformationISignalProps(props)
            elif tag_name == "SOMEIP-TRANSFORMATION-I-SIGNAL-PROPS":
                props = SOMEIPTransformationISignalProps()
                self.readSOMEIPTransformationISignalProps(child_element, props)
                signal.addTransformationISignalProps(props)
            elif tag_name == "USER-DEFINED-TRANSFORMATION-I-SIGNAL-PROPS":
                props = UserDefinedTransformationISignalProps()
                self.readUserDefinedTransformationISignalProps(child_element, props)
                signal.addTransformationISignalProps(props)
            else:
                self.notImplemented("Unsupported TransformationISignalProps %s" % tag_name)

    def readEcucValueCollectionEcucValues(self, element: ET.Element, parent: EcucValueCollection):
        for child_element in self.findall(element, "ECUC-VALUES/ECUC-MODULE-CONFIGURATION-VALUES-REF-CONDITIONAL"):
            ref = self.getChildElementOptionalRefType(child_element, "ECUC-MODULE-CONFIGURATION-VALUES-REF")
            if ref is not None:
                parent.addEcucValueRef(ref)
            self.logger.debug("EcucValue <%s> of EcucValueCollection <%s> has been added", ref.value, parent.getShortName())

    def readEcucValueCollection(self, element: ET.Element, collection: EcucValueCollection):
        self.logger.debug("Read EcucValueCollection <%s>" % collection.getShortName())
        self.readIdentifiable(element, collection)
        collection.setEcuExtractRef(self.getChildElementOptionalRefType(element, "ECU-EXTRACT-REF"))
        self.readEcucValueCollectionEcucValues(element, collection)

    def readParameterValue(self, element: ET.Element, param_value: ParameterValue):
        """Read the R3.2.3 abstract ParameterValue members (DEFINITION-REF; DEST optional in legacy files)."""
        param_value.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))

    def readIntegerValue(self, element: ET.Element, integer_value: IntegerValue):
        """Read an R3.2.3 <INTEGER-VALUE> element (Table 3.34): DEFINITION-REF followed by VALUE."""
        self.readParameterValue(element, integer_value)
        child_element = self.find(element, "VALUE")
        if child_element is not None:
            value = UnlimitedInteger()
            self.readARType(child_element, value)
            value.setValue(child_element.text)
            integer_value.setValue(value)

    def readBooleanValue(self, element: ET.Element, boolean_value: BooleanValue):
        """Read an R3.2.3 <BOOLEAN-VALUE> element (Table 3.33): DEFINITION-REF followed by VALUE."""
        self.readParameterValue(element, boolean_value)
        boolean_value.setValue(self.getChildElementOptionalBooleanValue(element, "VALUE"))

    def readFloatValue(self, element: ET.Element, float_value: FloatValue):
        """Read an R3.2.3 <FLOAT-VALUE> element (Table 3.35): DEFINITION-REF followed by VALUE."""
        self.readParameterValue(element, float_value)
        float_value.setValue(self.getChildElementOptionalFloatValue(element, "VALUE"))

    def readMixedStringText(self, element: ET.Element, obj: AtpMixedString):
        """<<atpMixedString>>: the element text is the value (pure-text shape).
        Whitespace is preserved verbatim."""
        if element.text is not None and obj is not None:
            obj.setMixedString(element.text)

    def readStringValue(self, element: ET.Element, string_value: StringValue):
        """Read an R3.2.3 <STRING-VALUE> element (Table 3.36): DEFINITION-REF followed by VALUE."""
        self.readParameterValue(element, string_value)
        string_value.setValue(self.getChildElementOptionalString(element, "VALUE"))

    def readLinkerSymbolValue(self, element: ET.Element, linker_symbol_value: LinkerSymbolValue):
        """Read an R3.2.3 <LINKER-SYMBOL-VALUE> element (Table 3.37): DEFINITION-REF followed by VALUE."""
        self.readStringValue(element, linker_symbol_value)

    def readFunctionNameValue(self, element: ET.Element, function_name_value: FunctionNameValue):
        """Read an R3.2.3 <FUNCTION-NAME-VALUE> element (Table 3.38): DEFINITION-REF followed by VALUE."""
        self.readStringValue(element, function_name_value)

    def readEnumerationValue(self, element: ET.Element, enumeration_value: EnumerationValue):
        """Read an R3.2.3 <ENUMERATION-VALUE> element (Table 3.39): DEFINITION-REF followed by VALUE."""
        self.readParameterValue(element, enumeration_value)
        enumeration_value.setValue(self.getChildElementOptionalString(element, "VALUE"))

    def readConfigReferenceValue(self, element: ET.Element, config_reference_value: ConfigReferenceValue):
        """Read the R3.2.3 abstract ConfigReferenceValue members (DEFINITION-REF; DEST optional in legacy files)."""
        config_reference_value.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))

    def readReferenceValue(self, element: ET.Element, reference_value: ReferenceValue):
        """Read an R3.2.3 <REFERENCE-VALUE> element (Table 3.41): DEFINITION-REF followed by VALUE-REF."""
        self.readConfigReferenceValue(element, reference_value)
        reference_value.setValueRef(self.getChildElementOptionalRefType(element, "VALUE-REF"))

    def readInstanceReferenceValue(self, element: ET.Element, instance_reference_value: InstanceReferenceValue):
        """Read an R3.2.3 <INSTANCE-REFERENCE-VALUE> element (Table 3.42): DEFINITION-REF followed by VALUE-IREF (CONTEXT-REF* then VALUE-REF)."""
        self.readConfigReferenceValue(element, instance_reference_value)
        child_element = self.find(element, "VALUE-IREF")
        if child_element is not None:
            iref = AnyInstanceRef()
            for ref in self.getChildElementRefTypeList(child_element, "CONTEXT-REF"):
                iref.addContextElementRef(ref)
            iref.setTargetRef(self.getChildElementOptionalRefType(child_element, "VALUE-REF"))
            instance_reference_value.setValueIRef(iref)

    def readContainer(self, element: ET.Element, container: Container):
        """Read an R3.2.3 <CONTAINER> element (Table 3.31): SHORT-NAME, DEFINITION-REF, PARAMETER-VALUES, REFERENCE-VALUES, SUB-CONTAINERS."""
        self.readIdentifiable(element, container)
        container.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))
        for child_element in self.findall(element, "PARAMETER-VALUES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "BOOLEAN-VALUE":
                value = BooleanValue()
                self.readBooleanValue(child_element, value)
                container.addParameterValue(value)
            elif tag_name == "ENUMERATION-VALUE":
                value = EnumerationValue()
                self.readEnumerationValue(child_element, value)
                container.addParameterValue(value)
            elif tag_name == "FLOAT-VALUE":
                value = FloatValue()
                self.readFloatValue(child_element, value)
                container.addParameterValue(value)
            elif tag_name == "FUNCTION-NAME-VALUE":
                value = FunctionNameValue()
                self.readFunctionNameValue(child_element, value)
                container.addParameterValue(value)
            elif tag_name == "INTEGER-VALUE":
                value = IntegerValue()
                self.readIntegerValue(child_element, value)
                container.addParameterValue(value)
            elif tag_name == "LINKER-SYMBOL-VALUE":
                value = LinkerSymbolValue()
                self.readLinkerSymbolValue(child_element, value)
                container.addParameterValue(value)
            elif tag_name == "STRING-VALUE":
                value = StringValue()
                self.readStringValue(child_element, value)
                container.addParameterValue(value)
            else:
                self.notImplemented("Unsupported Container parameter value <%s>" % tag_name)
        for child_element in self.findall(element, "REFERENCE-VALUES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "REFERENCE-VALUE":
                value = ReferenceValue()
                self.readReferenceValue(child_element, value)
                container.addReferenceValue(value)
            elif tag_name == "INSTANCE-REFERENCE-VALUE":
                value = InstanceReferenceValue()
                self.readInstanceReferenceValue(child_element, value)
                container.addReferenceValue(value)
            else:
                self.notImplemented("Unsupported Container reference value <%s>" % tag_name)
        for child_element in self.findall(element, "SUB-CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CONTAINER":
                sub_container = container.createSubContainer(self.getShortName(child_element))
                self.readContainer(child_element, sub_container)
            else:
                self.notImplemented("Unsupported Container sub container <%s>" % tag_name)

    def readModuleConfiguration(self, element: ET.Element, module_configuration: ModuleConfiguration):
        """Read an R3.2.3 <MODULE-CONFIGURATION> element (Table 3.30): DEFINITION-REF, IMPLEMENTATION-CONFIG-VARIANT, MODULE-DESCRIPTION-REF, CONTAINERS."""
        self.readIdentifiable(element, module_configuration)
        module_configuration.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))
        module_configuration.setImplementationConfigVariant(self.getChildElementOptionalLiteral(element, "IMPLEMENTATION-CONFIG-VARIANT"))
        module_configuration.setModuleDescriptionRef(self.getChildElementOptionalRefType(element, "MODULE-DESCRIPTION-REF"))
        for child_element in self.findall(element, "CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CONTAINER":
                container = module_configuration.createContainer(self.getShortName(child_element))
                self.readContainer(child_element, container)
            else:
                self.notImplemented("Unsupported ModuleConfiguration container <%s>" % tag_name)

    def readEcucParameterValue(self, element: ET.Element, param_value: EcucParameterValue):
        param_value.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))
        param_value.setIndex(self.getChildElementOptionalPositiveInteger(element, "INDEX"))
        for annotation in self.getAnnotations(element):
            param_value.addAnnotation(annotation)
        param_value.setIsAutoValue(self.getChildElementOptionalBooleanValue(element, "IS-AUTO-VALUE"))
        self.readVariationPointCapable(element, param_value)

    def readEcucTextualParamValue(self, element: ET.Element, param_value: EcucTextualParamValue):
        self.readEcucParameterValue(element, param_value)
        param_value.setValue(self.getChildElementOptionalVerbatimString(element, "VALUE"))

    def readEcucNumericalParamValue(self, element: ET.Element, param_value: EcucNumericalParamValue):
        self.readEcucParameterValue(element, param_value)
        param_value.setValue(self.getChildElementOptionalNumerical(element, "VALUE"))

    def readEcucAddInfoParamValue(self, element: ET.Element, param_value: EcucAddInfoParamValue):
        self.readEcucParameterValue(element, param_value)
        param_value.setValue(self.getDocumentationBlock(element, "VALUE"))

    def readEcucContainerValueParameterValues(self, element: ET.Element, container_value: EcucContainerValue):
        for child_element in self.findall(element, "PARAMETER-VALUES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-TEXTUAL-PARAM-VALUE":
                param_value = EcucTextualParamValue()
                self.readEcucTextualParamValue(child_element, param_value)
                container_value.addParameterValue(param_value)
            elif tag_name == "ECUC-NUMERICAL-PARAM-VALUE":
                param_value = EcucNumericalParamValue()
                self.readEcucNumericalParamValue(child_element, param_value)
                container_value.addParameterValue(param_value)
            elif tag_name == "ECUC-ADD-INFO-PARAM-VALUE":
                param_value = EcucAddInfoParamValue()
                self.readEcucAddInfoParamValue(child_element, param_value)
                container_value.addParameterValue(param_value)
            else:
                self.notImplemented("Unsupported EcucParameterValue <%s>" % tag_name)

    def readEcucAbstractReferenceValue(self, element: ET.Element, value: EcucAbstractReferenceValue):
        value.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))
        value.setIndex(self.getChildElementOptionalPositiveInteger(element, "INDEX"))
        for annotation in self.getAnnotations(element):
            value.addAnnotation(annotation)
        value.setIsAutoValue(self.getChildElementOptionalBooleanValue(element, "IS-AUTO-VALUE"))
        self.readVariationPointCapable(element, value)

    def readEcucReferenceValue(self, element: ET.Element, value: EcucReferenceValue):
        self.readEcucAbstractReferenceValue(element, value)
        value.setValueRef(self.getChildElementOptionalRefType(element, "VALUE-REF"))

    def getAnyInstanceRef(self, element: ET.Element, key) -> AnyInstanceRef:
        instance_ref = None
        child_element = self.find(element, key)
        if child_element is not None:
            instance_ref = self.getAnyInstanceRefFromElement(child_element)
        return instance_ref

    def getAnyInstanceRefFromElement(self, child_element: ET.Element) -> AnyInstanceRef:
        instance_ref = AnyInstanceRef()
        instance_ref.setBaseRef(self.getChildElementOptionalRefType(child_element, "BASE-REF"))
        for ref in self.getChildElementRefTypeList(child_element, "CONTEXT-ELEMENT-REF"):
            instance_ref.addContextElementRef(ref)
        instance_ref.setTargetRef(self.getChildElementOptionalRefType(child_element, "TARGET-REF"))
        return instance_ref

    def readEcucInstanceReferenceValue(self, element: ET.Element, value: EcucInstanceReferenceValue):
        self.readEcucAbstractReferenceValue(element, value)
        value.setValueIRef(self.getAnyInstanceRef(element, "VALUE-IREF"))

    def readEcucContainerValueReferenceValues(self, element: ET.Element, container_value: EcucContainerValue):
        for child_element in self.findall(element, "REFERENCE-VALUES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-REFERENCE-VALUE":
                value = EcucReferenceValue()
                self.readEcucReferenceValue(child_element, value)
                container_value.addReferenceValue(value)
            elif tag_name == "ECUC-INSTANCE-REFERENCE-VALUE":
                value = EcucInstanceReferenceValue()
                self.readEcucInstanceReferenceValue(child_element, value)
                container_value.addReferenceValue(value)
            else:
                self.notImplemented("Unsupported EcucParameterValue <%s>" % tag_name)

    def readEcucContainerValue(self, element: ET.Element, container_value: EcucContainerValue):
        self.readIdentifiable(element, container_value)
        container_value.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))
        container_value.setIndex(self.getChildElementOptionalPositiveInteger(element, "INDEX"))
        self.readEcucContainerValueParameterValues(element, container_value)
        self.readEcucContainerValueReferenceValues(element, container_value)
        self.readEcucContainerValueSubContainers(element, container_value)

    def readEcucContainerValueEcucContainerValue(self, element: ET.Element, parent: EcucContainerValue):
        short_name = self.getShortName(element)
        self.logger.debug("EcucContainerValue %s" % short_name)
        container_value = parent.createSubContainer(short_name)
        self.readEcucContainerValue(element, container_value)

    def readEcucContainerValueSubContainers(self, element: ET.Element, parent: EcucContainerValue):
        for child_element in self.findall(element, "SUB-CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-CONTAINER-VALUE":
                self.readEcucContainerValueEcucContainerValue(child_element, parent)
            else:
                self.notImplemented("Unsupported Sub Container %s" % tag_name)

    def readEcucModuleConfigurationValuesEcucContainerValue(self, element: ET.Element, parent: EcucModuleConfigurationValues):
        short_name = self.getShortName(element)
        self.logger.debug("EcucContainerValue %s" % short_name)
        container_value = parent.createContainer(short_name)
        self.readEcucContainerValue(element, container_value)

    def readEcucModuleConfigurationValuesContainers(self, element: ET.Element, values: EcucModuleConfigurationValues):
        for child_element in self.findall(element, "CONTAINERS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECUC-CONTAINER-VALUE":
                self.readEcucModuleConfigurationValuesEcucContainerValue(child_element, values)
            else:
                self.notImplemented("Unsupported Container %s" % tag_name)

    def readEcucModuleConfigurationValues(self, element: ET.Element, values: EcucModuleConfigurationValues):
        self.logger.debug("Read EcucModuleConfigurationValues %s" % values.getShortName())
        self.readIdentifiable(element, values)
        values.setDefinitionRef(self.getChildElementOptionalRefType(element, "DEFINITION-REF"))
        values.setEcucDefEdition(self.getChildElementOptionalRevisionLabelString(element, "ECUC-DEF-EDITION"))
        values.setImplementationConfigVariant(self.getChildElementOptionalLiteral(element, "IMPLEMENTATION-CONFIG-VARIANT"))
        values.setModuleDescriptionRef(self.getChildElementOptionalRefType(element, "MODULE-DESCRIPTION-REF"))
        values.setPostBuildVariantUsed(self.getChildElementOptionalBooleanValue(element, "POST-BUILD-VARIANT-USED"))
        self.readEcucModuleConfigurationValuesContainers(element, values)

    def readPhysicalDimension(self, element: ET.Element, dimension: PhysicalDimension):
        self.logger.debug("Read PhysicalDimension <%s>" % dimension.getShortName())
        self.readIdentifiable(element, dimension)
        dimension.setLengthExp(self.getChildElementOptionalNumericalValue(element, "LENGTH-EXP"))
        dimension.setLuminousIntensityExp(self.getChildElementOptionalNumericalValue(element, "LUMINOUS-INTENSITY-EXP"))
        dimension.setMassExp(self.getChildElementOptionalNumericalValue(element, "MASS-EXP"))
        dimension.setMolarAmountExp(self.getChildElementOptionalNumericalValue(element, "MOLAR-AMOUNT-EXP"))
        dimension.setTemperatureExp(self.getChildElementOptionalNumericalValue(element, "TEMPERATURE-EXP"))
        dimension.setTimeExp(self.getChildElementOptionalNumericalValue(element, "TIME-EXP"))
        dimension.setCurrentExp(self.getChildElementOptionalNumericalValue(element, "CURRENT-EXP"))

    def readISignalGroupISignalRef(self, element: ET.Element, group: ISignalGroup):
        for ref_type in self.getChildElementRefTypeList(element, "I-SIGNAL-REFS/I-SIGNAL-REF"):
            group.addISignalRef(ref_type)

    def readISignalGroupComBasedSignalGroupTransformation(self, element: ET.Element, group: ISignalGroup):
        ref = self.getChildElementOptionalRefType(element, "COM-BASED-SIGNAL-GROUP-TRANSFORMATIONS/DATA-TRANSFORMATION-REF-CONDITIONAL/DATA-TRANSFORMATION-REF")
        group.setComBasedSignalGroupTransformationRef(ref)

    def readTransformationISignalProps(self, element: ET.Element, props: TransformationISignalProps):
        self.readDescribable(element, props)
        cs_error_reaction = self.getChildElementOptionalLiteral(element, "CS-ERROR-REACTION")
        if cs_error_reaction is not None:
            e = CSTransformerErrorReactionEnum()
            e.setValue(cs_error_reaction.getValue())
            props.setCsErrorReaction(e)
        for child_element in self.findall(element, "DATA-PROTOTYPE-TRANSFORMATION-PROPSS/*"):
            if self.getTagName(child_element) == "DATA-PROTOTYPE-TRANSFORMATION-PROPS":
                dp_props = DataPrototypeTransformationProps()
                self.readDataPrototypeTransformationProps(child_element, dp_props)
                props.addDataPrototypeTransformationProps(dp_props)
            else:
                self.notImplemented("Unsupported DataPrototypeTransformationProps %s" % self.getTagName(child_element))

    def readDataPrototypeInPortInterfaceRef(self, element: ET.Element, ref: DataPrototypeInPortInterfaceRef):
        self.readARObject(element, ref)
        ref.setTagId(self.getChildElementOptionalPositiveInteger(element, "TAG-ID"))
        child_element = self.find(element, "DATA-PROTOTYPE-IN-CLIENT-SERVER-INTERFACE-REF")
        if child_element is not None:
            cs_ref = DataPrototypeInClientServerInterfaceInstanceRef()
            self.readDataPrototypeInClientServerInterfaceInstanceRef(child_element, cs_ref)
            ref.setDataPrototypeInClientServerInterface(cs_ref)

    def readDataPrototypeInSenderReceiverInterfaceInstanceRef(self, element: ET.Element, iref: DataPrototypeInSenderReceiverInterfaceInstanceRef):
        self.readARObject(element, iref)
        iref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE"))
        for ctx in self.findall(element, "CONTEXT-DATA-PROTOTYPE-IN-SR"):
            iref.addContextDataPrototypeInSrRefs(self.getChildElementOptionalRefType(ctx, "CONTEXT-DATA-PROTOTYPE-IN-SR") or self.getChildElementOptionalRefType(ctx, "CONTEXT-DATA-PROTOTYPE"))
        iref.setRootDataPrototypeInSrRef(self.getChildElementOptionalRefType(element, "ROOT-DATA-PROTOTYPE-IN-SR"))
        iref.setTargetDataPrototypeInSrRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-IN-SR"))

    def readDataPrototypeInClientServerInterfaceInstanceRef(self, element: ET.Element, iref: DataPrototypeInClientServerInterfaceInstanceRef):
        self.readARObject(element, iref)
        iref.setBaseRef(self.getChildElementOptionalRefType(element, "BASE"))
        for ctx in self.findall(element, "CONTEXT-DATA-PROTOTYPE-IN-CS"):
            iref.addContextDataPrototypeInCsRefs(self.getChildElementOptionalRefType(ctx, "CONTEXT-DATA-PROTOTYPE-IN-CS") or self.getChildElementOptionalRefType(ctx, "CONTEXT-DATA-PROTOTYPE"))
        iref.setRootDataPrototypeInCsRef(self.getChildElementOptionalRefType(element, "ROOT-DATA-PROTOTYPE-IN-CS"))
        iref.setTargetDataPrototypeInCsRef(self.getChildElementOptionalRefType(element, "TARGET-DATA-PROTOTYPE-IN-CS"))

    def readDataPrototypeTransformationProps(self, element: ET.Element, props: DataPrototypeTransformationProps):
        self.readARObject(element, props)
        child_element = self.find(element, "DATA-PROTOTYPE-IN-PORT-INTERFACE-REF")
        if child_element is not None:
            ref = DataPrototypeInPortInterfaceRef()
            self.readDataPrototypeInPortInterfaceRef(child_element, ref)
            props.setDataPrototypeInPortInterfaceRef(ref)
        props.setNetworkRepresentationProps(self.getSwDataDefProps(element, "NETWORK-REPRESENTATION-PROPS"))
        props.setTransformationPropsRef(self.getChildElementOptionalRefType(element, "TRANSFORMATION-PROPS-REF"))

    def readEndToEndTransformationISignalPropsDataIds(self, element: ET.Element, props: EndToEndTransformationISignalProps):
        child_element = self.find(element, "DATA-IDS")
        if child_element is not None:
            for data_id_element in self.findall(child_element, "DATA-ID"):
                if data_id_element.text is not None:
                    data_id = PositiveInteger()
                    data_id.setValue(data_id_element.text)
                    props.addDataId(data_id)

    def readEndToEndTransformationISignalProps(self, element: ET.Element, props: EndToEndTransformationISignalProps):
        child_element = self.find(element, "END-TO-END-TRANSFORMATION-I-SIGNAL-PROPS-VARIANTS/END-TO-END-TRANSFORMATION-I-SIGNAL-PROPS-CONDITIONAL")
        if child_element is not None:
            self.readTransformationISignalProps(child_element, props)
            props.setTransformerRef(self.getChildElementOptionalRefType(child_element, "TRANSFORMER-REF"))
            self.readEndToEndTransformationISignalPropsDataIds(child_element, props)
            props.setDataLength(self.getChildElementOptionalPositiveInteger(child_element, "DATA-LENGTH"))
            props.setMaxDataLength(self.getChildElementOptionalPositiveInteger(child_element, "MAX-DATA-LENGTH"))
            props.setMinDataLength(self.getChildElementOptionalPositiveInteger(child_element, "MIN-DATA-LENGTH"))
            props.setSourceId(self.getChildElementOptionalPositiveInteger(child_element, "SOURCE-ID"))

    def readSOMEIPTransformationISignalProps(self, element: ET.Element, props: SOMEIPTransformationISignalProps):
        child_element = self.find(element, "SOMEIP-TRANSFORMATION-I-SIGNAL-PROPS-VARIANTS/SOMEIP-TRANSFORMATION-I-SIGNAL-PROPS-CONDITIONAL")
        if child_element is not None:
            self.readTransformationISignalProps(child_element, props)
            props.setTransformerRef(self.getChildElementOptionalRefType(child_element, "TRANSFORMER-REF"))
            props.setImplementsLegacyStringSerialization(self.getChildElementOptionalBooleanValue(child_element, "IMPLEMENTS-LEGACY-STRING-SERIALIZATION"))
            props.setInterfaceVersion(self.getChildElementOptionalPositiveInteger(child_element, "INTERFACE-VERSION"))
            props.setIsDynamicLengthFieldSize(self.getChildElementOptionalBooleanValue(child_element, "IS-DYNAMIC-LENGTH-FIELD-SIZE"))
            message_type = self.getChildElementOptionalLiteral(child_element, "MESSAGE-TYPE")
            if message_type is not None:
                message_type_enum = SOMEIPMessageTypeEnum()
                message_type_enum.setValue(message_type.getValue())
                props.setMessageType(message_type_enum)
            props.setSizeOfArrayLengthFields(self.getChildElementOptionalPositiveInteger(child_element, "SIZE-OF-ARRAY-LENGTH-FIELDS"))
            props.setSizeOfStringLengthFields(self.getChildElementOptionalPositiveInteger(child_element, "SIZE-OF-STRING-LENGTH-FIELDS"))
            props.setSizeOfStructLengthFields(self.getChildElementOptionalPositiveInteger(child_element, "SIZE-OF-STRUCT-LENGTH-FIELDS"))
            props.setSizeOfUnionLengthFields(self.getChildElementOptionalPositiveInteger(child_element, "SIZE-OF-UNION-LENGTH-FIELDS"))
            for ref_type in self.getChildElementRefTypeList(child_element, "TLV-DATA-ID-DEFINITION-REFS/TLV-DATA-ID-DEFINITION-REF"):
                props.addTlvDataIdDefinitionRef(ref_type)

    def readUserDefinedTransformationISignalProps(self, element: ET.Element, props: UserDefinedTransformationISignalProps):
        child_element = self.find(element, "USER-DEFINED-TRANSFORMATION-I-SIGNAL-PROPS-VARIANTS/USER-DEFINED-TRANSFORMATION-I-SIGNAL-PROPS-CONDITIONAL")
        if child_element is not None:
            self.readTransformationISignalProps(child_element, props)
            props.setTransformerRef(self.getChildElementOptionalRefType(child_element, "TRANSFORMER-REF"))

    def readISignalGroupTransformationISignalProps(self, element: ET.Element, group: ISignalGroup):
        for child_element in self.findall(element, "TRANSFORMATION-I-SIGNAL-PROPSS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "END-TO-END-TRANSFORMATION-I-SIGNAL-PROPS":
                props = EndToEndTransformationISignalProps()
                self.readEndToEndTransformationISignalProps(child_element, props)
                group.addTransformationISignalProps(props)
            elif tag_name == "SOMEIP-TRANSFORMATION-I-SIGNAL-PROPS":
                props = SOMEIPTransformationISignalProps()
                self.readSOMEIPTransformationISignalProps(child_element, props)
                group.addTransformationISignalProps(props)
            elif tag_name == "USER-DEFINED-TRANSFORMATION-I-SIGNAL-PROPS":
                props = UserDefinedTransformationISignalProps()
                self.readUserDefinedTransformationISignalProps(child_element, props)
                group.addTransformationISignalProps(props)
            else:
                self.notImplemented("Unsupported TransformationISignalProps %s" % tag_name)

    def readISignalGroup(self, element: ET.Element, group: ISignalGroup):
        self.logger.debug("Read ISignalGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        self.readISignalGroupComBasedSignalGroupTransformation(element, group)
        self.readISignalGroupISignalRef(element, group)
        group.setSystemSignalGroupRef(self.getChildElementOptionalRefType(element, "SYSTEM-SIGNAL-GROUP-REF"))
        self.readISignalGroupTransformationISignalProps(element, group)

    def readSystemSignal(self, element: ET.Element, signal: SystemSignal):
        self.logger.debug("Read SystemSignal <%s>" % signal.getShortName())
        self.readIdentifiable(element, signal)
        signal.setDynamicLength(self.getChildElementOptionalBooleanValue(element, "DYNAMIC-LENGTH"))
        signal.setPhysicalProps(self.getSwDataDefProps(element, "PHYSICAL-PROPS"))

    def readSystemSignalGroup(self, element: ET.Element, group: SystemSignalGroup):
        self.logger.debug("Read SystemSignalGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        for ref_type in self.getChildElementRefTypeList(element, "SYSTEM-SIGNAL-REFS/SYSTEM-SIGNAL-REF"):
            group.addSystemSignalRef(ref_type)
        group.setTransformingSystemSignalRef(self.getChildElementOptionalRefType(element, "TRANSFORMING-SYSTEM-SIGNAL-REF"))

    def readSignalServiceTranslationPropsSet(self, element: ET.Element, props_set: SignalServiceTranslationPropsSet):
        self.logger.debug("Read SignalServiceTranslationPropsSet <%s>" % props_set.getShortName())
        self.readIdentifiable(element, props_set)
        for child_element in self.findall(element, "SIGNAL-SERVICE-TRANSLATION-PROPS"):
            props = props_set.createSignalServiceTranslationProps(self.getShortName(child_element))
            self.readSignalServiceTranslationProps(child_element, props)

    def readSignalServiceTranslationProps(self, element: ET.Element, props: SignalServiceTranslationProps):
        self.logger.debug("Read SignalServiceTranslationProps <%s>" % props.getShortName())
        self.readIdentifiable(element, props)
        for ref_type in self.getChildElementRefTypeList(element, "CONTROL-CONSUMED-EVENT-GROUP-REFS/CONTROL-CONSUMED-EVENT-GROUP-REF"):
            props.addControlConsumedEventGroupRef(ref_type)
        for ref_type in self.getChildElementRefTypeList(element, "CONTROL-PNC-REFS/CONTROL-PNC-REF"):
            props.addControlPncRef(ref_type)
        for ref_type in self.getChildElementRefTypeList(element, "CONTROL-PROVIDED-EVENT-GROUP-REFS/CONTROL-PROVIDED-EVENT-GROUP-REF"):
            props.addControlProvidedEventGroupRef(ref_type)
        props.setServiceControl(self.getChildElementOptionalLiteral(element, "SERVICE-CONTROL"))
        for child_element in self.findall(element, "SIGNAL-SERVICE-TRANSLATION-EVENT-PROPS"):
            event_props = props.createSignalServiceTranslationEventProps(self.getShortName(child_element))
            self.readSignalServiceTranslationEventProps(child_element, event_props)

    def readSignalServiceTranslationEventProps(self, element: ET.Element, event_props: SignalServiceTranslationEventProps):
        self.logger.debug("Read SignalServiceTranslationEventProps <%s>" % event_props.getShortName())
        self.readIdentifiable(element, event_props)
        for child_element in self.findall(element, "SIGNAL-SERVICE-TRANSLATION-ELEMENT-PROPS"):
            element_props = event_props.createSignalServiceTranslationElementProps(self.getShortName(child_element))
            self.readSignalServiceTranslationElementProps(child_element, element_props)
        event_props.setSafeTranslation(self.getChildElementOptionalBooleanValue(element, "SAFE-TRANSLATION"))
        event_props.setSecureTranslation(self.getChildElementOptionalBooleanValue(element, "SECURE-TRANSLATION"))
        event_props.setTranslationTarget(self.getVariableDataPrototypeInSystemInstanceRef(self.find(element, "TRANSLATION-TARGET")))

    def readSignalServiceTranslationElementProps(self, element: ET.Element, element_props: SignalServiceTranslationElementProps):
        self.logger.debug("Read SignalServiceTranslationElementProps <%s>" % element_props.getShortName())
        self.readIdentifiable(element, element_props)
        element_props.setFilter(self.getDataFilter(element, "FILTER"))
        element_props.setTransmissionTrigger(self.getChildElementOptionalBooleanValue(element, "TRANSMISSION-TRIGGER"))

    def readISignalToPduMappings(self, element: ET.Element, parent: ISignalIPdu):
        for child_element in self.findall(element, "I-SIGNAL-TO-PDU-MAPPINGS/I-SIGNAL-TO-I-PDU-MAPPING"):
            short_name = self.getShortName(child_element)
            mapping = parent.createISignalToPduMappings(short_name)
            self.readIdentifiable(child_element, mapping)
            mapping.setISignalRef(self.getChildElementOptionalRefType(child_element, "I-SIGNAL-REF"))
            mapping.setISignalGroupRef(self.getChildElementOptionalRefType(child_element, "I-SIGNAL-GROUP-REF"))
            mapping.setPackingByteOrder(self.getChildElementOptionalLiteral(child_element, "PACKING-BYTE-ORDER"))
            mapping.setStartPosition(self.getChildElementOptionalNumericalValue(child_element, "START-POSITION"))
            mapping.setTransferProperty(self.getChildElementOptionalLiteral(child_element, "TRANSFER-PROPERTY"))
            mapping.setUpdateIndicationBitPosition(self.getChildElementOptionalNumericalValue(child_element, "UPDATE-INDICATION-BIT-POSITION"))

    def getDataFilter(self, element: ET.Element, key: str) -> DataFilter:
        filter = None
        child_element = self.find(element, key)
        if child_element is not None:
            filter = DataFilter()
            literal = self.getChildElementOptionalLiteral(child_element, "DATA-FILTER-TYPE")
            if literal is not None:
                filter.setDataFilterType(DataFilterTypeEnum().setValue(literal.getText()))
            filter.setMask(self.getChildElementOptionalUnlimitedInteger(child_element, "MASK"))
            filter.setMax(self.getChildElementOptionalUnlimitedInteger(child_element, "MAX"))
            filter.setMin(self.getChildElementOptionalUnlimitedInteger(child_element, "MIN"))
            filter.setOffset(self.getChildElementOptionalPositiveInteger(child_element, "OFFSET"))
            filter.setPeriod(self.getChildElementOptionalPositiveInteger(child_element, "PERIOD"))
            filter.setX(self.getChildElementOptionalUnlimitedInteger(child_element, "X"))

        return filter

    def getTransmissionModeConditions(self, element: ET.Element, key: str) -> List[TransmissionModeCondition]:
        result = []
        child_elements = self.findall(element, key)
        for child_element in child_elements:
            condition = TransmissionModeCondition()
            condition.setDataFilter(self.getDataFilter(child_element, "DATA-FILTER"))
            condition.setISignalInIPduRef(self.getChildElementOptionalRefType(child_element, "I-SIGNAL-IN-I-PDU-REF"))
            result.append(condition)
        return result

    def getTimeRangeType(self, element: ET.Element, key: str) -> TimeRangeType:
        time_range = None
        child_element = self.find(element, key)
        if child_element is not None:
            time_range = TimeRangeType()
            time_range.setValue(self.getChildElementOptionalTimeValue(child_element, "VALUE"))
        return time_range

    def getCyclicTiming(self, element: ET.Element, key: str) -> CyclicTiming:
        timing = None
        child_element = self.find(element, key)
        if child_element is not None:
            timing = CyclicTiming()
            timing.setTimeOffset(self.getTimeRangeType(child_element, "TIME-OFFSET"))
            timing.setTimePeriod(self.getTimeRangeType(child_element, "TIME-PERIOD"))
        return timing

    def getEventControlledTiming(self, element: ET.Element, key: str) -> EventControlledTiming:
        timing = None
        child_element = self.find(element, key)
        if child_element is not None:
            timing = EventControlledTiming()
            timing.setNumberOfRepetitions(self.getChildElementOptionalIntegerValue(child_element, "NUMBER-OF-REPETITIONS"))
            timing.setRepetitionPeriod(self.getTimeRangeType(child_element, "REPETITION-PERIOD"))
        return timing

    def getTransmissionModeTiming(self, element: ET.Element, key: str) -> TransmissionModeTiming:
        timing = None
        child_element = self.find(element, key)
        if child_element is not None:
            # self.logger.debug("Get TransmissionModeTiming of <%s>" % key)
            timing = TransmissionModeTiming()
            timing.setCyclicTiming(self.getCyclicTiming(child_element, "CYCLIC-TIMING"))
            timing.setEventControlledTiming(self.getEventControlledTiming(child_element, "EVENT-CONTROLLED-TIMING"))
        return timing

    def getTransmissionModeDeclaration(self, element: ET.Element, key: str) -> TransmissionModeDeclaration:
        decl = None
        child_element = self.find(element, key)
        if child_element is not None:
            decl = TransmissionModeDeclaration()
            for condition_element in self.findall(child_element, "MODE-DRIVEN-FALSE-CONDITIONS/MODE-DRIVEN-TRANSMISSION-MODE-CONDITION"):
                condition = ModeDrivenTransmissionModeCondition()
                self.readModeDrivenTransmissionModeCondition(condition_element, condition)
                decl.addModeDrivenFalseCondition(condition)
            for condition_element in self.findall(child_element, "MODE-DRIVEN-TRUE-CONDITIONS/MODE-DRIVEN-TRANSMISSION-MODE-CONDITION"):
                condition = ModeDrivenTransmissionModeCondition()
                self.readModeDrivenTransmissionModeCondition(condition_element, condition)
                decl.addModeDrivenTrueCondition(condition)
            for condition in self.getTransmissionModeConditions(child_element, "TRANSMISSION-MODE-CONDITIONS/TRANSMISSION-MODE-CONDITION"):
                decl.addTransmissionModeCondition(condition)
            decl.setTransmissionModeFalseTiming(self.getTransmissionModeTiming(child_element, "TRANSMISSION-MODE-FALSE-TIMING"))
            decl.setTransmissionModeTrueTiming(self.getTransmissionModeTiming(child_element, "TRANSMISSION-MODE-TRUE-TIMING"))
        return decl

    def getISignalIPduIPduTimingSpecification(self, element: ET.Element) -> IPduTiming:
        timing = None
        child_element = self.find(element, "I-PDU-TIMING-SPECIFICATIONS/I-PDU-TIMING")
        if child_element is not None:
            timing = IPduTiming()
            timing.setMinimumDelay(self.getChildElementOptionalTimeValue(child_element, "MINIMUM-DELAY"))
            timing.setTransmissionModeDeclaration(self.getTransmissionModeDeclaration(child_element, "TRANSMISSION-MODE-DECLARATION"))
        return timing

    def readDoIpConfig(self, element: ET.Element, config: DoIpConfig):
        for child_element in self.findall(element, "DOIP-INTERFACES/DO-IP-INTERFACE"):
            interface = config.createDoIpInterface(self.getShortName(child_element))
            self.readDoIpInterface(child_element, interface)
        logic_address_element = self.find(element, "LOGIC-ADDRESS")
        if logic_address_element is not None:
            address = config.createLogicAddress(self.getShortName(logic_address_element))
            self.readDoIpLogicAddress(logic_address_element, address)

    def readDoIpInterface(self, element: ET.Element, interface: DoIpInterface):
        self.logger.debug("Read DoIpInterface <%s>" % interface.getShortName())
        self.readIdentifiable(element, interface)
        interface.setAliveCheckResponseTimeout(self.getChildElementOptionalTimeValue(element, "ALIVE-CHECK-RESPONSE-TIMEOUT"))
        for child_element in self.findall(element, "DO-IP-ROUTING-ACTIVATIONS/DO-IP-ROUTING-ACTIVATION"):
            activation = interface.createDoIpRoutingActivation(self.getShortName(child_element))
            self.readDoIpRoutingActivation(child_element, activation)
        interface.setDoipChannelCollectionRef(self.getChildElementOptionalRefType(element, "DOIP-CHANNEL-COLLECTION-REF"))
        for ref in self.getChildElementRefTypeList(element, "DOIP-CONNECTION-REFS/DOIP-CONNECTION-REF"):
            interface.addDoipConnectionRef(ref)
        interface.setGeneralInactivityTime(self.getChildElementOptionalTimeValue(element, "GENERAL-INACTIVITY-TIME"))
        interface.setInitialInactivityTime(self.getChildElementOptionalTimeValue(element, "INITIAL-INACTIVITY-TIME"))
        interface.setInitialVehicleAnnouncementTime(self.getChildElementOptionalTimeValue(element, "INITIAL-VEHICLE-ANNOUNCEMENT-TIME"))
        interface.setIsActivationLineDependent(self.getChildElementOptionalBooleanValue(element, "IS-ACTIVATION-LINE-DEPENDENT"))
        interface.setMaxTesterConnections(self.getChildElementOptionalPositiveInteger(element, "MAX-TESTER-CONNECTIONS"))
        for ref in self.getChildElementRefTypeList(element, "SOCKET-CONNECTION-REFS/SOCKET-CONNECTION-REF"):
            interface.addSocketConnectionRef(ref)
        interface.setUseMacAddressForIdentification(self.getChildElementOptionalBooleanValue(element, "USE-MAC-ADDRESS-FOR-IDENTIFICATION"))
        interface.setUseVehicleIdentificationSyncStatus(self.getChildElementOptionalBooleanValue(element, "USE-VEHICLE-IDENTIFICATION-SYNC-STATUS"))
        interface.setVehicleAnnouncementCount(self.getChildElementOptionalPositiveInteger(element, "VEHICLE-ANNOUNCEMENT-COUNT"))
        interface.setVehicleAnnouncementInterval(self.getChildElementOptionalTimeValue(element, "VEHICLE-ANNOUNCEMENT-INTERVAL"))

    def readDoIpRoutingActivation(self, element: ET.Element, activation: DoIpRoutingActivation):
        self.logger.debug("Read DoIpRoutingActivation <%s>" % activation.getShortName())
        self.readIdentifiable(element, activation)
        for ref in self.getChildElementRefTypeList(element, "DO-IP-TARGET-ADDRESS-REFS/DO-IP-TARGET-ADDRESS-REF"):
            activation.addDoIpTargetAddressRef(ref)

    def readISignalIPdu(self, element: ET.Element, ipdu: ISignalIPdu):
        self.logger.debug("Read ISignalIPdu <%s>" % ipdu.getShortName())
        self.readIdentifiable(element, ipdu)
        ipdu.setLength(self.getChildElementOptionalNumericalValue(element, "LENGTH"))
        ipdu.setIPduTimingSpecification(self.getISignalIPduIPduTimingSpecification(element))
        self.readISignalToPduMappings(element, ipdu)
        ipdu.setUnusedBitPattern(self.getChildElementOptionalIntegerValue(element, "UNUSED-BIT-PATTERN"))

    def getISignalIPduRefs(self, element: ET.Element) -> List[RefType]:
        ref_types = []
        for child_element in self.findall(element, "I-SIGNAL-I-PDUS/I-SIGNAL-I-PDU-REF-CONDITIONAL"):
            ref_types.append(self.getChildElementOptionalRefType(child_element, "I-SIGNAL-I-PDU-REF"))
        return ref_types

    def readISignalIPduGroup(self, element: ET.Element, group: ISignalIPduGroup):
        self.logger.debug("Read ISignalIPduGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        group.setCommunicationDirection(self.getChildElementOptionalLiteral(element, "COMMUNICATION-DIRECTION"))
        group.setCommunicationMode(self.getChildElementOptionalLiteral(element, "COMMUNICATION-MODE"))
        for ref_type in self.getChildElementRefTypeList(element, "CONTAINED-I-SIGNAL-I-PDU-GROUP-REFS/CONTAINED-I-SIGNAL-I-PDU-GROUP-REF"):
            group.addContainedISignalIPduGroupRef(ref_type)
        for ref_type in self.getISignalIPduRefs(element):
            group.addISignalIPduRef(ref_type)
        for ref_type in self.getChildElementRefTypeList(element, "NM-PDUS/NM-PDU-REF-CONDITIONAL/NM-PDU-REF"):
            group.addNmPduRef(ref_type)

    def readPdurIPduGroup(self, element: ET.Element, group: PdurIPduGroup):
        self.logger.debug("Read PdurIPduGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        group.setCommunicationMode(self.getChildElementOptionalString(element, "COMMUNICATION-MODE"))
        for child_element in self.findall(element, "I-PDUS/PDU-TRIGGERING-REF-CONDITIONAL"):
            group.addIPduRef(self.getChildElementOptionalRefType(child_element, "PDU-TRIGGERING-REF"))

    def readDataMapping(self, element: ET.Element, mapping: DataMapping):
        self.readARObject(element, mapping)
        mapping.setIntroduction(self.getDocumentationBlock(element, "INTRODUCTION"))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(mapping, VariationPointCapable):
                mapping.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readSenderReceiverToSignalMapping(self, element: ET.Element, mapping: SenderReceiverToSignalMapping):
        self.readDataMapping(element, mapping)
        mapping.setDataElementIRef(self.getVariableDataPrototypeInSystemInstanceRef(self.find(element, "DATA-ELEMENT-IREF")))
        sender_to_signal_element = self.find(element, "SENDER-TO-SIGNAL-TEXT-TABLE-MAPPING")
        if sender_to_signal_element is not None:
            mapping.setSenderToSignalTextTableMapping(self.getTextTableMapping(sender_to_signal_element))
        signal_to_receiver_element = self.find(element, "SIGNAL-TO-RECEIVER-TEXT-TABLE-MAPPING")
        if signal_to_receiver_element is not None:
            mapping.setSignalToReceiverTextTableMapping(self.getTextTableMapping(signal_to_receiver_element))
        mapping.setSystemSignalRef(self.getChildElementOptionalRefType(element, "SYSTEM-SIGNAL-REF"))

    def readSenderRecCompositeTypeMapping(self, element: ET.Element, mapping: SenderRecCompositeTypeMapping):
        self.readARObject(element, mapping)

    def readSenderRecRecordElementMapping(self, element: ET.Element, mapping: SenderRecRecordElementMapping):
        self.readARObject(element, mapping)
        mapping.setApplicationRecordElementRef(self.getChildElementOptionalRefType(element, "APPLICATION-RECORD-ELEMENT-REF"))
        complex_element = self.find(element, "COMPLEX-TYPE-MAPPING")
        if complex_element is not None:
            type_mapping_element = self.find(complex_element, "*")
            if type_mapping_element is not None:
                tag_name = self.getTagName(type_mapping_element)
                if tag_name == "SENDER-REC-ARRAY-TYPE-MAPPING":
                    type_mapping = SenderRecArrayTypeMapping()
                    self.readSenderRecArrayTypeMapping(type_mapping_element, type_mapping)
                    mapping.setComplexTypeMapping(type_mapping)
                elif tag_name == "SENDER-REC-RECORD-TYPE-MAPPING":
                    type_mapping = SenderRecRecordTypeMapping()
                    self.readSenderRecRecordTypeMapping(type_mapping_element, type_mapping)
                    mapping.setComplexTypeMapping(type_mapping)
                else:
                    self.notImplemented("Unsupported ComplexTypeMapping %s" % tag_name)
        mapping.setImplementationRecordElementRef(self.getChildElementOptionalRefType(element, "IMPLEMENTATION-RECORD-ELEMENT-REF"))
        sender_to_signal_element = self.find(element, "SENDER-TO-SIGNAL-TEXT-TABLE-MAPPING")
        if sender_to_signal_element is not None:
            mapping.setSenderToSignalTextTableMapping(self.getTextTableMapping(sender_to_signal_element))
        signal_to_receiver_element = self.find(element, "SIGNAL-TO-RECEIVER-TEXT-TABLE-MAPPING")
        if signal_to_receiver_element is not None:
            mapping.setSignalToReceiverTextTableMapping(self.getTextTableMapping(signal_to_receiver_element))
        mapping.setSystemSignalRef(self.getChildElementOptionalRefType(element, "SYSTEM-SIGNAL-REF"))

    def readIndexedArrayElement(self, element: ET.Element, indexed: IndexedArrayElement):
        self.readARObject(element, indexed)
        indexed.setApplicationArrayElementRef(self.getChildElementOptionalRefType(element, "APPLICATION-ARRAY-ELEMENT-REF"))
        indexed.setImplementationArrayElementRef(self.getChildElementOptionalRefType(element, "IMPLEMENTATION-ARRAY-ELEMENT-REF"))
        indexed.setIndex(self.getChildElementOptionalIntegerValue(element, "INDEX"))

    def readSenderRecArrayElementMapping(self, element: ET.Element, mapping: SenderRecArrayElementMapping):
        self.readARObject(element, mapping)
        complex_element = self.find(element, "COMPLEX-TYPE-MAPPING")
        if complex_element is not None:
            type_mapping_element = self.find(complex_element, "*")
            if type_mapping_element is not None:
                tag_name = self.getTagName(type_mapping_element)
                if tag_name == "SENDER-REC-ARRAY-TYPE-MAPPING":
                    type_mapping = SenderRecArrayTypeMapping()
                    self.readSenderRecArrayTypeMapping(type_mapping_element, type_mapping)
                    mapping.setComplexTypeMapping(type_mapping)
                elif tag_name == "SENDER-REC-RECORD-TYPE-MAPPING":
                    type_mapping = SenderRecRecordTypeMapping()
                    self.readSenderRecRecordTypeMapping(type_mapping_element, type_mapping)
                    mapping.setComplexTypeMapping(type_mapping)
                else:
                    self.notImplemented("Unsupported ComplexTypeMapping %s" % tag_name)
        indexed_element = self.find(element, "INDEXED-ARRAY-ELEMENT")
        if indexed_element is not None:
            indexed = IndexedArrayElement()
            self.readIndexedArrayElement(indexed_element, indexed)
            mapping.setIndexedArrayElement(indexed)
        mapping.setSystemSignalRef(self.getChildElementOptionalRefType(element, "SYSTEM-SIGNAL-REF"))

    def readSenderRecArrayTypeMapping(self, element: ET.Element, mapping: SenderRecArrayTypeMapping):
        self.readSenderRecCompositeTypeMapping(element, mapping)
        for child_element in self.findall(element, "ARRAY-ELEMENT-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SENDER-REC-ARRAY-ELEMENT-MAPPING":
                array_element_mapping = SenderRecArrayElementMapping()
                self.readSenderRecArrayElementMapping(child_element, array_element_mapping)
                mapping.addArrayElementMapping(array_element_mapping)
            else:
                self.notImplemented("Unsupported ArrayElementMapping %s" % tag_name)
        sender_to_signal_element = self.find(element, "SENDER-TO-SIGNAL-TEXT-TABLE-MAPPING")
        if sender_to_signal_element is not None:
            mapping.setSenderToSignalTextTableMapping(self.getTextTableMapping(sender_to_signal_element))
        signal_to_receiver_element = self.find(element, "SIGNAL-TO-RECEIVER-TEXT-TABLE-MAPPING")
        if signal_to_receiver_element is not None:
            mapping.setSignalToReceiverTextTableMapping(self.getTextTableMapping(signal_to_receiver_element))

    def readSenderRecArrayTypeMappingRecordElementMapping(self, element: ET.Element, mapping: SenderRecRecordTypeMapping):
        for child_element in self.findall(element, "RECORD-ELEMENT-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SENDER-REC-RECORD-ELEMENT-MAPPING":
                record_element_mapping = SenderRecRecordElementMapping()
                self.readSenderRecRecordElementMapping(child_element, record_element_mapping)
                mapping.addRecordElementMapping(record_element_mapping)
            else:
                self.notImplemented("Unsupported RecordElementMapping %s" % tag_name)

    def readSenderRecRecordTypeMapping(self, element: ET.Element, mapping: SenderRecRecordTypeMapping):
        self.readSenderRecCompositeTypeMapping(element, mapping)
        self.readSenderRecArrayTypeMappingRecordElementMapping(element, mapping)

    def readSenderReceiverToSignalGroupMappingTypeMapping(self, element: ET.Element, mapping: SenderReceiverToSignalGroupMapping):
        child_element = self.find(element, "TYPE-MAPPING/*")
        if child_element is not None:
            tag_name = self.getTagName(child_element)
            if tag_name == "SENDER-REC-RECORD-TYPE-MAPPING":
                type_mapping = SenderRecRecordTypeMapping()
                self.readSenderRecRecordTypeMapping(child_element, type_mapping)
                mapping.setTypeMapping(type_mapping)
            elif tag_name == "SENDER-REC-ARRAY-TYPE-MAPPING":
                type_mapping = SenderRecArrayTypeMapping()
                self.readSenderRecArrayTypeMapping(child_element, type_mapping)
                mapping.setTypeMapping(type_mapping)
            else:
                self.notImplemented("Unsupported Type Mapping %s" % tag_name)

    def readSenderReceiverToSignalGroupMapping(self, element: ET.Element, mapping: SenderReceiverToSignalGroupMapping):
        self.readDataMapping(element, mapping)
        mapping.setDataElementIRef(self.getVariableDataPrototypeInSystemInstanceRef(self.find(element, "DATA-ELEMENT-IREF")))
        mapping.setSignalGroupRef(self.getChildElementOptionalRefType(element, "SIGNAL-GROUP-REF"))
        self.readSenderReceiverToSignalGroupMappingTypeMapping(element, mapping)

    def readSystemMappingDataMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "DATA-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SENDER-RECEIVER-TO-SIGNAL-MAPPING":
                signal_mapping = SenderReceiverToSignalMapping()
                self.readSenderReceiverToSignalMapping(child_element, signal_mapping)
                mapping.addDataMapping(signal_mapping)
            elif tag_name == "SENDER-RECEIVER-TO-SIGNAL-GROUP-MAPPING":
                signal_group_mapping = SenderReceiverToSignalGroupMapping()
                self.readSenderReceiverToSignalGroupMapping(child_element, signal_group_mapping)
                mapping.addDataMapping(signal_group_mapping)
            else:
                self.notImplemented("Unsupported Data Mapping %s" % tag_name)

    def readApplicationPartitionToEcuPartitionMapping(self, element: ET.Element, mapping: ApplicationPartitionToEcuPartitionMapping):
        self.readIdentifiable(element, mapping)
        for ref in self.getChildElementRefTypeList(element, "APPLICATION-PARTITION-REFS/APPLICATION-PARTITION-REF"):
            mapping.addApplicationPartitionRef(ref)
        mapping.setEcuPartitionRef(self.getChildElementOptionalRefType(element, "ECU-PARTITION-REF"))

    def readSystemMappingApplicationPartitionToEcuPartitionMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "APPLICATION-PARTITION-TO-ECU-PARTITION-MAPPINGS/APPLICATION-PARTITION-TO-ECU-PARTITION-MAPPING"):
            partition_mapping = mapping.createApplicationPartitionToEcuPartitionMapping(self.getShortName(child_element))
            self.readApplicationPartitionToEcuPartitionMapping(child_element, partition_mapping)

    def readAppOsTaskProxyToEcuTaskProxyMapping(self, element: ET.Element, mapping: AppOsTaskProxyToEcuTaskProxyMapping):
        self.readIdentifiable(element, mapping)
        mapping.setAppTaskProxyRef(self.getChildElementOptionalRefType(element, "APP-TASK-PROXY-REF"))
        mapping.setEcuTaskProxyRef(self.getChildElementOptionalRefType(element, "ECU-TASK-PROXY-REF"))
        mapping.setOffset(self.getChildElementOptionalIntegerValue(element, "OFFSET"))

    def readSystemMappingAppOsTaskProxyToEcuTaskProxyMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "APP-OS-TASK-PROXY-TO-ECU-TASK-PROXY-MAPPINGS/APP-OS-TASK-PROXY-TO-ECU-TASK-PROXY-MAPPING"):
            app_ecu_mapping = mapping.createAppOsTaskProxyToEcuTaskProxyMapping(self.getShortName(child_element))
            self.readAppOsTaskProxyToEcuTaskProxyMapping(child_element, app_ecu_mapping)

    def readSwcToEcuMapping(self, element: ET.Element, mapping: SwcToEcuMapping):
        # self.logger.debug("SwcToEcuMapping %s" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        for child_element in self.findall(element, "COMPONENT-IREFS/COMPONENT-IREF"):
            mapping.addComponentIRef(self.getComponentInSystemInstanceRef(child_element))
        mapping.setControlledHwElementRef(self.getChildElementOptionalRefType(element, "CONTROLLED-HW-ELEMENT-REF"))
        mapping.setEcuInstanceRef(self.getChildElementOptionalRefType(element, "ECU-INSTANCE-REF"))
        mapping.setProcessingUnitRef(self.getChildElementOptionalRefType(element, "PROCESSING-UNIT-REF"))

    def readSystemMappingSwMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "SW-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SWC-TO-ECU-MAPPING":
                swc_to_ecu_mapping = mapping.createSwcToEcuMapping(self.getShortName(child_element))
                self.readSwcToEcuMapping(child_element, swc_to_ecu_mapping)
            else:
                self.notImplemented("Unsupported Sw Mapping %s" % tag_name)

    def readCommunicationControllerMapping(self, element: ET.Element) -> CommunicationControllerMapping:
        mapping = CommunicationControllerMapping()
        mapping.setCommunicationControllerRef(self.getChildElementOptionalRefType(element, "COMMUNICATION-CONTROLLER-REF"))
        mapping.setHwCommunicationControllerRef(self.getChildElementOptionalRefType(element, "HW-COMMUNICATION-CONTROLLER-REF"))
        return mapping

    def readHwPortMapping(self, element: ET.Element) -> HwPortMapping:
        mapping = HwPortMapping()
        mapping.setCommunicationConnectorRef(self.getChildElementOptionalRefType(element, "COMMUNICATION-CONNECTOR-REF"))
        mapping.setHwCommunicationPortRef(self.getChildElementOptionalRefType(element, "HW-COMMUNICATION-PORT-REF"))
        return mapping

    def readEcuMapping(self, element: ET.Element, mapping: ECUMapping):
        self.readIdentifiable(element, mapping)
        for child_element in self.findall(element, "COMM-CONTROLLER-MAPPINGS/COMMUNICATION-CONTROLLER-MAPPING"):
            mapping.addCommControllerMapping(self.readCommunicationControllerMapping(child_element))
        mapping.setEcuInstanceRef(self.getChildElementOptionalRefType(element, "ECU-INSTANCE-REF"))
        mapping.setEcuRef(self.getChildElementOptionalRefType(element, "ECU-REF"))
        for child_element in self.findall(element, "HW-PORT-MAPPINGS/HW-PORT-MAPPING"):
            mapping.addHwPortMapping(self.readHwPortMapping(child_element))

    def readSystemMappingEcuResourceMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "ECU-RESOURCE-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "ECU-MAPPING":
                ecu_mapping = mapping.createECUMapping(self.getShortName(child_element))
                self.readEcuMapping(child_element, ecu_mapping)
            else:
                self.notImplemented("Unsupported EcuResourceMapping <%s>" % tag_name)

    def readSwcToImplMapping(self, element: ET.Element, mapping: SwcToImplMapping):
        self.readIdentifiable(element, mapping)
        mapping.setComponentImplementationRef(self.getChildElementOptionalRefType(element, "COMPONENT-IMPLEMENTATION-REF"))
        for child_element in self.findall(element, "COMPONENT-IREFS/COMPONENT-IREF"):
            mapping.addComponentIRef(self.getComponentInSystemInstanceRef(child_element))

    def readSystemMappingSwImplMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "SW-IMPL-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SWC-TO-IMPL-MAPPING":
                sw_impl_mapping = mapping.createSwcToImplMapping(self.getShortName(child_element))
                self.readSwcToImplMapping(child_element, sw_impl_mapping)
            else:
                self.notImplemented("Unsupported SwImplMapping <%s>" % tag_name)

    def readComManagementMapping(self, element: ET.Element, mapping: ComManagementMapping):
        self.readIdentifiable(element, mapping)
        for ref in self.getChildElementRefTypeList(element, "COM-MANAGEMENT-GROUP-REFS/COM-MANAGEMENT-GROUP-REF"):
            mapping.addComManagementGroupRef(ref)
        for iref_element in self.findall(element, "COM-MANAGEMENT-PORT-GROUP-IREFS/COM-MANAGEMENT-PORT-GROUP-IREF"):
            mapping.addComManagementPortGroupIRef(self.getPortGroupInSystemInstanceRef(iref_element))
        for ref in self.getChildElementRefTypeList(element, "PHYSICAL-CHANNEL-REFS/PHYSICAL-CHANNEL-REF"):
            mapping.addPhysicalChannelRef(ref)

    def readSystemMappingComManagementMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "COM-MANAGEMENT-MAPPINGS/COM-MANAGEMENT-MAPPING"):
            com_mapping = mapping.createComManagementMapping(self.getShortName(child_element))
            self.readComManagementMapping(child_element, com_mapping)

    def readSystemMappingCryptoServiceMappings(self, element: ET.Element, mapping: SystemMapping):
        for child_element in self.findall(element, "CRYPTO-SERVICE-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SEC-OC-CRYPTO-SERVICE-MAPPING":
                crypto_mapping = mapping.createSecOcCryptoServiceMapping(self.getShortName(child_element))
                self.readSecOcCryptoServiceMapping(child_element, crypto_mapping)
            elif tag_name == "TLS-CRYPTO-SERVICE-MAPPING":
                crypto_mapping = mapping.createTlsCryptoServiceMapping(self.getShortName(child_element))
                self.readTlsCryptoServiceMapping(child_element, crypto_mapping)
            else:
                self.notImplemented("Unsupported CryptoServiceMapping %s" % tag_name)

    def readCryptoEllipticCurveProps(self, element: ET.Element, props: CryptoEllipticCurveProps):
        self.logger.debug("Read CryptoEllipticCurveProps <%s>" % props.getShortName())
        self.readIdentifiable(element, props)
        props.setNamedCurveId(self.getChildElementOptionalPositiveInteger(element, "NAMED-CURVE-ID"))

    def readCryptoSignatureScheme(self, element: ET.Element, scheme: CryptoSignatureScheme):
        self.logger.debug("Read CryptoSignatureScheme <%s>" % scheme.getShortName())
        self.readIdentifiable(element, scheme)
        scheme.setSignatureSchemeId(self.getChildElementOptionalPositiveInteger(element, "SIGNATURE-SCHEME-ID"))

    def readIPSecRule(self, element: ET.Element, rule: IPSecRule):
        self.logger.debug("Read IPSecRule <%s>" % rule.getShortName())
        self.readIdentifiable(element, rule)
        literal = self.getChildElementOptionalLiteral(element, "DIRECTION")
        if literal is not None:
            e = CommunicationDirectionType()
            e.setValue(literal.getValue())
            rule.setDirection(e)
        literal = self.getChildElementOptionalLiteral(element, "HEADER-TYPE")
        if literal is not None:
            e = IPsecHeaderTypeEnum()
            e.setValue(literal.getValue())
            rule.setHeaderType(e)
        literal = self.getChildElementOptionalLiteral(element, "IP-PROTOCOL")
        if literal is not None:
            e = IPsecIpProtocolEnum()
            e.setValue(literal.getValue())
            rule.setIpProtocol(e)
        for ref in self.getChildElementRefTypeList(element, "LOCAL-CERTIFICATE-REFS/LOCAL-CERTIFICATE-REF"):
            rule.addLocalCertificateRef(ref)
        rule.setLocalId(self.getChildElementOptionalString(element, "LOCAL-ID"))
        rule.setLocalPortRangeEnd(self.getChildElementOptionalPositiveInteger(element, "LOCAL-PORT-RANGE-END"))
        rule.setLocalPortRangeStart(self.getChildElementOptionalPositiveInteger(element, "LOCAL-PORT-RANGE-START"))
        literal = self.getChildElementOptionalLiteral(element, "MODE")
        if literal is not None:
            e = IPsecModeEnum()
            e.setValue(literal.getValue())
            rule.setMode(e)
        literal = self.getChildElementOptionalLiteral(element, "POLICY")
        if literal is not None:
            e = IPsecPolicyEnum()
            e.setValue(literal.getValue())
            rule.setPolicy(e)
        rule.setPreSharedKeyRef(self.getChildElementOptionalRefType(element, "PRE-SHARED-KEY-REF"))
        rule.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))
        for ref in self.getChildElementRefTypeList(element, "REMOTE-CERTIFICATE-REFS/REMOTE-CERTIFICATE-REF"):
            rule.addRemoteCertificateRef(ref)
        rule.setRemoteId(self.getChildElementOptionalString(element, "REMOTE-ID"))
        for ref in self.getChildElementRefTypeList(element, "REMOTE-IP-ADDRESS-REFS/REMOTE-IP-ADDRESS-REF"):
            rule.addRemoteIpAddressRef(ref)
        rule.setRemotePortRangeEnd(self.getChildElementOptionalPositiveInteger(element, "REMOTE-PORT-RANGE-END"))
        rule.setRemotePortRangeStart(self.getChildElementOptionalPositiveInteger(element, "REMOTE-PORT-RANGE-START"))

    def readIPSecConfigProps(self, element: ET.Element, props: IPSecConfigProps):
        self.logger.debug("Read IPSecConfigProps <%s>" % props.getShortName())
        self.readIdentifiable(element, props)
        wrapper = self.find(element, "AH-CIPHER-SUITE-NAMES")
        if wrapper is not None:
            for child_element in self.findall(wrapper, "AH-CIPHER-SUITE-NAME"):
                if child_element.text is not None:
                    value = String()
                    value.setValue(child_element.text)
                    props.addAhCipherSuiteName(value)
        literal = self.getChildElementOptionalLiteral(element, "DPD-ACTION")
        if literal is not None:
            e = IPsecDpdActionEnum()
            e.setValue(literal.getValue())
            props.setDpdAction(e)
        props.setDpdDelay(self.getChildElementOptionalTimeValue(element, "DPD-DELAY"))
        wrapper = self.find(element, "ESP-CIPHER-SUITE-NAMES")
        if wrapper is not None:
            for child_element in self.findall(wrapper, "ESP-CIPHER-SUITE-NAME"):
                if child_element.text is not None:
                    value = String()
                    value.setValue(child_element.text)
                    props.addEspCipherSuiteName(value)
        props.setIkeCipherSuiteName(self.getChildElementOptionalString(element, "IKE-CIPHER-SUITE-NAME"))
        props.setIkeOverTime(self.getChildElementOptionalTimeValue(element, "IKE-OVER-TIME"))
        props.setIkeRandTime(self.getChildElementOptionalPositiveInteger(element, "IKE-RAND-TIME"))
        props.setIkeReauthTime(self.getChildElementOptionalTimeValue(element, "IKE-REAUTH-TIME"))
        props.setIkeRekeyTime(self.getChildElementOptionalTimeValue(element, "IKE-REKEY-TIME"))
        props.setSaOverTime(self.getChildElementOptionalPositiveInteger(element, "SA-OVER-TIME"))
        props.setSaRandTime(self.getChildElementOptionalTimeValue(element, "SA-RAND-TIME"))
        props.setSaRekeyTime(self.getChildElementOptionalTimeValue(element, "SA-REKEY-TIME"))

    def readIPSecConfig(self, element: ET.Element, config: IPSecConfig):
        self.logger.debug("Read IPSecConfig")
        config.setIpSecConfigPropsRef(self.getChildElementOptionalRefType(element, "IP-SEC-CONFIG-PROPS-REF"))
        wrapper = self.find(element, "IP-SEC-RULES")
        if wrapper is not None:
            for child_element in self.findall(wrapper, "IP-SEC-RULE"):
                rule = IPSecRule(config, self.getShortName(child_element))
                config.addIPSecRule(rule)
                self.readIPSecRule(child_element, rule)

    def readCryptoServiceCertificate(self, element: ET.Element, certificate: CryptoServiceCertificate):
        self.logger.debug("Read CryptoServiceCertificate <%s>" % certificate.getShortName())
        self.readIdentifiable(element, certificate)
        family = self.getChildElementOptionalLiteral(element, "ALGORITHM-FAMILY")
        if family is not None:
            e = CryptoCertificateAlgorithmFamilyEnum()
            e.setValue(family.getValue())
            certificate.setAlgorithmFamily(e)
        fmt = self.getChildElementOptionalLiteral(element, "FORMAT")
        if fmt is not None:
            e = CryptoCertificateFormatEnum()
            e.setValue(fmt.getValue())
            certificate.setFormat(e)
        certificate.setMaximumLength(self.getChildElementOptionalPositiveInteger(element, "MAXIMUM-LENGTH"))
        certificate.setNextHigherCertificateRef(self.getChildElementOptionalRefType(element, "NEXT-HIGHER-CERTIFICATE-REF"))
        certificate.setServerNameIdentification(self.getChildElementOptionalString(element, "SERVER-NAME-IDENTIFICATION"))

    def readCryptoServicePrimitive(self, element: ET.Element, primitive: CryptoServicePrimitive):
        self.logger.debug("Read CryptoServicePrimitive <%s>" % primitive.getShortName())
        self.readIdentifiable(element, primitive)
        primitive.setAlgorithmFamily(self.getChildElementOptionalString(element, "ALGORITHM-FAMILY"))
        primitive.setAlgorithmMode(self.getChildElementOptionalString(element, "ALGORITHM-MODE"))
        primitive.setAlgorithmSecondaryFamily(self.getChildElementOptionalString(element, "ALGORITHM-SECONDARY-FAMILY"))

    def readSecOcCryptoServiceMapping(self, element: ET.Element, mapping: SecOcCryptoServiceMapping):
        self.readIdentifiable(element, mapping)
        ref = self.getChildElementOptionalRefType(element, "AUTHENTICATION-REF")
        if ref is not None:
            mapping.setAuthenticationRef(ref)
        ref = self.getChildElementOptionalRefType(element, "CRYPTO-SERVICE-KEY-REF")
        if ref is not None:
            mapping.setCryptoServiceKeyRef(ref)
        ref = self.getChildElementOptionalRefType(element, "CRYPTO-SERVICE-QUEUE-REF")
        if ref is not None:
            mapping.setCryptoServiceQueueRef(ref)

    def readTlsCryptoServiceMapping(self, element: ET.Element, mapping: TlsCryptoServiceMapping):
        self.readIdentifiable(element, mapping)
        for ref in self.getChildElementRefTypeList(element, "KEY-EXCHANGE-REFS/KEY-EXCHANGE-REF"):
            mapping.addKeyExchangeRef(ref)
        for suite_element in self.findall(element, "TLS-CIPHER-SUITES/TLS-CRYPTO-CIPHER-SUITE"):
            cipher_suite = TlsCryptoCipherSuite(mapping, self.getShortName(suite_element))
            mapping.addTlsCipherSuite(cipher_suite)
            self.readTlsCryptoCipherSuite(suite_element, cipher_suite)
        mapping.setUseClientAuthenticationRequest(self.getChildElementOptionalBooleanValue(element, "USE-CLIENT-AUTHENTICATION-REQUEST"))
        mapping.setUseSecurityExtensionRecordSizeLimit(self.getChildElementOptionalBooleanValue(element, "USE-SECURITY-EXTENSION-RECORD-SIZE-LIMIT"))

    def readTlsCryptoCipherSuite(self, element: ET.Element, cipher_suite: TlsCryptoCipherSuite):
        self.logger.debug("Read TlsCryptoCipherSuite <%s>" % cipher_suite.getShortName())
        self.readIdentifiable(element, cipher_suite)
        cipher_suite.setAuthenticationRef(self.getChildElementOptionalRefType(element, "AUTHENTICATION-REF"))
        cipher_suite.setCertificateRef(self.getChildElementOptionalRefType(element, "CERTIFICATE-REF"))
        cipher_suite.setCipherSuiteId(self.getChildElementOptionalPositiveInteger(element, "CIPHER-SUITE-ID"))
        cipher_suite.setCipherSuiteShortLabel(self.getChildElementOptionalString(element, "CIPHER-SUITE-SHORT-LABEL"))
        for ref in self.getChildElementRefTypeList(element, "ELLIPTIC-CURVE-REFS/ELLIPTIC-CURVE-REF"):
            cipher_suite.addEllipticCurveRef(ref)
        cipher_suite.setEncryptionRef(self.getChildElementOptionalRefType(element, "ENCRYPTION-REF"))
        for ref in self.getChildElementRefTypeList(element, "KEY-EXCHANGE-AUTHENTICATION-REFS/KEY-EXCHANGE-AUTHENTICATION-REF"):
            cipher_suite.addKeyExchangeAuthenticationRef(ref)
        for ref in self.getChildElementRefTypeList(element, "KEY-EXCHANGE-REFS/KEY-EXCHANGE-REF"):
            cipher_suite.addKeyExchangeRef(ref)
        cipher_suite.setPriority(self.getChildElementOptionalPositiveInteger(element, "PRIORITY"))
        props_element = self.find(element, "PROPS")
        if props_element is not None:
            props = TlsCryptoCipherSuiteProps(cipher_suite, self.getShortName(props_element))
            self.readTlsCryptoCipherSuiteProps(props_element, props)
            cipher_suite.setProps(props)
        psk_element = self.find(element, "PSK-IDENTITY")
        if psk_element is not None:
            psk_identity = TlsPskIdentity()
            self.readTlsPskIdentity(psk_element, psk_identity)
            cipher_suite.setPskIdentity(psk_identity)
        cipher_suite.setRemoteCertificateRef(self.getChildElementOptionalRefType(element, "REMOTE-CERTIFICATE-REF"))
        for ref in self.getChildElementRefTypeList(element, "SIGNATURE-SCHEME-REFS/SIGNATURE-SCHEME-REF"):
            cipher_suite.addSignatureSchemeRef(ref)
        literal = self.getChildElementOptionalLiteral(element, "VERSION")
        if literal is not None:
            e = TlsVersionEnum()
            e.setValue(literal.getValue())
            cipher_suite.setVersion(e)

    def readTlsPskIdentity(self, element: ET.Element, psk_identity: TlsPskIdentity):
        ref = self.getChildElementOptionalRefType(element, "PRE-SHARED-KEY-REF")
        if ref is not None:
            psk_identity.setPreSharedKeyRef(ref)
        psk_identity.setPskIdentity(self.getChildElementOptionalString(element, "PSK-IDENTITY"))
        psk_identity.setPskIdentityHint(self.getChildElementOptionalString(element, "PSK-IDENTITY-HINT"))

    def readTlsCryptoCipherSuiteProps(self, element: ET.Element, cipher_suite_props: TlsCryptoCipherSuiteProps):
        self.readIdentifiable(element, cipher_suite_props)
        cipher_suite_props.setTcpIpTlsUseSecurityExtensionForceEncryptThenMac(self.getChildElementOptionalBooleanValue(element, "TCP-IP-TLS-USE-SECURITY-EXTENSION-FORCE-ENCRYPT-THEN-MAC"))

    def readTlvDataIdDefinition(self, element: ET.Element, tlv_data_id_definition: TlvDataIdDefinition):
        tlv_data_id_definition.setId(self.getChildElementOptionalPositiveInteger(element, "ID"))
        tlv_data_id_definition.setTlvArgumentRef(self.getChildElementOptionalRefType(element, "TLV-ARGUMENT-REF"))
        tlv_data_id_definition.setTlvImplementationDataTypeElementRef(self.getChildElementOptionalRefType(element, "TLV-IMPLEMENTATION-DATA-TYPE-ELEMENT-REF"))
        tlv_data_id_definition.setTlvRecordElementRef(self.getChildElementOptionalRefType(element, "TLV-RECORD-ELEMENT-REF"))

    def readTlvDataIdDefinitionSetTlvDataIdDefinitions(self, element: ET.Element, tlv_data_id_definition_set: TlvDataIdDefinitionSet):
        for child_element in self.findall(element, "TLV-DATA-ID-DEFINITIONS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "TLV-DATA-ID-DEFINITION":
                tlv_data_id_definition = TlvDataIdDefinition()
                self.readTlvDataIdDefinition(child_element, tlv_data_id_definition)
                tlv_data_id_definition_set.addTlvDataIdDefinition(tlv_data_id_definition)
            else:
                self.notImplemented("Unsupported TlvDataIdDefinition <%s>" % tag_name)

    def readTlvDataIdDefinitionSet(self, element: ET.Element, tlv_data_id_definition_set: TlvDataIdDefinitionSet):
        self.logger.debug("Read TlvDataIdDefinitionSet <%s>" % tlv_data_id_definition_set.getShortName())
        self.readARElement(element, tlv_data_id_definition_set)
        self.readTlvDataIdDefinitionSetTlvDataIdDefinitions(element, tlv_data_id_definition_set)

    def readSystemMapping(self, element: ET.Element, mapping: SystemMapping):
        # self.logger.debug("Read SystemMapping <%s>" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        self.readSystemMappingAppOsTaskProxyToEcuTaskProxyMappings(element, mapping)
        self.readSystemMappingApplicationPartitionToEcuPartitionMappings(element, mapping)
        self.readSystemMappingComManagementMappings(element, mapping)
        self.readSystemMappingCryptoServiceMappings(element, mapping)
        self.readSystemMappingDataMappings(element, mapping)
        self.readSystemMappingEcuResourceMappings(element, mapping)
        self.readSystemMappingSwImplMappings(element, mapping)
        self.readSystemMappingSwMappings(element, mapping)

    def readSystemMappings(self, element: ET.Element, system: System):
        for child_element in self.findall(element, "MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "SYSTEM-MAPPING":
                mapping = system.createSystemMapping(self.getShortName(child_element))
                self.readSystemMapping(child_element, mapping)
            else:
                self.notImplemented("Unsupported Mapping %s" % tag_name)

    def readRootSwCompositionPrototype(self, element: ET.Element, system: System):
        child_element = self.find(element, "ROOT-SOFTWARE-COMPOSITIONS/ROOT-SW-COMPOSITION-PROTOTYPE")
        if child_element is not None:
            short_name = self.getShortName(child_element)
            self.logger.debug("Read RootSwCompositionPrototype %s" % short_name)
            prototype = system.createRootSoftwareComposition(short_name)
            self.readIdentifiable(child_element, prototype)
            for ref in self.getChildElementRefTypeList(child_element, "CALIBRATION-PARAMETER-VALUE-SET-REFS/CALIBRATION-PARAMETER-VALUE-SET-REF"):
                prototype.addCalibrationParameterValueSetRef(ref)
            prototype.setFlatMapRef(self.getChildElementOptionalRefType(child_element, "FLAT-MAP-REF"))
            prototype.setSoftwareCompositionTRef(self.getChildElementOptionalRefType(child_element, "SOFTWARE-COMPOSITION-TREF"))
            try:
                document = AUTOSAR.getInstance()
                document.setRootSwCompositionPrototype(prototype)
            except ValueError as e:
                self.raiseWarning("%s" % e)

    def readSystemFibexElementRefs(self, element: ET.Element, system: System):
        for ref in self.getChildElementRefTypeList(element, "FIBEX-ELEMENTS/FIBEX-ELEMENT-REF-CONDITIONAL/FIBEX-ELEMENT-REF"):
            system.addFibexElementRef(ref)

    def readSystemDocumentations(self, element: ET.Element, system: System):
        for chapter_element in self.findall(element, "SYSTEM-DOCUMENTATIONS/CHAPTER"):
            chapter = system.createSystemDocumentation(self.getShortName(chapter_element))
            self.readChapterBody(chapter_element, chapter)

    def readSystemClientIdDefinitionSetRefs(self, element: ET.Element, system: System):
        for ref in self.getChildElementRefTypeList(element, "CLIENT-ID-DEFINITION-SET-REFS/CLIENT-ID-DEFINITION-SET-REF"):
            system.addClientIdDefinitionSetRef(ref)

    def readClientIdDefinition(self, element: ET.Element, id_definition: ClientIdDefinition):
        self.readIdentifiable(element, id_definition)
        id_definition.setClientId(self.getChildElementOptionalNumerical(element, "CLIENT-ID"))
        id_definition.setClientServerOperationIRef(self.getOperationInSystemInstanceRef(self.find(element, "CLIENT-SERVER-OPERATION-IREF")))

    def readClientIdDefinitionSet(self, element: ET.Element, id_definition_set: ClientIdDefinitionSet):
        self.logger.debug("Read ClientIdDefinitionSet <%s>" % id_definition_set.getShortName())
        self.readARElement(element, id_definition_set)
        wrapper_element = self.find(element, "CLIENT-ID-DEFINITIONS")
        if wrapper_element is not None:
            for child_element in self.findall(wrapper_element, "CLIENT-ID-DEFINITION"):
                id_definition = id_definition_set.createClientIdDefinition(self.getShortName(child_element))
                self.readClientIdDefinition(child_element, id_definition)

    def readInterpolationRoutine(self, element: ET.Element, interpolation_routine: InterpolationRoutine):
        self.logger.debug("Read InterpolationRoutine")
        interpolation_routine.setShortLabel(self.getChildElementOptionalLiteral(element, "SHORT-LABEL"))
        interpolation_routine.setIsDefault(self.getChildElementOptionalBooleanValue(element, "IS-DEFAULT"))
        interpolation_routine.setInterpolationRoutineRef(self.getChildElementOptionalRefType(element, "INTERPOLATION-ROUTINE-REF"))

    def readInterpolationRoutineMapping(self, element: ET.Element, mapping: InterpolationRoutineMapping):
        self.logger.debug("Read InterpolationRoutineMapping")
        wrapper_element = self.find(element, "INTERPOLATION-ROUTINES")
        if wrapper_element is not None:
            for child_element in self.findall(wrapper_element, "INTERPOLATION-ROUTINE"):
                routine = mapping.createInterpolationRoutine()
                self.readInterpolationRoutine(child_element, routine)
        mapping.setSwRecordLayoutRef(self.getChildElementOptionalRefType(element, "SW-RECORD-LAYOUT-REF"))

    def readInterpolationRoutineMappingSet(self, element: ET.Element, mapping_set: InterpolationRoutineMappingSet):
        self.logger.debug("Read InterpolationRoutineMappingSet <%s>" % mapping_set.getShortName())
        self.readARElement(element, mapping_set)
        wrapper_element = self.find(element, "INTERPOLATION-ROUTINE-MAPPINGS")
        if wrapper_element is not None:
            for child_element in self.findall(wrapper_element, "INTERPOLATION-ROUTINE-MAPPING"):
                mapping = mapping_set.createInterpolationRoutineMapping()
                self.readInterpolationRoutineMapping(child_element, mapping)

    def readSwComponentPrototypeAssignment(self, element: ET.Element, assignment: SwComponentPrototypeAssignment):
        self.readARObject(element, assignment)
        assignment.setSwComponentIRef(self.getComponentInSystemInstanceRef(self.find(element, "SW-COMPONENT-IREF")))
        variation_point_element = self.find(element, "VARIATION-POINT")
        if variation_point_element is not None:
            if isinstance(assignment, VariationPointCapable):
                assignment.setVariationPoint(self.readVariationPoint(variation_point_element, VariationPoint()))
            else:
                self.logger.warning("VARIATION-POINT on non-variant element <%s> ignored" % self.getPureTagName(element.tag))

    def readCpSoftwareCluster(self, element: ET.Element, cluster: CpSoftwareCluster):
        self.readARElement(element, cluster)
        cluster.setSoftwareClusterId(self.getChildElementOptionalPositiveInteger(element, "SOFTWARE-CLUSTER-ID"))
        for child_element in self.findall(element, "SW-COMPONENT-ASSIGNMENTS/SW-COMPONENT-PROTOTYPE-ASSIGNMENT"):
            assignment = cluster.createSwComponentAssignment()
            self.readSwComponentPrototypeAssignment(child_element, assignment)
        for ref in self.getChildElementRefTypeList(element, "SW-COMPOSITIONS/COMPOSITION-SW-COMPONENT-TYPE-REF-CONDITIONAL/COMPOSITION-SW-COMPONENT-TYPE-REF"):
            cluster.addSwCompositionRef(ref)

    def readSystemInterpolationRoutineMappingSetRefs(self, element: ET.Element, system: System):
        for ref in self.getChildElementRefTypeList(element, "INTERPOLATION-ROUTINE-MAPPING-SET-REFS/INTERPOLATION-ROUTINE-MAPPING-SET-REF"):
            system.addInterpolationRoutineMappingSetRef(ref)

    def readJ1939SharedAddressCluster(self, element: ET.Element, cluster: J1939SharedAddressCluster):
        self.readIdentifiable(element, cluster)
        for ref in self.getChildElementRefTypeList(element, "PARTICIPATING-J-1939-CLUSTER-REFS/PARTICIPATING-J-1939-CLUSTER-REF"):
            cluster.addParticipatingJ1939ClusterRef(ref)

    def readSystemJ1939SharedAddressClusters(self, element: ET.Element, system: System):
        for child_element in self.findall(element, "J-1939-SHARED-ADDRESS-CLUSTERS/J-1939-SHARED-ADDRESS-CLUSTER"):
            cluster = system.createJ1939SharedAddressCluster(self.getShortName(child_element))
            self.readJ1939SharedAddressCluster(child_element, cluster)

    def readSystemSwClusterRefs(self, element: ET.Element, system: System):
        for ref in self.getChildElementRefTypeList(element, "SW-CLUSTERS/CP-SOFTWARE-CLUSTER-REF-CONDITIONAL/CP-SOFTWARE-CLUSTER-REF"):
            system.addSwClusterRef(ref)

    def readSystem(self, element: ET.Element, system: System):
        self.logger.debug("Read System <%s>" % system.getShortName())
        self.readIdentifiable(element, system)
        self.readSystemDocumentations(element, system)
        self.readSystemClientIdDefinitionSetRefs(element, system)
        system.setContainerIPduHeaderByteOrder(self.getChildElementOptionalLiteral(element, "CONTAINER-I-PDU-HEADER-BYTE-ORDER"))
        system.setEcuExtractVersion(self.getChildElementOptionalRevisionLabelString(element, "ECU-EXTRACT-VERSION"))
        self.readSystemFibexElementRefs(element, system)
        self.readSystemInterpolationRoutineMappingSetRefs(element, system)
        self.readSystemJ1939SharedAddressClusters(element, system)
        self.readSystemMappings(element, system)
        system.setPncVectorLength(self.getChildElementOptionalPositiveInteger(element, "PNC-VECTOR-LENGTH"))
        system.setPncVectorOffset(self.getChildElementOptionalPositiveInteger(element, "PNC-VECTOR-OFFSET"))
        self.readRootSwCompositionPrototype(element, system)
        self.readSystemSwClusterRefs(element, system)
        system.setSystemVersion(self.getChildElementOptionalRevisionLabelString(element, "SYSTEM-VERSION"))
        document = AUTOSAR.getInstance()
        document.addSystem(system)

    def readGenericEthernetFrame(self, element: ET.Element, frame: GenericEthernetFrame):
        self.logger.debug("Read GenericEthernetFrame <%s>" % frame.getShortName())
        self.readFrame(element, frame)

    def getLifeCyclePeriod(self, element: ET.Element, key: str) -> LifeCyclePeriod:
        child_element = self.find(element, key)
        period = None
        if child_element is not None:
            period = LifeCyclePeriod()
            period.setDate(self.getChildElementOptionalDateTime(child_element, "DATE"))
            period.setArReleaseVersion(self.getChildElementOptionalRevisionLabelString(child_element, "AR-RELEASE-VERSION"))
            period.setProductRelease(self.getChildElementOptionalRevisionLabelString(child_element, "PRODUCT-RELEASE"))
        return period

    def readLifeCycleInfoUseInsteadRefs(self, element: ET.Element, info: LifeCycleInfo):
        for ref in self.getChildElementRefTypeList(element, "USE-INSTEAD-REFS/USE-INSTEAD-REF"):
            info.addUseInsteadRef(ref)

    def readLifeCycleInfo(self, element: ET.Element, info: LifeCycleInfo):
        self.readARObject(element, info)
        info.setLcObjectRef(self.getChildElementOptionalRefType(element, "LC-OBJECT-REF"))
        info.setLcStateRef(self.getChildElementOptionalRefType(element, "LC-STATE-REF"))
        info.setPeriodBegin(self.getLifeCyclePeriod(element, "PERIOD-BEGIN"))
        info.setPeriodEnd(self.getLifeCyclePeriod(element, "PERIOD-END"))
        info.setRemark(self.getDocumentationBlock(element, "REMARK"))
        self.readLifeCycleInfoUseInsteadRefs(element, info)

    def readLifeCycleInfoSetLifeCycleInfos(self, element: ET.Element, info_set: LifeCycleInfoSet):
        for child_element in self.findall(element, "LIFE-CYCLE-INFOS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "LIFE-CYCLE-INFO":
                info = LifeCycleInfo()
                self.readLifeCycleInfo(child_element, info)
                info_set.addLifeCycleInfo(info)
            else:
                self.notImplemented("Unsupported Life Cycle Info <%s>" % tag_name)

    def readLifeCycleInfoSet(self, element: ET.Element, info_set: LifeCycleInfoSet):
        self.logger.debug("Read LifeCycleInfoSet <%s>" % info_set.getShortName())
        self.readIdentifiable(element, info_set)
        info_set.setDefaultLcStateRef(self.getChildElementOptionalRefType(element, "DEFAULT-LC-STATE-REF"))
        info_set.setDefaultPeriodBegin(self.getLifeCyclePeriod(element, "DEFAULT-PERIOD-BEGIN"))
        info_set.setDefaultPeriodEnd(self.getLifeCyclePeriod(element, "DEFAULT-PERIOD-END"))
        self.readLifeCycleInfoSetLifeCycleInfos(element, info_set)
        info_set.setUsedLifeCycleStateDefinitionGroupRef(self.getChildElementOptionalRefType(element, "USED-LIFE-CYCLE-STATE-DEFINITION-GROUP-REF"))

    def readFlatInstanceDescriptor(self, element: ET.Element, desc: FlatInstanceDescriptor):
        self.logger.debug("Read FlatInstanceDescriptor %s" % desc.getShortName())
        self.readIdentifiable(element, desc)
        desc.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        rte_plugin_props_element = self.find(element, "RTE-PLUGIN-PROPS")
        if rte_plugin_props_element is not None:
            rte_plugin_props = RtePluginProps()
            self.readRtePluginProps(rte_plugin_props_element, rte_plugin_props)
            desc.setRtePluginProps(rte_plugin_props)
        desc.setSwDataDefProps(self.getSwDataDefProps(element, "SW-DATA-DEF-PROPS"))
        desc.setUpstreamReferenceIRef(self.getAnyInstanceRef(element, "UPSTREAM-REFERENCE-IREF"))
        desc.setEcuExtractReferenceIRef(self.getAnyInstanceRef(element, "ECU-EXTRACT-REFERENCE-IREF"))

    def readRtePluginProps(self, element: ET.Element, props: RtePluginProps):
        self.logger.debug("Read RtePluginProps")
        props.setAssociatedCrossSwClusterComRtePluginRef(self.getChildElementOptionalRefType(element, "ASSOCIATED-CROSS-SW-CLUSTER-COM-RTE-PLUGIN-REF"))
        props.setAssociatedRtePluginRef(self.getChildElementOptionalRefType(element, "ASSOCIATED-RTE-PLUGIN-REF"))

    def readFlatMapInstances(self, element: ET.Element, map: FlatMap):
        for child_element in self.findall(element, "INSTANCES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "FLAT-INSTANCE-DESCRIPTOR":
                desc = map.createFlatInstanceDescriptor(self.getShortName(child_element))
                self.readFlatInstanceDescriptor(child_element, desc)
            else:
                self.notImplemented("Unsupported Flat Map Instances <%s>" % tag_name)

    def readFlatMap(self, element: ET.Element, map: FlatMap):
        self.logger.debug("Read FlatMap <%s>" % map.getShortName())
        self.readIdentifiable(element, map)
        self.readFlatMapInstances(element, map)

    def getDataPrototypeMappings(self, element: ET.Element, key: str) -> List[DataPrototypeMapping]:
        mappings = []
        for child_element in self.findall(element, "%s/DATA-PROTOTYPE-MAPPING" % key):
            mapping = DataPrototypeMapping()
            mapping.setFirstDataPrototypeRef(self.getChildElementOptionalRefType(child_element, "FIRST-DATA-PROTOTYPE-REF"))
            mapping.setFirstToSecondDataTransformationRef(self.getChildElementOptionalRefType(child_element, "FIRST-TO-SECOND-DATA-TRANSFORMATION-REF"))
            mapping.setSecondDataPrototypeRef(self.getChildElementOptionalRefType(child_element, "SECOND-DATA-PROTOTYPE-REF"))
            mapping.setSecondToFirstDataTransformationRef(self.getChildElementOptionalRefType(child_element, "SECOND-TO-FIRST-DATA-TRANSFORMATION-REF"))
            for sub_element in self.findall(child_element, "SUB-ELEMENT-MAPPINGS/SUB-ELEMENT-MAPPING"):
                mapping.addSubElementMapping(self.getSubElementMapping(sub_element))
            for text_table in self.findall(child_element, "TEXT-TABLE-MAPPINGS/TEXT-TABLE-MAPPING"):
                mapping.addTextTableMapping(self.getTextTableMapping(text_table))
            mappings.append(mapping)
        return mappings

    def getSubElementMapping(self, element: ET.Element) -> SubElementMapping:
        mapping = SubElementMapping()
        for ref_element in self.findall(element, "FIRST-ELEMENTS/*"):
            if self.getTagName(ref_element) == "APPLICATION-COMPOSITE-DATA-TYPE-SUB-ELEMENT-REF":
                mapping.setFirstElement(self.getApplicationCompositeDataTypeSubElementRef(ref_element))
            else:
                self.notImplemented("Unsupported firstElement SubElementRef <%s>" % self.getTagName(ref_element))
        for ref_element in self.findall(element, "SECOND-ELEMENTS/*"):
            if self.getTagName(ref_element) == "APPLICATION-COMPOSITE-DATA-TYPE-SUB-ELEMENT-REF":
                mapping.setSecondElement(self.getApplicationCompositeDataTypeSubElementRef(ref_element))
            else:
                self.notImplemented("Unsupported secondElement SubElementRef <%s>" % self.getTagName(ref_element))
        for text_table in self.findall(element, "TEXT-TABLE-MAPPINGS/TEXT-TABLE-MAPPING"):
            mapping.addTextTableMapping(self.getTextTableMapping(text_table))
        return mapping

    def getApplicationCompositeDataTypeSubElementRef(self, element: ET.Element) -> ApplicationCompositeDataTypeSubElementRef:
        sub_element_ref = ApplicationCompositeDataTypeSubElementRef()
        sub_element_ref.setApplicationCompositeElementIRef(self.getApplicationCompositeElementInPortInterfaceInstanceRef(element, "APPLICATION-COMPOSITE-ELEMENT-IREF"))
        return sub_element_ref

    def getTextTableMapping(self, element: ET.Element) -> TextTableMapping:
        mapping = TextTableMapping()
        mapping.setBitfieldTextTableMaskFirst(self.getChildElementOptionalPositiveInteger(element, "BITFIELD-TEXT-TABLE-MASK-FIRST"))
        mapping.setBitfieldTextTableMaskSecond(self.getChildElementOptionalPositiveInteger(element, "BITFIELD-TEXT-TABLE-MASK-SECOND"))
        mapping.setIdenticalMapping(self.getChildElementOptionalBooleanValue(element, "IDENTICAL-MAPPING"))
        mapping.setMappingDirection(self.getChildElementOptionalLiteral(element, "MAPPING-DIRECTION"))
        for pair_element in self.findall(element, "VALUE-PAIRS/TEXT-TABLE-VALUE-PAIR"):
            mapping.addValuePair(self.getTextTableValuePair(pair_element))
        return mapping

    def getTextTableValuePair(self, element: ET.Element) -> TextTableValuePair:
        value_pair = TextTableValuePair()
        value_pair.setFirstValue(self.getChildElementOptionalNumerical(element, "FIRST-VALUE"))
        value_pair.setSecondValue(self.getChildElementOptionalNumerical(element, "SECOND-VALUE"))
        return value_pair

    def readVariableAndParameterInterfaceMapping(self, element: ET.Element, mapping: VariableAndParameterInterfaceMapping):
        # self.logger.debug("Read VariableAndParameterInterfaceMapping %s" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        for item in self.getDataPrototypeMappings(element, "DATA-MAPPINGS"):
            mapping.addDataMapping(item)

    def readClientServerOperationMapping(self, element: ET.Element, mapping: ClientServerOperationMapping):
        for item in self.getDataPrototypeMappings(element, "ARGUMENT-MAPPINGS"):
            mapping.addArgumentMapping(item)
        mapping.setFirstOperationRef(self.getChildElementOptionalRefType(element, "FIRST-OPERATION-REF"))
        mapping.setFirstToSecondDataTransformationRef(self.getChildElementOptionalRefType(element, "FIRST-TO-SECOND-DATA-TRANSFORMATION-REF"))
        mapping.setSecondOperationRef(self.getChildElementOptionalRefType(element, "SECOND-OPERATION-REF"))

    def readClientServerApplicationErrorMapping(self, element: ET.Element, mapping: ClientServerApplicationErrorMapping):
        mapping.setFirstApplicationErrorRef(self.getChildElementOptionalRefType(element, "FIRST-APPLICATION-ERROR-REF"))
        mapping.setSecondApplicationErrorRef(self.getChildElementOptionalRefType(element, "SECOND-APPLICATION-ERROR-REF"))

    def readClientServerInterfaceMappingErrorMappings(self, element: ET.Element, mapping: ClientServerInterfaceMapping):
        for child_element in self.findall(element, "ERROR-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CLIENT-SERVER-APPLICATION-ERROR-MAPPING":
                error_mapping = ClientServerApplicationErrorMapping()
                self.readClientServerApplicationErrorMapping(child_element, error_mapping)
                mapping.addErrorMapping(error_mapping)
            else:
                self.notImplemented("Unsupported Error Mapping <%s>" % tag_name)

    def readClientServerInterfaceMappingOperationMappings(self, element: ET.Element, mapping: ClientServerInterfaceMapping):
        for child_element in self.findall(element, "OPERATION-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "CLIENT-SERVER-OPERATION-MAPPING":
                operation_mapping = ClientServerOperationMapping()
                self.readClientServerOperationMapping(child_element, operation_mapping)
                mapping.addOperationMapping(operation_mapping)
            else:
                self.notImplemented("Unsupported Operation Mapping <%s>" % tag_name)

    def readClientServerInterfaceMapping(self, element: ET.Element, mapping: ClientServerInterfaceMapping):
        # self.logger.debug("Read ClientServerInterfaceMapping %s" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        self.readClientServerInterfaceMappingErrorMappings(element, mapping)
        self.readClientServerInterfaceMappingOperationMappings(element, mapping)

    def readModeInterfaceMappingModeMapping(self, element: ET.Element, mapping: ModeInterfaceMapping):
        child_element = self.find(element, "MODE-MAPPING")
        if child_element is not None:
            mode_mapping = ModeDeclarationGroupPrototypeMapping()
            mode_mapping.setFirstModeGroupRef(self.getChildElementOptionalRefType(child_element, "FIRST-MODE-GROUP-REF"))
            mode_mapping.setModeDeclarationMappingSetRef(self.getChildElementOptionalRefType(child_element, "MODE-DECLARATION-MAPPING-SET-REF"))
            mode_mapping.setSecondModeGroupRef(self.getChildElementOptionalRefType(child_element, "SECOND-MODE-GROUP-REF"))
            mapping.setModeMapping(mode_mapping)

    def readModeInterfaceMapping(self, element: ET.Element, mapping: ModeInterfaceMapping):
        # self.logger.debug("Read ModeInterfaceMapping %s" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        self.readModeInterfaceMappingModeMapping(element, mapping)

    def readField(self, element: ET.Element, field: Field):
        self.readIdentifiable(element, field)
        field.setHasGetter(self.getChildElementOptionalBooleanValue(element, "HAS-GETTER"))
        field.setHasNotifier(self.getChildElementOptionalBooleanValue(element, "HAS-NOTIFIER"))
        field.setHasSetter(self.getChildElementOptionalBooleanValue(element, "HAS-SETTER"))

    def readTriggerMapping(self, element: ET.Element, trigger_mapping: TriggerMapping):
        trigger_mapping.setFirstTriggerRef(self.getChildElementOptionalRefType(element, "FIRST-TRIGGER-REF"))
        trigger_mapping.setSecondTriggerRef(self.getChildElementOptionalRefType(element, "SECOND-TRIGGER-REF"))

    def readTriggerInterfaceMappingTriggerMappings(self, element: ET.Element, mapping: TriggerInterfaceMapping):
        for child_element in self.findall(element, "TRIGGER-MAPPINGS/TRIGGER-MAPPING"):
            trigger_mapping = TriggerMapping()
            self.readTriggerMapping(child_element, trigger_mapping)
            mapping.addTriggerMapping(trigger_mapping)

    def readTriggerInterfaceMapping(self, element: ET.Element, mapping: TriggerInterfaceMapping):
        # self.logger.debug("Read TriggerInterfaceMapping %s" % mapping.getShortName())
        self.readIdentifiable(element, mapping)
        self.readTriggerInterfaceMappingTriggerMappings(element, mapping)

    def readPortInterfaceMappings(self, element: ET.Element, mapping_set: PortInterfaceMappingSet):
        for child_element in self.findall(element, "PORT-INTERFACE-MAPPINGS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VARIABLE-AND-PARAMETER-INTERFACE-MAPPING":
                mapping = mapping_set.createVariableAndParameterInterfaceMapping(self.getShortName(child_element))
                self.readVariableAndParameterInterfaceMapping(child_element, mapping)
            elif tag_name == "CLIENT-SERVER-INTERFACE-MAPPING":
                mapping = mapping_set.createClientServerInterfaceMapping(self.getShortName(child_element))
                self.readClientServerInterfaceMapping(child_element, mapping)
            elif tag_name == "MODE-INTERFACE-MAPPING":
                mapping = mapping_set.createModeInterfaceMapping(self.getShortName(child_element))
                self.readModeInterfaceMapping(child_element, mapping)
            elif tag_name == "TRIGGER-INTERFACE-MAPPING":
                mapping = mapping_set.createTriggerInterfaceMapping(self.getShortName(child_element))
                self.readTriggerInterfaceMapping(child_element, mapping)
            else:
                self.notImplemented("Unsupported PortInterfaceMapping <%s>" % tag_name)

    def readPortInterfaceMappingSet(self, element: ET.Element, mapping_set: PortInterfaceMappingSet):
        self.logger.debug("Read PortInterfaceMappingSet %s" % mapping_set.getShortName())
        self.readIdentifiable(element, mapping_set)
        self.readPortInterfaceMappings(element, mapping_set)

    def readARPackageElements(self, element: ET.Element, parent: ARPackage):
        for child_element in self.findall(element, "ELEMENTS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "COMPOSITION-SW-COMPONENT-TYPE":
                type = parent.createCompositionSwComponentType(self.getShortName(child_element))
                self.readCompositionSwComponentType(child_element, type)
            elif tag_name == "COLLECTION":
                collection = parent.createCollection(self.getShortName(child_element))
                self.readCollection(child_element, collection)
            elif tag_name == "BUILD-ACTION-MANIFEST":
                manifest = parent.createBuildActionManifest(self.getShortName(child_element))
                self.readBuildActionManifest(child_element, manifest)
            elif tag_name == "DATA-PROTOTYPE-GROUP":
                data_group = parent.createDataPrototypeGroup(self.getShortName(child_element))
                self.readDataPrototypeGroup(child_element, data_group)
            elif tag_name == "RUNNABLE-ENTITY-GROUP":
                runnable_group = parent.createRunnableEntityGroup(self.getShortName(child_element))
                self.readRunnableEntityGroup(child_element, runnable_group)
            elif tag_name == "CONSISTENCY-NEEDS":
                consistency_needs = parent.createConsistencyNeeds(self.getShortName(child_element))
                self.readConsistencyNeeds(child_element, consistency_needs)
            elif tag_name == "COMPLEX-DEVICE-DRIVER-SW-COMPONENT-TYPE":
                type = parent.createComplexDeviceDriverSwComponentType(self.getShortName(child_element))
                self.readComplexDeviceDriverSwComponentType(child_element, type)
            elif tag_name == "SWC-IMPLEMENTATION":
                impl = parent.createSwcImplementation(self.getShortName(child_element))
                self.readSwcImplementation(child_element, impl)
            elif tag_name == "APPLICATION-DEFERRED-DATA-TYPE":
                data_type = parent.createApplicationDeferredDataType(self.getShortName(child_element))
                self.readApplicationDeferredDataType(child_element, data_type)
            elif tag_name == "APPLICATION-PRIMITIVE-DATA-TYPE":
                data_type = parent.createApplicationPrimitiveDataType(self.getShortName(child_element))
                self.readApplicationPrimitiveDataType(child_element, data_type)
            elif tag_name == "APPLICATION-RECORD-DATA-TYPE":
                data_type = parent.createApplicationRecordDataType(self.getShortName(child_element))
                self.readApplicationRecordDataType(child_element, data_type)
            elif tag_name == "SW-BASE-TYPE":
                data_type = parent.createSwBaseType(self.getShortName(child_element))
                self.readSwBaseType(child_element, data_type)
            elif tag_name == "COMPU-METHOD":
                compu_method = parent.createCompuMethod(self.getShortName(child_element))
                self.readCompuMethod(child_element, compu_method)
            elif tag_name == "CONSTANT-SPECIFICATION":
                spec = parent.createConstantSpecification(self.getShortName(child_element))
                self.readConstantSpecification(child_element, spec)
            elif tag_name == "DATA-CONSTR":
                constr = parent.createDataConstr(self.getShortName(child_element))
                self.readDataConstr(child_element, constr)
            elif tag_name == "END-TO-END-PROTECTION-SET":
                protection_set = parent.createEndToEndProtectionSet(self.getShortName(child_element))
                self.readEndToEndProtectionSet(child_element, protection_set)
            elif tag_name == "SENDER-RECEIVER-INTERFACE":
                sr_interface = parent.createSenderReceiverInterface(self.getShortName(child_element))
                self.readSenderReceiverInterface(child_element, sr_interface)
            elif tag_name == "UNIT":
                unit = parent.createUnit(self.getShortName(child_element))
                self.readUnit(child_element, unit)
            elif tag_name == "UNIT-GROUP":
                unit_group = parent.createUnitGroup(self.getShortName(child_element))
                self.readUnitGroup(child_element, unit_group)
            elif tag_name == "BSW-MODULE-DESCRIPTION":
                desc = parent.createBswModuleDescription(self.getShortName(child_element))
                self.readBswModuleDescription(child_element, desc)
            elif tag_name == "BSW-MODULE-ENTRY":
                entry = parent.createBswModuleEntry(self.getShortName(child_element))
                self.readBswModuleEntry(child_element, entry)
            elif tag_name == "BSW-ENTRY-RELATIONSHIP-SET":
                entry_set = parent.createBswEntryRelationshipSet(self.getShortName(child_element))
                self.readBswEntryRelationshipSet(child_element, entry_set)
            elif tag_name == "SWC-BSW-MAPPING":
                mapping = parent.createSwcBswMapping(self.getShortName(child_element))
                self.readSwcBswMapping(child_element, mapping)
            elif tag_name == "BSW-IMPLEMENTATION":
                impl = parent.createBswImplementation(self.getShortName(child_element))
                self.readBswImplementation(child_element, impl)
            elif tag_name == "IMPLEMENTATION-DATA-TYPE":
                data_type = parent.createImplementationDataType(self.getShortName(child_element))
                self.readImplementationDataType(child_element, data_type)
            elif tag_name == "CLIENT-SERVER-INTERFACE":
                cs_interface = parent.createClientServerInterface(self.getShortName(child_element))
                self.readClientServerInterface(child_element, cs_interface)
            elif tag_name == "APPLICATION-SW-COMPONENT-TYPE":
                sw_component = parent.createApplicationSwComponentType(self.getShortName(child_element))
                self.readApplicationSwComponentType(child_element, sw_component)
            elif tag_name == "ECU-ABSTRACTION-SW-COMPONENT-TYPE":
                sw_component = parent.createEcuAbstractionSwComponentType(self.getShortName(child_element))
                self.readEcuAbstractionSwComponentType(child_element, sw_component)
            elif tag_name == "APPLICATION-ARRAY-DATA-TYPE":
                data_type = parent.createApplicationArrayDataType(self.getShortName(child_element))
                self.readApplicationArrayDataType(child_element, data_type)
            elif tag_name == "SW-RECORD-LAYOUT":
                layout = parent.createSwRecordLayout(self.getShortName(child_element))
                self.readSwRecordLayout(child_element, layout)
            elif tag_name == "SW-ADDR-METHOD":
                method = parent.createSwAddrMethod(self.getShortName(child_element))
                self.readSwAddrMethod(child_element, method)
            elif tag_name == "TRIGGER-INTERFACE":
                trigger_if = parent.createTriggerInterface(self.getShortName(child_element))
                self.readTriggerInterface(child_element, trigger_if)
            elif tag_name == "SERVICE-SW-COMPONENT-TYPE":
                sw_component = parent.createServiceSwComponentType(self.getShortName(child_element))
                self.readServiceSwComponentType(child_element, sw_component)
            elif tag_name == "SENSOR-ACTUATOR-SW-COMPONENT-TYPE":
                sw_component = parent.createSensorActuatorSwComponentType(self.getShortName(child_element))
                self.readSensorActuatorSwComponentType(child_element, sw_component)
            elif tag_name == "NV-BLOCK-SW-COMPONENT-TYPE":
                sw_component = parent.createNvBlockSwComponentType(self.getShortName(child_element))
                self.readNvBlockSwComponentType(child_element, sw_component)
            elif tag_name == "SERVICE-PROXY-SW-COMPONENT-TYPE":
                sw_component = parent.createServiceProxySwComponentType(self.getShortName(child_element))
                self.readServiceProxySwComponentType(child_element, sw_component)
            elif tag_name == "DATA-TYPE-MAPPING-SET":
                mapping_set = parent.createDataTypeMappingSet(self.getShortName(child_element))
                self.readDataTypeMappingSet(child_element, mapping_set)
            elif tag_name == "MODE-DECLARATION-GROUP":
                group = parent.createModeDeclarationGroup(self.getShortName(child_element))
                self.readModeDeclarationGroup(child_element, group)
            elif tag_name == "MODE-SWITCH-INTERFACE":
                mode_interface = parent.createModeSwitchInterface(self.getShortName(child_element))
                self.readModeSwitchInterface(child_element, mode_interface)
            elif tag_name == "SWC-TIMING":
                timing = parent.createSwcTiming(self.getShortName(child_element))
                self.readSwcTiming(child_element, timing)
            elif tag_name == "LIN-CLUSTER":
                cluster = parent.createLinCluster(self.getShortName(child_element))
                self.readLinCluster(child_element, cluster)
            elif tag_name == "LIN-UNCONDITIONAL-FRAME":
                frame = parent.createLinUnconditionalFrame(self.getShortName(child_element))
                self.readLinUnconditionalFrame(child_element, frame)
            elif tag_name == "NM-PDU":
                pdu = parent.createNmPdu(self.getShortName(child_element))
                self.readNmPdu(child_element, pdu)
            elif tag_name == "N-PDU":
                pdu = parent.createNPdu(self.getShortName(child_element))
                self.readNPdu(child_element, pdu)
            elif tag_name == "DCM-I-PDU":
                i_pdu = parent.createDcmIPdu(self.getShortName(child_element))
                self.readDcmIPdu(child_element, i_pdu)
            elif tag_name == "SECURED-I-PDU":
                i_pdu = parent.createSecuredIPdu(self.getShortName(child_element))
                self.readSecuredIPdu(child_element, i_pdu)
            elif tag_name == "NM-CONFIG":
                config = parent.createNmConfig(self.getShortName(child_element))
                self.readNmConfig(child_element, config)
            elif tag_name == "CAN-TP-CONFIG":
                config = parent.createCanTpConfig(self.getShortName(child_element))
                self.readCanTpConfig(child_element, config)
            elif tag_name == "LIN-TP-CONFIG":
                config = parent.createLinTpConfig(self.getShortName(child_element))
                self.readLinTpConfig(child_element, config)
            elif tag_name == "CLIENT-ID-DEFINITION-SET":
                id_definition_set = parent.createClientIdDefinitionSet(self.getShortName(child_element))
                self.readClientIdDefinitionSet(child_element, id_definition_set)
            elif tag_name == "CP-SOFTWARE-CLUSTER":
                cluster = parent.createCpSoftwareCluster(self.getShortName(child_element))
                self.readCpSoftwareCluster(child_element, cluster)
            elif tag_name == "INTERPOLATION-ROUTINE-MAPPING-SET":
                mapping_set = parent.createInterpolationRoutineMappingSet(self.getShortName(child_element))
                self.readInterpolationRoutineMappingSet(child_element, mapping_set)
            elif tag_name == "SYSTEM":
                system = parent.createSystem(self.getShortName(child_element))
                self.readSystem(child_element, system)
            elif tag_name == "ECU-INSTANCE":
                instance = parent.createEcuInstance(self.getShortName(child_element))
                self.readEcuInstance(child_element, instance)
            elif tag_name == "CONSUMED-PROVIDED-SERVICE-INSTANCE-GROUP":
                group = parent.createConsumedProvidedServiceInstanceGroup(self.getShortName(child_element))
                self.readConsumedProvidedServiceInstanceGroup(child_element, group)
            elif tag_name == "GATEWAY":
                gateway = parent.createGateway(self.getShortName(child_element))
                self.readGateway(child_element, gateway)
            elif tag_name == "I-SIGNAL-I-PDU-GROUP":
                group = parent.createISignalIPduGroup(self.getShortName(child_element))
                self.readISignalIPduGroup(child_element, group)
            elif tag_name == "PDUR-I-PDU-GROUP":
                group = parent.createPdurIPduGroup(self.getShortName(child_element))
                self.readPdurIPduGroup(child_element, group)
            elif tag_name == "CAN-CLUSTER":
                cluster = parent.createCanCluster(self.getShortName(child_element))
                self.readCanCluster(child_element, cluster)
            elif tag_name == "J-1939-CLUSTER":
                cluster = parent.createJ1939Cluster(self.getShortName(child_element))
                self.readJ1939Cluster(child_element, cluster)
            elif tag_name == "CAN-FRAME":
                frame = parent.createCanFrame(self.getShortName(child_element))
                self.readCanFrame(child_element, frame)
            elif tag_name == "I-SIGNAL":
                signal = parent.createISignal(self.getShortName(child_element))
                self.readISignal(child_element, signal)
            elif tag_name == "I-SIGNAL-GROUP":
                group = parent.createISignalGroup(self.getShortName(child_element))
                self.readISignalGroup(child_element, group)
            elif tag_name == "I-SIGNAL-I-PDU":
                i_pdu = parent.createISignalIPdu(self.getShortName(child_element))
                self.readISignalIPdu(child_element, i_pdu)
            elif tag_name == "SYSTEM-SIGNAL":
                signal = parent.createSystemSignal(self.getShortName(child_element))
                self.readSystemSignal(child_element, signal)
            elif tag_name == "SYSTEM-SIGNAL-GROUP":
                group = parent.createSystemSignalGroup(self.getShortName(child_element))
                self.readSystemSignalGroup(child_element, group)
            elif tag_name == "SIGNAL-SERVICE-TRANSLATION-PROPS-SET":
                props_set = parent.createSignalServiceTranslationPropsSet(self.getShortName(child_element))
                self.readSignalServiceTranslationPropsSet(child_element, props_set)
            elif tag_name == "ECUC-VALUE-COLLECTION":
                collection = parent.createEcucValueCollection(self.getShortName(child_element))
                self.readEcucValueCollection(child_element, collection)
            elif tag_name == "ETH-TCP-IP-PROPS":
                props = parent.createEthTcpIpProps(self.getShortName(child_element))
                self.readEthTcpIpProps(child_element, props)
            elif tag_name == "ETH-TCP-IP-ICMP-PROPS":
                props = parent.createEthTcpIpIcmpProps(self.getShortName(child_element))
                self.readEthTcpIpIcmpProps(child_element, props)
            elif tag_name == "OS-TASK-PROXY":
                proxy = parent.createOsTaskProxy(self.getShortName(child_element))
                self.readOsTaskProxy(child_element, proxy)
            elif tag_name == "ECUC-MODULE-CONFIGURATION-VALUES":
                values = parent.createEcucModuleConfigurationValues(self.getShortName(child_element))
                self.readEcucModuleConfigurationValues(child_element, values)
            elif tag_name == "MODULE-CONFIGURATION":
                module_configuration = parent.createModuleConfiguration(self.getShortName(child_element))
                self.readModuleConfiguration(child_element, module_configuration)
            elif tag_name == "PHYSICAL-DIMENSION":
                dimension = parent.createPhysicalDimension(self.getShortName(child_element))
                self.readPhysicalDimension(child_element, dimension)
            elif tag_name == "PARAMETER-INTERFACE":
                param_interface = parent.createParameterInterface(self.getShortName(child_element))
                self.readParameterInterface(child_element, param_interface)
            elif tag_name == "GENERIC-ETHERNET-FRAME":
                frame = parent.createGenericEthernetFrame(self.getShortName(child_element))
                self.readGenericEthernetFrame(child_element, frame)
            elif tag_name == "LIFE-CYCLE-INFO-SET":
                info_set = parent.createLifeCycleInfoSet(self.getShortName(child_element))
                self.readLifeCycleInfoSet(child_element, info_set)
            elif tag_name == "FLAT-MAP":
                map = parent.createFlatMap(self.getShortName(child_element))
                self.readFlatMap(child_element, map)
            elif tag_name == "PORT-INTERFACE-MAPPING-SET":
                mapping_set = parent.createPortInterfaceMappingSet(self.getShortName(child_element))
                self.readPortInterfaceMappingSet(child_element, mapping_set)
            elif tag_name == "ETHERNET-CLUSTER":
                cluster = parent.createEthernetCluster(self.getShortName(child_element))
                self.readEthernetCluster(child_element, cluster)
            elif tag_name == "CAN-XL-PROPS":
                can_xl_props = parent.createCanXlProps(self.getShortName(child_element))
                self.readCanXlProps(child_element, can_xl_props)
            elif tag_name == "DIAGNOSTIC-CONNECTION":
                connection = parent.createDiagnosticConnection(self.getShortName(child_element))
                self.readDiagnosticConnection(child_element, connection)
            elif tag_name == "DIAGNOSTIC-SERVICE-TABLE":
                table = parent.createDiagnosticServiceTable(self.getShortName(child_element))
                self.readDiagnosticServiceTable(child_element, table)
            elif tag_name == "DIAGNOSTIC-SESSION":
                session = parent.createDiagnosticSession(self.getShortName(child_element))
                self.readDiagnosticSession(child_element, session)
            elif tag_name == "DIAGNOSTIC-SECURITY-LEVEL":
                security_level = parent.createDiagnosticSecurityLevel(self.getShortName(child_element))
                self.readDiagnosticSecurityLevel(child_element, security_level)
            elif tag_name == "DIAGNOSTIC-ENVIRONMENTAL-CONDITION":
                condition = parent.createDiagnosticEnvironmentalCondition(self.getShortName(child_element))
                self.readDiagnosticEnvironmentalCondition(child_element, condition)
            elif tag_name == "DIAGNOSTIC-ACCESS-PERMISSION":
                permission = parent.createDiagnosticAccessPermission(self.getShortName(child_element))
                self.readDiagnosticAccessPermission(child_element, permission)
            elif tag_name == "DLT-CONTEXT":
                context = parent.createDltContext(self.getShortName(child_element))
                self.readDltContext(child_element, context)
            elif tag_name == "DLT-ECU":
                ecu = parent.createDltEcu(self.getShortName(child_element))
                self.readDltEcu(child_element, ecu)
            elif tag_name == "DOCUMENTATION":
                documentation = parent.createDocumentation(self.getShortName(child_element))
                self.readDocumentation(child_element, documentation)
            elif tag_name == "MULTIPLEXED-I-PDU":
                i_pdu = parent.createMultiplexedIPdu(self.getShortName(child_element))
                self.readMultiplexedIPdu(child_element, i_pdu)
            elif tag_name == "USER-DEFINED-I-PDU":
                i_pdu = parent.createUserDefinedIPdu(self.getShortName(child_element))
                self.readUserDefinedIPdu(child_element, i_pdu)
            elif tag_name == "USER-DEFINED-PDU":
                pdu = parent.createUserDefinedPdu(self.getShortName(child_element))
                self.readUserDefinedPdu(child_element, pdu)
            elif tag_name == "GENERAL-PURPOSE-PDU":
                pdu = parent.createGeneralPurposePdu(self.getShortName(child_element))
                self.readGeneralPurposePdu(child_element, pdu)
            elif tag_name == "GENERAL-PURPOSE-I-PDU":
                i_pdu = parent.createGeneralPurposeIPdu(self.getShortName(child_element))
                self.readGeneralPurposeIPdu(child_element, i_pdu)
            elif tag_name == "SECURE-COMMUNICATION-PROPS-SET":
                prop_set = parent.createSecureCommunicationPropsSet(self.getShortName(child_element))
                self.readSecureCommunicationPropsSet(child_element, prop_set)
            elif tag_name == "CRYPTO-ELLIPTIC-CURVE-PROPS":
                props = parent.createCryptoEllipticCurveProps(self.getShortName(child_element))
                self.readCryptoEllipticCurveProps(child_element, props)
            elif tag_name == "CRYPTO-SIGNATURE-SCHEME":
                scheme = parent.createCryptoSignatureScheme(self.getShortName(child_element))
                self.readCryptoSignatureScheme(child_element, scheme)
            elif tag_name == "CRYPTO-SERVICE-CERTIFICATE":
                certificate = parent.createCryptoServiceCertificate(self.getShortName(child_element))
                self.readCryptoServiceCertificate(child_element, certificate)
            elif tag_name == "IP-SEC-CONFIG-PROPS":
                props = parent.createIPSecConfigProps(self.getShortName(child_element))
                self.readIPSecConfigProps(child_element, props)
            elif tag_name == "CRYPTO-SERVICE-PRIMITIVE":
                primitive = parent.createCryptoServicePrimitive(self.getShortName(child_element))
                self.readCryptoServicePrimitive(child_element, primitive)
            elif tag_name == "SO-AD-ROUTING-GROUP":
                group = parent.createSoAdRoutingGroup(self.getShortName(child_element))
                self.readSoAdRoutingGroup(child_element, group)
            elif tag_name == "TCP-OPTION-FILTER-SET":
                tcp_option_filter_set = parent.createTcpOptionFilterSet(self.getShortName(child_element))
                self.readTcpOptionFilterSet(child_element, tcp_option_filter_set)
            elif tag_name == "SOME-IP-SD-CLIENT-SERVICE-INSTANCE-CONFIG":
                config = parent.createSomeipSdClientServiceInstanceConfig(self.getShortName(child_element))
                self.readSomeipSdClientServiceInstanceConfig(child_element, config)
            elif tag_name == "SOME-IP-SD-CLIENT-EVENT-GROUP-TIMING-CONFIG":
                config = parent.createSomeipSdClientEventGroupTimingConfig(self.getShortName(child_element))
                self.readSomeipSdClientEventGroupTimingConfig(child_element, config)
            elif tag_name == "SOME-IP-SD-SERVER-EVENT-GROUP-TIMING-CONFIG":
                config = parent.createSomeipSdServerEventGroupTimingConfig(self.getShortName(child_element))
                self.readSomeipSdServerEventGroupTimingConfig(child_element, config)
            elif tag_name == "DO-IP-TP-CONFIG":
                config = parent.createDoIpTpConfig(self.getShortName(child_element))
                self.readDoIpTpConfig(child_element, config)
            elif tag_name == "HW-ELEMENT":
                hw_element = parent.createHwElement(self.getShortName(child_element))
                self.readHwElement(child_element, hw_element)
            elif tag_name == "HW-CATEGORY":
                hw_category = parent.createHwCategory(self.getShortName(child_element))
                self.readHwCategory(child_element, hw_category)
            elif tag_name == "HW-TYPE":
                type = parent.createHwType(self.getShortName(child_element))
                self.readHwType(child_element, type)
            elif tag_name == "FLEXRAY-FRAME":
                frame = parent.createFlexrayFrame(self.getShortName(child_element))
                self.readFlexrayFrame(child_element, frame)
            elif tag_name == "FLEXRAY-CLUSTER":
                cluster = parent.createFlexrayCluster(self.getShortName(child_element))
                self.readFlexrayCluster(child_element, cluster)
            elif tag_name == "DATA-TRANSFORMATION-SET":
                transformation_set = parent.createDataTransformationSet(self.getShortName(child_element))
                self.readDataTransformationSet(child_element, transformation_set)
            elif tag_name == "E-2-E-PROFILE-COMPATIBILITY-PROPS":
                props = parent.createE2EProfileCompatibilityProps(self.getShortName(child_element))
                self.readE2EProfileCompatibilityProps(child_element, props)
            elif tag_name == "TLV-DATA-ID-DEFINITION-SET":
                tlv_data_id_definition_set = parent.createTlvDataIdDefinitionSet(self.getShortName(child_element))
                self.readTlvDataIdDefinitionSet(child_element, tlv_data_id_definition_set)
            elif tag_name == "COLLECTION":
                collection = parent.createCollection(self.getShortName(child_element))
                self.readCollection(child_element, collection)
            elif tag_name == "KEYWORD-SET":
                keyword_set = parent.createKeywordSet(self.getShortName(child_element))
                self.readKeywordSet(child_element, keyword_set)
            elif tag_name == "PORT-PROTOTYPE-BLUEPRINT":
                blueprint = parent.createPortPrototypeBlueprint(self.getShortName(child_element))
                self.readPortPrototypeBlueprint(child_element, blueprint)
            elif tag_name == "MODE-DECLARATION-MAPPING-SET":
                mapping_set = parent.createModeDeclarationMappingSet(self.getShortName(child_element))
                self.readModeDeclarationMappingSet(child_element, mapping_set)
            elif tag_name == "ECUC-MODULE-DEF":
                module_def = parent.createEcucModuleDef(self.getShortName(child_element))
                self.readEcucModuleDef(child_element, module_def)
            elif tag_name == "ECUC-DEFINITION-COLLECTION":
                collection = parent.createEcucDefinitionCollection(self.getShortName(child_element))
                self.readEcucDefinitionCollection(child_element, collection)
            elif tag_name == "ECUC-DESTINATION-URI-DEF-SET":
                uri_def_set = parent.createEcucDestinationUriDefSet(self.getShortName(child_element))
                self.readEcucDestinationUriDefSet(child_element, uri_def_set)
            elif tag_name == "SW-SYSTEMCONST":
                system_const = parent.createSwSystemConst(self.getShortName(child_element))
                self.readSwSystemconst(child_element, system_const)
            elif tag_name == "SW-SYSTEMCONSTANT-VALUE-SET":
                value_set = parent.createSwSystemconstantValueSet(self.getShortName(child_element))
                self.readSwSystemconstantValueSet(child_element, value_set)
            elif tag_name == "PREDEFINED-VARIANT":
                variant = parent.createPredefinedVariant(self.getShortName(child_element))
                self.readPredefinedVariant(child_element, variant)
            elif tag_name == "EVALUATED-VARIANT-SET":
                variant_set = parent.createEvaluatedVariantSet(self.getShortName(child_element))
                self.readEvaluatedVariantSet(child_element, variant_set)
            elif tag_name == "SDG-DEF":
                sdg_def = parent.createSdgDef(self.getShortName(child_element))
                self.readSdgDef(child_element, sdg_def)
            elif tag_name == "POST-BUILD-VARIANT-CRITERION":
                criterion = parent.createPostBuildVariantCriterion(self.getShortName(child_element))
                self.readPostBuildVariantCriterion(child_element, criterion)
            elif tag_name == "NV-DATA-INTERFACE":
                interface = parent.createNvDataInterface(self.getShortName(child_element))
                self.readNvDataInterface(child_element, interface)
            elif tag_name == "FIREWALL-RULE":
                rule = parent.createFirewallRule(self.getShortName(child_element))
                self.readFirewallRule(child_element, rule)
            elif tag_name == "BLUEPRINT-MAPPING-SET":
                blueprint_mapping_set = parent.createBlueprintMappingSet(self.getShortName(child_element))
                self.readBlueprintMappingSet(child_element, blueprint_mapping_set)
            elif tag_name == "CONSTANT-SPECIFICATION-MAPPING-SET":
                constant_specification_mapping_set = parent.createConstantSpecificationMappingSet(self.getShortName(child_element))
                self.readConstantSpecificationMappingSet(child_element, constant_specification_mapping_set)
            elif tag_name == "STATE-DEPENDENT-FIREWALL":
                firewall = parent.createStateDependentFirewall(self.getShortName(child_element))
                self.readStateDependentFirewall(child_element, firewall)
            elif tag_name == "PLATFORM-MODULE-ETHERNET-ENDPOINT-CONFIGURATION":
                configuration = parent.createPlatformModuleEthernetEndpointConfiguration(self.getShortName(child_element))
                self.readPlatformModuleEthernetEndpointConfiguration(child_element, configuration)
            elif tag_name == "MC-FUNCTION":
                func = parent.createMcFunction(self.getShortName(child_element))
                self.readMcFunction(child_element, func)
            elif tag_name == "MC-GROUP":
                group = parent.createMcGroup(self.getShortName(child_element))
                self.readMcGroup(child_element, group)
            elif tag_name == "ACL-PERMISSION":
                acl_permission = parent.createAclPermission(self.getShortName(child_element))
                self.readAclPermission(child_element, acl_permission)
            elif tag_name == "ACL-OBJECT-SET":
                acl_object_set = parent.createAclObjectSet(self.getShortName(child_element))
                self.readAclObjectSet(child_element, acl_object_set)
            elif tag_name == "ACL-OPERATION":
                acl_operation = parent.createAclOperation(self.getShortName(child_element))
                self.readAclOperation(child_element, acl_operation)
            elif tag_name == "ACL-ROLE":
                acl_role = parent.createAclRole(self.getShortName(child_element))
                self.readAclRole(child_element, acl_role)
            elif tag_name == "LIFE-CYCLE-STATE-DEFINITION-GROUP":
                group = parent.createLifeCycleStateDefinitionGroup(self.getShortName(child_element))
                self.readLifeCycleStateDefinitionGroup(child_element, group)
            elif tag_name == "VIEW-MAP-SET":
                view_map_set = parent.createViewMapSet(self.getShortName(child_element))
                self.readViewMapSet(child_element, view_map_set)
            else:
                self.notImplemented("Unsupported Element type of ARPackage <%s>" % tag_name)

    def readDataLinkLayerRule(self, element: ET.Element, rule: DataLinkLayerRule):
        destination_mac = self.getChildElementOptionalLiteral(element, "DESTINATION-MAC-ADDRESS")
        if destination_mac is not None:
            mac_address = MacAddressString()
            mac_address.setValue(destination_mac.getValue())
            rule.setDestinationMacAddress(mac_address)
        destination_mac_mask = self.getChildElementOptionalLiteral(element, "DESTINATION-MAC-ADDRESS-MASK")
        if destination_mac_mask is not None:
            mac_address = MacAddressString()
            mac_address.setValue(destination_mac_mask.getValue())
            rule.setDestinationMacAddressMask(mac_address)
        rule.setEtherType(self.getChildElementOptionalPositiveInteger(element, "ETHER-TYPE"))
        source_mac = self.getChildElementOptionalLiteral(element, "SOURCE-MAC-ADDRESS")
        if source_mac is not None:
            mac_address = MacAddressString()
            mac_address.setValue(source_mac.getValue())
            rule.setSourceMacAddress(mac_address)
        source_mac_mask = self.getChildElementOptionalLiteral(element, "SOURCE-MAC-ADDRESS-MASK")
        if source_mac_mask is not None:
            mac_address = MacAddressString()
            mac_address.setValue(source_mac_mask.getValue())
            rule.setSourceMacAddressMask(mac_address)
        rule.setVlanId(self.getChildElementOptionalPositiveInteger(element, "VLAN-ID"))
        rule.setVlanPriority(self.getChildElementOptionalPositiveInteger(element, "VLAN-PRIORITY"))

    def readPayloadBytePatternRule(self, element: ET.Element, payload_rule: PayloadBytePatternRule):
        parts = self.find(element, "PAYLOAD-BYTE-PATTERN-RULE-PARTS")
        if parts is not None:
            for child in self.findall(parts, "PAYLOAD-BYTE-PATTERN-RULE-PART"):
                part = PayloadBytePatternRulePart()
                self.readPayloadBytePatternRulePart(child, part)
                payload_rule.addPayloadBytePatternRulePart(part)

    def readPayloadBytePatternRulePart(self, element: ET.Element, part: PayloadBytePatternRulePart):
        part.setOffset(self.getChildElementOptionalPositiveInteger(element, "OFFSET"))
        part.setValue(self.getChildElementOptionalPositiveInteger(element, "VALUE"))

    def readSomeipProtocolRule(self, element: ET.Element, rule: SomeipProtocolRule):
        rule.setClientId(self.getChildElementOptionalPositiveInteger(element, "CLIENT-ID"))
        rule.setLengthVerification(self.getChildElementOptionalBooleanValue(element, "LENGTH-VERIFICATION"))
        rule.setMajorVersion(self.getChildElementOptionalPositiveInteger(element, "MAJOR-VERSION"))
        rule.setMessageType(self.getChildElementOptionalPositiveInteger(element, "MESSAGE-TYPE"))
        rule.setMethodId(self.getChildElementOptionalPositiveInteger(element, "METHOD-ID"))
        rule.setProtocolVersion(self.getChildElementOptionalPositiveInteger(element, "PROTOCOL-VERSION"))
        rule.setReturnCode(self.getChildElementOptionalPositiveInteger(element, "RETURN-CODE"))
        rule.setServiceInterfaceId(self.getChildElementOptionalPositiveInteger(element, "SERVICE-INTERFACE-ID"))

    def readSomeipSdRule(self, element: ET.Element, rule: SomeipSdRule):
        rule.setEntryType(self.getChildElementOptionalPositiveInteger(element, "ENTRY-TYPE"))
        rule.setEventGroupId(self.getChildElementOptionalPositiveInteger(element, "EVENT-GROUP-ID"))
        rule.setMaxMajorVersion(self.getChildElementOptionalPositiveInteger(element, "MAX-MAJOR-VERSION"))
        rule.setMaxMinorVersion(self.getChildElementOptionalPositiveInteger(element, "MAX-MINOR-VERSION"))
        rule.setMinMajorVersion(self.getChildElementOptionalPositiveInteger(element, "MIN-MAJOR-VERSION"))
        rule.setMinMinorVersion(self.getChildElementOptionalPositiveInteger(element, "MIN-MINOR-VERSION"))
        rule.setServiceInstanceId(self.getChildElementOptionalPositiveInteger(element, "SERVICE-INSTANCE-ID"))
        rule.setServiceInterfaceId(self.getChildElementOptionalPositiveInteger(element, "SERVICE-INTERFACE-ID"))

    def readDoIpRule(self, element: ET.Element, rule: DoIpRule):
        rule.setDestinationMaxAddress(self.getChildElementOptionalPositiveInteger(element, "DESTINATION-MAX-ADDRESS"))
        rule.setDestinationMinAddress(self.getChildElementOptionalPositiveInteger(element, "DESTINATION-MIN-ADDRESS"))
        rule.setInverseProtocolVersion(self.getChildElementOptionalPositiveInteger(element, "INVERSE-PROTOCOL-VERSION"))
        rule.setPayloadLength(self.getChildElementOptionalPositiveInteger(element, "PAYLOAD-LENGTH"))
        rule.setPayloadType(self.getChildElementOptionalPositiveInteger(element, "PAYLOAD-TYPE"))
        rule.setProtocolVersion(self.getChildElementOptionalPositiveInteger(element, "PROTOCOL-VERSION"))
        rule.setSourceMaxAddress(self.getChildElementOptionalPositiveInteger(element, "SOURCE-MAX-ADDRESS"))
        rule.setSourceMinAddress(self.getChildElementOptionalPositiveInteger(element, "SOURCE-MIN-ADDRESS"))
        rule.setUdsService(self.getChildElementOptionalPositiveInteger(element, "UDS-SERVICE"))

    def readTcpRule(self, element: ET.Element, rule: TcpRule):
        rule.setNumberOfParallelTcpSessions(self.getChildElementOptionalPositiveInteger(element, "NUMBER-OF-PARALLEL-TCP-SESSIONS"))
        rule.setStateManagementBasedOnTcpFlags(self.getChildElementOptionalBooleanValue(element, "STATE-MANAGEMENT-BASED-ON-TCP-FLAGS"))
        rule.setTimeoutCheck(self.getChildElementOptionalPositiveInteger(element, "TIMEOUT-CHECK"))

    def readIcmpRule(self, element: ET.Element, rule: IcmpRule):
        rule.setChecksumVerification(self.getChildElementOptionalBooleanValue(element, "CHECKSUM-VERIFICATION"))
        rule.setCode(self.getChildElementOptionalPositiveInteger(element, "CODE"))
        rule.setType(self.getChildElementOptionalPositiveInteger(element, "TYPE"))

    def readIpv4Rule(self, element: ET.Element, rule: Ipv4Rule):
        rule.setChecksumVerification(self.getChildElementOptionalBooleanValue(element, "CHECKSUM-VERIFICATION"))
        destination_ip_address = self.getChildElementOptionalLiteral(element, "DESTINATION-IP-ADDRESS")
        if destination_ip_address is not None:
            ip4_address = Ip4AddressString()
            ip4_address.setValue(destination_ip_address.getValue())
            rule.setDestinationIpAddress(ip4_address)
        destination_network_mask = self.getChildElementOptionalLiteral(element, "DESTINATION-NETWORK-MASK")
        if destination_network_mask is not None:
            ip4_address = Ip4AddressString()
            ip4_address.setValue(destination_network_mask.getValue())
            rule.setDestinationNetworkMask(ip4_address)
        rule.setDifferentiatedServiceCodePoint(self.getChildElementOptionalPositiveInteger(element, "DIFFERENTIATED-SERVICE-CODE-POINT"))
        rule.setDoNotFragment(self.getChildElementOptionalBooleanValue(element, "DO-NOT-FRAGMENT"))
        rule.setExplicitCongestionNotification(self.getChildElementOptionalPositiveInteger(element, "EXPLICIT-CONGESTION-NOTIFICATION"))
        child = self.find(element, "ICMP-RULE")
        if child is not None:
            icmp_rule = IcmpRule()
            self.readIcmpRule(child, icmp_rule)
            rule.setIcmpRule(icmp_rule)
        rule.setInternetHeaderLength(self.getChildElementOptionalPositiveInteger(element, "INTERNET-HEADER-LENGTH"))
        rule.setMoreFragments(self.getChildElementOptionalBooleanValue(element, "MORE-FRAGMENTS"))
        rule.setProtocol(self.getChildElementOptionalPositiveInteger(element, "PROTOCOL"))
        source_ip_address = self.getChildElementOptionalLiteral(element, "SOURCE-IP-ADDRESS")
        if source_ip_address is not None:
            ip4_address = Ip4AddressString()
            ip4_address.setValue(source_ip_address.getValue())
            rule.setSourceIpAddress(ip4_address)
        source_network_mask = self.getChildElementOptionalLiteral(element, "SOURCE-NETWORK-MASK")
        if source_network_mask is not None:
            ip4_address = Ip4AddressString()
            ip4_address.setValue(source_network_mask.getValue())
            rule.setSourceNetworkMask(ip4_address)
        rule.setTtlMax(self.getChildElementOptionalPositiveInteger(element, "TTL-MAX"))
        rule.setTtlMin(self.getChildElementOptionalPositiveInteger(element, "TTL-MIN"))

    def readIpv6Rule(self, element: ET.Element, rule: Ipv6Rule):
        destination_ip_address = self.getChildElementOptionalLiteral(element, "DESTINATION-IP-ADDRESS")
        if destination_ip_address is not None:
            ip6_address = Ip6AddressString()
            ip6_address.setValue(destination_ip_address.getValue())
            rule.setDestinationIpAddress(ip6_address)
        destination_network_mask = self.getChildElementOptionalLiteral(element, "DESTINATION-NETWORK-MASK")
        if destination_network_mask is not None:
            ip6_address = Ip6AddressString()
            ip6_address.setValue(destination_network_mask.getValue())
            rule.setDestinationNetworkMask(ip6_address)
        rule.setFlowLabel(self.getChildElementOptionalPositiveInteger(element, "FLOW-LABEL"))
        rule.setHopLimit(self.getChildElementOptionalPositiveInteger(element, "HOP-LIMIT"))
        child = self.find(element, "ICMP-RULE")
        if child is not None:
            icmp_rule = IcmpRule()
            self.readIcmpRule(child, icmp_rule)
            rule.setIcmpRule(icmp_rule)
        rule.setNextHeader(self.getChildElementOptionalPositiveInteger(element, "NEXT-HEADER"))
        source_ip_address = self.getChildElementOptionalLiteral(element, "SOURCE-IP-ADDRESS")
        if source_ip_address is not None:
            ip6_address = Ip6AddressString()
            ip6_address.setValue(source_ip_address.getValue())
            rule.setSourceIpAddress(ip6_address)
        source_network_mask = self.getChildElementOptionalLiteral(element, "SOURCE-NETWORK-MASK")
        if source_network_mask is not None:
            ip6_address = Ip6AddressString()
            ip6_address.setValue(source_network_mask.getValue())
            rule.setSourceNetworkMask(ip6_address)
        rule.setTrafficClass(self.getChildElementOptionalPositiveInteger(element, "TRAFFIC-CLASS"))

    def readFirewallRule(self, element: ET.Element, rule: FirewallRule):
        self.readIdentifiable(element, rule)
        rule.setBucketSize(self.getChildElementOptionalPositiveInteger(element, "BUCKET-SIZE"))
        child = self.find(element, "DATA-LINK-LAYER-RULE")
        if child is not None:
            data_link_layer_rule = DataLinkLayerRule()
            self.readDataLinkLayerRule(child, data_link_layer_rule)
            rule.setDataLinkLayerRule(data_link_layer_rule)
        child = self.find(element, "DDS-RULE")
        if child is not None:
            rule.setDdsRule(DdsRule())
        child = self.find(element, "DO-IP-RULE")
        if child is not None:
            do_ip_rule = DoIpRule()
            self.readDoIpRule(child, do_ip_rule)
            rule.setDoIpRule(do_ip_rule)
        child = self.find(element, "NETWORK-LAYER-RULE")
        if child is not None:
            ipv4_rule = self.find(child, "IPV-4-RULE")
            if ipv4_rule is not None:
                rule_obj = Ipv4Rule()
                self.readIpv4Rule(ipv4_rule, rule_obj)
                rule.setNetworkLayerRule(rule_obj)
            elif self.find(child, "IPV-6-RULE") is not None:
                rule_obj = Ipv6Rule()
                self.readIpv6Rule(self.find(child, "IPV-6-RULE"), rule_obj)
                rule.setNetworkLayerRule(rule_obj)
            else:
                rule.setNetworkLayerRule(NetworkLayerRule())
        payload_rules = self.find(element, "PAYLOAD-BYTE-PATTERN-RULES")
        if payload_rules is not None:
            for child in self.findall(payload_rules, "PAYLOAD-BYTE-PATTERN-RULE"):
                payload_rule = PayloadBytePatternRule()
                self.readPayloadBytePatternRule(child, payload_rule)
                rule.addPayloadBytePatternRule(payload_rule)
        rule.setRefillAmount(self.getChildElementOptionalPositiveInteger(element, "REFILL-AMOUNT"))
        child = self.find(element, "SOMEIP-RULE")
        if child is not None:
            someip_rule = SomeipProtocolRule()
            self.readSomeipProtocolRule(child, someip_rule)
            rule.setSomeipRule(someip_rule)
        child = self.find(element, "SOMEIP-SD-RULE")
        if child is not None:
            someip_sd_rule = SomeipSdRule()
            self.readSomeipSdRule(child, someip_sd_rule)
            rule.setSomeipSdRule(someip_sd_rule)
        child = self.find(element, "TRANSPORT-LAYER-RULE")
        if child is not None:
            tcp_rule = self.find(child, "TCP-RULE")
            if tcp_rule is not None:
                rule_obj = TcpRule()
                self.readTcpRule(tcp_rule, rule_obj)
                rule.setTransportLayerRule(rule_obj)
            elif self.find(child, "UDP-RULE") is not None:
                rule.setTransportLayerRule(UdpRule())
            else:
                rule.setTransportLayerRule(TransportLayerRule())

    def readBlueprintMappingSet(self, element: ET.Element, blueprint_mapping_set: BlueprintMappingSet):
        self.readIdentifiable(element, blueprint_mapping_set)
        maps_parent = self.find(element, "BLUEPRINT-MAPS")
        if maps_parent is not None:
            for map_element in list(maps_parent):
                tag_name = self.getTagName(map_element)
                if tag_name == "BLUEPRINT-MAPPING":
                    blueprint_map = BlueprintMapping()
                    self.readBlueprintMapping(map_element, blueprint_map)
                    blueprint_mapping_set.addBlueprintMap(blueprint_map)
                elif tag_name == "PORT-INTERFACE-BLUEPRINT-MAPPING":
                    blueprint_map = PortInterfaceBlueprintMapping()
                    self.readPortInterfaceBlueprintMapping(map_element, blueprint_map)
                    blueprint_mapping_set.addBlueprintMap(blueprint_map)
                elif tag_name == "PORT-PROTOTYPE-BLUEPRINT-MAPPING":
                    blueprint_map = PortPrototypeBlueprintMapping()
                    self.readPortPrototypeBlueprintMapping(map_element, blueprint_map)
                    blueprint_mapping_set.addBlueprintMap(blueprint_map)

    def readConstantSpecificationMappingSet(self, element: ET.Element, constant_specification_mapping_set: ConstantSpecificationMappingSet):
        self.readIdentifiable(element, constant_specification_mapping_set)
        mappings_parent = self.find(element, "MAPPINGS")
        if mappings_parent is not None:
            for map_element in self.findall(mappings_parent, "CONSTANT-SPECIFICATION-MAPPING"):
                mapping = self.getConstantSpecificationMapping(map_element)
                constant_specification_mapping_set.addMapping(mapping)

    def readAtpBlueprintMapping(self, element: ET.Element, blueprint_map: AtpBlueprintMapping):
        self.readARObject(element, blueprint_map)

    def readBlueprintMapping(self, element: ET.Element, blueprint_map: BlueprintMapping):
        self.readAtpBlueprintMapping(element, blueprint_map)
        blueprint_map.setBlueprintRef(self.getChildElementOptionalRefType(element, "BLUEPRINT-REF"))
        blueprint_map.setDerivedObjectRef(self.getChildElementOptionalRefType(element, "DERIVED-OBJECT-REF"))

    def readPortInterfaceBlueprintMapping(self, element: ET.Element, blueprint_map: PortInterfaceBlueprintMapping):
        self.readAtpBlueprintMapping(element, blueprint_map)
        blueprint_map.setPortInterfaceBlueprintRef(self.getChildElementOptionalRefType(element, "PORT-INTERFACE-BLUEPRINT-REF"))
        blueprint_map.setDerivedPortInterfaceRef(self.getChildElementOptionalRefType(element, "DERIVED-PORT-INTERFACE-REF"))

    def readPortPrototypeBlueprintMapping(self, element: ET.Element, blueprint_map: PortPrototypeBlueprintMapping):
        self.readAtpBlueprintMapping(element, blueprint_map)
        blueprint_map.setPortPrototypeBlueprintRef(self.getChildElementOptionalRefType(element, "PORT-PROTOTYPE-BLUEPRINT-REF"))
        blueprint_map.setDerivedPortPrototypeRef(self.getChildElementOptionalRefType(element, "DERIVED-PORT-PROTOTYPE-REF"))

    def readStateDependentFirewall(self, element: ET.Element, firewall: StateDependentFirewall):
        self.readIdentifiable(element, firewall)
        default_action = self.getChildElementOptionalLiteral(element, "DEFAULT-ACTION")
        if default_action is not None:
            firewall.setDefaultAction(FirewallActionEnum().setValue(default_action.getValue()))
        props_parent = self.find(element, "FIREWALL-RULE-PROPSS")
        if props_parent is not None:
            for props_element in self.findall(props_parent, "FIREWALL-RULE-PROPS"):
                props = FirewallRuleProps()
                self.readFirewallRuleProps(props_element, props)
                firewall.addFirewallRuleProps(props)
        refs_parent = self.find(element, "FIREWALL-STATE-MODE-DECLARATION-REFS")
        if refs_parent is not None:
            for ref in self.getChildElementRefTypeList(refs_parent, "FIREWALL-STATE-MODE-DECLARATION-REF"):
                firewall.addFirewallStateModeDeclarationRef(ref)

    def readFirewallRuleProps(self, element: ET.Element, props: FirewallRuleProps):
        action = self.getChildElementOptionalLiteral(element, "ACTION")
        if action is not None:
            props.setAction(FirewallActionEnum().setValue(action.getValue()))
        egress_refs_parent = self.find(element, "MATCHING-EGRESS-RULE-REFS")
        if egress_refs_parent is not None:
            for ref in self.getChildElementRefTypeList(egress_refs_parent, "MATCHING-EGRESS-RULE-REF"):
                props.addMatchingEgressRuleRef(ref)
        ingress_refs_parent = self.find(element, "MATCHING-INGRESS-RULE-REFS")
        if ingress_refs_parent is not None:
            for ref in self.getChildElementRefTypeList(ingress_refs_parent, "MATCHING-INGRESS-RULE-REF"):
                props.addMatchingIngressRuleRef(ref)

    def readIdsPlatformInstantiation(self, element: ET.Element, ar_element: IdsPlatformInstantiation):
        self.readIdentifiable(element, ar_element)
        refs_parent = self.find(element, "NETWORK-INTERFACE-REFS")
        if refs_parent is not None:
            for ref in self.getChildElementRefTypeList(refs_parent, "NETWORK-INTERFACE-REF"):
                ar_element.addNetworkInterfaceRef(ref)
        time_bases_element = self.find(element, "TIME-BASES")
        if time_bases_element is not None:
            conditional_element = self.find(time_bases_element, "TIME-BASE-RESOURCE-REF-CONDITIONAL")
            if conditional_element is not None:
                ar_element.setTimeBaseRef(self.getChildElementOptionalRefType(conditional_element, "TIME-BASE-RESOURCE-REF"))

    def readIdsmModuleInstantiation(self, element: ET.Element, instantiation: IdsmModuleInstantiation):
        self.readIdsPlatformInstantiation(element, instantiation)

    def readPlatformModuleEthernetEndpointConfiguration(self, element: ET.Element, configuration: PlatformModuleEthernetEndpointConfiguration):
        self.readIdentifiable(element, configuration)
        configuration.setCommunicationConnectorRef(self.getChildElementOptionalRefType(element, "COMMUNICATION-CONNECTOR-REF"))
        ipv4_address = self.getChildElementOptionalLiteral(element, "IPV-4-MULTICAST-IP-ADDRESS")
        if ipv4_address is not None:
            configuration.setIpv4MulticastIpAddress(Ip4AddressString().setValue(ipv4_address.getValue()))
        ipv6_address = self.getChildElementOptionalLiteral(element, "IPV-6-MULTICAST-IP-ADDRESS")
        if ipv6_address is not None:
            configuration.setIpv6MulticastIpAddress(Ip6AddressString().setValue(ipv6_address.getValue()))

    def readMcFunction(self, element: ET.Element, func: McFunction):
        self.readIdentifiable(element, func)
        def_calprm_set_element = self.find(element, "DEF-CALPRM-SET")
        if def_calprm_set_element is not None:
            def_calprm_set = McFunctionDataRefSet()
            self.readMcFunctionDataRefSet(def_calprm_set_element, def_calprm_set)
            func.setDefCalprmSet(def_calprm_set)
        ref_calprm_set_element = self.find(element, "REF-CALPRM-SET")
        if ref_calprm_set_element is not None:
            ref_calprm_set = McFunctionDataRefSet()
            self.readMcFunctionDataRefSet(ref_calprm_set_element, ref_calprm_set)
            func.setRefCalprmSet(ref_calprm_set)
        in_measurement_set_element = self.find(element, "IN-MEASUREMENT-SET")
        if in_measurement_set_element is not None:
            in_measurement_set = McFunctionDataRefSet()
            self.readMcFunctionDataRefSet(in_measurement_set_element, in_measurement_set)
            func.setInMeasurementSet(in_measurement_set)
        loc_measurement_set_element = self.find(element, "LOC-MEASUREMENT-SET")
        if loc_measurement_set_element is not None:
            loc_measurement_set = McFunctionDataRefSet()
            self.readMcFunctionDataRefSet(loc_measurement_set_element, loc_measurement_set)
            func.setLocMeasurementSet(loc_measurement_set)
        out_measurement_set_element = self.find(element, "OUT-MEASUREMENT-SET")
        if out_measurement_set_element is not None:
            out_measurement_set = McFunctionDataRefSet()
            self.readMcFunctionDataRefSet(out_measurement_set_element, out_measurement_set)
            func.setOutMeasurementSet(out_measurement_set)
        for ref in self.getChildElementRefTypeList(element, "SUB-FUNCTION-REFS/SUB-FUNCTION-REF"):
            func.addSubFunctionRef(ref)

    def readMcFunctionDataRefSet(self, element: ET.Element, data_ref_set: McFunctionDataRefSet):
        conditional_element = self.find(element, "MC-FUNCTION-DATA-REF-SET-VARIANTS/MC-FUNCTION-DATA-REF-SET-CONDITIONAL")
        if conditional_element is None:
            return
        for ref in self.getChildElementRefTypeList(conditional_element, "FLAT-MAP-ENTRY-REFS/FLAT-MAP-ENTRY-REF"):
            data_ref_set.addFlatMapEntryRef(ref)
        for ref in self.getChildElementRefTypeList(conditional_element, "MC-DATA-INSTANCE-REFS/MC-DATA-INSTANCE-REF"):
            data_ref_set.addMcDataInstanceRef(ref)

    def readMcGroup(self, element: ET.Element, group: McGroup):
        self.readIdentifiable(element, group)
        for ref in self.getChildElementRefTypeList(element, "SUB-GROUP-REFS/SUB-GROUP-REF"):
            group.addSubGroupRef(ref)
        ref_calprm_set_element = self.find(element, "REF-CALPRM-SET")
        if ref_calprm_set_element is not None:
            ref_calprm_set = McGroupDataRefSet()
            self.readMcGroupDataRefSet(ref_calprm_set_element, ref_calprm_set)
            group.setRefCalprmSet(ref_calprm_set)
        ref_measurement_set_element = self.find(element, "REF-MEASUREMENT-SET")
        if ref_measurement_set_element is not None:
            ref_measurement_set = McGroupDataRefSet()
            self.readMcGroupDataRefSet(ref_measurement_set_element, ref_measurement_set)
            group.setRefMeasurementSet(ref_measurement_set)
        for ref in self.getChildElementRefTypeList(element, "MC-FUNCTION-REFS/MC-FUNCTION-REF"):
            group.addMcFunctionRef(ref)

    def readMcGroupDataRefSet(self, element: ET.Element, data_ref_set: McGroupDataRefSet):
        conditional_element = self.find(element, "MC-GROUP-DATA-REF-SET-VARIANTS/MC-GROUP-DATA-REF-SET-CONDITIONAL")
        if conditional_element is None:
            return
        for ref in self.getChildElementRefTypeList(conditional_element, "FLAT-MAP-ENTRY-REFS/FLAT-MAP-ENTRY-REF"):
            data_ref_set.addFlatMapEntryRef(ref)
        for ref in self.getChildElementRefTypeList(conditional_element, "MC-DATA-INSTANCE-REFS/MC-DATA-INSTANCE-REF"):
            data_ref_set.addMcDataInstanceRef(ref)

    def readReferenceBases(self, element: ET.Element, parent: ARPackage):
        for child_element in self.findall(element, "REFERENCE-BASES/REFERENCE-BASE"):
            base = ReferenceBase()
            base.setShortLabel(self.getChildElementOptionalLiteral(child_element, "SHORT-LABEL"))
            base.setIsDefault(self.getChildElementOptionalBooleanValue(child_element, "IS-DEFAULT"))
            base.setIsGlobal(self.getChildElementOptionalBooleanValue(child_element, "IS-GLOBAL"))
            base.setBaseIsThisPackage(self.getChildElementOptionalBooleanValue(child_element, "BASE-IS-THIS-PACKAGE"))
            for global_in_package_ref in self.getChildElementRefTypeList(child_element, "GLOBAL-IN-PACKAGE-REFS/GLOBAL-IN-PACKAGE-REF"):
                base.addGlobalInPackageRef(global_in_package_ref)
            for global_element in self.findall(child_element, "GLOBAL-ELEMENTS/GLOBAL-ELEMENT"):
                literal = ReferrableSubtypesEnum()
                literal.setValue(global_element.text)
                base.addGlobalElement(literal)
            base.setPackageRef(self.getChildElementOptionalRefType(child_element, "PACKAGE-REF"))
            parent.addReferenceBase(base)

    def readAclPermission(self, element: ET.Element, acl_permission: AclPermission) -> AclPermission:
        self.logger.debug("Read AclPermission <%s>" % acl_permission.getShortName())
        self.readIdentifiable(element, acl_permission)
        for child_element in self.findall(element, "ACL-CONTEXTS/ACL-CONTEXT"):
            acl_permission.addAclContext(NameToken().setValue(child_element.text))
        for object_ref in self.getChildElementRefTypeList(element, "ACL-OBJECT-REFS/ACL-OBJECT-REF"):
            acl_permission.addAclObjectRef(object_ref)
        for operation_ref in self.getChildElementRefTypeList(element, "ACL-OPERATION-REFS/ACL-OPERATION-REF"):
            acl_permission.addAclOperationRef(operation_ref)
        for role_ref in self.getChildElementRefTypeList(element, "ACL-ROLE-REFS/ACL-ROLE-REF"):
            acl_permission.addAclRoleRef(role_ref)
        acl_scope = self.find(element, "ACL-SCOPE")
        if acl_scope is not None:
            literal = None
            for literal_name, token in ACL_SCOPE_XML_MAP.items():
                if token == acl_scope.text:
                    literal = literal_name
                    break
            if literal is not None:
                acl_permission.setAclScope(AclScopeEnum().setValue(literal))
            else:
                self.notImplemented("Unsupported ACL-SCOPE <%s>" % acl_scope.text)
        return acl_permission

    def readAclObjectSet(self, element: ET.Element, acl_object_set: AclObjectSet) -> AclObjectSet:
        self.logger.debug("Read AclObjectSet <%s>" % acl_object_set.getShortName())
        self.readIdentifiable(element, acl_object_set)
        for child_element in self.findall(element, "ACL-OBJECT-CLASSS/ACL-OBJECT-CLASS"):
            literal = ReferrableSubtypesEnum()
            literal.setValue(child_element.text)
            acl_object_set.addAclObjectClass(literal)
        acl_scope = self.find(element, "ACL-SCOPE")
        if acl_scope is not None:
            literal = None
            for literal_name, token in ACL_SCOPE_XML_MAP.items():
                if token == acl_scope.text:
                    literal = literal_name
                    break
            if literal is not None:
                acl_object_set.setAclScope(AclScopeEnum().setValue(literal))
            else:
                self.notImplemented("Unsupported ACL-SCOPE <%s>" % acl_scope.text)
        acl_object_set.setCollectionRef(self.getChildElementOptionalRefType(element, "COLLECTION-REF"))
        for blueprint_ref in self.getChildElementRefTypeList(element, "DERIVED-FROM-BLUEPRINT-REFS/DERIVED-FROM-BLUEPRINT-REF"):
            acl_object_set.addDerivedFromBlueprintRef(blueprint_ref)
        for child_element in self.findall(element, "ENGINEERING-OBJECTS/AUTOSAR-ENGINEERING-OBJECT"):
            acl_object_set.addEngineeringObject(self.getAutosarEngineeringObject(child_element))
        for object_definition_ref in self.getChildElementRefTypeList(element, "OBJECT-DEFINITION-REFS/OBJECT-DEFINITION-REF"):
            acl_object_set.addObjectDefinitionRef(object_definition_ref)
        for object_ref in self.getChildElementRefTypeList(element, "OBJECT-REFS/OBJECT-REF"):
            acl_object_set.addObjectRef(object_ref)
        return acl_object_set

    def readAclOperation(self, element: ET.Element, acl_operation: AclOperation) -> AclOperation:
        self.logger.debug("Read AclOperation <%s>" % acl_operation.getShortName())
        self.readIdentifiable(element, acl_operation)
        for implied_operation_ref in self.getChildElementRefTypeList(element, "IMPLIED-OPERATION-REFS/IMPLIED-OPERATION-REF"):
            acl_operation.addImpliedOperationRef(implied_operation_ref)
        return acl_operation

    def readAclRole(self, element: ET.Element, acl_role: AclRole) -> AclRole:
        self.logger.debug("Read AclRole <%s>" % acl_role.getShortName())
        self.readIdentifiable(element, acl_role)
        acl_role.setLdapUrl(self.getChildElementOptionalUriString(element, "LDAP-URL"))
        return acl_role

    def readLifeCycleState(self, element: ET.Element, lc_state: LifeCycleState) -> LifeCycleState:
        self.logger.debug("Read LifeCycleState <%s>" % lc_state.getShortName())
        self.readIdentifiable(element, lc_state)
        return lc_state

    def readLifeCycleStateDefinitionGroupLcStates(self, element: ET.Element, group: LifeCycleStateDefinitionGroup):
        for child_element in self.findall(element, "LC-STATES/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "LIFE-CYCLE-STATE":
                lc_state = group.createLcState(self.getShortName(child_element))
                self.readLifeCycleState(child_element, lc_state)
            else:
                self.notImplemented("Unsupported LifeCycleState <%s>" % tag_name)

    def readLifeCycleStateDefinitionGroup(self, element: ET.Element, group: LifeCycleStateDefinitionGroup) -> LifeCycleStateDefinitionGroup:
        self.logger.debug("Read LifeCycleStateDefinitionGroup <%s>" % group.getShortName())
        self.readIdentifiable(element, group)
        self.readLifeCycleStateDefinitionGroupLcStates(element, group)
        return group

    def readViewMap(self, element: ET.Element, view_map: ViewMap) -> ViewMap:
        self.logger.debug("Read ViewMap <%s>" % view_map.getShortName())
        self.readIdentifiable(element, view_map)
        view_map.setRole(self.getChildElementOptionalIdentifier(element, "ROLE"))
        for first_element_ref in self.getChildElementRefTypeList(element, "FIRST-ELEMENT-REFS/FIRST-ELEMENT-REF"):
            view_map.addFirstElementRef(first_element_ref)
        for second_element_ref in self.getChildElementRefTypeList(element, "SECOND-ELEMENT-REFS/SECOND-ELEMENT-REF"):
            view_map.addSecondElementRef(second_element_ref)
        for child_element in self.findall(element, "FIRST-ELEMENT-INSTANCE-IREFS/FIRST-ELEMENT-INSTANCE-IREF"):
            view_map.addFirstElementIRef(self.getAnyInstanceRefFromElement(child_element))
        for child_element in self.findall(element, "SECOND-ELEMENT-INSTANCE-IREFS/SECOND-ELEMENT-INSTANCE-IREF"):
            view_map.addSecondElementIRef(self.getAnyInstanceRefFromElement(child_element))
        return view_map

    def readViewMapSetViewMaps(self, element: ET.Element, view_map_set: ViewMapSet):
        for child_element in self.findall(element, "VIEW-MAPS/*"):
            tag_name = self.getTagName(child_element)
            if tag_name == "VIEW-MAP":
                view_map = view_map_set.createViewMap(self.getShortName(child_element))
                self.readViewMap(child_element, view_map)
            else:
                self.notImplemented("Unsupported ViewMap <%s>" % tag_name)

    def readViewMapSet(self, element: ET.Element, view_map_set: ViewMapSet) -> ViewMapSet:
        self.logger.debug("Read ViewMapSet <%s>" % view_map_set.getShortName())
        self.readIdentifiable(element, view_map_set)
        self.readViewMapSetViewMaps(element, view_map_set)
        return view_map_set

    def readCollection(self, element: ET.Element, collection: Collection) -> Collection:
        self.logger.debug("Read Collection <%s>" % collection.getShortName())
        self.readIdentifiable(element, collection)
        auto_collect = self.find(element, "AUTO-COLLECT")
        if auto_collect is not None:
            literal = None
            for literal_name, token in AUTO_COLLECT_XML_MAP.items():
                if token == auto_collect.text:
                    literal = literal_name
                    break
            if literal is not None:
                collection.setAutoCollect(AutoCollectEnum().setValue(literal))
            else:
                self.notImplemented("Unsupported AUTO-COLLECT <%s>" % auto_collect.text)
        collection_semantics = self.find(element, "COLLECTION-SEMANTICS")
        if collection_semantics is not None:
            collection.setCollectionSemantics(NameToken().setValue(collection_semantics.text))
        collection.setElementRole(self.getChildElementOptionalIdentifier(element, "ELEMENT-ROLE"))
        for element_ref in self.getChildElementRefTypeList(element, "ELEMENT-REFS/ELEMENT-REF"):
            collection.addElementRef(element_ref)
        for source_element_ref in self.getChildElementRefTypeList(element, "SOURCE-ELEMENT-REFS/SOURCE-ELEMENT-REF"):
            collection.addSourceElementRef(source_element_ref)
        for child_element in self.findall(element, "COLLECTED-INSTANCE-IREFS/COLLECTED-INSTANCE-IREF"):
            collection.addCollectedInstanceIRef(self.getAnyInstanceRefFromElement(child_element))
        for child_element in self.findall(element, "SOURCE-INSTANCE-IREFS/SOURCE-INSTANCE-IREF"):
            collection.addSourceInstanceIRef(self.getAnyInstanceRefFromElement(child_element))
        return collection

    def readARPackage(self, element: ET.Element, ar_package: ARPackage):
        self.logger.debug("Read ARPackages <%s>" % ar_package.getFullName())

        self.readIdentifiable(element, ar_package)
        self.readARPackages(element, ar_package)
        self.readARPackageElements(element, ar_package)
        self.readReferenceBases(element, ar_package)

    def readARPackages(self, element: ET.Element, parent: ARPackage):
        child_elements = self.findall(element, "AR-PACKAGES/*")
        if len(child_elements) == 0:
            # Legacy R3.x releases: TOP-LEVEL-PACKAGES at document root, SUB-PACKAGES
            # inside an AR-PACKAGE (autosar/R3.2.3/xsd/AUTOSAR.xsd L315/L270).
            if isinstance(parent, AUTOSAR):
                child_elements = self.findall(element, "TOP-LEVEL-PACKAGES/*")
            else:
                child_elements = self.findall(element, "SUB-PACKAGES/*")
        for child_element in child_elements:
            tag_name = self.getTagName(child_element)
            if tag_name == "AR-PACKAGE":
                ar_package = parent.createARPackage(self.getShortName(child_element))
                self.readARPackage(child_element, ar_package)
            else:
                self.notImplemented("Unsupported ARPackage <%s>" % tag_name)

    def load(self, filename, document: AUTOSAR):
        self.logger.info("Loading %s ..." % os.path.realpath(filename))

        tree = ET.parse(filename)
        root = tree.getroot()
        if self.getPureTagName(root.tag) != "AUTOSAR":
            self.raiseError("Invalid ARXML file <%s>" % filename)

        self.detectNamespace(root)
        self.getAUTOSARInfo(root, document)
        document.setAdminData(self.getAdminData(root, "ADMIN-DATA"))
        document.setFileInfoComment(self.getFileInfoComment(root, "FILE-INFO-COMMENT"))
        document.setIntroduction(self.getDocumentationBlock(root, "INTRODUCTION"))
        self.readARPackages(root, document)

        document.reload()
