from __future__ import annotations
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.StereotypeMixins import VariationPointCapable

from abc import ABC
from typing import List, Optional

from armodel.models.M2.AUTOSARTemplates.GenericStructure.AbstractStructure import AtpInstanceRef
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.FormulaLanguage import FormulaExpression
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Identifiable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import RefType

from armodel.models.M2.AUTOSARTemplates.CommonStructure.Timing.TimingDescription.TimingDescriptionEvents.TDEventOccurrenceExpression import (
    AutosarOperationArgumentInstance,
    AutosarVariableInstance,
)


class ModeInSwcBswInstanceRef(ARObject, ABC):
    """
    Abstract class representing an instance reference to be capable of referencing a specific ModeDeclaration utilized by a SW-C or BSW module.
    """

    # ModeInSwcBswInstanceRef method parity checklist:
    # Spec: AUTOSAR_00052.xsd line 82683, group MODE-IN-SWC-BSW-INSTANCE-REF (XSD-only; no own table in repo corpus)
    # XSD verified: AUTOSAR_00052.xsd
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11

    def __init__(self):
        if type(self) is ModeInSwcBswInstanceRef:
            raise TypeError("ModeInSwcBswInstanceRef is an abstract class.")
        super().__init__()


class ModeInBswInstanceRef(ModeInSwcBswInstanceRef):
    """
    Instance reference to be capable of referencing a specific ModeDeclaration of a ModeDeclarationGroupPrototype utilized in a BSW module.

    [constr_6853] Existence of ModeInBswInstanceRef.contextModeDeclarationGroupPrototype: For each ModeInBswInstanceRef, the reference to ModeDeclarationGroupPrototype in the role contextModeDeclarationGroupPrototype shall exist at least once at the time when the Bsw Timing Description is complete.
    [constr_6854] Existence of ModeInBswInstanceRef.targetModeDeclaration: For each ModeInBswInstanceRef, the reference to ModeDeclaration in the role targetModeDeclaration shall exist at least once at the time when the Bsw Timing Description is complete.
    """

    # ModeInBswInstanceRef method parity checklist:
    # Spec: AUTOSAR_CP_TPS_TimingExtensions.pdf, Table 3.11, p.38
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                             [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getContextBswImplementationRef       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setContextBswImplementationRef       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getContextModeDeclarationGroupPrototypeRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setContextModeDeclarationGroupPrototypeRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTargetModeDeclarationRef          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTargetModeDeclarationRef          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Specifies the BSW implementation that manifests the context.
        self.contextBswImplementationRef: Optional[RefType] = None

        # Specifies the mode declaration group prototype that manifests the context. [constr_6853] The reference shall exist at least once at the time when the Bsw Timing Description is complete.
        self.contextModeDeclarationGroupPrototypeRef: Optional[RefType] = None

        # Specifies the specific mode declaration in the given context. [constr_6854] The reference shall exist at least once at the time when the Bsw Timing Description is complete.
        self.targetModeDeclarationRef: Optional[RefType] = None

    def getContextBswImplementationRef(self) -> Optional[RefType]:
        """Specifies the BSW implementation that manifests the context."""
        return self.contextBswImplementationRef

    def setContextBswImplementationRef(self, value: Optional[RefType]) -> ModeInBswInstanceRef:
        """Specifies the BSW implementation that manifests the context. A None value is a no-op and does not overwrite an existing contextBswImplementationRef."""
        if value is not None:
            self.contextBswImplementationRef = value
        return self

    def getContextModeDeclarationGroupPrototypeRef(self) -> Optional[RefType]:
        """Specifies the mode declaration group prototype that manifests the context. [constr_6853] The reference shall exist at least once at the time when the Bsw Timing Description is complete."""
        return self.contextModeDeclarationGroupPrototypeRef

    def setContextModeDeclarationGroupPrototypeRef(self, value: Optional[RefType]) -> ModeInBswInstanceRef:
        """Specifies the mode declaration group prototype that manifests the context. [constr_6853] The reference shall exist at least once at the time when the Bsw Timing Description is complete. A None value is a no-op and does not overwrite an existing contextModeDeclarationGroupPrototypeRef."""
        if value is not None:
            self.contextModeDeclarationGroupPrototypeRef = value
        return self

    def getTargetModeDeclarationRef(self) -> Optional[RefType]:
        """Specifies the specific mode declaration in the given context. [constr_6854] The reference shall exist at least once at the time when the Bsw Timing Description is complete."""
        return self.targetModeDeclarationRef

    def setTargetModeDeclarationRef(self, value: Optional[RefType]) -> ModeInBswInstanceRef:
        """Specifies the specific mode declaration in the given context. [constr_6854] The reference shall exist at least once at the time when the Bsw Timing Description is complete. A None value is a no-op and does not overwrite an existing targetModeDeclarationRef."""
        if value is not None:
            self.targetModeDeclarationRef = value
        return self


class ModeInSwcInstanceRef(AtpInstanceRef, ModeInSwcBswInstanceRef):
    """
    Instance reference to be capable of referencing a ModeDeclaration at a specific Mode Switch Port of a SW-C.
    """

    # ModeInSwcInstanceRef method parity checklist:
    # Spec: AUTOSAR_CP_TPS_TimingExtensions.pdf, Table 3.12, p.39
    # Spec verified: R23-11 (2026-09-27, user 9b confirmation)
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element; `base` is an
    #          atpDerived association XSD-skipped in group MODE-IN-SWC-INSTANCE-REF — field kept per the
    #          PDF table, no XML element to read or write)
    # [x] __init__                             [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getBaseRef                           [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] setBaseRef                           [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getContextComponentRefs              [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] addContextComponentRef               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getContextModeDeclarationGroupPrototypeRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setContextModeDeclarationGroupPrototypeRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getContextPortRef                    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setContextPortRef                    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getTargetModeDeclarationRef          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setTargetModeDeclarationRef          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # Specifies the SW component representing the base of the context.
        self.baseRef: Optional[RefType] = None

        # Specifies the SW component prototype representing the context.
        self.contextComponentRefs: List[RefType] = []

        # Specifies the mode declaration group prototype that manifests the context.
        self.contextModeDeclarationGroupPrototypeRef: Optional[RefType] = None

        # Specifies the port prototype representing the context.
        self.contextPortRef: Optional[RefType] = None

        # Specifies the specific mode declaration in the given context.
        self.targetModeDeclarationRef: Optional[RefType] = None

    def getBaseRef(self) -> Optional[RefType]:
        """Specifies the SW component representing the base of the context."""
        return self.baseRef

    def setBaseRef(self, value: Optional[RefType]) -> ModeInSwcInstanceRef:
        """Specifies the SW component representing the base of the context. A None value is a no-op and does not overwrite an existing baseRef."""
        if value is not None:
            self.baseRef = value
        return self

    def getContextComponentRefs(self) -> List[RefType]:
        """Specifies the SW component prototype representing the context."""
        return self.contextComponentRefs

    def addContextComponentRef(self, value: Optional[RefType]) -> ModeInSwcInstanceRef:
        """Specifies the SW component prototype representing the context. A None value is a no-op and does not append anything."""
        if value is not None:
            self.contextComponentRefs.append(value)
        return self

    def getContextModeDeclarationGroupPrototypeRef(self) -> Optional[RefType]:
        """Specifies the mode declaration group prototype that manifests the context."""
        return self.contextModeDeclarationGroupPrototypeRef

    def setContextModeDeclarationGroupPrototypeRef(self, value: Optional[RefType]) -> ModeInSwcInstanceRef:
        """Specifies the mode declaration group prototype that manifests the context. A None value is a no-op and does not overwrite an existing contextModeDeclarationGroupPrototypeRef."""
        if value is not None:
            self.contextModeDeclarationGroupPrototypeRef = value
        return self

    def getContextPortRef(self) -> Optional[RefType]:
        """Specifies the port prototype representing the context."""
        return self.contextPortRef

    def setContextPortRef(self, value: Optional[RefType]) -> ModeInSwcInstanceRef:
        """Specifies the port prototype representing the context. A None value is a no-op and does not overwrite an existing contextPortRef."""
        if value is not None:
            self.contextPortRef = value
        return self

    def getTargetModeDeclarationRef(self) -> Optional[RefType]:
        """Specifies the specific mode declaration in the given context."""
        return self.targetModeDeclarationRef

    def setTargetModeDeclarationRef(self, value: Optional[RefType]) -> ModeInSwcInstanceRef:
        """Specifies the specific mode declaration in the given context. A None value is a no-op and does not overwrite an existing targetModeDeclarationRef."""
        if value is not None:
            self.targetModeDeclarationRef = value
        return self


class TimingModeInstance(Identifiable, VariationPointCapable):
    """
    This class specifies the mode declaration to be checked in a specific instance of a mode declaration group. This is used in a timing condition formula as an operand of the unary timing function TIMEX_mode Active to check whether the mode declaration is active at the point in time this expression is evaluated.
    """

    # TimingModeInstance method parity checklist:
    # Spec: AUTOSAR_CP_TPS_TimingExtensions.pdf, Table 3.10, p.37
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                 [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getModeInstance          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setModeInstance          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self, parent, short_name: str):
        super().__init__(parent, short_name)

        # This refers to a specific mode declaration in the given context.
        # Aggregates ModeInBswInstanceRef or ModeInSwcInstanceRef (polymorphic choice); both derive from the abstract ModeInSwcBswInstanceRef.
        self.modeInstance: Optional[ModeInSwcBswInstanceRef] = None

    def getModeInstance(self) -> Optional[ModeInSwcBswInstanceRef]:
        """This refers to a specific mode declaration in the given context."""
        return self.modeInstance

    def setModeInstance(self, value: Optional[ModeInSwcBswInstanceRef]) -> TimingModeInstance:
        """This refers to a specific mode declaration in the given context. A None value is a no-op and does not overwrite an existing modeInstance."""
        if value is not None:
            self.modeInstance = value
        return self


class TimingCondition(Identifiable, VariationPointCapable):
    """
    A TimingCondition describes a dependency on a specific condition. The element owns an expression which describes the timing condition dependency.
    """

    # TimingCondition method parity checklist:
    # Spec: AUTOSAR_CP_TPS_TimingExtensions.pdf, Table 3.7, p.35
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                   [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getTimingConditionFormula  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimingConditionFormula  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self, parent, short_name: str):
        super().__init__(parent, short_name)

        # This is the expression describing the dependency on a specific condition.
        self.timingConditionFormula: Optional[TimingConditionFormula] = None

    def getTimingConditionFormula(self) -> Optional[TimingConditionFormula]:
        """This is the expression describing the dependency on a specific condition."""
        return self.timingConditionFormula

    def setTimingConditionFormula(self, value: Optional[TimingConditionFormula]) -> TimingCondition:
        """This is the expression describing the dependency on a specific condition. A None value is a no-op and does not overwrite an existing formula."""
        if value is not None:
            self.timingConditionFormula = value
        return self


class TimingConditionFormula(FormulaExpression):
    """
    A TimingConditionFormula describes a specific dependency. The expression shall be a boolean expression addressing modes, variables, arguments, and/or events.
    """

    # TimingConditionFormula method parity checklist:
    # Spec: AUTOSAR_CP_TPS_TimingExtensions.pdf, Table 3.8, p.35
    # Spec verified: R23-11
    # 2026-09-25 drift fix (Rule 0012.3): re-parented to FormulaExpression per spec Base row (most-derived) — see docs/plan/atp_mixed_string_hierarchy.md
    # (Referrable base dropped — XSD complexType composes AR-OBJECT + FORMULA-EXPRESSION only, no SHORT-NAME)
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                 [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # getMixedString / setMixedString provided by the AtpMixedString base (mixin) — no spec row (stereotype-inherent)
    # [x] getTimingArgumentRef     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimingArgumentRef     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingConditionRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimingConditionRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingEventRef        [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimingEventRef        [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingModeRef         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimingModeRef         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingVariableRef     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimingVariableRef     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # This refers to an argument of an operation call.
        self.timingArgumentRef: Optional[RefType] = None

        # This refers to a timing condition that is part of an expression describing the dependency on a specific condition.
        self.timingConditionRef: Optional[RefType] = None

        # This refers to a timing event.
        self.timingEventRef: Optional[RefType] = None

        # This refers to a mode declaration.
        self.timingModeRef: Optional[RefType] = None

        # This refers to a variable.
        self.timingVariableRef: Optional[RefType] = None

    def getTimingArgumentRef(self) -> Optional[RefType]:
        """This refers to an argument of an operation call."""
        return self.timingArgumentRef

    def setTimingArgumentRef(self, value: Optional[RefType]) -> TimingConditionFormula:
        """This refers to an argument of an operation call. A None value is a no-op and does not overwrite an existing timingArgumentRef."""
        if value is not None:
            self.timingArgumentRef = value
        return self

    def getTimingConditionRef(self) -> Optional[RefType]:
        """This refers to a timing condition that is part of an expression describing the dependency on a specific condition."""
        return self.timingConditionRef

    def setTimingConditionRef(self, value: Optional[RefType]) -> TimingConditionFormula:
        """This refers to a timing condition that is part of an expression describing the dependency on a specific condition. A None value is a no-op and does not overwrite an existing timingConditionRef."""
        if value is not None:
            self.timingConditionRef = value
        return self

    def getTimingEventRef(self) -> Optional[RefType]:
        """This refers to a timing event."""
        return self.timingEventRef

    def setTimingEventRef(self, value: Optional[RefType]) -> TimingConditionFormula:
        """This refers to a timing event. A None value is a no-op and does not overwrite an existing timingEventRef."""
        if value is not None:
            self.timingEventRef = value
        return self

    def getTimingModeRef(self) -> Optional[RefType]:
        """This refers to a mode declaration."""
        return self.timingModeRef

    def setTimingModeRef(self, value: Optional[RefType]) -> TimingConditionFormula:
        """This refers to a mode declaration. A None value is a no-op and does not overwrite an existing timingModeRef."""
        if value is not None:
            self.timingModeRef = value
        return self

    def getTimingVariableRef(self) -> Optional[RefType]:
        """This refers to a variable."""
        return self.timingVariableRef

    def setTimingVariableRef(self, value: Optional[RefType]) -> TimingConditionFormula:
        """This refers to a variable. A None value is a no-op and does not overwrite an existing timingVariableRef."""
        if value is not None:
            self.timingVariableRef = value
        return self


class TimingExtensionResource(Identifiable):
    """
    A TimingExtensionResource provides the capability to contain instance references referred from within a timing condition formula.
    """

    # TimingExtensionResource method parity checklist:
    # Spec: AUTOSAR_CP_TPS_TimingExtensions.pdf, Table 3.9, p.36
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                 [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] createTimingArgument     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingArguments       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] createTimingMode         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingModes           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] createTimingVariable     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimingVariables       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self, parent, short_name):
        super().__init__(parent, short_name)

        # This refers to an instance reference of an argument of an operation call.
        self.timingArguments: List[AutosarOperationArgumentInstance] = []

        # This refers to an instance reference of a mode declaration.
        self.timingModes: List[TimingModeInstance] = []

        # This refers to an instance reference of a variable.
        self.timingVariables: List[AutosarVariableInstance] = []

    def createTimingArgument(self, short_name: str) -> AutosarOperationArgumentInstance:
        """This refers to an instance reference of an argument of an operation call."""
        if not self.IsElementExists(short_name, AutosarOperationArgumentInstance):
            argument = AutosarOperationArgumentInstance(self, short_name)
            self.addElement(argument)
            self.timingArguments.append(argument)
        return self.getElement(short_name, AutosarOperationArgumentInstance)

    def getTimingArguments(self) -> List[AutosarOperationArgumentInstance]:
        """This refers to an instance reference of an argument of an operation call."""
        return self.timingArguments

    def createTimingMode(self, short_name: str) -> TimingModeInstance:
        """This refers to an instance reference of a mode declaration."""
        if not self.IsElementExists(short_name, TimingModeInstance):
            mode = TimingModeInstance(self, short_name)
            self.addElement(mode)
            self.timingModes.append(mode)
        return self.getElement(short_name, TimingModeInstance)

    def getTimingModes(self) -> List[TimingModeInstance]:
        """This refers to an instance reference of a mode declaration."""
        return self.timingModes

    def createTimingVariable(self, short_name: str) -> AutosarVariableInstance:
        """This refers to an instance reference of a variable."""
        if not self.IsElementExists(short_name, AutosarVariableInstance):
            variable = AutosarVariableInstance(self, short_name)
            self.addElement(variable)
            self.timingVariables.append(variable)
        return self.getElement(short_name, AutosarVariableInstance)

    def getTimingVariables(self) -> List[AutosarVariableInstance]:
        """This refers to an instance reference of a variable."""
        return self.timingVariables
