"""
This module contains the ResourceConsumption class, its aggregated context classes
(HardwareConfiguration, SoftwareContext), and imports related resource consumption
classes for representing resource consumption in AUTOSAR models.
"""

from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.ExecutionTime import (
    AnalyzedExecutionTime,
    ExecutionTime,
    MeasuredExecutionTime,
    RoughEstimateOfExecutionTime,
    SimulatedExecutionTime,
)
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.HeapUsage import HeapUsage, MeasuredHeapUsage, RoughEstimateHeapUsage, WorstCaseHeapUsage
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.MemorySectionUsage import MemorySection, SectionNamePrefix
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Identifiable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import String
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.AccessCount import AccessCountSet


class HardwareConfiguration(ARObject):
    """
    Describes in which mode the hardware is operating while needing this resource consumption.
    """

    # HardwareConfiguration method parity checklist:
    # Spec: R23-11/AUTOSAR_CP_TPS_BSWModuleDescriptionTemplate.pdf, Table 8.18, p.161 (R23-11)
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                  [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getAdditionalInformation  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setAdditionalInformation  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getProcessorMode          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setProcessorMode          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getProcessorSpeed         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setProcessorSpeed         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # Specifies additional information on the Hardware Configuration.
        self.additionalInformation: Optional[String] = None

        # Specifies in which mode the processor is operating.
        self.processorMode: Optional[String] = None

        # Specifies the speed the processor is operating.
        self.processorSpeed: Optional[String] = None

    def getAdditionalInformation(self) -> Optional[String]:
        """
        Specifies additional information on the Hardware Configuration.
        """
        return self.additionalInformation

    def setAdditionalInformation(self, value: Optional[String]) -> "HardwareConfiguration":
        """
        Specifies additional information on the Hardware Configuration.
        A None value is a no-op and does not overwrite an existing additionalInformation.
        """
        if value is not None:
            self.additionalInformation = value
        return self

    def getProcessorMode(self) -> Optional[String]:
        """
        Specifies in which mode the processor is operating.
        """
        return self.processorMode

    def setProcessorMode(self, value: Optional[String]) -> "HardwareConfiguration":
        """
        Specifies in which mode the processor is operating.
        A None value is a no-op and does not overwrite an existing processorMode.
        """
        if value is not None:
            self.processorMode = value
        return self

    def getProcessorSpeed(self) -> Optional[String]:
        """
        Specifies the speed the processor is operating.
        """
        return self.processorSpeed

    def setProcessorSpeed(self, value: Optional[String]) -> "HardwareConfiguration":
        """
        Specifies the speed the processor is operating.
        A None value is a no-op and does not overwrite an existing processorSpeed.
        """
        if value is not None:
            self.processorSpeed = value
        return self


class SoftwareContext(ARObject):
    """
    Specifies the context of the software for this resource consumption.
    """

    # SoftwareContext method parity checklist:
    # Spec: R23-11/AUTOSAR_CP_TPS_BSWModuleDescriptionTemplate.pdf, Table 8.20, p.163 (R23-11)
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__   [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getInput   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setInput   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getState   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setState   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # Specifies the input vector which is used to provide the ExecutionTime.
        self.input: Optional[String] = None

        # Specifies the state the software is in when the Execution Time is provided.
        self.state: Optional[String] = None

    def getInput(self) -> Optional[String]:
        """
        Specifies the input vector which is used to provide the ExecutionTime.
        """
        return self.input

    def setInput(self, value: Optional[String]) -> "SoftwareContext":
        """
        Specifies the input vector which is used to provide the ExecutionTime.
        A None value is a no-op and does not overwrite an existing input.
        """
        if value is not None:
            self.input = value
        return self

    def getState(self) -> Optional[String]:
        """
        Specifies the state the software is in when the Execution Time is provided.
        """
        return self.state

    def setState(self, value: Optional[String]) -> "SoftwareContext":
        """
        Specifies the state the software is in when the Execution Time is provided.
        A None value is a no-op and does not overwrite an existing state.
        """
        if value is not None:
            self.state = value
        return self


# Runtime cycle-breaker: StackUsage.py imports HardwareConfiguration / SoftwareContext
# (defined above) at its bottom, so this import must run after those class definitions
# (Rule 0005).
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ResourceConsumption.StackUsage import MeasuredStackUsage, RoughEstimateStackUsage, StackUsage, WorstCaseStackUsage  # noqa: E402


class ResourceConsumption(Identifiable):
    """
    Description of consumed resources by one implementation of a software.
    """

    # ResourceConsumption method parity checklist:
    # Spec: R23-11/AUTOSAR_CP_TPS_BSWModuleDescriptionTemplate.pdf, Table 8.1, p.138 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__               [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] addAccessCountSet      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getAccessCountSets     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] getExecutionTimes      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] getHeapUsages          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] getMemorySections      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] getMemorySection       [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getSectionNamePrefixes [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] getStackUsages         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] createAnalyzedExecutionTime       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createMeasuredExecutionTime       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createRoughEstimateOfExecutionTime [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createSimulatedExecutionTime      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createMeasuredHeapUsage            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createRoughEstimateHeapUsage       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createWorstCaseHeapUsage           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createMemorySection                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createSectionNamePrefix           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createMeasuredStackUsage           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createRoughEstimateStackUsage      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] createWorstCaseStackUsage          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # Set of access count values.
        self.accessCountSets: List["AccessCountSet"] = []

        # Collection of the execution time descriptions for this implementation. The aggregation of executionTime is subject to variability with the purpose to support the conditional existence of runnable entities.
        self.executionTimes: List[ExecutionTime] = []

        # Collection of the heap memory allocated by this implementation.
        self.heapUsages: List[HeapUsage] = []

        # An abstract memory section required by this Implementation.
        self.memorySections: List[MemorySection] = []

        # A prefix to be used for the memory section symbol in the code.
        self.sectionNamePrefixes: List[SectionNamePrefix] = []

        # Collection of the stack memory usage for each runnable entity of this implementation. The aggregation of Stack Usage is subject to variability with the purpose to support the conditional existence of runnable entities.
        self.stackUsages: List[StackUsage] = []

    def addAccessCountSet(self, value: Optional["AccessCountSet"]) -> "ResourceConsumption":
        """Set of access count values. A None value is a no-op and does not append anything."""
        if value is not None:
            self.accessCountSets.append(value)
        return self

    def getAccessCountSets(self) -> List["AccessCountSet"]:
        """Set of access count values"""
        return self.accessCountSets

    def createAnalyzedExecutionTime(self, short_name: str) -> AnalyzedExecutionTime:
        """
        Creates and adds an AnalyzedExecutionTime to this resource consumption object.

        Args:
            short_name: The short name for the new analyzed execution time

        Returns:
            The created AnalyzedExecutionTime instance
        """
        if not self.IsElementExists(short_name, AnalyzedExecutionTime):
            execution_time = AnalyzedExecutionTime(self, short_name)
            self.addElement(execution_time)
            self.executionTimes.append(execution_time)
        return self.getElement(short_name, AnalyzedExecutionTime)

    def createMeasuredExecutionTime(self, short_name: str) -> MeasuredExecutionTime:
        """
        Creates and adds a MeasuredExecutionTime to this resource consumption object.

        Args:
            short_name: The short name for the new measured execution time

        Returns:
            The created MeasuredExecutionTime instance
        """
        if not self.IsElementExists(short_name, MeasuredExecutionTime):
            execution_time = MeasuredExecutionTime(self, short_name)
            self.addElement(execution_time)
            self.executionTimes.append(execution_time)
        return self.getElement(short_name, MeasuredExecutionTime)

    def createRoughEstimateOfExecutionTime(self, short_name: str) -> RoughEstimateOfExecutionTime:
        """
        Creates and adds a RoughEstimateOfExecutionTime to this resource consumption object.

        Args:
            short_name: The short name for the new rough estimate of execution time

        Returns:
            The created RoughEstimateOfExecutionTime instance
        """
        if not self.IsElementExists(short_name, RoughEstimateOfExecutionTime):
            execution_time = RoughEstimateOfExecutionTime(self, short_name)
            self.addElement(execution_time)
            self.executionTimes.append(execution_time)
        return self.getElement(short_name, RoughEstimateOfExecutionTime)

    def createSimulatedExecutionTime(self, short_name: str) -> SimulatedExecutionTime:
        """
        Creates and adds a SimulatedExecutionTime to this resource consumption object.

        Args:
            short_name: The short name for the new simulated execution time

        Returns:
            The created SimulatedExecutionTime instance
        """
        if not self.IsElementExists(short_name, SimulatedExecutionTime):
            execution_time = SimulatedExecutionTime(self, short_name)
            self.addElement(execution_time)
            self.executionTimes.append(execution_time)
        return self.getElement(short_name, SimulatedExecutionTime)

    def getExecutionTimes(self) -> List[ExecutionTime]:
        """Collection of the execution time descriptions for this implementation. The aggregation of executionTime is subject to variability with the purpose to support the conditional existence of runnable entities."""
        return sorted(self.executionTimes, key=lambda o: o.short_name)

    def createMeasuredHeapUsage(self, short_name: str) -> MeasuredHeapUsage:
        """
        Creates and adds a MeasuredHeapUsage to this resource consumption object.

        Args:
            short_name: The short name for the new measured heap usage

        Returns:
            The created MeasuredHeapUsage instance
        """
        if not self.IsElementExists(short_name, MeasuredHeapUsage):
            heap_usage = MeasuredHeapUsage(self, short_name)
            self.addElement(heap_usage)
            self.heapUsages.append(heap_usage)
        return self.getElement(short_name, MeasuredHeapUsage)

    def createRoughEstimateHeapUsage(self, short_name: str) -> RoughEstimateHeapUsage:
        """
        Creates and adds a RoughEstimateHeapUsage to this resource consumption object.

        Args:
            short_name: The short name for the new rough estimate heap usage

        Returns:
            The created RoughEstimateHeapUsage instance
        """
        if not self.IsElementExists(short_name, RoughEstimateHeapUsage):
            heap_usage = RoughEstimateHeapUsage(self, short_name)
            self.addElement(heap_usage)
            self.heapUsages.append(heap_usage)
        return self.getElement(short_name, RoughEstimateHeapUsage)

    def createWorstCaseHeapUsage(self, short_name: str) -> WorstCaseHeapUsage:
        """
        Creates and adds a WorstCaseHeapUsage to this resource consumption object.

        Args:
            short_name: The short name for the new worst case heap usage

        Returns:
            The created WorstCaseHeapUsage instance
        """
        if not self.IsElementExists(short_name, WorstCaseHeapUsage):
            heap_usage = WorstCaseHeapUsage(self, short_name)
            self.addElement(heap_usage)
            self.heapUsages.append(heap_usage)
        return self.getElement(short_name, WorstCaseHeapUsage)

    def getHeapUsages(self) -> List[HeapUsage]:
        """Collection of the heap memory allocated by this implementation."""
        return sorted(self.heapUsages, key=lambda o: o.short_name)

    def createMemorySection(self, short_name: str) -> MemorySection:
        """
        Creates and adds a MemorySection to this resource consumption object.

        Args:
            short_name: The short name for the new memory section

        Returns:
            The created MemorySection instance
        """
        if not self.IsElementExists(short_name, MemorySection):
            section = MemorySection(self, short_name)
            self.addElement(section)
            self.memorySections.append(section)
        return self.getElement(short_name, MemorySection)

    def getMemorySections(self) -> List[MemorySection]:
        """An abstract memory section required by this Implementation."""
        return sorted(self.memorySections, key=lambda o: o.short_name)

    def getMemorySection(self, short_name: str) -> MemorySection:
        """
        Gets a specific MemorySection by its short name.

        Args:
            short_name: The short name of the memory section to find

        Returns:
            MemorySection instance with the specified short name, or None if not found
        """
        return next(filter(lambda o: isinstance(o, MemorySection) and (o.short_name == short_name), self.elements), None)

    def createSectionNamePrefix(self, short_name: str) -> SectionNamePrefix:
        """
        Creates and adds a SectionNamePrefix to this resource consumption object.

        Args:
            short_name: The short name for the new section name prefix

        Returns:
            The created SectionNamePrefix instance
        """
        if not self.IsElementExists(short_name, SectionNamePrefix):
            prefix = SectionNamePrefix(self, short_name)
            self.addElement(prefix)
            self.sectionNamePrefixes.append(prefix)
        return self.getElement(short_name, SectionNamePrefix)

    def getSectionNamePrefixes(self) -> List[SectionNamePrefix]:
        """A prefix to be used for the memory section symbol in the code."""
        return sorted(self.sectionNamePrefixes, key=lambda o: o.short_name)

    def createMeasuredStackUsage(self, short_name: str) -> MeasuredStackUsage:
        """
        Creates and adds a MeasuredStackUsage to this resource consumption object.

        Args:
            short_name: The short name for the new measured stack usage

        Returns:
            The created MeasuredStackUsage instance
        """
        if not self.IsElementExists(short_name, MeasuredStackUsage):
            section = MeasuredStackUsage(self, short_name)
            self.addElement(section)
            self.stackUsages.append(section)
        return self.getElement(short_name, MeasuredStackUsage)

    def createRoughEstimateStackUsage(self, short_name: str) -> RoughEstimateStackUsage:
        """
        Creates and adds a RoughEstimateStackUsage to this resource consumption object.

        Args:
            short_name: The short name for the new rough estimate stack usage

        Returns:
            The created RoughEstimateStackUsage instance
        """
        if not self.IsElementExists(short_name, RoughEstimateStackUsage):
            section = RoughEstimateStackUsage(self, short_name)
            self.addElement(section)
            self.stackUsages.append(section)
        return self.getElement(short_name, RoughEstimateStackUsage)

    def createWorstCaseStackUsage(self, short_name: str) -> WorstCaseStackUsage:
        """
        Creates and adds a WorstCaseStackUsage to this resource consumption object.

        Args:
            short_name: The short name for the new worst case stack usage

        Returns:
            The created WorstCaseStackUsage instance
        """
        if not self.IsElementExists(short_name, WorstCaseStackUsage):
            section = WorstCaseStackUsage(self, short_name)
            self.addElement(section)
            self.stackUsages.append(section)
        return self.getElement(short_name, WorstCaseStackUsage)

    def getStackUsages(self) -> List[StackUsage]:
        """Collection of the stack memory usage for each runnable entity of this implementation. The aggregation of Stack Usage is subject to variability with the purpose to support the conditional existence of runnable entities."""
        return sorted(self.stackUsages, key=lambda o: o.short_name)
