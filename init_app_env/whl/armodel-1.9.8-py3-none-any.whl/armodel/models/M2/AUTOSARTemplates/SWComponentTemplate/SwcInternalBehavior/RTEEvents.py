"""
This module contains classes for representing AUTOSAR RTE events
in software component internal behavior templates.
"""

from __future__ import annotations

from abc import ABC
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.StereotypeMixins import VariationPointCapable
from typing import List, Optional
from armodel.models.M2.AUTOSARTemplates.CommonStructure.InternalBehavior import AbstractEvent
from armodel.models.M2.AUTOSARTemplates.CommonStructure.ModeDeclaration import ModeActivationKind
from armodel.models.M2.AUTOSARTemplates.GenericStructure.AbstractStructure import AtpStructureElement
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Components.InstanceRefs import RVariableInAtomicSwcInstanceRef, RModeInAtomicSwcInstanceRef
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Components.InstanceRefs import POperationInAtomicSwcInstanceRef
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Identifiable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import RefType, TimeValue


class RTEEvent(AtpStructureElement, AbstractEvent, VariationPointCapable, ABC):
    """Abstract base class for all RTE-related events"""

    # RTEEvent method parity checklist:
    # Spec: R23-11/AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.9, p.541 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getDisabledModeIRefs    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] addDisabledModeIRef     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getStartOnEventRef      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setStartOnEventRef      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        if type(self) is RTEEvent:
            raise TypeError("RTEEvent is an abstract class.")
        super().__init__(parent, short_name)

        # Reference to the Modes that disable the Event.
        self.disabledModeIRefs: List[RModeInAtomicSwcInstanceRef] = []

        # The referenced RunnableEntity starts when the corresponding RTEEvent is raised.
        self.startOnEventRef: Optional[RefType] = None

    def getDisabledModeIRefs(self) -> List[RModeInAtomicSwcInstanceRef]:
        """
        Reference to the Modes that disable the Event.
        """
        return self.disabledModeIRefs

    def addDisabledModeIRef(self, value: Optional[RModeInAtomicSwcInstanceRef]) -> RTEEvent:
        """
        Reference to the Modes that disable the Event.
        A None value is a no-op and does not append anything.
        """
        if value is not None:
            self.disabledModeIRefs.append(value)
        return self

    def getStartOnEventRef(self) -> Optional[RefType]:
        """
        The referenced RunnableEntity starts when the corresponding RTEEvent is raised.
        """
        return self.startOnEventRef

    def setStartOnEventRef(self, value: Optional[RefType]) -> RTEEvent:
        """
        The referenced RunnableEntity starts when the corresponding RTEEvent is raised.
        A None value is a no-op and does not overwrite an existing startOnEventRef.
        """
        if value is not None:
            self.startOnEventRef = value
        return self


class AsynchronousServerCallReturnsEvent(RTEEvent):
    """
    This event is raised when an asynchronous server call is finished.

    [constr_1940] Existence of attribute AsynchronousServerCallReturnsEvent.eventSource: For each AsynchronousServerCallReturnsEvent, attribute eventSource shall exist at the time when the contract phase generation is executed.
    """

    # AsynchronousServerCallReturnsEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.10, p.541
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getEventSourceRef [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEventSourceRef [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # The referenced AsynchronousServerCallResultPoint raises this AsynchronousServerCallReturnsEvent when the asynchronous server call returns.
        self.eventSourceRef: Optional[RefType] = None

    def getEventSourceRef(self) -> Optional[RefType]:
        """
        The referenced AsynchronousServerCallResultPoint raises this AsynchronousServerCallReturnsEvent when the asynchronous server call returns.
        """
        return self.eventSourceRef

    def setEventSourceRef(self, value: Optional[RefType]) -> AsynchronousServerCallReturnsEvent:
        """
        The referenced AsynchronousServerCallResultPoint raises this AsynchronousServerCallReturnsEvent when the asynchronous server call returns.
        A None value is a no-op and does not overwrite an existing eventSourceRef.
        """
        if value is not None:
            self.eventSourceRef = value
        return self


class DataSendCompletedEvent(RTEEvent):
    """
    This event is raised when the referenced explicit data element has been sent or an error occurred.

    [constr_1941] Existence of attribute DataSendCompletedEvent.eventSource: For each DataSendCompletedEvent, attribute eventSource shall exist at the time when the contract phase generation is executed.
    """

    # DataSendCompletedEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.11, p.542
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getEventSourceRef [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEventSourceRef [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # The referenced VariableAccess raises this DataSendCompletedEvent when the explicit write access was successful or an error occurred.
        self.eventSourceRef: Optional[RefType] = None

    def getEventSourceRef(self) -> Optional[RefType]:
        """
        The referenced VariableAccess raises this DataSendCompletedEvent when the explicit write access was successful or an error occurred.
        """
        return self.eventSourceRef

    def setEventSourceRef(self, value: Optional[RefType]) -> DataSendCompletedEvent:
        """
        The referenced VariableAccess raises this DataSendCompletedEvent when the explicit write access was successful or an error occurred.
        A None value is a no-op and does not overwrite an existing eventSourceRef.
        """
        if value is not None:
            self.eventSourceRef = value
        return self


class DataWriteCompletedEvent(RTEEvent):
    """
    This event is raised when an implicit write access was successful or an error occurred.

    [constr_1942] Existence of attribute DataWriteCompletedEvent.eventSource: For each DataWriteCompletedEvent, attribute eventSource shall exist at the time when the contract phase generation is executed.
    """

    # DataWriteCompletedEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.12, p.542
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getEventSourceRef [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEventSourceRef [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # The referenced VariableAccess raises this DataWriteCompletedEvent when the implicit write access was successful or an error occurred.
        self.eventSourceRef: Optional[RefType] = None

    def getEventSourceRef(self) -> Optional[RefType]:
        """The referenced VariableAccess raises this DataWriteCompletedEvent when the implicit write access was successful or an error occurred."""
        return self.eventSourceRef

    def setEventSourceRef(self, value: Optional[RefType]) -> DataWriteCompletedEvent:
        """
        The referenced VariableAccess raises this DataWriteCompletedEvent when the implicit write access was successful or an error occurred.
        A None value is a no-op and does not overwrite an existing eventSourceRef.
        """
        if value is not None:
            self.eventSourceRef = value
        return self


class DataReceivedEvent(RTEEvent):
    """
    This event is raised when the referenced data element is received.

    [constr_1943] Existence of attribute DataReceivedEvent.data: For each DataReceivedEvent, attribute data shall exist at the time when the contract phase generation is executed.
    """

    # DataReceivedEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.13, p.542
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getDataIRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setDataIRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # The referenced VariableDataPrototype raises this DataReceivedEvent when the data has been received. InstanceRef implemented by: RVariableInAtomicSwcInstanceRef
        self.dataIRef: Optional[RVariableInAtomicSwcInstanceRef] = None

    def getDataIRef(self) -> Optional[RVariableInAtomicSwcInstanceRef]:
        """
        The referenced VariableDataPrototype raises this DataReceivedEvent when the data has been received. InstanceRef implemented by: RVariableInAtomicSwcInstanceRef
        """
        return self.dataIRef

    def setDataIRef(self, value: Optional[RVariableInAtomicSwcInstanceRef]) -> DataReceivedEvent:
        """
        The referenced VariableDataPrototype raises this DataReceivedEvent when the data has been received. InstanceRef implemented by: RVariableInAtomicSwcInstanceRef
        A None value is a no-op and does not overwrite an existing dataIRef.
        """
        if value is not None:
            self.dataIRef = value
        return self


class SwcModeSwitchEvent(RTEEvent):
    """
    This event is raised when the specified mode change occurs.
    """

    # SwcModeSwitchEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.17, p.544
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__         [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getActivation    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setActivation    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] addModeIRef      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getModeIRefs     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # Specifies if the event is raised on entering or exiting a specific mode or is raised on the transition between two modes.
        self.activation: Optional[ModeActivationKind] = None

        # The referenced mode or the transition between two modes raises this SwcModeSwitchEvent. InstanceRef implemented by: RModeInAtomicSwc InstanceRef
        self.modeIRefs: List[RModeInAtomicSwcInstanceRef] = []

    def getActivation(self) -> Optional[ModeActivationKind]:
        """
        Specifies if the event is raised on entering or exiting a specific mode or is raised on the transition between two modes.
        """
        return self.activation

    def setActivation(self, value: Optional[ModeActivationKind]) -> SwcModeSwitchEvent:
        """
        Specifies if the event is raised on entering or exiting a specific mode or is raised on the transition between two modes.
        A None value is a no-op and does not overwrite an existing activation.
        """
        if value is not None:
            self.activation = value
        return self

    def addModeIRef(self, value: Optional[RModeInAtomicSwcInstanceRef]) -> SwcModeSwitchEvent:
        """
        The referenced mode or the transition between two modes raises this SwcModeSwitchEvent. InstanceRef implemented by: RModeInAtomicSwc InstanceRef
        A None value is a no-op and does not append anything.
        """
        if value is not None:
            self.modeIRefs.append(value)
        return self

    def getModeIRefs(self) -> List[RModeInAtomicSwcInstanceRef]:
        """
        The referenced mode or the transition between two modes raises this SwcModeSwitchEvent. InstanceRef implemented by: RModeInAtomicSwc InstanceRef
        """
        return self.modeIRefs


class DataReceiveErrorEvent(RTEEvent):
    """
    This event is raised when the Com layer detects and notifies an error concerning the reception of the referenced VariableDataPrototype.

    [constr_1944] Existence of attribute DataReceiveErrorEvent.data: For each DataReceiveErrorEvent, attribute data shall exist at the time when the contract phase generation is executed.
    """

    # DataReceiveErrorEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.14, p.543
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getDataIRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setDataIRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # The referenced VariableDataPrototype raises this DataReceiveErrorEvent when there was an error during the reception. InstanceRef implemented by: RVariableInAtomicSwcInstanceRef
        self.dataIRef: Optional[RVariableInAtomicSwcInstanceRef] = None

    def getDataIRef(self) -> Optional[RVariableInAtomicSwcInstanceRef]:
        """
        The referenced VariableDataPrototype raises this DataReceiveErrorEvent when there was an error during the reception. InstanceRef implemented by: RVariableInAtomicSwcInstanceRef
        """
        return self.dataIRef

    def setDataIRef(self, value: Optional[RVariableInAtomicSwcInstanceRef]) -> DataReceiveErrorEvent:
        """
        The referenced VariableDataPrototype raises this DataReceiveErrorEvent when there was an error during the reception. InstanceRef implemented by: RVariableInAtomicSwcInstanceRef
        A None value is a no-op and does not overwrite an existing dataIRef.
        """
        if value is not None:
            self.dataIRef = value
        return self


class OperationInvokedEvent(RTEEvent):
    """
    This event is raised when the ClientServerOperation referenced in OperationInvokedEvent.operation shall be invoked.

    [constr_1945] Existence of attribute OperationInvokedEvent.operation: For each OperationInvokedEvent, attribute operation shall exist at the time when the contract phase generation is executed.
    """

    # OperationInvokedEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.15, p.543
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getOperationIRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setOperationIRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # This represents the ClientServerOperation which shall be invoked.
        self.operationIRef: Optional[POperationInAtomicSwcInstanceRef] = None

    def getOperationIRef(self) -> Optional[POperationInAtomicSwcInstanceRef]:
        """This represents the ClientServerOperation which shall be invoked."""
        return self.operationIRef

    def setOperationIRef(self, value: Optional[POperationInAtomicSwcInstanceRef]) -> OperationInvokedEvent:
        """
        This represents the ClientServerOperation which shall be invoked.
        A None value is a no-op and does not overwrite an existing operationIRef.
        """
        if value is not None:
            self.operationIRef = value
        return self


class InitEvent(RTEEvent):
    """
    This RTEEvent is supposed to be used for initialization purposes, i.e. for starting and restarting a partition. It is not guaranteed that all RunnableEntities referenced by this InitEvent are executed before the 'regular' RunnableEntities are executed for the first time. The execution order depends on the task mapping.
    """

    # InitEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.22, p.546 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)


class TimingEvent(RTEEvent):
    """
    This event is used to start RunnableEntities that shall be executed
    periodically.
    """

    # TimingEvent method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [ ] test
    # [ ] periodMs                     [x] impl  [ ] docstring  [ ] test
    # [ ] getOffset                    [x] impl  [x] docstring  [ ] test
    # [ ] setOffset                    [x] impl  [x] docstring  [ ] test
    # [ ] getPeriod                    [x] impl  [x] docstring  [ ] test
    # [ ] setPeriod                    [x] impl  [x] docstring  [ ] test

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        self.offset: TimeValue = None
        self.period: TimeValue = None

    @property
    def periodMs(self):
        if self.period is None:
            return None
        else:
            period_value = self.period.getValue() if hasattr(self.period, "getValue") else self.period
            if period_value < 0.001:
                return period_value * 1000
            else:
                return (int)(period_value * 1000)

    def getOffset(self):
        """
        Gets the offset before the first event firing.

        Returns:
            TimeValue: The offset
        """
        return self.offset

    def setOffset(self, value):
        """
        Sets the offset before the first event firing.

        Args:
            value: The offset to set

        Returns:
            self for method chaining
        """
        if value is not None:
            self.offset = value
        return self

    def getPeriod(self):
        """
        Gets the period between event firings.

        Returns:
            TimeValue: The period
        """
        return self.period

    def setPeriod(self, value):
        """
        Sets the period between event firings.

        Args:
            value: The period to set

        Returns:
            self for method chaining
        """
        if value is not None:
            self.period = value
        return self


class InternalTriggerOccurredEvent(RTEEvent):
    """
    This event is raised when the referenced InternalTriggeringPoint has occurred.

    [constr_1950] Existence of attribute InternalTriggerOccurredEvent.eventSource: For each InternalTriggerOccurredEvent, the attribute eventSource shall exist at the time when the RTE is generated.
    """

    # InternalTriggerOccurredEvent method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.21, p.546
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getEventSourceRef [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEventSourceRef [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # The referenced InternalTriggeringPoint raises this InternalTriggerOccurredEvent.
        self.eventSourceRef: Optional[RefType] = None

    def getEventSourceRef(self) -> Optional[RefType]:
        """The referenced InternalTriggeringPoint raises this InternalTriggerOccurredEvent."""
        return self.eventSourceRef

    def setEventSourceRef(self, value: Optional[RefType]) -> InternalTriggerOccurredEvent:
        """
        The referenced InternalTriggeringPoint raises this InternalTriggerOccurredEvent.
        A None value is a no-op and does not overwrite an existing eventSourceRef.
        """
        if value is not None:
            self.eventSourceRef = value
        return self


class BackgroundEvent(RTEEvent):
    """
    This event is used to start RunnableEntities that are supposed to be executed in the background.
    """

    # BackgroundEvent method parity checklist:
    # Spec: R23-11/AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.16, p.544 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__  [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)


class ModeSwitchedAckEvent(RTEEvent):
    """
    This event is raised when the referenced ModeSwitchPoint has been
    processed or an error occurred.
    """

    # ModeSwitchedAckEvent method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [ ] test
    # [ ] getEventSourceRef            [x] impl  [x] docstring  [ ] test
    # [ ] setEventSourceRef            [x] impl  [x] docstring  [ ] test

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        self.eventSourceRef: RefType = None

    def getEventSourceRef(self):
        """
        Gets the event source reference.

        Returns:
            RefType: The event source reference
        """
        return self.eventSourceRef

    def setEventSourceRef(self, value):
        """
        Sets the event source reference.

        Args:
            value: The event source reference to set

        Returns:
            self for method chaining
        """
        if value is not None:
            self.eventSourceRef = value
        return self


class WaitPoint(Identifiable):
    """
    This defines a wait-point for which the RunnableEntity can wait.
    """

    # WaitPoint method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 7.25, p.550
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getTimeout                   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimeout                   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTriggerRef                [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTriggerRef                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # Time in seconds before the WaitPoint times out and the blocking wait call returns with an error indicating the timeout.
        self.timeout: Optional[TimeValue] = None

        # This is the RTEEvent this WaitPoint is waiting for.
        self.triggerRef: Optional[RefType] = None

    def getTimeout(self) -> Optional[TimeValue]:
        """
        Time in seconds before the WaitPoint times out and the blocking wait call returns with an error indicating the timeout.

        Returns:
            Optional[TimeValue]: The timeout, or None if not set
        """
        return self.timeout

    def setTimeout(self, value: Optional[TimeValue]) -> WaitPoint:
        """
        Time in seconds before the WaitPoint times out and the blocking wait call returns with an error indicating the timeout.
        A None value is a no-op and does not overwrite an existing timeout.

        Args:
            value: The timeout to set

        Returns:
            WaitPoint: self for method chaining
        """
        if value is not None:
            self.timeout = value
        return self

    def getTriggerRef(self) -> Optional[RefType]:
        """
        This is the RTEEvent this WaitPoint is waiting for.

        Returns:
            Optional[RefType]: The trigger reference, or None if not set
        """
        return self.triggerRef

    def setTriggerRef(self, value: Optional[RefType]) -> WaitPoint:
        """
        This is the RTEEvent this WaitPoint is waiting for.
        A None value is a no-op and does not overwrite an existing triggerRef.

        Args:
            value: The trigger reference to set

        Returns:
            WaitPoint: self for method chaining
        """
        if value is not None:
            self.triggerRef = value
        return self


class ExternalTriggerOccurredEvent(RTEEvent):
    pass


class OsTaskExecutionEvent(RTEEvent):
    pass


class TransformerHardErrorEvent(RTEEvent):
    pass
