"""
This module contains classes for representing AUTOSAR communication specifications
in the SWComponentTemplate module. It includes various communication specifications
for different types of port communication such as sender/receiver, client/server,
and mode switching communications, as well as non-volatile and parameter communications.
"""

from __future__ import annotations

from abc import ABC
from typing import List, Optional

from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Describable
from armodel.models.M2.MSR.DataDictionary.DataDefProperties import SwDataDefProps
from armodel.models.M2.AUTOSARTemplates.CommonStructure import ValueSpecification
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import AREnum, PositiveInteger, Boolean
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import TimeValue
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import RefType
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.PortInterface.InstanceRefs import ApplicationCompositeElementInPortInterfaceInstanceRef
from armodel.models.M2.AUTOSARTemplates.CommonStructure.Filter import DataFilter
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.SwcInternalBehavior.DataElements import VariableAccess


class HandleInvalidEnum(AREnum):
    """
    Strategies of handling the reception of invalidValue.
    """

    # HandleInvalidEnum method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.3, p.97
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # (no methods) — enum value form serialized on InvalidationPolicy.handleInvalid
    # [x] __init__  [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11

    # Invalidation is switched off. Tags: atp.EnumerationLiteralIndex=0
    DONT_INVALIDATE = "dontInvalidate"
    # Replace a received invalidValue. The replacement value is sourced from the aggregation in the role replaceWith. Tags: atp.EnumerationLiteralIndex=1
    EXTERNAL_REPLACEMENT = "externalReplacement"
    # The application software is supposed to handle signal invalidation on RTE API level either by Data ReceiveErrorEvent or check of error code on read access. Tags: atp.EnumerationLiteralIndex=2
    KEEP = "keep"
    # Replace a received invalidValue. The replacement value is specified by the initValue. Tags: atp.EnumerationLiteralIndex=3
    REPLACE = "replace"

    def __init__(self):
        super().__init__((HandleInvalidEnum.DONT_INVALIDATE, HandleInvalidEnum.EXTERNAL_REPLACEMENT, HandleInvalidEnum.KEEP, HandleInvalidEnum.REPLACE))


class PPortComSpec(ARObject, ABC):
    """
    Communication attributes of a provided PortPrototype. This class will contain attributes that are valid for all kinds of provide ports, independent of client-server or sender-receiver communication patterns.
    """

    # PPortComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.58, p.166
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    def __init__(self):
        if type(self) is PPortComSpec:
            raise TypeError("PPortComSpec is an abstract class.")
        super().__init__()


class RPortComSpec(ARObject, ABC):
    """
    Communication attributes of a required PortPrototype. This class will contain attributes that are valid for all kinds of require-ports, independent of client-server or sender-receiver communication patterns.
    """

    # RPortComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.59, p.167
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    def __init__(self):
        if type(self) is RPortComSpec:
            raise TypeError("RPortComSpec is an abstract class.")

        super().__init__()


class ReceptionComSpecProps(ARObject):
    """
    This meta-class defines a set of reception attributes which the application software is assumed to implement.
    """

    # ReceptionComSpecProps method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.64, p.174
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__             [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getDataUpdatePeriod  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setDataUpdatePeriod  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getTimeout           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setTimeout           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # This attribute defines the period in which the application shall check for updated data. This attribute is used for the configuration of the E2E protection, but may also indicate a general data reception period.
        self.dataUpdatePeriod: Optional[TimeValue] = None

        # This attribute defines the time interval after which the application shall assume that the to be received data reception has timed out, i.e. the respective data has not been received for that amount of time.
        self.timeout: Optional[TimeValue] = None

    def getDataUpdatePeriod(self) -> Optional[TimeValue]:
        """
        This attribute defines the period in which the application shall check for updated data. This attribute is used for the configuration of the E2E protection, but may also indicate a general data reception period.
        """
        return self.dataUpdatePeriod

    def setDataUpdatePeriod(self, value: Optional[TimeValue]) -> ReceptionComSpecProps:
        """
        This attribute defines the period in which the application shall check for updated data. This attribute is used for the configuration of the E2E protection, but may also indicate a general data reception period. A None value is a no-op and does not overwrite an existing dataUpdatePeriod.
        """
        if value is not None:
            self.dataUpdatePeriod = value
        return self

    def getTimeout(self) -> Optional[TimeValue]:
        """
        This attribute defines the time interval after which the application shall assume that the to be received data reception has timed out, i.e. the respective data has not been received for that amount of time.
        """
        return self.timeout

    def setTimeout(self, value: Optional[TimeValue]) -> ReceptionComSpecProps:
        """
        This attribute defines the time interval after which the application shall assume that the to be received data reception has timed out, i.e. the respective data has not been received for that amount of time. A None value is a no-op and does not overwrite an existing timeout.
        """
        if value is not None:
            self.timeout = value
        return self


class CompositeNetworkRepresentation(ARObject):
    """
    This meta-class is used to define the network representation of leaf elements of composite application data types.
    """

    # CompositeNetworkRepresentation method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.74, p.181
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                 [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getLeafElementIRef       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setLeafElementIRef       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getNetworkRepresentation [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setNetworkRepresentation [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # This represents that leaf element of an application composite data type. InstanceRef implemented by: ApplicationCompositeElementInPortInterfaceInstanceRef
        self.leafElementIRef: Optional[ApplicationCompositeElementInPortInterfaceInstanceRef] = None

        # The SwDataDefProps owned by the CompositeNetworkRepresentation are used to define the network representation of the leaf element of an ApplicationCompositeDataType.
        self.networkRepresentation: Optional[SwDataDefProps] = None

    def getLeafElementIRef(self) -> Optional[ApplicationCompositeElementInPortInterfaceInstanceRef]:
        """
        This represents that leaf element of an application composite data type. InstanceRef implemented by: ApplicationCompositeElementInPortInterfaceInstanceRef
        """
        return self.leafElementIRef

    def setLeafElementIRef(self, value: Optional[ApplicationCompositeElementInPortInterfaceInstanceRef]) -> CompositeNetworkRepresentation:
        """
        This represents that leaf element of an application composite data type. InstanceRef implemented by: ApplicationCompositeElementInPortInterfaceInstanceRef. A None value is a no-op and does not overwrite an existing leafElementIRef.
        """
        if value is not None:
            self.leafElementIRef = value
        return self

    def getNetworkRepresentation(self) -> Optional[SwDataDefProps]:
        """
        The SwDataDefProps owned by the CompositeNetworkRepresentation are used to define the network representation of the leaf element of an ApplicationCompositeDataType.
        """
        return self.networkRepresentation

    def setNetworkRepresentation(self, value: Optional[SwDataDefProps]) -> CompositeNetworkRepresentation:
        """
        The SwDataDefProps owned by the CompositeNetworkRepresentation are used to define the network representation of the leaf element of an ApplicationCompositeDataType. A None value is a no-op and does not overwrite an existing networkRepresentation.
        """
        if value is not None:
            self.networkRepresentation = value
        return self


class TransmissionModeDefinitionEnum(AREnum):
    """
    This meta-class defines possible settings for the transmission mode.
    """

    # TransmissionModeDefinitionEnum method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.73, p.181
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # (no methods) — enum value form serialized on TransmissionComSpecProps.transmissionMode
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    # The data is assumed to be transmitted in a cyclic manner. The cycle is defined by dataUpdatePeriod. Tags: atp.EnumerationLiteralIndex=0
    CYCLIC = "cyclic"

    # The data is assumed to be transmitted in a cyclic manner (with cycle time dataUpdatePeriod) and additionally there may be arbitrary transmission if the data value changes (minimumSendInterval to be respected, if defined). Tags: atp.EnumerationLiteralIndex=2
    CYCLIC_AND_ON_CHANGE = "cyclicAndOnChange"

    # The data is assumed to be transmitted in an arbitrary manner (minimumSendInterval to be respected, if defined). Tags: atp.EnumerationLiteralIndex=1
    TRIGGERED = "triggered"

    def __init__(self):
        super().__init__(
            [
                TransmissionModeDefinitionEnum.CYCLIC,
                TransmissionModeDefinitionEnum.CYCLIC_AND_ON_CHANGE,
                TransmissionModeDefinitionEnum.TRIGGERED,
            ]
        )


class TransmissionComSpecProps(ARObject):
    """
    This meta-class defines a set of transmission attributes which the application software is assumed to implement.
    """

    # TransmissionComSpecProps method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.70, p.179
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getDataUpdatePeriod     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDataUpdatePeriod     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMinimumSendInterval  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMinimumSendInterval  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTransmissionMode     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTransmissionMode     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # This attribute defines the period in which the application is assumed to transmit the respective data.
        self.dataUpdatePeriod: Optional[TimeValue] = None

        # This attribute defines the minimum interval between two consecutive transmissions of the respective data the application is assumed to ensure.
        self.minimumSendInterval: Optional[TimeValue] = None

        # The attribute defines the mode in which the application is assumed to transmit the respective data.
        self.transmissionMode: Optional[TransmissionModeDefinitionEnum] = None

    def getDataUpdatePeriod(self) -> Optional[TimeValue]:
        """
        This attribute defines the period in which the application is assumed to transmit the respective data.
        """
        return self.dataUpdatePeriod

    def setDataUpdatePeriod(self, value: Optional[TimeValue]) -> TransmissionComSpecProps:
        """
        This attribute defines the period in which the application is assumed to transmit the respective data.
        A None value is a no-op and does not overwrite an existing dataUpdatePeriod.
        """
        if value is not None:
            self.dataUpdatePeriod = value
        return self

    def getMinimumSendInterval(self) -> Optional[TimeValue]:
        """
        This attribute defines the minimum interval between two consecutive transmissions of the respective data the application is assumed to ensure.
        """
        return self.minimumSendInterval

    def setMinimumSendInterval(self, value: Optional[TimeValue]) -> TransmissionComSpecProps:
        """
        This attribute defines the minimum interval between two consecutive transmissions of the respective data the application is assumed to ensure.
        A None value is a no-op and does not overwrite an existing minimumSendInterval.
        """
        if value is not None:
            self.minimumSendInterval = value
        return self

    def getTransmissionMode(self) -> Optional[TransmissionModeDefinitionEnum]:
        """
        The attribute defines the mode in which the application is assumed to transmit the respective data.
        """
        return self.transmissionMode

    def setTransmissionMode(self, value: Optional[TransmissionModeDefinitionEnum]) -> TransmissionComSpecProps:
        """
        The attribute defines the mode in which the application is assumed to transmit the respective data.
        A None value is a no-op and does not overwrite an existing transmissionMode.
        """
        if value is not None:
            self.transmissionMode = value
        return self


class TransmissionAcknowledgementRequest(ARObject):
    """
    Requests transmission acknowledgement that data has been sent successfully. Success/failure is reported via a SendPoint of a RunnableEntity.
    """

    # TransmissionAcknowledgementRequest method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.71, p.180
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getTimeout   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimeout   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
        self.timeout: Optional[TimeValue] = None

    def getTimeout(self) -> Optional[TimeValue]:
        """
        Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
        """
        return self.timeout

    def setTimeout(self, value: Optional[TimeValue]) -> TransmissionAcknowledgementRequest:
        """
        Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
        A None value is a no-op and does not overwrite an existing timeout.
        """
        if value is not None:
            self.timeout = value
        return self


class SenderComSpec(PPortComSpec, ABC):
    """
    Communication attributes for a sender port (PPortPrototype typed by SenderReceiverInterface).
    """

    # SenderComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.67, p.178
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addCompositeNetworkRepresentation [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getCompositeNetworkRepresentations [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getDataElementRef          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDataElementRef          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHandleOutOfRange        [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHandleOutOfRange        [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getNetworkRepresentation   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setNetworkRepresentation   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTransmissionAcknowledge [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTransmissionAcknowledge [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTransmissionProps       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTransmissionProps       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getUsesEndToEndProtection  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setUsesEndToEndProtection  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        if type(self) is SenderComSpec:
            raise TypeError("SenderComSpec is an abstract class.")

        super().__init__()

        # This represents a CompositeNetworkRepresentation defined in the context of a SenderComSpec. Stereotypes: atpSplitable Tags: atp.Splitkey=compositeNetworkRepresentation
        self.compositeNetworkRepresentations: List[CompositeNetworkRepresentation] = []

        # Data element these quality of service attributes apply to.
        self.dataElementRef: Optional[RefType] = None

        # This attribute controls how out-of-range values shall be dealt with.
        self.handleOutOfRange: Optional[HandleOutOfRangeEnum] = None

        # A networkRepresentation is used to define how the data Element is mapped to a communication bus. Stereotypes: atpSplitable Tags: atp.Splitkey=networkRepresentation
        self.networkRepresentation: Optional[SwDataDefProps] = None

        # Requested transmission acknowledgement for data element.
        self.transmissionAcknowledge: Optional[TransmissionAcknowledgementRequest] = None

        # This aggregation represents the definition transmission props in the context of the enclosing SenderComSpec.
        self.transmissionProps: Optional[TransmissionComSpecProps] = None

        # This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection. Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime
        self.usesEndToEndProtection: Optional[Boolean] = None

    def addCompositeNetworkRepresentation(self, representation: Optional[CompositeNetworkRepresentation]) -> SenderComSpec:
        """
        This represents a CompositeNetworkRepresentation defined in the context of a SenderComSpec. Stereotypes: atpSplitable Tags: atp.Splitkey=compositeNetworkRepresentation
        A None value is a no-op and does not append anything.
        """
        if representation is not None:
            self.compositeNetworkRepresentations.append(representation)
        return self

    def getCompositeNetworkRepresentations(self) -> List[CompositeNetworkRepresentation]:
        """
        This represents a CompositeNetworkRepresentation defined in the context of a SenderComSpec. Stereotypes: atpSplitable Tags: atp.Splitkey=compositeNetworkRepresentation
        """
        return self.compositeNetworkRepresentations

    def getDataElementRef(self) -> Optional[RefType]:
        """
        Data element these quality of service attributes apply to.
        """
        return self.dataElementRef

    def setDataElementRef(self, value: Optional[RefType]) -> SenderComSpec:
        """
        Data element these quality of service attributes apply to.
        A None value is a no-op and does not overwrite an existing dataElementRef.
        """
        if value is not None:
            self.dataElementRef = value
        return self

    def getHandleOutOfRange(self) -> Optional["HandleOutOfRangeEnum"]:
        """
        This attribute controls how out-of-range values shall be dealt with.
        """
        return self.handleOutOfRange

    def setHandleOutOfRange(self, value: Optional["HandleOutOfRangeEnum"]) -> SenderComSpec:
        """
        This attribute controls how out-of-range values shall be dealt with.
        A None value is a no-op and does not overwrite an existing handleOutOfRange.
        """
        if value is not None:
            self.handleOutOfRange = value
        return self

    def getNetworkRepresentation(self) -> Optional[SwDataDefProps]:
        """
        A networkRepresentation is used to define how the data Element is mapped to a communication bus. Stereotypes: atpSplitable Tags: atp.Splitkey=networkRepresentation
        """
        return self.networkRepresentation

    def setNetworkRepresentation(self, value: Optional[SwDataDefProps]) -> SenderComSpec:
        """
        A networkRepresentation is used to define how the data Element is mapped to a communication bus. Stereotypes: atpSplitable Tags: atp.Splitkey=networkRepresentation
        A None value is a no-op and does not overwrite an existing networkRepresentation.
        """
        if value is not None:
            self.networkRepresentation = value
        return self

    def getTransmissionAcknowledge(self) -> Optional[TransmissionAcknowledgementRequest]:
        """
        Requested transmission acknowledgement for data element.
        """
        return self.transmissionAcknowledge

    def setTransmissionAcknowledge(self, value: Optional[TransmissionAcknowledgementRequest]) -> SenderComSpec:
        """
        Requested transmission acknowledgement for data element.
        A None value is a no-op and does not overwrite an existing transmissionAcknowledge.
        """
        if value is not None:
            self.transmissionAcknowledge = value
        return self

    def getTransmissionProps(self) -> Optional[TransmissionComSpecProps]:
        """
        This aggregation represents the definition transmission props in the context of the enclosing SenderComSpec.
        """
        return self.transmissionProps

    def setTransmissionProps(self, value: Optional[TransmissionComSpecProps]) -> SenderComSpec:
        """
        This aggregation represents the definition transmission props in the context of the enclosing SenderComSpec.
        A None value is a no-op and does not overwrite an existing transmissionProps.
        """
        if value is not None:
            self.transmissionProps = value
        return self

    def getUsesEndToEndProtection(self) -> Optional[Boolean]:
        """
        This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection. Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime
        """
        return self.usesEndToEndProtection

    def setUsesEndToEndProtection(self, value: Optional[Boolean]) -> SenderComSpec:
        """
        This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection. Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime
        A None value is a no-op and does not overwrite an existing usesEndToEndProtection.
        """
        if value is not None:
            self.usesEndToEndProtection = value
        return self


class QueuedSenderComSpec(SenderComSpec):
    """
    Communication attributes specific to distribution of events (PPortPrototype, SenderReceiverInterface and dataElement carries an "event").
    """

    # QueuedSenderComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.68, p.179 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()


class NonqueuedSenderComSpec(SenderComSpec):
    """
    Communication attributes for non-queued sender/receiver communication (sender side)
    """

    # NonqueuedSenderComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.69, p.179
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getDataFilter  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDataFilter  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getInitValue  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setInitValue  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # The applicable filter algorithm for filtering the value of the corresponding dataElement.
        self.dataFilter: Optional[DataFilter] = None

        # Initial value to be sent if sender component is not yet fully initialized, but receiver needs data already.
        self.initValue: Optional[ValueSpecification] = None

    def getDataFilter(self) -> Optional[DataFilter]:
        """
        The applicable filter algorithm for filtering the value of the corresponding dataElement.
        """
        return self.dataFilter

    def setDataFilter(self, value: Optional[DataFilter]) -> NonqueuedSenderComSpec:
        """
        The applicable filter algorithm for filtering the value of the corresponding dataElement.
        A None value is a no-op and does not overwrite an existing dataFilter.
        """
        if value is not None:
            self.dataFilter = value
        return self

    def getInitValue(self) -> Optional[ValueSpecification]:
        """
        Initial value to be sent if sender component is not yet fully initialized, but receiver needs data already.
        """
        return self.initValue

    def setInitValue(self, value: Optional[ValueSpecification]) -> NonqueuedSenderComSpec:
        """
        Initial value to be sent if sender component is not yet fully initialized, but receiver needs data already.
        A None value is a no-op and does not overwrite an existing initValue.
        """
        if value is not None:
            self.initValue = value
        return self


class ClientComSpec(RPortComSpec):
    """
    Client-specific communication attributes (RPortPrototype typed by ClientServerInterface).
    """

    # ClientComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.77, p.187
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getEndToEndCallResponseTimeout  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setEndToEndCallResponseTimeout  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getOperationRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setOperationRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] addTransformationComSpecProps  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTransformationComSpecProps  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self):
        super().__init__()

        # This attribute defines the maximum time interval in which the application shall expect the servers's response (time between the sending of the call invocation until the arrival of the server's response).
        self.endToEndCallResponseTimeout: Optional[TimeValue] = None

        # This represents the corresponding ClientServerOperation.
        self.operationRef: Optional[RefType] = None

        # This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        self.transformationComSpecProps: List[TransformationComSpecProps] = []

    def getEndToEndCallResponseTimeout(self) -> Optional[TimeValue]:
        """
        This attribute defines the maximum time interval in which the application shall expect the servers's response (time between the sending of the call invocation until the arrival of the server's response).
        """
        return self.endToEndCallResponseTimeout

    def setEndToEndCallResponseTimeout(self, value: Optional[TimeValue]) -> ClientComSpec:
        """
        This attribute defines the maximum time interval in which the application shall expect the servers's response (time between the sending of the call invocation until the arrival of the server's response).
        A None value is a no-op and does not overwrite an existing endToEndCallResponseTimeout.
        """
        if value is not None:
            self.endToEndCallResponseTimeout = value
        return self

    def getOperationRef(self) -> Optional[RefType]:
        """
        This represents the corresponding ClientServerOperation.
        """
        return self.operationRef

    def setOperationRef(self, value: Optional[RefType]) -> ClientComSpec:
        """
        This represents the corresponding ClientServerOperation.
        A None value is a no-op and does not overwrite an existing operationRef.
        """
        if value is not None:
            self.operationRef = value
        return self

    def addTransformationComSpecProps(self, value: Optional["TransformationComSpecProps"]) -> ClientComSpec:
        """
        This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        A None value is a no-op and does not append anything.
        """
        if value is not None:
            self.transformationComSpecProps.append(value)
        return self

    def getTransformationComSpecProps(self) -> List["TransformationComSpecProps"]:
        """
        This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        """
        return self.transformationComSpecProps


class ModeSwitchReceiverComSpec(RPortComSpec):
    """
    Communication attributes of RPortPrototypes with respect to mode communication
    """

    # ModeSwitchReceiverComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.81, p.191
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getEnhancedModeApi                [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEnhancedModeApi                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getModeGroupRef                   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setModeGroupRef                   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getSupportsAsynchronousModeSwitch [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setSupportsAsynchronousModeSwitch [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # This controls the creation of the enhanced mode API that returns information about the previous mode and the next mode. If set to "true" the enhanced mode API is supposed to be generated. For more details please refer to the SWS_RTE.
        self.enhancedModeApi: Optional[Boolean] = None

        # ModeDeclarationGroupPrototype (of the same PortInterface) to which these communication attributes apply. [constr_1896]
        self.modeGroupRef: Optional[RefType] = None

        # This attribute controls the behavior of the corresponding RPortPrototype with respect to the question whether it can deal with asynchronous mode switch requests, i.e. if set to true, the RPortPrototype is able to deal with an asynchronous mode switch request.
        self.supportsAsynchronousModeSwitch: Optional[Boolean] = None

    def getEnhancedModeApi(self) -> Optional[Boolean]:
        """
        This controls the creation of the enhanced mode API that returns information about the previous mode and the next mode. If set to "true" the enhanced mode API is supposed to be generated. For more details please refer to the SWS_RTE.
        """
        return self.enhancedModeApi

    def setEnhancedModeApi(self, value: Optional[Boolean]) -> ModeSwitchReceiverComSpec:
        """
        This controls the creation of the enhanced mode API that returns information about the previous mode and the next mode. If set to "true" the enhanced mode API is supposed to be generated. For more details please refer to the SWS_RTE. A None value is a no-op and does not overwrite an existing enhancedModeApi.
        """
        if value is not None:
            self.enhancedModeApi = value
        return self

    def getModeGroupRef(self) -> Optional[RefType]:
        """
        ModeDeclarationGroupPrototype (of the same PortInterface) to which these communication attributes apply. [constr_1896]
        """
        return self.modeGroupRef

    def setModeGroupRef(self, value: Optional[RefType]) -> ModeSwitchReceiverComSpec:
        """
        ModeDeclarationGroupPrototype (of the same PortInterface) to which these communication attributes apply. [constr_1896] A None value is a no-op and does not overwrite an existing modeGroupRef.
        """
        if value is not None:
            self.modeGroupRef = value
        return self

    def getSupportsAsynchronousModeSwitch(self) -> Optional[Boolean]:
        """
        This attribute controls the behavior of the corresponding RPortPrototype with respect to the question whether it can deal with asynchronous mode switch requests, i.e. if set to true, the RPortPrototype is able to deal with an asynchronous mode switch request.
        """
        return self.supportsAsynchronousModeSwitch

    def setSupportsAsynchronousModeSwitch(self, value: Optional[Boolean]) -> ModeSwitchReceiverComSpec:
        """
        This attribute controls the behavior of the corresponding RPortPrototype with respect to the question whether it can deal with asynchronous mode switch requests, i.e. if set to true, the RPortPrototype is able to deal with an asynchronous mode switch request. A None value is a no-op and does not overwrite an existing supportsAsynchronousModeSwitch.
        """
        if value is not None:
            self.supportsAsynchronousModeSwitch = value
        return self


class NvRequireComSpec(RPortComSpec):
    """
    Communication attributes of RPortPrototypes with respect to Nv data communication on the required side.
    """

    # NvRequireComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.84, p.194
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getInitValue                 [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setInitValue                 [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getVariableRef               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setVariableRef               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # The initial value owned by the NvComSpec
        self.initValue: Optional[ValueSpecification] = None

        # The VariableDataPrototype the ComSpec applies for. [constr_1899]
        self.variableRef: Optional[RefType] = None

    def getInitValue(self) -> Optional[ValueSpecification]:
        """
        The initial value owned by the NvComSpec
        """
        return self.initValue

    def setInitValue(self, value: Optional[ValueSpecification]) -> NvRequireComSpec:
        """
        The initial value owned by the NvComSpec A None value is a no-op and does not overwrite an existing initValue.
        """
        if value is not None:
            self.initValue = value
        return self

    def getVariableRef(self) -> Optional[RefType]:
        """
        The VariableDataPrototype the ComSpec applies for. [constr_1899]
        """
        return self.variableRef

    def setVariableRef(self, value: Optional[RefType]) -> NvRequireComSpec:
        """
        The VariableDataPrototype the ComSpec applies for. [constr_1899] A None value is a no-op and does not overwrite an existing variableRef.
        """
        if value is not None:
            self.variableRef = value
        return self


class ParameterRequireComSpec(RPortComSpec):
    """
    "Communication" specification that applies to parameters on the required side of a connection.
    """

    # ParameterRequireComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.83, p.193
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__           [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getInitValue       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setInitValue       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getParameterRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setParameterRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # The initial value applicable for the corresponding ParameterDataPrototype.
        self.initValue: Optional[ValueSpecification] = None

        # The ParameterDataPrototype to which the ParameterRequireComSpec applies. [constr_1898]
        self.parameterRef: Optional[RefType] = None

    def getInitValue(self) -> Optional[ValueSpecification]:
        """
        The initial value applicable for the corresponding ParameterDataPrototype.
        """
        return self.initValue

    def setInitValue(self, value: Optional[ValueSpecification]) -> ParameterRequireComSpec:
        """
        The initial value applicable for the corresponding ParameterDataPrototype. A None value is a no-op and does not overwrite an existing initValue.
        """
        if value is not None:
            self.initValue = value
        return self

    def getParameterRef(self) -> Optional[RefType]:
        """
        The ParameterDataPrototype to which the ParameterRequireComSpec applies. [constr_1898]
        """
        return self.parameterRef

    def setParameterRef(self, value: Optional[RefType]) -> ParameterRequireComSpec:
        """
        The ParameterDataPrototype to which the ParameterRequireComSpec applies. [constr_1898] A None value is a no-op and does not overwrite an existing parameterRef.
        """
        if value is not None:
            self.parameterRef = value
        return self


class ReceiverComSpec(RPortComSpec, ABC):
    """
    Receiver-specific communication attributes (RPortPrototype typed by SenderReceiverInterface).
    """

    # ReceiverComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.60, p.172
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addCompositeNetworkRepresentation [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getCompositeNetworkRepresentations [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getDataElementRef            [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDataElementRef            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHandleOutOfRange          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHandleOutOfRange          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHandleOutOfRangeStatus    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHandleOutOfRangeStatus    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMaxDeltaCounterInit       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMaxDeltaCounterInit       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMaxNoNewOrRepeatedData    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMaxNoNewOrRepeatedData    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getNetworkRepresentation     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setNetworkRepresentation     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getReceptionProps            [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setReceptionProps            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getReplaceWith               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setReplaceWith               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getSyncCounterInit           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setSyncCounterInit           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] addTransformationComSpecProps [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTransformationComSpecProps [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getUsesEndToEndProtection    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setUsesEndToEndProtection    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        if type(self) is ReceiverComSpec:
            raise TypeError("ReceiverComSpec is an abstract class.")
        super().__init__()

        # This represents a CompositeNetworkRepresentation defined in the context of a ReceiverComSpec. The purpose of this aggregation is to be able to specify the network representation of leaf elements of Application CompositeDataTypes.
        self.compositeNetworkRepresentations: List[CompositeNetworkRepresentation] = []

        # Data element these attributes belong to.
        self.dataElementRef: Optional[RefType] = None

        # This attribute controls how values that are out of the specified range are handled according to the values of HandleOutOfRangeEnum.
        self.handleOutOfRange: Optional[HandleOutOfRangeEnum] = None

        # Control the way how return values are created in case of an out-of-range situation.
        self.handleOutOfRangeStatus: Optional[HandleOutOfRangeStatusEnum] = None

        # Initial maximum allowed gap between two counter values of two consecutively received valid Data, i.e. how many subsequent lost data is accepted. For example, if the receiver gets Data with counter 1 and MaxDeltaCounterInit is 1, then at the next reception the receiver can accept Counters with values 2 and 3, but not 4. Note that if the receiver does not receive new Data at a consecutive read, then the receiver increments the tolerance by 1. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        self.maxDeltaCounterInit: Optional[PositiveInteger] = None

        # The maximum amount of missing or repeated Data which the receiver does not expect to exceed under normal communication conditions. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        self.maxNoNewOrRepeatedData: Optional[PositiveInteger] = None

        # A networkRepresentation is used to define how the data Element is mapped to a communication bus.
        self.networkRepresentation: Optional[SwDataDefProps] = None

        # This aggregation represents the definition transmission props in the context of the enclosing ReceiverComSpec.
        self.receptionProps: Optional[ReceptionComSpecProps] = None

        # This aggregation is used to identify the AutosarData Prototype to be taken for sourcing an external replacement in the out-of-range and invalidValue handling.
        self.replaceWith: Optional[VariableAccess] = None

        # Number of Data required for validating the consistency of the counter that shall be received with a valid counter (i.e. counter within the allowed lock-in range) after the detection of an unexpected behavior of a received counter. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        self.syncCounterInit: Optional[PositiveInteger] = None

        # This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        self.transformationComSpecProps: List[TransformationComSpecProps] = []

        # This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        self.usesEndToEndProtection: Optional[Boolean] = None

    def addCompositeNetworkRepresentation(self, representation: CompositeNetworkRepresentation) -> ReceiverComSpec:
        """
        This represents a CompositeNetworkRepresentation defined in the context of a ReceiverComSpec. The purpose of this aggregation is to be able to specify the network representation of leaf elements of Application CompositeDataTypes. Stereotypes: atpSplitable Tags: atp.Splitkey=compositeNetworkRepresentation
        A None value is a no-op and does not append anything.
        """
        if representation is not None:
            self.compositeNetworkRepresentations.append(representation)
        return self

    def getCompositeNetworkRepresentations(self) -> List[CompositeNetworkRepresentation]:
        """
        This represents a CompositeNetworkRepresentation defined in the context of a ReceiverComSpec. The purpose of this aggregation is to be able to specify the network representation of leaf elements of Application CompositeDataTypes. Stereotypes: atpSplitable Tags: atp.Splitkey=compositeNetworkRepresentation
        """
        return self.compositeNetworkRepresentations

    def getDataElementRef(self) -> Optional[RefType]:
        """
        Data element these attributes belong to.
        """
        return self.dataElementRef

    def setDataElementRef(self, value: Optional[RefType]) -> ReceiverComSpec:
        """
        Data element these attributes belong to.
        A None value is a no-op and does not overwrite an existing dataElementRef.
        """
        if value is not None:
            self.dataElementRef = value
        return self

    def getHandleOutOfRange(self) -> Optional["HandleOutOfRangeEnum"]:
        """
        This attribute controls how values that are out of the specified range are handled according to the values of HandleOutOfRangeEnum.
        """
        return self.handleOutOfRange

    def setHandleOutOfRange(self, value: Optional["HandleOutOfRangeEnum"]) -> ReceiverComSpec:
        """
        This attribute controls how values that are out of the specified range are handled according to the values of HandleOutOfRangeEnum.
        A None value is a no-op and does not overwrite an existing handleOutOfRange.
        """
        if value is not None:
            self.handleOutOfRange = value
        return self

    def getHandleOutOfRangeStatus(self) -> Optional["HandleOutOfRangeStatusEnum"]:
        """
        Control the way how return values are created in case of an out-of-range situation.
        """
        return self.handleOutOfRangeStatus

    def setHandleOutOfRangeStatus(self, value: Optional["HandleOutOfRangeStatusEnum"]) -> ReceiverComSpec:
        """
        Control the way how return values are created in case of an out-of-range situation.
        A None value is a no-op and does not overwrite an existing handleOutOfRangeStatus.
        """
        if value is not None:
            self.handleOutOfRangeStatus = value
        return self

    def getMaxDeltaCounterInit(self) -> Optional[PositiveInteger]:
        """
        Initial maximum allowed gap between two counter values of two consecutively received valid Data, i.e. how many subsequent lost data is accepted. For example, if the receiver gets Data with counter 1 and MaxDeltaCounterInit is 1, then at the next reception the receiver can accept Counters with values 2 and 3, but not 4. Note that if the receiver does not receive new Data at a consecutive read, then the receiver increments the tolerance by 1. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach. Stereotypes: atpVariation
        """
        return self.maxDeltaCounterInit

    def setMaxDeltaCounterInit(self, value: Optional[PositiveInteger]) -> ReceiverComSpec:
        """
        Initial maximum allowed gap between two counter values of two consecutively received valid Data, i.e. how many subsequent lost data is accepted. For example, if the receiver gets Data with counter 1 and MaxDeltaCounterInit is 1, then at the next reception the receiver can accept Counters with values 2 and 3, but not 4. Note that if the receiver does not receive new Data at a consecutive read, then the receiver increments the tolerance by 1. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach. Stereotypes: atpVariation
        A None value is a no-op and does not overwrite an existing maxDeltaCounterInit.
        """
        if value is not None:
            self.maxDeltaCounterInit = value
        return self

    def getMaxNoNewOrRepeatedData(self) -> Optional[PositiveInteger]:
        """
        The maximum amount of missing or repeated Data which the receiver does not expect to exceed under normal communication conditions. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        """
        return self.maxNoNewOrRepeatedData

    def setMaxNoNewOrRepeatedData(self, value: Optional[PositiveInteger]) -> ReceiverComSpec:
        """
        The maximum amount of missing or repeated Data which the receiver does not expect to exceed under normal communication conditions. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        A None value is a no-op and does not overwrite an existing maxNoNewOrRepeatedData.
        """
        if value is not None:
            self.maxNoNewOrRepeatedData = value
        return self

    def getNetworkRepresentation(self) -> Optional[SwDataDefProps]:
        """
        A networkRepresentation is used to define how the data Element is mapped to a communication bus. Stereotypes: atpSplitable Tags: atp.Splitkey=networkRepresentation
        """
        return self.networkRepresentation

    def setNetworkRepresentation(self, value: Optional[SwDataDefProps]) -> ReceiverComSpec:
        """
        A networkRepresentation is used to define how the data Element is mapped to a communication bus. Stereotypes: atpSplitable Tags: atp.Splitkey=networkRepresentation
        A None value is a no-op and does not overwrite an existing networkRepresentation.
        """
        if value is not None:
            self.networkRepresentation = value
        return self

    def getReceptionProps(self) -> Optional[ReceptionComSpecProps]:
        """
        This aggregation represents the definition transmission props in the context of the enclosing ReceiverComSpec.
        """
        return self.receptionProps

    def setReceptionProps(self, value: Optional[ReceptionComSpecProps]) -> ReceiverComSpec:
        """
        This aggregation represents the definition transmission props in the context of the enclosing ReceiverComSpec.
        A None value is a no-op and does not overwrite an existing receptionProps.
        """
        if value is not None:
            self.receptionProps = value
        return self

    def getReplaceWith(self) -> Optional[VariableAccess]:
        """
        This aggregation is used to identify the AutosarData Prototype to be taken for sourcing an external replacement in the out-of-range and invalidValue handling.
        """
        return self.replaceWith

    def setReplaceWith(self, value: Optional[VariableAccess]) -> ReceiverComSpec:
        """
        This aggregation is used to identify the AutosarData Prototype to be taken for sourcing an external replacement in the out-of-range and invalidValue handling.
        A None value is a no-op and does not overwrite an existing replaceWith.
        """
        if value is not None:
            self.replaceWith = value
        return self

    def getSyncCounterInit(self) -> Optional[PositiveInteger]:
        """
        Number of Data required for validating the consistency of the counter that shall be received with a valid counter (i.e. counter within the allowed lock-in range) after the detection of an unexpected behavior of a received counter. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        """
        return self.syncCounterInit

    def setSyncCounterInit(self, value: Optional[PositiveInteger]) -> ReceiverComSpec:
        """
        Number of Data required for validating the consistency of the counter that shall be received with a valid counter (i.e. counter within the allowed lock-in range) after the detection of an unexpected behavior of a received counter. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach.
        A None value is a no-op and does not overwrite an existing syncCounterInit.
        """
        if value is not None:
            self.syncCounterInit = value
        return self

    def addTransformationComSpecProps(self, value: Optional["TransformationComSpecProps"]) -> ReceiverComSpec:
        """
        This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        A None value is a no-op and does not append anything.
        """
        if value is not None:
            self.transformationComSpecProps.append(value)
        return self

    def getTransformationComSpecProps(self) -> List["TransformationComSpecProps"]:
        """
        This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        """
        return self.transformationComSpecProps

    def getUsesEndToEndProtection(self) -> Optional[Boolean]:
        """
        This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach. Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime
        """
        return self.usesEndToEndProtection

    def setUsesEndToEndProtection(self, value: Optional[Boolean]) -> ReceiverComSpec:
        """
        This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection. Caveat: The E2E wrapper approach involves technologies that are not subjected to the AUTOSAR standard and is superseded by the superior E2E transformer approach (which is fully standardized by AUTOSAR). Hence, new projects (without legacy constraints due to carry-over parts) shall use the fully standardized E2E transformer approach. Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime
        A None value is a no-op and does not overwrite an existing usesEndToEndProtection.
        """
        if value is not None:
            self.usesEndToEndProtection = value
        return self


class ModeSwitchedAckRequest(ARObject):
    """
    Requests acknowledgements that a mode switch has been proceeded successfully
    """

    # ModeSwitchedAckRequest method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.80, p.190
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getTimeout   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setTimeout   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
        self.timeout: Optional[TimeValue] = None

    def getTimeout(self) -> Optional[TimeValue]:
        """
        Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
        """
        return self.timeout

    def setTimeout(self, value: Optional[TimeValue]) -> ModeSwitchedAckRequest:
        """
        Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again. A None value is a no-op and does not overwrite an existing timeout.
        """
        if value is not None:
            self.timeout = value
        return self


class ModeSwitchSenderComSpec(PPortComSpec):
    """
    Communication attributes of PPortPrototypes with respect to mode communication
    """

    # ModeSwitchSenderComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.79, p.190
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__             [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getEnhancedModeApi   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEnhancedModeApi   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getModeGroupRef      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setModeGroupRef      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getModeSwitchedAck   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setModeSwitchedAck   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getQueueLength       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setQueueLength       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # This controls the creation of the enhanced mode API that returns information about the previous mode and the next mode. If set to "true" the enhanced mode API is supposed to be generated. For more details please refer to the SWS_RTE.
        self.enhancedModeApi: Optional[Boolean] = None

        # ModeDeclarationGroupPrototype (of the same PortInterface) to which these communication attributes apply. [constr_1895]
        self.modeGroupRef: Optional[RefType] = None

        # If this aggregation exists an acknowledgement for the successful processing of the mode switch request is required.
        self.modeSwitchedAck: Optional[ModeSwitchedAckRequest] = None

        # Length of call queue on the mode user side. The queue is implemented by the RTE. The value shall be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed. [constr_1894]
        self.queueLength: Optional[PositiveInteger] = None

    def getEnhancedModeApi(self) -> Optional[Boolean]:
        """
        This controls the creation of the enhanced mode API that returns information about the previous mode and the next mode. If set to "true" the enhanced mode API is supposed to be generated. For more details please refer to the SWS_RTE.
        """
        return self.enhancedModeApi

    def setEnhancedModeApi(self, value: Optional[Boolean]) -> ModeSwitchSenderComSpec:
        """
        This controls the creation of the enhanced mode API that returns information about the previous mode and the next mode. If set to "true" the enhanced mode API is supposed to be generated. For more details please refer to the SWS_RTE. A None value is a no-op and does not overwrite an existing enhancedModeApi.
        """
        if value is not None:
            self.enhancedModeApi = value
        return self

    def getModeGroupRef(self) -> Optional[RefType]:
        """
        ModeDeclarationGroupPrototype (of the same PortInterface) to which these communication attributes apply. [constr_1895]
        """
        return self.modeGroupRef

    def setModeGroupRef(self, value: Optional[RefType]) -> ModeSwitchSenderComSpec:
        """
        ModeDeclarationGroupPrototype (of the same PortInterface) to which these communication attributes apply. [constr_1895] A None value is a no-op and does not overwrite an existing modeGroupRef.
        """
        if value is not None:
            self.modeGroupRef = value
        return self

    def getModeSwitchedAck(self) -> Optional[ModeSwitchedAckRequest]:
        """
        If this aggregation exists an acknowledgement for the successful processing of the mode switch request is required.
        """
        return self.modeSwitchedAck

    def setModeSwitchedAck(self, value: Optional[ModeSwitchedAckRequest]) -> ModeSwitchSenderComSpec:
        """
        If this aggregation exists an acknowledgement for the successful processing of the mode switch request is required. A None value is a no-op and does not overwrite an existing modeSwitchedAck.
        """
        if value is not None:
            self.modeSwitchedAck = value
        return self

    def getQueueLength(self) -> Optional[PositiveInteger]:
        """
        Length of call queue on the mode user side. The queue is implemented by the RTE. The value shall be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed. [constr_1894]
        """
        return self.queueLength

    def setQueueLength(self, value: Optional[PositiveInteger]) -> ModeSwitchSenderComSpec:
        """
        Length of call queue on the mode user side. The queue is implemented by the RTE. The value shall be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed. [constr_1894] A None value is a no-op and does not overwrite an existing queueLength.
        """
        if value is not None:
            self.queueLength = value
        return self


class ParameterProvideComSpec(PPortComSpec):
    """
    "Communication" specification that applies to parameters on the provided side of a connection.
    """

    # ParameterProvideComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.82, p.192
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getInitValue  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setInitValue  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getParameterRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setParameterRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # The initial value applicable for the corresponding ParameterDataPrototype.
        self.initValue: Optional[ValueSpecification] = None

        # The ParameterDataPrototype to which the Parameter ComSpec applies.
        self.parameterRef: Optional[RefType] = None

    def getInitValue(self) -> Optional[ValueSpecification]:
        """
        The initial value applicable for the corresponding ParameterDataPrototype.
        """
        return self.initValue

    def setInitValue(self, value: Optional[ValueSpecification]) -> ParameterProvideComSpec:
        """
        The initial value applicable for the corresponding ParameterDataPrototype.
        A None value is a no-op and does not overwrite an existing initValue.
        """
        if value is not None:
            self.initValue = value
        return self

    def getParameterRef(self) -> Optional[RefType]:
        """
        The ParameterDataPrototype to which the Parameter ComSpec applies.
        """
        return self.parameterRef

    def setParameterRef(self, value: Optional[RefType]) -> ParameterProvideComSpec:
        """
        The ParameterDataPrototype to which the Parameter ComSpec applies.
        A None value is a no-op and does not overwrite an existing parameterRef.
        """
        if value is not None:
            self.parameterRef = value
        return self


class TransformationComSpecProps(Describable, ABC):
    """
    TransformationComSpecProps holds all the attributes for transformers that are port specific.
    """

    # TransformationComSpecProps method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.86, p.197
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    def __init__(self):
        if type(self) is TransformationComSpecProps:
            raise TypeError("TransformationComSpecProps is an abstract class.")

        super().__init__()


class UserDefinedTransformationComSpecProps(TransformationComSpecProps):
    """
    The UserDefinedTransformationComSpecProps is used to specify port specific configuration properties for custom transformers.
    """

    # UserDefinedTransformationComSpecProps method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.91, p.200 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()


class ServerComSpec(PPortComSpec):
    """
    Communication attributes for a server port (PPortPrototype and ClientServerInterface).
    """

    # ServerComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.78, p.188
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getOperationRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setOperationRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getQueueLength  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setQueueLength  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] addTransformationComSpecProps  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTransformationComSpecProps  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer

    def __init__(self):
        super().__init__()

        # Operation these communication attributes apply to.
        self.operationRef: Optional[RefType] = None

        # Length of call queue on the server side. The queue is implemented by the RTE. The value shall be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
        self.queueLength: Optional[PositiveInteger] = None

        # This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        self.transformationComSpecProps: List[TransformationComSpecProps] = []

    def getOperationRef(self) -> Optional[RefType]:
        """
        Operation these communication attributes apply to.
        """
        return self.operationRef

    def setOperationRef(self, value: Optional[RefType]) -> ServerComSpec:
        """
        Operation these communication attributes apply to.
        A None value is a no-op and does not overwrite an existing operationRef.
        """
        if value is not None:
            self.operationRef = value
        return self

    def getQueueLength(self) -> Optional[PositiveInteger]:
        """
        Length of call queue on the server side. The queue is implemented by the RTE. The value shall be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
        """
        return self.queueLength

    def setQueueLength(self, value: Optional[PositiveInteger]) -> ServerComSpec:
        """
        Length of call queue on the server side. The queue is implemented by the RTE. The value shall be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
        A None value is a no-op and does not overwrite an existing queueLength.
        """
        if value is not None:
            self.queueLength = value
        return self

    def addTransformationComSpecProps(self, value: Optional[TransformationComSpecProps]) -> ServerComSpec:
        """
        This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        A None value is a no-op and does not append anything.
        """
        if value is not None:
            self.transformationComSpecProps.append(value)
        return self

    def getTransformationComSpecProps(self) -> List[TransformationComSpecProps]:
        """
        This references the TransformationComSpecProps which define port-specific configuration for data transformation.
        """
        return self.transformationComSpecProps


class NvProvideComSpec(PPortComSpec):
    """
    Communication attributes of PPortPrototypes with respect to Nv data communication on the provided side.
    """

    # NvProvideComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.85, p.195
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getRamBlockInitValue         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setRamBlockInitValue         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getRomBlockInitValue         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setRomBlockInitValue         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getVariableRef               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setVariableRef               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # This represents the initial value of the RAM Block that corresponds to the referenced variable.
        self.ramBlockInitValue: Optional[ValueSpecification] = None

        # This represents the initial value of the ROM block that corresponds to the referenced variable.
        self.romBlockInitValue: Optional[ValueSpecification] = None

        # This represents the variable for which the ComSpec is specified. [constr_1900]
        self.variableRef: Optional[RefType] = None

    def getRamBlockInitValue(self) -> Optional[ValueSpecification]:
        """
        This represents the initial value of the RAM Block that corresponds to the referenced variable.
        """
        return self.ramBlockInitValue

    def setRamBlockInitValue(self, value: Optional[ValueSpecification]) -> NvProvideComSpec:
        """
        This represents the initial value of the RAM Block that corresponds to the referenced variable. A None value is a no-op and does not overwrite an existing ramBlockInitValue.
        """
        if value is not None:
            self.ramBlockInitValue = value
        return self

    def getRomBlockInitValue(self) -> Optional[ValueSpecification]:
        """
        This represents the initial value of the ROM block that corresponds to the referenced variable.
        """
        return self.romBlockInitValue

    def setRomBlockInitValue(self, value: Optional[ValueSpecification]) -> NvProvideComSpec:
        """
        This represents the initial value of the ROM block that corresponds to the referenced variable. A None value is a no-op and does not overwrite an existing romBlockInitValue.
        """
        if value is not None:
            self.romBlockInitValue = value
        return self

    def getVariableRef(self) -> Optional[RefType]:
        """
        This represents the variable for which the ComSpec is specified. [constr_1900]
        """
        return self.variableRef

    def setVariableRef(self, value: Optional[RefType]) -> NvProvideComSpec:
        """
        This represents the variable for which the ComSpec is specified. [constr_1900] A None value is a no-op and does not overwrite an existing variableRef.
        """
        if value is not None:
            self.variableRef = value
        return self


class NonqueuedReceiverComSpec(ReceiverComSpec):
    """
    Communication attributes specific to non-queued receiving.
    """

    # NonqueuedReceiverComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.62, p.173
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getAliveTimeout              [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setAliveTimeout              [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getEnableUpdate              [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setEnableUpdate              [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getFilter                    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setFilter                    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHandleDataStatus          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHandleDataStatus          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHandleNeverReceived       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHandleNeverReceived       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getHandleTimeoutType         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setHandleTimeoutType         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getInitValue                 [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setInitValue                 [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getTimeoutSubstitutionValue  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setTimeoutSubstitutionValue  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Specify the amount of time (in seconds) after which the software component (via the RTE) needs to be notified if the corresponding data item have not been received according to the specified timing description. If the aliveTimeout attribute is 0 no timeout monitoring shall be performed.
        self.aliveTimeout: Optional[TimeValue] = None

        # This attribute controls whether application code is entitled to check whether the value of the corresponding Variable DataPrototype has been updated.
        self.enableUpdate: Optional[Boolean] = None

        # The applicable filter algorithm for filtering the value of the corresponding dataElement.
        self.filter: Optional[DataFilter] = None

        # If this attribute is set to true, then the Rte_IStatus API shall exist. If the attribute does not exist or is set to false, then the Rte_IStatus API may still exist in response to the existence of further conditions.
        self.handleDataStatus: Optional[Boolean] = None

        # This attribute specifies whether for the corresponding VariableDataPrototype the "never received" flag is available. If yes, the RTE is supposed to assume that initially the VariableDataPrototype has not been received before. After the first reception of the corresponding VariableDataPrototype the flag is cleared. • If the value of this attribute is set to "true" the flag is required. • If set to "false", the RTE shall not support the "never received" functionality for the corresponding Variable DataPrototype.
        self.handleNeverReceived: Optional[Boolean] = None

        # This attribute controls the behavior with respect to the handling of timeouts.
        self.handleTimeoutType: Optional["HandleTimeoutEnum"] = None

        # Initial value to be used in case the sending component is not yet initialized. If the sender also specifies an initial value, then the receiver's value will be used.
        self.initValue: Optional[ValueSpecification] = None

        # This attribute represents the substitution value applicable in the case of a timeout.
        self.timeoutSubstitutionValue: Optional[ValueSpecification] = None

    def getAliveTimeout(self) -> Optional[TimeValue]:
        """
        Specify the amount of time (in seconds) after which the software component (via the RTE) needs to be notified if the corresponding data item have not been received according to the specified timing description. If the aliveTimeout attribute is 0 no timeout monitoring shall be performed.
        """
        return self.aliveTimeout

    def setAliveTimeout(self, value: Optional[TimeValue]) -> NonqueuedReceiverComSpec:
        """
        Specify the amount of time (in seconds) after which the software component (via the RTE) needs to be notified if the corresponding data item have not been received according to the specified timing description. If the aliveTimeout attribute is 0 no timeout monitoring shall be performed.
        A None value is a no-op and does not overwrite an existing aliveTimeout.
        """
        if value is not None:
            self.aliveTimeout = value
        return self

    def getEnableUpdate(self) -> Optional[Boolean]:
        """
        This attribute controls whether application code is entitled to check whether the value of the corresponding Variable DataPrototype has been updated.
        """
        return self.enableUpdate

    def setEnableUpdate(self, value: Optional[Boolean]) -> NonqueuedReceiverComSpec:
        """
        This attribute controls whether application code is entitled to check whether the value of the corresponding Variable DataPrototype has been updated.
        A None value is a no-op and does not overwrite an existing enableUpdate.
        """
        if value is not None:
            self.enableUpdate = value
        return self

    def getFilter(self) -> Optional[DataFilter]:
        """
        The applicable filter algorithm for filtering the value of the corresponding dataElement.
        """
        return self.filter

    def setFilter(self, value: Optional[DataFilter]) -> NonqueuedReceiverComSpec:
        """
        The applicable filter algorithm for filtering the value of the corresponding dataElement.
        A None value is a no-op and does not overwrite an existing filter.
        """
        if value is not None:
            self.filter = value
        return self

    def getHandleDataStatus(self) -> Optional[Boolean]:
        """
        If this attribute is set to true, then the Rte_IStatus API shall exist. If the attribute does not exist or is set to false, then the Rte_IStatus API may still exist in response to the existence of further conditions.
        """
        return self.handleDataStatus

    def setHandleDataStatus(self, value: Optional[Boolean]) -> NonqueuedReceiverComSpec:
        """
        If this attribute is set to true, then the Rte_IStatus API shall exist. If the attribute does not exist or is set to false, then the Rte_IStatus API may still exist in response to the existence of further conditions.
        A None value is a no-op and does not overwrite an existing handleDataStatus.
        """
        if value is not None:
            self.handleDataStatus = value
        return self

    def getHandleNeverReceived(self) -> Optional[Boolean]:
        """
        This attribute specifies whether for the corresponding VariableDataPrototype the "never received" flag is available. If yes, the RTE is supposed to assume that initially the VariableDataPrototype has not been received before. After the first reception of the corresponding VariableDataPrototype the flag is cleared. • If the value of this attribute is set to "true" the flag is required. • If set to "false", the RTE shall not support the "never received" functionality for the corresponding Variable DataPrototype.
        """
        return self.handleNeverReceived

    def setHandleNeverReceived(self, value: Optional[Boolean]) -> NonqueuedReceiverComSpec:
        """
        This attribute specifies whether for the corresponding VariableDataPrototype the "never received" flag is available. If yes, the RTE is supposed to assume that initially the VariableDataPrototype has not been received before. After the first reception of the corresponding VariableDataPrototype the flag is cleared. • If the value of this attribute is set to "true" the flag is required. • If set to "false", the RTE shall not support the "never received" functionality for the corresponding Variable DataPrototype.
        A None value is a no-op and does not overwrite an existing handleNeverReceived.
        """
        if value is not None:
            self.handleNeverReceived = value
        return self

    def getHandleTimeoutType(self) -> Optional["HandleTimeoutEnum"]:
        """
        This attribute controls the behavior with respect to the handling of timeouts.
        """
        return self.handleTimeoutType

    def setHandleTimeoutType(self, value: Optional["HandleTimeoutEnum"]) -> NonqueuedReceiverComSpec:
        """
        This attribute controls the behavior with respect to the handling of timeouts.
        A None value is a no-op and does not overwrite an existing handleTimeoutType.
        """
        if value is not None:
            self.handleTimeoutType = value
        return self

    def getInitValue(self) -> Optional[ValueSpecification]:
        """
        Initial value to be used in case the sending component is not yet initialized. If the sender also specifies an initial value, then the receiver's value will be used.
        """
        return self.initValue

    def setInitValue(self, value: Optional[ValueSpecification]) -> NonqueuedReceiverComSpec:
        """
        Initial value to be used in case the sending component is not yet initialized. If the sender also specifies an initial value, then the receiver's value will be used.
        A None value is a no-op and does not overwrite an existing initValue.
        """
        if value is not None:
            self.initValue = value
        return self

    def getTimeoutSubstitutionValue(self) -> Optional[ValueSpecification]:
        """
        This attribute represents the substitution value applicable in the case of a timeout.
        """
        return self.timeoutSubstitutionValue

    def setTimeoutSubstitutionValue(self, value: Optional[ValueSpecification]) -> NonqueuedReceiverComSpec:
        """
        This attribute represents the substitution value applicable in the case of a timeout.
        A None value is a no-op and does not overwrite an existing timeoutSubstitutionValue.
        """
        if value is not None:
            self.timeoutSubstitutionValue = value
        return self


class QueuedReceiverComSpec(ReceiverComSpec):
    """
    Communication attributes specific to queued receiving.
    """

    # QueuedReceiverComSpec method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.63, p.173
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__        [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getQueueLength  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setQueueLength  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # Length of queue for received events. [constr_1889]
        self.queueLength: Optional[PositiveInteger] = None

    def getQueueLength(self) -> Optional[PositiveInteger]:
        """
        Length of queue for received events. [constr_1889]
        """
        return self.queueLength

    def setQueueLength(self, value: Optional[PositiveInteger]) -> QueuedReceiverComSpec:
        """
        Length of queue for received events. [constr_1889] A None value is a no-op and does not overwrite an existing queueLength.
        """
        if value is not None:
            self.queueLength = value
        return self


class HandleOutOfRangeEnum(AREnum):
    """
    A value of this type is taken for controlling the range checking behavior of the AUTOSAR RTE.
    """

    # HandleOutOfRangeEnum method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.72, p.180
    # Spec verified: R23-11
    # (no methods)

    # The RTE will use the initValue if the actual value is out of the specified bounds. Tags: atp.EnumerationLiteralIndex=0
    DEFAULT = "default"

    # This indicates that the value replacement is sourced from the attribute replaceWith. Tags: atp.EnumerationLiteralIndex=1
    EXTERNAL_REPLACEMENT = "externalReplacement"

    # The RTE will ignore any attempt to send or receive the corresponding dataElement if the value is out of the specified range. Tags: atp.EnumerationLiteralIndex=2
    IGNORE = "ignore"

    # The RTE will use the invalidValue if the value is out of the specified bounds. Tags: atp.EnumerationLiteralIndex=3
    INVALID = "invalid"

    # A range check is not required. Tags: atp.EnumerationLiteralIndex=4
    NONE = "none"

    # The RTE will saturate the value of the dataElement such that it is limited to the applicable upper bound if it is greater than the upper bound. Consequently, it is limited to the applicable lower bound if the value is less than the lower bound. Tags: atp.EnumerationLiteralIndex=5
    SATURATE = "saturate"

    def __init__(self):
        super().__init__(
            [
                HandleOutOfRangeEnum.DEFAULT,
                HandleOutOfRangeEnum.EXTERNAL_REPLACEMENT,
                HandleOutOfRangeEnum.IGNORE,
                HandleOutOfRangeEnum.INVALID,
                HandleOutOfRangeEnum.NONE,
                HandleOutOfRangeEnum.SATURATE,
            ]
        )


class HandleOutOfRangeStatusEnum(AREnum):
    """
    This enumeration defines how the RTE handles values that are out of range.
    """

    # HandleOutOfRangeStatusEnum method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.61, p.172
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # (no methods) — enum value form serialized on ReceiverComSpec.handleOutOfRangeStatus
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    # The RTE sets the return status to RTE_E_OUT_OF_RANGE if the received value is out of range and the attribute handleOutOfRange is not set to "none" or "invalid". Tags: atp.EnumerationLiteralIndex=0
    INDICATE = "indicate"

    # The RTE sets the return status to RTE_E_OK Tags: atp.EnumerationLiteralIndex=1
    SILENT = "silent"

    def __init__(self):
        super().__init__(
            [
                HandleOutOfRangeStatusEnum.INDICATE,
                HandleOutOfRangeStatusEnum.SILENT,
            ]
        )


class HandleTimeoutEnum(AREnum):
    """
    Strategies of handling a reception timeout violation.
    """

    # HandleTimeoutEnum method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 4.65, p.174
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # (no methods) — enum value form serialized on NonqueuedReceiverComSpec.handleTimeoutType
    # [x] __init__     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer

    # If set to none no replacement shall take place. Tags: atp.EnumerationLiteralIndex=0
    NONE = "none"

    # If set to replace, the replacement value shall be the ComInitValue. Tags: atp.EnumerationLiteralIndex=1
    REPLACE = "replace"

    # If set to replace, the replacement value shall be the timeout substitution value. Tags: atp.EnumerationLiteralIndex=2
    REPLACE_BY_TIMEOUT_SUBSTITUTION_VALUE = "replaceByTimeoutSubstitutionValue"

    def __init__(self):
        super().__init__(
            (
                HandleTimeoutEnum.NONE,
                HandleTimeoutEnum.REPLACE,
                HandleTimeoutEnum.REPLACE_BY_TIMEOUT_SUBSTITUTION_VALUE,
            )
        )
