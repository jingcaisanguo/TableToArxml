from abc import ABC
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.StereotypeMixins import VariationPointCapable
from typing import List, Optional

from armodel.models.M2.MSR.Documentation.TextModel.BlockElements import DocumentationBlock
from armodel.models.M2.MSR.Documentation.Annotation import Annotation
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.AnyInstanceRef import AnyInstanceRef
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import (
    Boolean,
    Float,
    Numerical,
    PositiveInteger,
    RefType,
    RevisionLabelString,
    String,
    UnlimitedInteger,
    VerbatimString,
)
from armodel.models.M2.AUTOSARTemplates.ECUCParameterDefTemplate import EcucConfigurationVariantEnum
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import Identifiable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ARPackage import ARElement


class EcucValueCollection(ARElement):
    """
    This represents the anchor point of the ECU configuration description. Tags: atp.recommendedPackage=EcucValueCollections

    [TPS_ECUC_02151] Existence of EcucValueCollection.ecucValue An EcucValueCollection without any EcucModuleConfigurationValues has no effect on the Ecu configuration and should not occur at code generation time.

    [constr_3588] EcucValueCollection.ecuExtract always required The attribute EcucValueCollection.ecuExtract shall always be defined at code generation time.
    """

    # EcucValueCollection method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.45, p.108
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] addEcucValueRef   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getEcucValueRefs  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] getEcuExtractRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setEcuExtractRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # ARPackage.element dispatch: reader ECUC-VALUE-COLLECTION branch +
    # writer writeARPackageElement branch both present (Aggregated by row).

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # References to the configuration of individual software modules that are present on this ECU. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=ecucValue.ecucModuleConfigurationValues, ecucValue.variationPoint.shortLabel vh.latestBindingTime=preCompileTime
        self.ecucValueRefs: List[RefType] = []

        # Represents the extract of the System Configuration that is relevant for the ECU configured with that ECU Configuration Description.
        self.ecuExtractRef: Optional[RefType] = None

    def addEcucValueRef(self, value: Optional[RefType]) -> "EcucValueCollection":
        """References to the configuration of individual software modules that are present on this ECU. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=ecucValue.ecucModuleConfigurationValues, ecucValue.variationPoint.shortLabel vh.latestBindingTime=preCompileTime A None value is a no-op and does not append to the existing references."""
        if value is not None:
            self.ecucValueRefs.append(value)
        return self

    def getEcucValueRefs(self) -> List[RefType]:
        """References to the configuration of individual software modules that are present on this ECU. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=ecucValue.ecucModuleConfigurationValues, ecucValue.variationPoint.shortLabel vh.latestBindingTime=preCompileTime"""
        return self.ecucValueRefs

    def getEcuExtractRef(self) -> Optional[RefType]:
        """Represents the extract of the System Configuration that is relevant for the ECU configured with that ECU Configuration Description."""
        return self.ecuExtractRef

    def setEcuExtractRef(self, value: Optional[RefType]) -> "EcucValueCollection":
        """Represents the extract of the System Configuration that is relevant for the ECU configured with that ECU Configuration Description. A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.ecuExtractRef = value
        return self


class EcucIndexableValue(ARObject, ABC):
    """
    Used to support the specification of ordering of parameter values.
    """

    # EcucIndexableValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.46, p.110
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getIndex                     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setIndex                     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        if type(self) is EcucIndexableValue:
            raise TypeError("EcucIndexableValue is an abstract class.")

        super().__init__()

        # Used to support the specification of ordering of parameter values. Tags: xml.sequenceOffset=-5
        self.index: Optional[PositiveInteger] = None

    def getIndex(self) -> Optional[PositiveInteger]:
        """
        Used to support the specification of ordering of parameter values.
        """
        return self.index

    def setIndex(self, value: Optional[PositiveInteger]) -> "EcucIndexableValue":
        """
        Used to support the specification of ordering of parameter values.

        A None value is a no-op and does not overwrite an existing index.
        """
        if value is not None:
            self.index = value
        return self


class EcucParameterValue(EcucIndexableValue, VariationPointCapable, ABC):
    """
    Common class to all types of configuration values.
    """

    # EcucParameterValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.49, p.125
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addAnnotation                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getAnnotations               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getDefinitionRef             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDefinitionRef             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getIsAutoValue               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setIsAutoValue               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        if type(self) is EcucParameterValue:
            raise TypeError("EcucParameterValue is an abstract class.")

        super().__init__()

        # Possibility to provide additional notes while defining the ECU Configuration Parameter Values. These are not intended as documentation but are mere design notes. Tags: xml.sequenceOffset=10
        self.annotations: List[Annotation] = []

        # Reference to the definition of this EcucParameterValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

        # If withAuto is set to "true" for this parameter definition the isAutoValue can be set to "true". If isAutoValue is set to "true" the actual value will not be considered during ECU Configuration but will be (re-)calculated by the code generator and stored in the value attribute afterwards. These implicit updated values might require a re-generation of other modules which reference these values. If isAutoValue is not present the default is "false". Tags: xml.sequenceOffset=20
        self.isAutoValue: Optional[Boolean] = None

    def addAnnotation(self, value: Optional[Annotation]) -> "EcucParameterValue":
        """Possibility to provide additional notes while defining the ECU Configuration Parameter Values. These are not intended as documentation but are mere design notes. Tags: xml.sequenceOffset=10 A None value is a no-op and does not append to the existing annotations."""
        if value is not None:
            self.annotations.append(value)
        return self

    def getAnnotations(self) -> List[Annotation]:
        """Possibility to provide additional notes while defining the ECU Configuration Parameter Values. These are not intended as documentation but are mere design notes. Tags: xml.sequenceOffset=10"""
        return self.annotations

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this EcucParameterValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: Optional[RefType]) -> "EcucParameterValue":
        """Reference to the definition of this EcucParameterValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self

    def getIsAutoValue(self) -> Optional[Boolean]:
        """If withAuto is set to "true" for this parameter definition the isAutoValue can be set to "true". If isAutoValue is set to "true" the actual value will not be considered during ECU Configuration but will be (re-)calculated by the code generator and stored in the value attribute afterwards. These implicit updated values might require a re-generation of other modules which reference these values. If isAutoValue is not present the default is "false". Tags: xml.sequenceOffset=20"""
        return self.isAutoValue

    def setIsAutoValue(self, value: Optional[Boolean]) -> "EcucParameterValue":
        """If withAuto is set to "true" for this parameter definition the isAutoValue can be set to "true". If isAutoValue is set to "true" the actual value will not be considered during ECU Configuration but will be (re-)calculated by the code generator and stored in the value attribute afterwards. These implicit updated values might require a re-generation of other modules which reference these values. If isAutoValue is not present the default is "false". Tags: xml.sequenceOffset=20 A None value is a no-op and does not overwrite an existing flag."""
        if value is not None:
            self.isAutoValue = value
        return self


class EcucAddInfoParamValue(EcucParameterValue):
    """
    This parameter corresponds to EcucAddInfoParamDef.
    """

    # EcucAddInfoParamValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.52, p.129
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue                     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue                     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Holds the content of the formated text.
        self.value: Optional[DocumentationBlock] = None

    def getValue(self) -> Optional[DocumentationBlock]:
        """Holds the content of the formated text."""
        return self.value

    def setValue(self, value: Optional[DocumentationBlock]) -> "EcucAddInfoParamValue":
        """Holds the content of the formated text. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class EcucTextualParamValue(EcucParameterValue):
    """
    Holding a value which is not subject to variation.
    """

    # EcucTextualParamValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.50, p.127
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue                     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue                     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Value of the parameter, not subject to variant handling.
        self.value: Optional[VerbatimString] = None

    def getValue(self) -> Optional[VerbatimString]:
        """Value of the parameter, not subject to variant handling."""
        return self.value

    def setValue(self, value: Optional[VerbatimString]) -> "EcucTextualParamValue":
        """Value of the parameter, not subject to variant handling. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class EcucNumericalParamValue(EcucParameterValue):
    """
    Holding the value which is subject to variant handling.
    """

    # EcucNumericalParamValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.51, p.128
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue                     [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue                     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Value which is subject to variant handling. atpVariation: [RS_ECUC_00080] Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime
        self.value: Optional[Numerical] = None

    def getValue(self) -> Optional[Numerical]:
        """Value which is subject to variant handling. atpVariation: [RS_ECUC_00080] Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime"""
        return self.value

    def setValue(self, value: Optional[Numerical]) -> "EcucNumericalParamValue":
        """Value which is subject to variant handling. atpVariation: [RS_ECUC_00080] Stereotypes: atpVariation Tags: vh.latestBindingTime=preCompileTime A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class EcucAbstractReferenceValue(EcucIndexableValue, VariationPointCapable, ABC):
    """
    Abstract class to be used as common parent for all reference values in the ECU Configuration Description.
    """

    # EcucAbstractReferenceValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.53, p.131
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] addAnnotation     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getAnnotations    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getDefinitionRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDefinitionRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getIsAutoValue    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setIsAutoValue    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        if type(self) is EcucAbstractReferenceValue:
            raise TypeError("EcucAbstractReferenceValue is an abstract class.")

        super().__init__()

        # Possibility to provide additional notes while defining a model element (e.g. the ECU Configuration Parameter Values). These are not intended as documentation but are mere design notes.
        self.annotations: List[Annotation] = []

        # Reference to the definition of this EcucAbstractReferenceValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

        # If withAuto is set to "true" for this parameter definition the isAutoValue can be set to "true". If isAutoValue is set to "true" the actual value will not be considered during ECU Configuration but will be (re-)calculated by the code generator and stored in the value attribute afterwards. These implicit updated values might require a re-generation of other modules which reference these values. If isAutoValue is not present the default is "false".
        self.isAutoValue: Optional[Boolean] = None

    def addAnnotation(self, value: Optional[Annotation]) -> "EcucAbstractReferenceValue":
        """Possibility to provide additional notes while defining a model element (e.g. the ECU Configuration Parameter Values). These are not intended as documentation but are mere design notes. A None value is a no-op and does not append to the existing annotations."""
        if value is not None:
            self.annotations.append(value)
        return self

    def getAnnotations(self) -> List[Annotation]:
        """Possibility to provide additional notes while defining a model element (e.g. the ECU Configuration Parameter Values). These are not intended as documentation but are mere design notes."""
        return self.annotations

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this EcucAbstractReferenceValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: Optional[RefType]) -> "EcucAbstractReferenceValue":
        """Reference to the definition of this EcucAbstractReferenceValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self

    def getIsAutoValue(self) -> Optional[Boolean]:
        """If withAuto is set to "true" for this parameter definition the isAutoValue can be set to "true". If isAutoValue is set to "true" the actual value will not be considered during ECU Configuration but will be (re-)calculated by the code generator and stored in the value attribute afterwards. These implicit updated values might require a re-generation of other modules which reference these values. If isAutoValue is not present the default is "false"."""
        return self.isAutoValue

    def setIsAutoValue(self, value: Optional[Boolean]) -> "EcucAbstractReferenceValue":
        """If withAuto is set to "true" for this parameter definition the isAutoValue can be set to "true". If isAutoValue is set to "true" the actual value will not be considered during ECU Configuration but will be (re-)calculated by the code generator and stored in the value attribute afterwards. These implicit updated values might require a re-generation of other modules which reference these values. If isAutoValue is not present the default is "false". A None value is a no-op and does not overwrite an existing flag."""
        if value is not None:
            self.isAutoValue = value
        return self


class EcucInstanceReferenceValue(EcucAbstractReferenceValue):
    """
    InstanceReference representation in the ECU Configuration.
    """

    # EcucInstanceReferenceValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.55, p.134
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__        [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValueIRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValueIRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # InstanceReference representation in the ECU Configuration. InstanceRef implemented by: AnyInstanceRef
        self.valueIRef: Optional[AnyInstanceRef] = None

    def getValueIRef(self) -> Optional[AnyInstanceRef]:
        """InstanceReference representation in the ECU Configuration. InstanceRef implemented by: AnyInstanceRef"""
        return self.valueIRef

    def setValueIRef(self, value: Optional[AnyInstanceRef]) -> "EcucInstanceReferenceValue":
        """InstanceReference representation in the ECU Configuration. InstanceRef implemented by: AnyInstanceRef A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.valueIRef = value
        return self


class EcucReferenceValue(EcucAbstractReferenceValue):
    """
    Used to represent a configuration value that has a parameter definition of type EcucAbstractReferenceDef (used for all of its specializations excluding EcucInstanceReferenceDef).
    """

    # EcucReferenceValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.54, p.132
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValueRef   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValueRef   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # Specifies the destination of the reference.
        self.valueRef: Optional[RefType] = None

    def getValueRef(self) -> Optional[RefType]:
        """Specifies the destination of the reference."""
        return self.valueRef

    def setValueRef(self, value: Optional[RefType]) -> "EcucReferenceValue":
        """Specifies the destination of the reference. A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.valueRef = value
        return self


class EcucContainerValue(Identifiable, EcucIndexableValue, VariationPointCapable):
    """
    Represents a Container definition in the ECU Configuration Description.
    """

    # EcucContainerValue method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.48, p.119
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getDefinitionRef             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDefinitionRef             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getParameterValues           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] addParameterValue            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getReferenceValues           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] addReferenceValue            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getSubContainers             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] createSubContainer           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self, parent: ARObject, short_name: str):
        EcucIndexableValue.__init__(self)
        Identifiable.__init__(self, parent, short_name)

        # Reference to the definition of this Container in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

        # Aggregates all ECU Configuration Values within this Container. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=parameterValue, parameterValue.variation Point.shortLabel vh.latestBindingTime=postBuild
        self.parameterValues: List[EcucParameterValue] = []

        # Aggregates all References with this container. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=referenceValue, referenceValue.variation Point.shortLabel vh.latestBindingTime=postBuild
        self.referenceValues: List[EcucAbstractReferenceValue] = []

        # Aggregates all sub-containers within this container. atpVariation: [RS_ECUC_00078] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=subContainer.shortName, sub Container.variationPoint.shortLabel vh.latestBindingTime=postBuild
        self.subContainers: List["EcucContainerValue"] = []

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this Container in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: RefType) -> "EcucContainerValue":
        """Reference to the definition of this Container in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self

    def getParameterValues(self) -> List[EcucParameterValue]:
        """Aggregates all ECU Configuration Values within this Container. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=parameterValue, parameterValue.variation Point.shortLabel vh.latestBindingTime=postBuild"""
        return self.parameterValues

    def addParameterValue(self, value: EcucParameterValue) -> "EcucContainerValue":
        """Aggregates all ECU Configuration Values within this Container. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=parameterValue, parameterValue.variation Point.shortLabel vh.latestBindingTime=postBuild"""
        self.parameterValues.append(value)
        return self

    def getReferenceValues(self) -> List[EcucAbstractReferenceValue]:
        """Aggregates all References with this container. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=referenceValue, referenceValue.variation Point.shortLabel vh.latestBindingTime=postBuild"""
        return self.referenceValues

    def addReferenceValue(self, value: EcucAbstractReferenceValue) -> "EcucContainerValue":
        """Aggregates all References with this container. atpVariation: [RS_ECUC_00079] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=referenceValue, referenceValue.variation Point.shortLabel vh.latestBindingTime=postBuild"""
        self.referenceValues.append(value)
        return self

    def getSubContainers(self) -> List["EcucContainerValue"]:
        """Aggregates all sub-containers within this container. atpVariation: [RS_ECUC_00078] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=subContainer.shortName, sub Container.variationPoint.shortLabel vh.latestBindingTime=postBuild"""
        return self.subContainers

    def createSubContainer(self, short_name: str) -> "EcucContainerValue":
        """Aggregates all sub-containers within this container. atpVariation: [RS_ECUC_00078] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=subContainer.shortName, sub Container.variationPoint.shortLabel vh.latestBindingTime=postBuild"""
        if not self.IsElementExists(short_name, EcucContainerValue):
            container_value = EcucContainerValue(self, short_name)
            self.addElement(container_value)
            self.subContainers.append(container_value)
        return self.getElement(short_name, EcucContainerValue)


class EcucModuleConfigurationValues(ARElement):
    """
    Head of the configuration of one Module. A Module can be a BSW module as well as the RTE and ECU Infrastructure. As part of the BSW module description, the EcucModuleConfigurationValues element has two different roles: The recommendedConfiguration contains parameter values recommended by the BSW module vendor. The preconfiguredConfiguration contains values for those parameters which are fixed by the implementation and cannot be changed. These two EcucModuleConfigurationValues are used when the base EcucModuleConfigurationValues (as part of the base ECU configuration) is created to fill parameters with initial values. Tags: atp.recommendedPackage=EcucModuleConfigurationValuess
    """

    # EcucModuleConfigurationValues method parity checklist:
    # Spec: AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.47, p.111
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                         [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] createContainer                  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getContainers                    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getDefinitionRef                [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDefinitionRef                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getEcucDefEdition                [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setEcucDefEdition                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getImplementationConfigVariant   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setImplementationConfigVariant   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getModuleDescriptionRef         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setModuleDescriptionRef         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getPostBuildVariantUsed          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setPostBuildVariantUsed          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # Aggregates all containers that belong to this module configuration. atpVariation: [RS_ECUC_00078] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=container.shortName, container.variationPoint.shortLabel vh.latestBindingTime=postBuild xml.sequenceOffset=10
        self.containers: List[EcucContainerValue] = []

        # Reference to the definition of this EcucModuleConfigurationValues element. Typically, this is a vendor specific module configuration. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

        # This is the version info of the ModuleDef ECUC Parameter definition to which this values conform to / are based on. For the Definition of ModuleDef ECUC Parameters the AdminData shall be used to express the semantic changes. The compatibility rules between the definition and value revision labels is up to the module's vendor.
        self.ecucDefEdition: Optional[RevisionLabelString] = None

        # Specifies the kind of deliverable this EcucModuleConfigurationValues element provides. If this element is not used in a particular role (e.g. preconfiguredConfiguration or recommendedConfiguration) then the value shall be one of VariantPreCompile, VariantLinkTime, VariantPostBuild.
        self.implementationConfigVariant: Optional[EcucConfigurationVariantEnum] = None

        # Referencing the BSW module description, which this EcucModuleConfigurationValues element is configuring. This is optional because the EcucModuleConfigurationValues element is also used to configure the ECU infrastructure (memory map) or Application SW-Cs. However in case the EcucModuleConfigurationValues are used to configure the module, the reference is mandatory in order to fetch module specific "common" published information.
        self.moduleDescriptionRef: Optional[RefType] = None

        # Indicates whether a module implementation has or plans to have (i.e., introduced at link or post-build time) new post-build variation points. TRUE means yes, FALSE means no. If the attribute is not defined, FALSE semantics shall be assumed.
        self.postBuildVariantUsed: Optional[Boolean] = None

    def createContainer(self, short_name: str) -> EcucContainerValue:
        """Aggregates all containers that belong to this module configuration. atpVariation: [RS_ECUC_00078] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=container.shortName, container.variationPoint.shortLabel vh.latestBindingTime=postBuild xml.sequenceOffset=10"""
        if not self.IsElementExists(short_name, EcucContainerValue):
            container = EcucContainerValue(self, short_name)
            self.addElement(container)
            self.containers.append(container)
        return self.getElement(short_name, EcucContainerValue)

    def getContainers(self) -> List[EcucContainerValue]:
        """Aggregates all containers that belong to this module configuration. atpVariation: [RS_ECUC_00078] Stereotypes: atpSplitable; atpVariation Tags: atp.Splitkey=container.shortName, container.variationPoint.shortLabel vh.latestBindingTime=postBuild xml.sequenceOffset=10"""
        return list(self.containers)

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this EcucModuleConfigurationValues element. Typically, this is a vendor specific module configuration. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: RefType) -> "EcucModuleConfigurationValues":
        """Reference to the definition of this EcucModuleConfigurationValues element. Typically, this is a vendor specific module configuration. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self

    def getEcucDefEdition(self) -> Optional[RevisionLabelString]:
        """This is the version info of the ModuleDef ECUC Parameter definition to which this values conform to / are based on. For the Definition of ModuleDef ECUC Parameters the AdminData shall be used to express the semantic changes. The compatibility rules between the definition and value revision labels is up to the module's vendor."""
        return self.ecucDefEdition

    def setEcucDefEdition(self, value: RevisionLabelString) -> "EcucModuleConfigurationValues":
        """This is the version info of the ModuleDef ECUC Parameter definition to which this values conform to / are based on. For the Definition of ModuleDef ECUC Parameters the AdminData shall be used to express the semantic changes. The compatibility rules between the definition and value revision labels is up to the module's vendor. A None value is a no-op and does not overwrite an existing version info."""
        if value is not None:
            self.ecucDefEdition = value
        return self

    def getImplementationConfigVariant(self) -> Optional[EcucConfigurationVariantEnum]:
        """Specifies the kind of deliverable this EcucModuleConfigurationValues element provides. If this element is not used in a particular role (e.g. preconfiguredConfiguration or recommendedConfiguration) then the value shall be one of VariantPreCompile, VariantLinkTime, VariantPostBuild."""
        return self.implementationConfigVariant

    def setImplementationConfigVariant(self, value: EcucConfigurationVariantEnum) -> "EcucModuleConfigurationValues":
        """Specifies the kind of deliverable this EcucModuleConfigurationValues element provides. If this element is not used in a particular role (e.g. preconfiguredConfiguration or recommendedConfiguration) then the value shall be one of VariantPreCompile, VariantLinkTime, VariantPostBuild. A None value is a no-op and does not overwrite an existing configuration variant."""
        if value is not None:
            self.implementationConfigVariant = value
        return self

    def getModuleDescriptionRef(self) -> Optional[RefType]:
        """Referencing the BSW module description, which this EcucModuleConfigurationValues element is configuring. This is optional because the EcucModuleConfigurationValues element is also used to configure the ECU infrastructure (memory map) or Application SW-Cs. However in case the EcucModuleConfigurationValues are used to configure the module, the reference is mandatory in order to fetch module specific "common" published information."""
        return self.moduleDescriptionRef

    def setModuleDescriptionRef(self, value: RefType) -> "EcucModuleConfigurationValues":
        """Referencing the BSW module description, which this EcucModuleConfigurationValues element is configuring. This is optional because the EcucModuleConfigurationValues element is also used to configure the ECU infrastructure (memory map) or Application SW-Cs. However in case the EcucModuleConfigurationValues are used to configure the module, the reference is mandatory in order to fetch module specific "common" published information. A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.moduleDescriptionRef = value
        return self

    def getPostBuildVariantUsed(self) -> Optional[Boolean]:
        """Indicates whether a module implementation has or plans to have (i.e., introduced at link or post-build time) new post-build variation points. TRUE means yes, FALSE means no. If the attribute is not defined, FALSE semantics shall be assumed."""
        return self.postBuildVariantUsed

    def setPostBuildVariantUsed(self, value: Boolean) -> "EcucModuleConfigurationValues":
        """Indicates whether a module implementation has or plans to have (i.e., introduced at link or post-build time) new post-build variation points. TRUE means yes, FALSE means no. If the attribute is not defined, FALSE semantics shall be assumed. A None value is a no-op and does not overwrite an existing flag."""
        if value is not None:
            self.postBuildVariantUsed = value
        return self


# EcucConfigurationVariantEnum lives in ECUCParameterDefTemplate.py
# (canonical, # Spec verified: R23-11 — AUTOSAR_CP_TPS_ECUConfiguration.pdf, Table 2.13, p.53).
# The duplicate stub that used to sit here was removed; import it from
# armodel.models.M2.AUTOSARTemplates.ECUCParameterDefTemplate when needed.


class ParameterValue(ARObject, ABC):
    """
    Common class to all types of configuration values.
    """

    # ParameterValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.32, p.97 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getDefinitionRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDefinitionRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # Deviations (spec member name is `definition`, kind ref; renamed per ECUC ref-suffix
    # convention to definitionRef):
    # 1. definition optional — spec Mul=1 but XSD group PARAMETER-VALUE (AUTOSAR.xsd L18140)
    #    has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins).
    # 2. DEFINITION-REF DEST attribute — XSD says use="required" but Os_ECUC.arxml carries
    #    no DEST; reader/writer treat DEST as optional.

    def __init__(self):
        if type(self) is ParameterValue:
            raise TypeError("ParameterValue is an abstract class.")

        super().__init__()

        # Reference to the definition of this ParameterValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this ParameterValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: Optional[RefType]) -> "ParameterValue":
        """Reference to the definition of this ParameterValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self


class IntegerValue(ParameterValue):
    """
    Representing a configuration value of definition type IntegerParamDef.
    """

    # IntegerValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.34, p.98 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # Deviation: value optional — spec Mul=1 but XSD group INTEGER-VALUE (AUTOSAR.xsd
    # L13680) has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins).

    def __init__(self):
        super().__init__()

        # Stores the value of the Integer parameter.
        self.value: Optional[UnlimitedInteger] = None

    def getValue(self) -> Optional[UnlimitedInteger]:
        """Stores the value of the Integer parameter."""
        return self.value

    def setValue(self, value: Optional[UnlimitedInteger]) -> "IntegerValue":
        """Stores the value of the Integer parameter. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class BooleanValue(ParameterValue):
    """
    Representing a configuration value of definition type BooleanParamDef.
    """

    # BooleanValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.33, p.97 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # Deviation: value optional — spec Mul=1 but XSD group BOOLEAN-VALUE (AUTOSAR.xsd
    # L1551) has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins).

    def __init__(self):
        super().__init__()

        # Stores the value of the Boolean parameter.
        self.value: Optional[Boolean] = None

    def getValue(self) -> Optional[Boolean]:
        """Stores the value of the Boolean parameter."""
        return self.value

    def setValue(self, value: Optional[Boolean]) -> "BooleanValue":
        """Stores the value of the Boolean parameter. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class FloatValue(ParameterValue):
    """
    Representing a configuration value of definition type FloatParamDef.
    """

    # FloatValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.35, p.99 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # Deviation: value optional — spec Mul=1 but XSD group FLOAT-VALUE (AUTOSAR.xsd
    # L11261) has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins).

    def __init__(self):
        super().__init__()

        # Stores the value of the Float parameter.
        self.value: Optional[Float] = None

    def getValue(self) -> Optional[Float]:
        """Stores the value of the Float parameter."""
        return self.value

    def setValue(self, value: Optional[Float]) -> "FloatValue":
        """Stores the value of the Float parameter. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class StringValue(ParameterValue):
    """
    Representing a configuration value of definition type StringParamDef.
    """

    # StringValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.36, p.99 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getValue      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValue      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # Deviation: value optional — spec Mul=1 but XSD group STRING-VALUE (AUTOSAR.xsd
    # L23746) has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins).

    def __init__(self):
        super().__init__()

        # Stores the value of the String parameter.
        self.value: Optional[String] = None

    def getValue(self) -> Optional[String]:
        """Stores the value of the String parameter."""
        return self.value

    def setValue(self, value: Optional[String]) -> "StringValue":
        """Stores the value of the String parameter. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class LinkerSymbolValue(StringValue):
    """
    Representing a configuration value of definition type LinkerSymbolDef.
    """

    # LinkerSymbolValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.37, p.100 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # ZERO own members (spec Table 3.37 attribute table is empty); inherits
    # definitionRef from ParameterValue and value from StringValue.

    def __init__(self):
        super().__init__()


class FunctionNameValue(LinkerSymbolValue):
    """
    Representing a configuration value of definition type FunctionNameDef
    """

    # FunctionNameValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.38, p.100 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] getValue      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setValue      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # ZERO own members (spec Table 3.38 attribute table is empty); inherits
    # definitionRef from ParameterValue and value from StringValue.


class EnumerationValue(ParameterValue):
    """
    Representing a configuration value of definition type EnumerationParamDef
    """

    # EnumerationValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.39, p.101 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] getValue      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setValue      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # Deviation: value optional — spec Mul=1 but XSD group ENUMERATION-VALUE (AUTOSAR.xsd
    # L9275) has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins).

    def __init__(self):
        super().__init__()

        # Stores the chosen literal.
        self.value: Optional[String] = None

    def getValue(self) -> Optional[String]:
        """Stores the chosen literal."""
        return self.value

    def setValue(self, value: Optional[String]) -> "EnumerationValue":
        """Stores the chosen literal. A None value is a no-op and does not overwrite an existing value."""
        if value is not None:
            self.value = value
        return self


class ConfigReferenceValue(ARObject, ABC):
    """
    Abstract class to be used as common parent for all reference values in the ECU Configuration Description.

    [ecuc_sws_3027] The metamodel class ReferenceValue provides the mechanism to reference to any model element of type Identifiable.

    [ecuc_sws_3028] Therefore this class provides the means to describe all kinds of reference definitions except an InstanceReferenceParamDef, which is described in section 3.4.5.1 in more detail.

    [ecuc_sws_3029] A ChoiceReferenceParamDef translates to a ReferenceValue in the ECU Configuration Description because the choice has to be resolved in that description. Therefore no special configuration description type is introduced.
    """

    # ConfigReferenceValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.md, Table 3.40, l.2284 (R3.2.3)
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__          [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] getDefinitionRef  [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setDefinitionRef  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # Naming (not a deviation): spec member `definition`, kind ref — Rule 0001.5 Ref
    # suffix gives definitionRef (ParameterValue/EcucContainerValue module convention).
    # Deviations (accepted):
    # 1. definition optional — spec Mul=1 but XSD group CONFIG-REFERENCE-VALUE
    #    (AUTOSAR.xsd l.6087) DEFINITION-REF has minOccurs="0"; modeled Optional per
    #    the XSD serialization contract (None-guarded setter, writer omits the element
    #    when unset).
    # 2. DEFINITION-REF DEST attribute — XSD use="required" (CONFIG-REFERENCE--
    #    SUBTYPES-ENUM) but the Os_ECUC.arxml integration fixture carries DEFINITION-REF
    #    with no DEST; reader/writer treat DEST as optional for a lossless round-trip.

    def __init__(self):
        if type(self) is ConfigReferenceValue:
            raise TypeError("ConfigReferenceValue is an abstract class.")

        super().__init__()

        # Reference to the definition of this ConfigReferenceValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this ConfigReferenceValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: Optional[RefType]) -> "ConfigReferenceValue":
        """Reference to the definition of this ConfigReferenceValue subclasses in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self


class ReferenceValue(ConfigReferenceValue):
    """
    Used to represent a configuration value that has a parameter definition of type ConfigReference (used for all of its specializations excluding InstanceReferenceParamDef).

    [ecuc_sws_2093] If a ConfigReferenceValue references a container within some ModuleConfiguration the referenced container shall be part of a ModuleConfiguration which is itself part of the EcuConfiguration. According to figure 3.20 a ModuleConfiguration is part of the EcuConfiguration if it is referenced with the module role.
    """

    # ReferenceValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.41, p.103 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__      [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] getValueRef   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setValueRef   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # Deviations (spec member name is `value`, kind ref; renamed per ECUC ref-suffix
    # convention to valueRef — EcucReferenceValue precedent):
    # value optional — spec Mul=1 but XSD group REFERENCE-VALUE (AUTOSAR.xsd L20706)
    # VALUE-REF has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins);
    # VALUE-REF DEST use="required" in XSD but sample carries no DEST → DEST optional.

    def __init__(self):
        super().__init__()

        # Specifies the destination of the reference.
        self.valueRef: Optional[RefType] = None

    def getValueRef(self) -> Optional[RefType]:
        """Specifies the destination of the reference."""
        return self.valueRef

    def setValueRef(self, value: Optional[RefType]) -> "ReferenceValue":
        """Specifies the destination of the reference. A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.valueRef = value
        return self


class InstanceReferenceValue(ConfigReferenceValue):
    """
    InstanceReference representation in the ECU Configuration.
    """

    # InstanceReferenceValue method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.42, p.106 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__        [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] getValueIRef    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setValueIRef    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # Deviations (spec member name is `value`, kind iref; named valueIRef per Rule 0001.5
    # IRef suffix — R4 EcucInstanceReferenceValue precedent, decomposed via AnyInstanceRef):
    # value optional — spec Mul=1 but XSD group INSTANCE-REFERENCE-VALUE (AUTOSAR.xsd
    # L13507) VALUE-IREF has minOccurs="0" (Rule 0019.3 inverted); R3 VALUE-IREF content
    # = CONTEXT-REF* (offset 10) + VALUE-REF (offset 20), serialized with the R3 element
    # names (NOT the R4 CONTEXT-ELEMENT-REF/TARGET-REF names).

    def __init__(self):
        super().__init__()

        # InstanceReference representation in the ECU Configuration.
        self.valueIRef: Optional[AnyInstanceRef] = None

    def getValueIRef(self) -> Optional[AnyInstanceRef]:
        """InstanceReference representation in the ECU Configuration."""
        return self.valueIRef

    def setValueIRef(self, value: Optional[AnyInstanceRef]) -> "InstanceReferenceValue":
        """InstanceReference representation in the ECU Configuration. A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.valueIRef = value
        return self


class Container(Identifiable):
    """
    Represents a Container definition in the ECU Configuration Description.

    [ecuc_sws_2092] If a ParamConfContainerDef is specified to be the multipleConfigurationContainer there can be several Container elements defined in the ECU Configuration. Each Container shortName does specify the name of the configuration set it contains.

    The multipleConfigurationContainer is further detailed in section 3.4.7.
    """

    # Container method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.pdf, Table 3.31, p.93 (R3.2 Rev 3)
    # Spec verified: R3.2.3
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__              [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] getDefinitionRef      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setDefinitionRef      [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # [x] getParameterValues    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] addParameterValue     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # [x] getReferenceValues    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] addReferenceValue     [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # [x] getSubContainers      [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] createSubContainer    [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # Deviations (spec member name is `definition`, kind ref; renamed per ECUC ref-suffix
    # convention to definitionRef):
    # definition optional — spec Mul=1 but XSD group CONTAINER (AUTOSAR.xsd L6243)
    # DEFINITION-REF has minOccurs="0" (Rule 0019.3 inverted, sample evidence wins);
    # DEFINITION-REF DEST use="required" in XSD but sample carries no DEST → DEST optional.
    # Aggregate member names pluralized per spec mult `*` (parameterValues /
    # referenceValues / subContainers; EcucContainerValue precedent).

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # Reference to the definition of this Container in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

        # Aggregates all ECU Configuration Values within this Container.
        self.parameterValues: List[ParameterValue] = []

        # Aggregates all References with this container.
        self.referenceValues: List[ConfigReferenceValue] = []

        # Aggregates all sub-containers within this container.
        self.subContainers: List["Container"] = []

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this Container in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: Optional[RefType]) -> "Container":
        """Reference to the definition of this Container in the ECU Configuration Parameter Definition. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self

    def getParameterValues(self) -> List[ParameterValue]:
        """Aggregates all ECU Configuration Values within this Container."""
        return self.parameterValues

    def addParameterValue(self, value: ParameterValue) -> "Container":
        """Aggregates all ECU Configuration Values within this Container."""
        self.parameterValues.append(value)
        return self

    def getReferenceValues(self) -> List[ConfigReferenceValue]:
        """Aggregates all References with this container."""
        return self.referenceValues

    def addReferenceValue(self, value: ConfigReferenceValue) -> "Container":
        """Aggregates all References with this container."""
        self.referenceValues.append(value)
        return self

    def getSubContainers(self) -> List["Container"]:
        """Aggregates all sub-containers within this container."""
        return self.subContainers

    def createSubContainer(self, short_name: str) -> "Container":
        """Aggregates all sub-containers within this container."""
        if not self.IsElementExists(short_name, Container):
            sub_container = Container(self, short_name)
            self.addElement(sub_container)
            self.subContainers.append(sub_container)
        return self.getElement(short_name, Container)


class ModuleConfiguration(ARElement):
    """
    Head of the configuration of one Module. A Module can be a BSW module as well as the RTE and ECU Infrastructure.

    As part of tthe BSW module description, the ModuleConfiguration has two different roles:

    The recommendedConfiguration contains parameter values recommended by the BSW module vendor.

    The preconfiguredConfiguration contains values for those parameters which are fixed by the implementation and cannot be changed.

    These two ModuleConfigurations are used when the base ModuleConfiguration (as part of the base ECU configuration) is created to fill parameters with initial values.
    """

    # ModuleConfiguration method parity checklist:
    # Spec: R3.2.3/AUTOSAR_ECU_Configuration.md, Table 3.30, l.1916 (R3.2.3)
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                         [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R3.2.3
    # [x] createContainer                  [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # [x] getContainers                    [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] getDefinitionRef                 [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setDefinitionRef                 [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # [x] getImplementationConfigVariant   [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setImplementationConfigVariant   [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # [x] getModuleDescriptionRef          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R3.2.3
    # [x] setModuleDescriptionRef          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R3.2.3
    # Naming (not a deviation): spec members `definition`/`moduleDescription` kind ref —
    # Rule 0001.5 Ref suffix gives definitionRef/moduleDescriptionRef (module convention).
    # Deviations (accepted):
    # 1. definition + implementationConfigVariant optional — spec Mul=1 but XSD group
    #    MODULE-CONFIGURATION (AUTOSAR.xsd l.16416) DEFINITION-REF and
    #    IMPLEMENTATION-CONFIG-VARIANT have minOccurs="0"; modeled Optional per the XSD
    #    serialization contract (None-guarded setters, writer omits unset elements;
    #    Os_ECUC.arxml carries neither).
    # 2. DEFINITION-REF/MODULE-DESCRIPTION-REF DEST attribute — XSD use="required"
    #    (MODULE-DEF--/BSW-IMPLEMENTATION--SUBTYPES-ENUM) but the Os_ECUC.arxml
    #    integration fixture carries the refs with no DEST; reader/writer treat DEST
    #    as optional for a lossless round-trip (BASE/DEST round-trip when present).
    # 3. implementationConfigVariant type — spec type ConfigurationVariant (R3.2.3
    #    AUTOSAR_ECU_Configuration.md Table 3.11, l.1200, ECUCParameterDefTemplate) is
    #    class not yet implemented; placeholder R23-11 EcucConfigurationVariantEnum in
    #    use (literal sets differ: R3.2.3 adds VARIANT-POST-BUILD-LOADABLE and
    #    VARIANT-POST-BUILD-SELECTABLE, has no RECOMMENDED-CONFIGURATION). Switch to
    #    the real type when that class gets its own pass (Rule 0001.10).
    # Aggregated by ARPackage.element (XSD l.222) → ARPackage.createModuleConfiguration
    # factory; reader/writer dispatch branches both present.
    # XML element order (XSD sequenceOffset): DEFINITION-REF (-10) → IMPLEMENTATION-CONFIG-VARIANT (0)
    # → MODULE-DESCRIPTION-REF (0) → CONTAINERS (10).

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # Aggregates all containers that belong to this module configuration. Stereotypes: atpSplitable Tags: xml.sequenceOffset=10
        self.containers: List[Container] = []

        # Reference to the definition of this ModuleConfiguration. Typically, this is a vendor specific module configuration. Tags: xml.sequenceOffset=-10
        self.definitionRef: Optional[RefType] = None

        # Specifies the ConfigurationVariant used for this ModuleConfiguration.
        self.implementationConfigVariant: Optional[EcucConfigurationVariantEnum] = None

        # Referencing the BSW module description, which this ModuleConfiguration is configuring. This is optional because the ModuleConfiguration is also used to configure the ECU infrastructure (memory map) or Application SW-Cs.
        self.moduleDescriptionRef: Optional[RefType] = None

    def createContainer(self, short_name: str) -> Container:
        """Aggregates all containers that belong to this module configuration. Stereotypes: atpSplitable Tags: xml.sequenceOffset=10"""
        if not self.IsElementExists(short_name, Container):
            container = Container(self, short_name)
            self.addElement(container)
            self.containers.append(container)
        return self.getElement(short_name, Container)

    def getContainers(self) -> List[Container]:
        """Aggregates all containers that belong to this module configuration. Stereotypes: atpSplitable Tags: xml.sequenceOffset=10"""
        return self.containers

    def getDefinitionRef(self) -> Optional[RefType]:
        """Reference to the definition of this ModuleConfiguration. Typically, this is a vendor specific module configuration. Tags: xml.sequenceOffset=-10"""
        return self.definitionRef

    def setDefinitionRef(self, value: Optional[RefType]) -> "ModuleConfiguration":
        """Reference to the definition of this ModuleConfiguration. Typically, this is a vendor specific module configuration. Tags: xml.sequenceOffset=-10 A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.definitionRef = value
        return self

    def getImplementationConfigVariant(self) -> Optional[EcucConfigurationVariantEnum]:
        """Specifies the ConfigurationVariant used for this ModuleConfiguration."""
        return self.implementationConfigVariant

    def setImplementationConfigVariant(self, value: Optional[EcucConfigurationVariantEnum]) -> "ModuleConfiguration":
        """Specifies the ConfigurationVariant used for this ModuleConfiguration. A None value is a no-op and does not overwrite an existing configuration variant."""
        if value is not None:
            self.implementationConfigVariant = value
        return self

    def getModuleDescriptionRef(self) -> Optional[RefType]:
        """Referencing the BSW module description, which this ModuleConfiguration is configuring. This is optional because the ModuleConfiguration is also used to configure the ECU infrastructure (memory map) or Application SW-Cs."""
        return self.moduleDescriptionRef

    def setModuleDescriptionRef(self, value: Optional[RefType]) -> "ModuleConfiguration":
        """Referencing the BSW module description, which this ModuleConfiguration is configuring. This is optional because the ModuleConfiguration is also used to configure the ECU infrastructure (memory map) or Application SW-Cs. A None value is a no-op and does not overwrite an existing reference."""
        if value is not None:
            self.moduleDescriptionRef = value
        return self
