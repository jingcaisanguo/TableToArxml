from __future__ import annotations

from typing import List, Optional
from armodel.models.M2.AUTOSARTemplates.CommonStructure.StandardizationTemplate.AbstractBlueprintStructure import AtpBlueprintable
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import (
    AREnum,
    Integer,
    Identifier,
    Limit,
    MonotonyEnum,
    Numerical,
    RefType,
)
from armodel.models.M2.MSR.Documentation.TextModel.MultilanguageData import MultiLanguageOverviewParagraph


class InternalConstrs(ARObject):
    """
    This meta-class represents the ability to express internal constraints.
    """

    # InternalConstrs method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 5.85, p.407
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getLowerLimit           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setLowerLimit           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMaxDiff              [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMaxDiff              [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMaxGradient          [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMaxGradient          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMonotony             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMonotony             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] addScaleConstr          [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getScaleConstrs         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getUpperLimit           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setUpperLimit           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # This specifies the lower limit of the constraint.
        self.lowerLimit: Optional[Limit] = None

        # Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis.
        self.maxDiff: Optional[Numerical] = None

        # This element specifies the maximum slope that may be used in maps and curves.
        self.maxGradient: Optional[Numerical] = None

        # This element specifies the monotony characteristics of the current internal or physical limits. The following table shows the monotony characteristics which are to be filled through the corresponding values. If the element has no contents or if it is omitted, "no Monotony" is the default content.
        self.monotony: Optional[MonotonyEnum] = None

        # This is one particular scale which contributes to the data constraints.
        self.scaleConstrs: List[ScaleConstr] = []

        # This specifies the upper limit defined by the constraint.
        self.upperLimit: Optional[Limit] = None

    def getLowerLimit(self) -> Optional[Limit]:
        """
        This specifies the lower limit of the constraint.
        """
        return self.lowerLimit

    def setLowerLimit(self, value: Optional[Limit]) -> InternalConstrs:
        """
        This specifies the lower limit of the constraint. A None value is a no-op and does not overwrite an existing lowerLimit.
        """
        if value is not None:
            self.lowerLimit = value
        return self

    def getMaxDiff(self) -> Optional[Numerical]:
        """
        Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis.
        """
        return self.maxDiff

    def setMaxDiff(self, value: Optional[Numerical]) -> InternalConstrs:
        """
        Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis. A None value is a no-op and does not overwrite an existing maxDiff.
        """
        if value is not None:
            self.maxDiff = value
        return self

    def getMaxGradient(self) -> Optional[Numerical]:
        """
        This element specifies the maximum slope that may be used in maps and curves.
        """
        return self.maxGradient

    def setMaxGradient(self, value: Optional[Numerical]) -> InternalConstrs:
        """
        This element specifies the maximum slope that may be used in maps and curves. A None value is a no-op and does not overwrite an existing maxGradient.
        """
        if value is not None:
            self.maxGradient = value
        return self

    def getMonotony(self) -> Optional[MonotonyEnum]:
        """
        This element specifies the monotony characteristics of the current internal or physical limits. The following table shows the monotony characteristics which are to be filled through the corresponding values. If the element has no contents or if it is omitted, "no Monotony" is the default content.
        """
        return self.monotony

    def setMonotony(self, value: Optional[MonotonyEnum]) -> InternalConstrs:
        """
        This element specifies the monotony characteristics of the current internal or physical limits. The following table shows the monotony characteristics which are to be filled through the corresponding values. If the element has no contents or if it is omitted, "no Monotony" is the default content. A None value is a no-op and does not overwrite an existing monotony.
        """
        if value is not None:
            self.monotony = value
        return self

    def addScaleConstr(self, value: Optional[ScaleConstr]) -> InternalConstrs:
        """
        This is one particular scale which contributes to the data constraints. A None value is a no-op and does not add a scaleConstr.
        """
        if value is not None:
            self.scaleConstrs.append(value)
        return self

    def getScaleConstrs(self) -> List[ScaleConstr]:
        """
        This is one particular scale which contributes to the data constraints.
        """
        return self.scaleConstrs

    def getUpperLimit(self) -> Optional[Limit]:
        """
        This specifies the upper limit defined by the constraint.
        """
        return self.upperLimit

    def setUpperLimit(self, value: Optional[Limit]) -> InternalConstrs:
        """
        This specifies the upper limit defined by the constraint. A None value is a no-op and does not overwrite an existing upperLimit.
        """
        if value is not None:
            self.upperLimit = value
        return self


class ScaleConstrValidityEnum(AREnum):
    """
    This enumerator specifies the possible values of a scale.
    """

    # ScaleConstrValidityEnum method parity checklist:
    # Spec: R4.3.1/AUTOSAR_TPS_SoftwareComponentTemplate.pdf, Table 5.95, p.417
    # Spec verified: R4.3.1 (2026-09-27, user 9b confirmation)
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # (no methods) — enum value form serialized on ScaleConstr.validity (VALIDITY attribute)
    # [x] __init__  [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R4.3.1

    # Currently invalid area The value usually is presented by the ECU but can currently not be performed due to e.g. initialization or temporary problems. Please note, that this behavior appears during runtime and cannot be handled while data is edited. Tags: atp.EnumerationValue=0
    NOT_AVAILABLE = "notAvailable"

    # Indicates an area which is marked in a specification (e.g. as reserved) Shall usually not be set by the ECU but is used by a tester to verify correct ECU. Tags: atp.EnumerationValue=1
    NOT_DEFINED = "notDefined"

    # The ECU cannot process the requested data. Tags: atp.EnumerationValue=2
    NOT_VALID = "notValid"

    # Current value is within a valid range and can be presented to user as is. Tags: atp.EnumerationValue=3
    VALID = "valid"

    def __init__(self):
        super().__init__(
            [
                ScaleConstrValidityEnum.NOT_AVAILABLE,
                ScaleConstrValidityEnum.NOT_DEFINED,
                ScaleConstrValidityEnum.NOT_VALID,
                ScaleConstrValidityEnum.VALID,
            ]
        )


class ScaleConstr(ARObject):
    """
    This meta-class represents the ability to specify constraints as a list of intervals (called scales).
    """

    # ScaleConstr method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table E.39/E.40, p.1003
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__            [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getDesc             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setDesc             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getLowerLimit       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setLowerLimit       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getShortLabel       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setShortLabel       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getUpperLimit       [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setUpperLimit       [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getValidity         [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setValidity         [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # <desc> represents a general but brief description of the object in question.
        self.desc: Optional[MultiLanguageOverviewParagraph] = None

        # This specifies the lower limit of the scale.
        self.lowerLimit: Optional[Limit] = None

        # This element specifies a short name for the scaleConstr. This can for example be used to create more specific messages of a constraint checker. The constraints cannot be associated in the meta-model, therefore shortLabel is somehow a substitute for shortName.
        self.shortLabel: Optional[Identifier] = None

        # This specifies the upper limit of a the scale.
        self.upperLimit: Optional[Limit] = None

        # Specifies if the values defined by the scales are considered to be valid. If the attribute is missing then the default value is "VALID".
        self.validity: Optional[ScaleConstrValidityEnum] = None

    def getDesc(self) -> Optional[MultiLanguageOverviewParagraph]:
        """
        <desc> represents a general but brief description of the object in question.
        """
        return self.desc

    def setDesc(self, value: Optional[MultiLanguageOverviewParagraph]) -> ScaleConstr:
        """
        <desc> represents a general but brief description of the object in question. A None value is a no-op and does not overwrite an existing desc.
        """
        if value is not None:
            self.desc = value
        return self

    def getLowerLimit(self) -> Optional[Limit]:
        """
        This specifies the lower limit of the scale.
        """
        return self.lowerLimit

    def setLowerLimit(self, value: Optional[Limit]) -> ScaleConstr:
        """
        This specifies the lower limit of the scale. A None value is a no-op and does not overwrite an existing lowerLimit.
        """
        if value is not None:
            self.lowerLimit = value
        return self

    def getShortLabel(self) -> Optional[Identifier]:
        """
        This element specifies a short name for the scaleConstr. This can for example be used to create more specific messages of a constraint checker. The constraints cannot be associated in the meta-model, therefore shortLabel is somehow a substitute for shortName.
        """
        return self.shortLabel

    def setShortLabel(self, value: Optional[Identifier]) -> ScaleConstr:
        """
        This element specifies a short name for the scaleConstr. This can for example be used to create more specific messages of a constraint checker. The constraints cannot be associated in the meta-model, therefore shortLabel is somehow a substitute for shortName. A None value is a no-op and does not overwrite an existing shortLabel.
        """
        if value is not None:
            self.shortLabel = value
        return self

    def getUpperLimit(self) -> Optional[Limit]:
        """
        This specifies the upper limit of a the scale.
        """
        return self.upperLimit

    def setUpperLimit(self, value: Optional[Limit]) -> ScaleConstr:
        """
        This specifies the upper limit of a the scale. A None value is a no-op and does not overwrite an existing upperLimit.
        """
        if value is not None:
            self.upperLimit = value
        return self

    def getValidity(self) -> Optional[ScaleConstrValidityEnum]:
        """
        Specifies if the values defined by the scales are considered to be valid. If the attribute is missing then the default value is "VALID".
        """
        return self.validity

    def setValidity(self, value: Optional[ScaleConstrValidityEnum]) -> ScaleConstr:
        """
        Specifies if the values defined by the scales are considered to be valid. If the attribute is missing then the default value is "VALID". A None value is a no-op and does not overwrite an existing validity.
        """
        if value is not None:
            self.validity = value
        return self


class PhysConstrs(ARObject):
    """
    This meta-class represents the ability to express physical constraints. Therefore it has (in opposite to InternalConstrs) a reference to a Unit.
    """

    # PhysConstrs method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 5.84, p.406
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer   ([—] = no XML element)
    # [x] __init__                  [x] impl  [x] docstring  [x] test  [—] reader  [—] writer
    # [x] getLowerLimit             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setLowerLimit             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMaxDiff                [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMaxDiff                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMaxGradient            [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMaxGradient            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getMonotony               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setMonotony               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] addScaleConstr            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getScaleConstrs           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] getUnitRef                [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setUnitRef                [x] impl  [x] docstring  [x] test  [x] reader  [—] writer
    # [x] getUpperLimit             [x] impl  [x] docstring  [x] test  [—] reader  [x] writer
    # [x] setUpperLimit             [x] impl  [x] docstring  [x] test  [x] reader  [—] writer

    def __init__(self):
        super().__init__()

        # This specifies the lower limit of the constraint.
        self.lowerLimit: Optional[Limit] = None

        # Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis.
        self.maxDiff: Optional[Numerical] = None

        # This element specifies the maximum slope that may be used in curves and maps.
        self.maxGradient: Optional[Numerical] = None

        # This specifies the monotony constraints on the data object. Note that this applies only to curves and maps.
        self.monotony: Optional[MonotonyEnum] = None

        # This is one particular scale which contributes to the data constraints.
        self.scaleConstrs: List[ScaleConstr] = []

        # This is the unit to which the physical constraints relate to. In particular, it is the physical unit of the specified limits.
        self.unitRef: Optional[RefType] = None

        # This specifies the upper limit of the constraint.
        self.upperLimit: Optional[Limit] = None

    def getLowerLimit(self) -> Optional[Limit]:
        """
        This specifies the lower limit of the constraint.
        """
        return self.lowerLimit

    def setLowerLimit(self, value: Optional[Limit]) -> PhysConstrs:
        """
        This specifies the lower limit of the constraint. A None value is a no-op and does not overwrite an existing lowerLimit.
        """
        if value is not None:
            self.lowerLimit = value
        return self

    def getMaxDiff(self) -> Optional[Numerical]:
        """
        Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis.
        """
        return self.maxDiff

    def setMaxDiff(self, value: Optional[Numerical]) -> PhysConstrs:
        """
        Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis. A None value is a no-op and does not overwrite an existing maxDiff.
        """
        if value is not None:
            self.maxDiff = value
        return self

    def getMaxGradient(self) -> Optional[Numerical]:
        """
        This element specifies the maximum slope that may be used in curves and maps.
        """
        return self.maxGradient

    def setMaxGradient(self, value: Optional[Numerical]) -> PhysConstrs:
        """
        This element specifies the maximum slope that may be used in curves and maps. A None value is a no-op and does not overwrite an existing maxGradient.
        """
        if value is not None:
            self.maxGradient = value
        return self

    def getMonotony(self) -> Optional[MonotonyEnum]:
        """
        This specifies the monotony constraints on the data object. Note that this applies only to curves and maps.
        """
        return self.monotony

    def setMonotony(self, value: Optional[MonotonyEnum]) -> PhysConstrs:
        """
        This specifies the monotony constraints on the data object. Note that this applies only to curves and maps. A None value is a no-op and does not overwrite an existing monotony.
        """
        if value is not None:
            self.monotony = value
        return self

    def addScaleConstr(self, value: Optional[ScaleConstr]) -> PhysConstrs:
        """
        This is one particular scale which contributes to the data constraints. A None value is a no-op and does not add a scaleConstr.
        """
        if value is not None:
            self.scaleConstrs.append(value)
        return self

    def getScaleConstrs(self) -> List[ScaleConstr]:
        """
        This is one particular scale which contributes to the data constraints.
        """
        return self.scaleConstrs

    def getUnitRef(self) -> Optional[RefType]:
        """
        This is the unit to which the physical constraints relate to. In particular, it is the physical unit of the specified limits.
        """
        return self.unitRef

    def setUnitRef(self, value: Optional[RefType]) -> PhysConstrs:
        """
        This is the unit to which the physical constraints relate to. In particular, it is the physical unit of the specified limits. A None value is a no-op and does not overwrite an existing unitRef.
        """
        if value is not None:
            self.unitRef = value
        return self

    def getUpperLimit(self) -> Optional[Limit]:
        """
        This specifies the upper limit of the constraint.
        """
        return self.upperLimit

    def setUpperLimit(self, value: Optional[Limit]) -> PhysConstrs:
        """
        This specifies the upper limit of the constraint. A None value is a no-op and does not overwrite an existing upperLimit.
        """
        if value is not None:
            self.upperLimit = value
        return self


class DataConstrRule(ARObject):
    """This meta-class represents the ability to express one specific data constraint rule."""

    # Spec verified: R23-11

    # DataConstrRule method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 5.83, p.406
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] getConstrLevel               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setConstrLevel               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getInternalConstrs           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setInternalConstrs           [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getPhysConstrs               [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11
    # [x] setPhysConstrs               [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11

    def __init__(self):
        super().__init__()

        # This attribute describes the category of a constraint. One of its functions is in the area of constraint violation, where it can be used from a certain level, to produce error messages. The lower the level, the more stringent the check. Used to distinguish hard or soft limits. Tags: xml.sequenceOffset=20
        self.constrLevel: Optional[Integer] = None

        # Describes the limitations applicable on the internal domain (as opposed to the physical domain). Tags: xml.sequenceOffset=40
        self.internalConstrs: Optional[InternalConstrs] = None

        # Describes the limitations applicable on the physical domain (as opposed to the internal domain). Tags: xml.sequenceOffset=30
        self.physConstrs: Optional[PhysConstrs] = None

    def getConstrLevel(self) -> Optional[Integer]:
        """This attribute describes the category of a constraint. One of its functions is in the area of constraint violation, where it can be used from a certain level, to produce error messages. The lower the level, the more stringent the check. Used to distinguish hard or soft limits. Tags: xml.sequenceOffset=20"""
        return self.constrLevel

    def setConstrLevel(self, value: Optional[Integer]) -> DataConstrRule:
        """This attribute describes the category of a constraint. One of its functions is in the area of constraint violation, where it can be used from a certain level, to produce error messages. The lower the level, the more stringent the check. Used to distinguish hard or soft limits. Tags: xml.sequenceOffset=20. None leaves the current value unchanged."""
        if value is not None:
            self.constrLevel = value
        return self

    def getInternalConstrs(self) -> Optional[InternalConstrs]:
        """Describes the limitations applicable on the internal domain (as opposed to the physical domain). Tags: xml.sequenceOffset=40"""
        return self.internalConstrs

    def setInternalConstrs(self, value: Optional[InternalConstrs]) -> DataConstrRule:
        """Describes the limitations applicable on the internal domain (as opposed to the physical domain). Tags: xml.sequenceOffset=40. None leaves the current value unchanged."""
        if value is not None:
            self.internalConstrs = value
        return self

    def getPhysConstrs(self) -> Optional[PhysConstrs]:
        """Describes the limitations applicable on the physical domain (as opposed to the internal domain). Tags: xml.sequenceOffset=30"""
        return self.physConstrs

    def setPhysConstrs(self, value: Optional[PhysConstrs]) -> DataConstrRule:
        """Describes the limitations applicable on the physical domain (as opposed to the internal domain). Tags: xml.sequenceOffset=30. None leaves the current value unchanged."""
        if value is not None:
            self.physConstrs = value
        return self


class DataConstr(AtpBlueprintable):
    """This meta-class represents the ability to specify constraints on data. Tags: atp.recommendedPackage=DataConstrs"""

    # Spec verified: R23-11

    # DataConstr method parity checklist:
    # Spec: AUTOSAR_CP_TPS_SoftwareComponentTemplate.pdf, Table 5.82, p.405
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__                     [x] impl  [x] docstring  [x] test  [—] reader  [—] writer  R23-11
    # [x] addDataConstrRule            [x] impl  [x] docstring  [x] test  [x] reader  [—] writer  R23-11
    # [x] getDataConstrRules           [x] impl  [x] docstring  [x] test  [—] reader  [x] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # This is one particular rule within the data constraints. Tags: xml.roleElement=true xml.roleWrapperElement=true xml.sequenceOffset=30 xml.typeElement=false xml.typeWrapperElement=false
        self.data_constr_rule: List[DataConstrRule] = []

    def addDataConstrRule(self, rule: Optional[DataConstrRule]) -> DataConstr:
        """This is one particular rule within the data constraints. Tags: xml.roleElement=true xml.roleWrapperElement=true xml.sequenceOffset=30 xml.typeElement=false xml.typeWrapperElement=false. None leaves the current list unchanged."""
        if rule is not None:
            self.data_constr_rule.append(rule)
        return self

    def getDataConstrRules(self) -> List[DataConstrRule]:
        """This is one particular rule within the data constraints. Tags: xml.roleElement=true xml.roleWrapperElement=true xml.sequenceOffset=30 xml.typeElement=false xml.typeWrapperElement=false."""
        return self.data_constr_rule
