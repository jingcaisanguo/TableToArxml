from typing import List

from armodel.models.M2.AUTOSARTemplates.AdaptivePlatform.ApplicationDesign.PortInterface import Field
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject
from armodel.models.M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.PrimitiveTypes import RefType
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.Datatype.Datatypes import ApplicationDataType
from armodel.models.M2.AUTOSARTemplates.SWComponentTemplate.PortInterface import ClientServerOperation, PortInterface


class ApplicationDeferredDataType(ApplicationDataType):
    """A placeholder data type in which the precise application data type is deferred to a later stage."""

    # ApplicationDeferredDataType method parity checklist:
    # Spec: R23-11/AUTOSAR_FO_TPS_AbstractPlatformSpecification.pdf, Table 3.17, p.37 (R23-11)
    # Spec verified: R23-11
    # Columns: impl / docstring / test / reader / writer / release   ([—] = no XML element)
    # [x] __init__     [x] impl  [x] docstring  [x] test  [x] reader  [x] writer  R23-11

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)


class ApplicationInterface(PortInterface):
    """
    This represents the ability to define a PortInterface that consists of a
    composition of commands (method calls), indications (events) and attributes
    (fields) Tags: atp.Status=draft atp.recommendedPackage=Interfaces

    Sources:
      - AUTOSAR_FO_TPS_AbstractPlatformSpecification.pdf (Page 28, Foundation
      R23-11)
    """

    # ApplicationInterface method parity checklist:
    # [ ] __init__                     [x] impl  [ ] docstring  [x] test
    # [ ] getAttributes                [x] impl  [ ] docstring  [ ] test
    # [ ] setAttributes                [x] impl  [ ] docstring  [ ] test
    # [x] addAttribute                 [x] impl  [x] docstring  [x] test
    # [ ] getCommands                  [x] impl  [ ] docstring  [ ] test
    # [ ] setCommands                  [x] impl  [ ] docstring  [ ] test
    # [x] addCommand                   [x] impl  [x] docstring  [x] test
    # [ ] getIndications               [x] impl  [ ] docstring  [ ] test
    # [ ] setIndications               [x] impl  [ ] docstring  [ ] test
    # [x] addIndication                [x] impl  [x] docstring  [x] test

    def __init__(self, parent: ARObject, short_name: str):
        super().__init__(parent, short_name)

        # This represents the set of attributes defined in the context Abstract
        # Platform ApplicationInterface.
        # atpVariation.
        self.attributes: List[Field] = []
        # This represents the collection of commands or function optional data
        # arguments) defined in the context ApplicationInterface.
        # atpVariation.
        self.commands: List[ClientServerOperation] = []
        # This represents the collection of indication or events (with argument)
        # defined in the context of an atpVariation.
        self.indications: List[RefType] = []

    def getAttributes(self) -> List[Field]:
        return self.attributes

    def setAttributes(self, value: List[Field]) -> "ApplicationInterface":
        self.attributes = value
        return self

    def addAttribute(self, value: Field) -> "ApplicationInterface":
        """Adds a value to the attributes list."""
        self.attributes.append(value)
        return self

    def getCommands(self) -> List[ClientServerOperation]:
        return self.commands

    def setCommands(self, value: List[ClientServerOperation]) -> "ApplicationInterface":
        self.commands = value
        return self

    def addCommand(self, value: ClientServerOperation) -> "ApplicationInterface":
        """Adds a value to the commands list."""
        self.commands.append(value)
        return self

    def getIndications(self) -> List[RefType]:
        return self.indications

    def setIndications(self, value: List[RefType]) -> "ApplicationInterface":
        self.indications = value
        return self

    def addIndication(self, value: RefType) -> "ApplicationInterface":
        """Adds a value to the indications list."""
        self.indications.append(value)
        return self
